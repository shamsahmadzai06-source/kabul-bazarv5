const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/Home-BZptX8n4.js","assets/LazyImage-BQXxCy1D.js","assets/heart-hUaeygrf.js","assets/eye-DuSfuGGQ.js","assets/phone-B81vov8F.js","assets/chevron-left-UUJ4_Fre.js","assets/chevron-right-B6jw7ymq.js","assets/PostDetail-BR0NYSqd.js","assets/circle-check-big-Db6plBme.js","assets/CreatePost-B7lxCjPi.js","assets/lock-ADJJu1eu.js","assets/store-Cb2u_32v.js","assets/Profile-BzWEA-7b.js","assets/package-C3q7gWcu.js","assets/ProfileEdit-DFF5X6tV.js","assets/Messages-BvUg67lJ.js","assets/message-square-CUTbalGc.js","assets/Chat-TVdsD_dG.js","assets/Notifications-B91uSy1P.js","assets/circle-x-DD2Je3Nn.js","assets/Admin-bwQPas81.js","assets/Login-BpMacnxv.js","assets/mail-CBI5Z0hM.js","assets/Signup-Cp5F891r.js"])))=>i.map(i=>d[i]);
(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const l of document.querySelectorAll('link[rel="modulepreload"]'))s(l);new MutationObserver(l=>{for(const c of l)if(c.type==="childList")for(const f of c.addedNodes)f.tagName==="LINK"&&f.rel==="modulepreload"&&s(f)}).observe(document,{childList:!0,subtree:!0});function i(l){const c={};return l.integrity&&(c.integrity=l.integrity),l.referrerPolicy&&(c.referrerPolicy=l.referrerPolicy),l.crossOrigin==="use-credentials"?c.credentials="include":l.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function s(l){if(l.ep)return;l.ep=!0;const c=i(l);fetch(l.href,c)}})();function z_(a){return a&&a.__esModule&&Object.prototype.hasOwnProperty.call(a,"default")?a.default:a}var Ud={exports:{}},Ko={};var vv;function Zy(){if(vv)return Ko;vv=1;var a=Symbol.for("react.transitional.element"),e=Symbol.for("react.fragment");function i(s,l,c){var f=null;if(c!==void 0&&(f=""+c),l.key!==void 0&&(f=""+l.key),"key"in l){c={};for(var p in l)p!=="key"&&(c[p]=l[p])}else c=l;return l=c.ref,{$$typeof:a,type:s,key:f,ref:l!==void 0?l:null,props:c}}return Ko.Fragment=e,Ko.jsx=i,Ko.jsxs=i,Ko}var _v;function Ky(){return _v||(_v=1,Ud.exports=Zy()),Ud.exports}var Re=Ky(),Nd={exports:{}},Qo={},Ld={exports:{}},Od={};var xv;function Qy(){return xv||(xv=1,(function(a){function e(L,H){var $=L.length;L.push(H);e:for(;0<$;){var _e=$-1>>>1,be=L[_e];if(0<l(be,H))L[_e]=H,L[$]=be,$=_e;else break e}}function i(L){return L.length===0?null:L[0]}function s(L){if(L.length===0)return null;var H=L[0],$=L.pop();if($!==H){L[0]=$;e:for(var _e=0,be=L.length,N=be>>>1;_e<N;){var Y=2*(_e+1)-1,de=L[Y],Te=Y+1,Ce=L[Te];if(0>l(de,$))Te<be&&0>l(Ce,de)?(L[_e]=Ce,L[Te]=$,_e=Te):(L[_e]=de,L[Y]=$,_e=Y);else if(Te<be&&0>l(Ce,$))L[_e]=Ce,L[Te]=$,_e=Te;else break e}}return H}function l(L,H){var $=L.sortIndex-H.sortIndex;return $!==0?$:L.id-H.id}if(a.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var c=performance;a.unstable_now=function(){return c.now()}}else{var f=Date,p=f.now();a.unstable_now=function(){return f.now()-p}}var m=[],h=[],_=1,g=null,v=3,M=!1,b=!1,C=!1,y=!1,x=typeof setTimeout=="function"?setTimeout:null,O=typeof clearTimeout=="function"?clearTimeout:null,I=typeof setImmediate<"u"?setImmediate:null;function w(L){for(var H=i(h);H!==null;){if(H.callback===null)s(h);else if(H.startTime<=L)s(h),H.sortIndex=H.expirationTime,e(m,H);else break;H=i(h)}}function B(L){if(C=!1,w(L),!b)if(i(m)!==null)b=!0,U||(U=!0,Q());else{var H=i(h);H!==null&&j(B,H.startTime-L)}}var U=!1,F=-1,T=5,P=-1;function q(){return y?!0:!(a.unstable_now()-P<T)}function V(){if(y=!1,U){var L=a.unstable_now();P=L;var H=!0;try{e:{b=!1,C&&(C=!1,O(F),F=-1),M=!0;var $=v;try{t:{for(w(L),g=i(m);g!==null&&!(g.expirationTime>L&&q());){var _e=g.callback;if(typeof _e=="function"){g.callback=null,v=g.priorityLevel;var be=_e(g.expirationTime<=L);if(L=a.unstable_now(),typeof be=="function"){g.callback=be,w(L),H=!0;break t}g===i(m)&&s(m),w(L)}else s(m);g=i(m)}if(g!==null)H=!0;else{var N=i(h);N!==null&&j(B,N.startTime-L),H=!1}}break e}finally{g=null,v=$,M=!1}H=void 0}}finally{H?Q():U=!1}}}var Q;if(typeof I=="function")Q=function(){I(V)};else if(typeof MessageChannel<"u"){var fe=new MessageChannel,me=fe.port2;fe.port1.onmessage=V,Q=function(){me.postMessage(null)}}else Q=function(){x(V,0)};function j(L,H){F=x(function(){L(a.unstable_now())},H)}a.unstable_IdlePriority=5,a.unstable_ImmediatePriority=1,a.unstable_LowPriority=4,a.unstable_NormalPriority=3,a.unstable_Profiling=null,a.unstable_UserBlockingPriority=2,a.unstable_cancelCallback=function(L){L.callback=null},a.unstable_forceFrameRate=function(L){0>L||125<L?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):T=0<L?Math.floor(1e3/L):5},a.unstable_getCurrentPriorityLevel=function(){return v},a.unstable_next=function(L){switch(v){case 1:case 2:case 3:var H=3;break;default:H=v}var $=v;v=H;try{return L()}finally{v=$}},a.unstable_requestPaint=function(){y=!0},a.unstable_runWithPriority=function(L,H){switch(L){case 1:case 2:case 3:case 4:case 5:break;default:L=3}var $=v;v=L;try{return H()}finally{v=$}},a.unstable_scheduleCallback=function(L,H,$){var _e=a.unstable_now();switch(typeof $=="object"&&$!==null?($=$.delay,$=typeof $=="number"&&0<$?_e+$:_e):$=_e,L){case 1:var be=-1;break;case 2:be=250;break;case 5:be=1073741823;break;case 4:be=1e4;break;default:be=5e3}return be=$+be,L={id:_++,callback:H,priorityLevel:L,startTime:$,expirationTime:be,sortIndex:-1},$>_e?(L.sortIndex=$,e(h,L),i(m)===null&&L===i(h)&&(C?(O(F),F=-1):C=!0,j(B,$-_e))):(L.sortIndex=be,e(m,L),b||M||(b=!0,U||(U=!0,Q()))),L},a.unstable_shouldYield=q,a.unstable_wrapCallback=function(L){var H=v;return function(){var $=v;v=H;try{return L.apply(this,arguments)}finally{v=$}}}})(Od)),Od}var Sv;function jy(){return Sv||(Sv=1,Ld.exports=Qy()),Ld.exports}var Pd={exports:{}},st={};var yv;function Jy(){if(yv)return st;yv=1;var a=Symbol.for("react.transitional.element"),e=Symbol.for("react.portal"),i=Symbol.for("react.fragment"),s=Symbol.for("react.strict_mode"),l=Symbol.for("react.profiler"),c=Symbol.for("react.consumer"),f=Symbol.for("react.context"),p=Symbol.for("react.forward_ref"),m=Symbol.for("react.suspense"),h=Symbol.for("react.memo"),_=Symbol.for("react.lazy"),g=Symbol.for("react.activity"),v=Symbol.iterator;function M(N){return N===null||typeof N!="object"?null:(N=v&&N[v]||N["@@iterator"],typeof N=="function"?N:null)}var b={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},C=Object.assign,y={};function x(N,Y,de){this.props=N,this.context=Y,this.refs=y,this.updater=de||b}x.prototype.isReactComponent={},x.prototype.setState=function(N,Y){if(typeof N!="object"&&typeof N!="function"&&N!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,N,Y,"setState")},x.prototype.forceUpdate=function(N){this.updater.enqueueForceUpdate(this,N,"forceUpdate")};function O(){}O.prototype=x.prototype;function I(N,Y,de){this.props=N,this.context=Y,this.refs=y,this.updater=de||b}var w=I.prototype=new O;w.constructor=I,C(w,x.prototype),w.isPureReactComponent=!0;var B=Array.isArray;function U(){}var F={H:null,A:null,T:null,S:null},T=Object.prototype.hasOwnProperty;function P(N,Y,de){var Te=de.ref;return{$$typeof:a,type:N,key:Y,ref:Te!==void 0?Te:null,props:de}}function q(N,Y){return P(N.type,Y,N.props)}function V(N){return typeof N=="object"&&N!==null&&N.$$typeof===a}function Q(N){var Y={"=":"=0",":":"=2"};return"$"+N.replace(/[=:]/g,function(de){return Y[de]})}var fe=/\/+/g;function me(N,Y){return typeof N=="object"&&N!==null&&N.key!=null?Q(""+N.key):Y.toString(36)}function j(N){switch(N.status){case"fulfilled":return N.value;case"rejected":throw N.reason;default:switch(typeof N.status=="string"?N.then(U,U):(N.status="pending",N.then(function(Y){N.status==="pending"&&(N.status="fulfilled",N.value=Y)},function(Y){N.status==="pending"&&(N.status="rejected",N.reason=Y)})),N.status){case"fulfilled":return N.value;case"rejected":throw N.reason}}throw N}function L(N,Y,de,Te,Ce){var ee=typeof N;(ee==="undefined"||ee==="boolean")&&(N=null);var Me=!1;if(N===null)Me=!0;else switch(ee){case"bigint":case"string":case"number":Me=!0;break;case"object":switch(N.$$typeof){case a:case e:Me=!0;break;case _:return Me=N._init,L(Me(N._payload),Y,de,Te,Ce)}}if(Me)return Ce=Ce(N),Me=Te===""?"."+me(N,0):Te,B(Ce)?(de="",Me!=null&&(de=Me.replace(fe,"$&/")+"/"),L(Ce,Y,de,"",function(nt){return nt})):Ce!=null&&(V(Ce)&&(Ce=q(Ce,de+(Ce.key==null||N&&N.key===Ce.key?"":(""+Ce.key).replace(fe,"$&/")+"/")+Me)),Y.push(Ce)),1;Me=0;var ve=Te===""?".":Te+":";if(B(N))for(var He=0;He<N.length;He++)Te=N[He],ee=ve+me(Te,He),Me+=L(Te,Y,de,ee,Ce);else if(He=M(N),typeof He=="function")for(N=He.call(N),He=0;!(Te=N.next()).done;)Te=Te.value,ee=ve+me(Te,He++),Me+=L(Te,Y,de,ee,Ce);else if(ee==="object"){if(typeof N.then=="function")return L(j(N),Y,de,Te,Ce);throw Y=String(N),Error("Objects are not valid as a React child (found: "+(Y==="[object Object]"?"object with keys {"+Object.keys(N).join(", ")+"}":Y)+"). If you meant to render a collection of children, use an array instead.")}return Me}function H(N,Y,de){if(N==null)return N;var Te=[],Ce=0;return L(N,Te,"","",function(ee){return Y.call(de,ee,Ce++)}),Te}function $(N){if(N._status===-1){var Y=N._result;Y=Y(),Y.then(function(de){(N._status===0||N._status===-1)&&(N._status=1,N._result=de)},function(de){(N._status===0||N._status===-1)&&(N._status=2,N._result=de)}),N._status===-1&&(N._status=0,N._result=Y)}if(N._status===1)return N._result.default;throw N._result}var _e=typeof reportError=="function"?reportError:function(N){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var Y=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof N=="object"&&N!==null&&typeof N.message=="string"?String(N.message):String(N),error:N});if(!window.dispatchEvent(Y))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",N);return}console.error(N)},be={map:H,forEach:function(N,Y,de){H(N,function(){Y.apply(this,arguments)},de)},count:function(N){var Y=0;return H(N,function(){Y++}),Y},toArray:function(N){return H(N,function(Y){return Y})||[]},only:function(N){if(!V(N))throw Error("React.Children.only expected to receive a single React element child.");return N}};return st.Activity=g,st.Children=be,st.Component=x,st.Fragment=i,st.Profiler=l,st.PureComponent=I,st.StrictMode=s,st.Suspense=m,st.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=F,st.__COMPILER_RUNTIME={__proto__:null,c:function(N){return F.H.useMemoCache(N)}},st.cache=function(N){return function(){return N.apply(null,arguments)}},st.cacheSignal=function(){return null},st.cloneElement=function(N,Y,de){if(N==null)throw Error("The argument must be a React element, but you passed "+N+".");var Te=C({},N.props),Ce=N.key;if(Y!=null)for(ee in Y.key!==void 0&&(Ce=""+Y.key),Y)!T.call(Y,ee)||ee==="key"||ee==="__self"||ee==="__source"||ee==="ref"&&Y.ref===void 0||(Te[ee]=Y[ee]);var ee=arguments.length-2;if(ee===1)Te.children=de;else if(1<ee){for(var Me=Array(ee),ve=0;ve<ee;ve++)Me[ve]=arguments[ve+2];Te.children=Me}return P(N.type,Ce,Te)},st.createContext=function(N){return N={$$typeof:f,_currentValue:N,_currentValue2:N,_threadCount:0,Provider:null,Consumer:null},N.Provider=N,N.Consumer={$$typeof:c,_context:N},N},st.createElement=function(N,Y,de){var Te,Ce={},ee=null;if(Y!=null)for(Te in Y.key!==void 0&&(ee=""+Y.key),Y)T.call(Y,Te)&&Te!=="key"&&Te!=="__self"&&Te!=="__source"&&(Ce[Te]=Y[Te]);var Me=arguments.length-2;if(Me===1)Ce.children=de;else if(1<Me){for(var ve=Array(Me),He=0;He<Me;He++)ve[He]=arguments[He+2];Ce.children=ve}if(N&&N.defaultProps)for(Te in Me=N.defaultProps,Me)Ce[Te]===void 0&&(Ce[Te]=Me[Te]);return P(N,ee,Ce)},st.createRef=function(){return{current:null}},st.forwardRef=function(N){return{$$typeof:p,render:N}},st.isValidElement=V,st.lazy=function(N){return{$$typeof:_,_payload:{_status:-1,_result:N},_init:$}},st.memo=function(N,Y){return{$$typeof:h,type:N,compare:Y===void 0?null:Y}},st.startTransition=function(N){var Y=F.T,de={};F.T=de;try{var Te=N(),Ce=F.S;Ce!==null&&Ce(de,Te),typeof Te=="object"&&Te!==null&&typeof Te.then=="function"&&Te.then(U,_e)}catch(ee){_e(ee)}finally{Y!==null&&de.types!==null&&(Y.types=de.types),F.T=Y}},st.unstable_useCacheRefresh=function(){return F.H.useCacheRefresh()},st.use=function(N){return F.H.use(N)},st.useActionState=function(N,Y,de){return F.H.useActionState(N,Y,de)},st.useCallback=function(N,Y){return F.H.useCallback(N,Y)},st.useContext=function(N){return F.H.useContext(N)},st.useDebugValue=function(){},st.useDeferredValue=function(N,Y){return F.H.useDeferredValue(N,Y)},st.useEffect=function(N,Y){return F.H.useEffect(N,Y)},st.useEffectEvent=function(N){return F.H.useEffectEvent(N)},st.useId=function(){return F.H.useId()},st.useImperativeHandle=function(N,Y,de){return F.H.useImperativeHandle(N,Y,de)},st.useInsertionEffect=function(N,Y){return F.H.useInsertionEffect(N,Y)},st.useLayoutEffect=function(N,Y){return F.H.useLayoutEffect(N,Y)},st.useMemo=function(N,Y){return F.H.useMemo(N,Y)},st.useOptimistic=function(N,Y){return F.H.useOptimistic(N,Y)},st.useReducer=function(N,Y,de){return F.H.useReducer(N,Y,de)},st.useRef=function(N){return F.H.useRef(N)},st.useState=function(N){return F.H.useState(N)},st.useSyncExternalStore=function(N,Y,de){return F.H.useSyncExternalStore(N,Y,de)},st.useTransition=function(){return F.H.useTransition()},st.version="19.2.7",st}var Mv;function hp(){return Mv||(Mv=1,Pd.exports=Jy()),Pd.exports}var Id={exports:{}},Bn={};var Ev;function $y(){if(Ev)return Bn;Ev=1;var a=hp();function e(m){var h="https://react.dev/errors/"+m;if(1<arguments.length){h+="?args[]="+encodeURIComponent(arguments[1]);for(var _=2;_<arguments.length;_++)h+="&args[]="+encodeURIComponent(arguments[_])}return"Minified React error #"+m+"; visit "+h+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function i(){}var s={d:{f:i,r:function(){throw Error(e(522))},D:i,C:i,L:i,m:i,X:i,S:i,M:i},p:0,findDOMNode:null},l=Symbol.for("react.portal");function c(m,h,_){var g=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:l,key:g==null?null:""+g,children:m,containerInfo:h,implementation:_}}var f=a.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function p(m,h){if(m==="font")return"";if(typeof h=="string")return h==="use-credentials"?h:""}return Bn.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=s,Bn.createPortal=function(m,h){var _=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!h||h.nodeType!==1&&h.nodeType!==9&&h.nodeType!==11)throw Error(e(299));return c(m,h,null,_)},Bn.flushSync=function(m){var h=f.T,_=s.p;try{if(f.T=null,s.p=2,m)return m()}finally{f.T=h,s.p=_,s.d.f()}},Bn.preconnect=function(m,h){typeof m=="string"&&(h?(h=h.crossOrigin,h=typeof h=="string"?h==="use-credentials"?h:"":void 0):h=null,s.d.C(m,h))},Bn.prefetchDNS=function(m){typeof m=="string"&&s.d.D(m)},Bn.preinit=function(m,h){if(typeof m=="string"&&h&&typeof h.as=="string"){var _=h.as,g=p(_,h.crossOrigin),v=typeof h.integrity=="string"?h.integrity:void 0,M=typeof h.fetchPriority=="string"?h.fetchPriority:void 0;_==="style"?s.d.S(m,typeof h.precedence=="string"?h.precedence:void 0,{crossOrigin:g,integrity:v,fetchPriority:M}):_==="script"&&s.d.X(m,{crossOrigin:g,integrity:v,fetchPriority:M,nonce:typeof h.nonce=="string"?h.nonce:void 0})}},Bn.preinitModule=function(m,h){if(typeof m=="string")if(typeof h=="object"&&h!==null){if(h.as==null||h.as==="script"){var _=p(h.as,h.crossOrigin);s.d.M(m,{crossOrigin:_,integrity:typeof h.integrity=="string"?h.integrity:void 0,nonce:typeof h.nonce=="string"?h.nonce:void 0})}}else h==null&&s.d.M(m)},Bn.preload=function(m,h){if(typeof m=="string"&&typeof h=="object"&&h!==null&&typeof h.as=="string"){var _=h.as,g=p(_,h.crossOrigin);s.d.L(m,_,{crossOrigin:g,integrity:typeof h.integrity=="string"?h.integrity:void 0,nonce:typeof h.nonce=="string"?h.nonce:void 0,type:typeof h.type=="string"?h.type:void 0,fetchPriority:typeof h.fetchPriority=="string"?h.fetchPriority:void 0,referrerPolicy:typeof h.referrerPolicy=="string"?h.referrerPolicy:void 0,imageSrcSet:typeof h.imageSrcSet=="string"?h.imageSrcSet:void 0,imageSizes:typeof h.imageSizes=="string"?h.imageSizes:void 0,media:typeof h.media=="string"?h.media:void 0})}},Bn.preloadModule=function(m,h){if(typeof m=="string")if(h){var _=p(h.as,h.crossOrigin);s.d.m(m,{as:typeof h.as=="string"&&h.as!=="script"?h.as:void 0,crossOrigin:_,integrity:typeof h.integrity=="string"?h.integrity:void 0})}else s.d.m(m)},Bn.requestFormReset=function(m){s.d.r(m)},Bn.unstable_batchedUpdates=function(m,h){return m(h)},Bn.useFormState=function(m,h,_){return f.H.useFormState(m,h,_)},Bn.useFormStatus=function(){return f.H.useHostTransitionStatus()},Bn.version="19.2.7",Bn}var bv;function H_(){if(bv)return Id.exports;bv=1;function a(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(a)}catch(e){console.error(e)}}return a(),Id.exports=$y(),Id.exports}var Tv;function eM(){if(Tv)return Qo;Tv=1;var a=jy(),e=hp(),i=H_();function s(t){var n="https://react.dev/errors/"+t;if(1<arguments.length){n+="?args[]="+encodeURIComponent(arguments[1]);for(var r=2;r<arguments.length;r++)n+="&args[]="+encodeURIComponent(arguments[r])}return"Minified React error #"+t+"; visit "+n+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function l(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)}function c(t){var n=t,r=t;if(t.alternate)for(;n.return;)n=n.return;else{t=n;do n=t,(n.flags&4098)!==0&&(r=n.return),t=n.return;while(t)}return n.tag===3?r:null}function f(t){if(t.tag===13){var n=t.memoizedState;if(n===null&&(t=t.alternate,t!==null&&(n=t.memoizedState)),n!==null)return n.dehydrated}return null}function p(t){if(t.tag===31){var n=t.memoizedState;if(n===null&&(t=t.alternate,t!==null&&(n=t.memoizedState)),n!==null)return n.dehydrated}return null}function m(t){if(c(t)!==t)throw Error(s(188))}function h(t){var n=t.alternate;if(!n){if(n=c(t),n===null)throw Error(s(188));return n!==t?null:t}for(var r=t,o=n;;){var u=r.return;if(u===null)break;var d=u.alternate;if(d===null){if(o=u.return,o!==null){r=o;continue}break}if(u.child===d.child){for(d=u.child;d;){if(d===r)return m(u),t;if(d===o)return m(u),n;d=d.sibling}throw Error(s(188))}if(r.return!==o.return)r=u,o=d;else{for(var S=!1,R=u.child;R;){if(R===r){S=!0,r=u,o=d;break}if(R===o){S=!0,o=u,r=d;break}R=R.sibling}if(!S){for(R=d.child;R;){if(R===r){S=!0,r=d,o=u;break}if(R===o){S=!0,o=d,r=u;break}R=R.sibling}if(!S)throw Error(s(189))}}if(r.alternate!==o)throw Error(s(190))}if(r.tag!==3)throw Error(s(188));return r.stateNode.current===r?t:n}function _(t){var n=t.tag;if(n===5||n===26||n===27||n===6)return t;for(t=t.child;t!==null;){if(n=_(t),n!==null)return n;t=t.sibling}return null}var g=Object.assign,v=Symbol.for("react.element"),M=Symbol.for("react.transitional.element"),b=Symbol.for("react.portal"),C=Symbol.for("react.fragment"),y=Symbol.for("react.strict_mode"),x=Symbol.for("react.profiler"),O=Symbol.for("react.consumer"),I=Symbol.for("react.context"),w=Symbol.for("react.forward_ref"),B=Symbol.for("react.suspense"),U=Symbol.for("react.suspense_list"),F=Symbol.for("react.memo"),T=Symbol.for("react.lazy"),P=Symbol.for("react.activity"),q=Symbol.for("react.memo_cache_sentinel"),V=Symbol.iterator;function Q(t){return t===null||typeof t!="object"?null:(t=V&&t[V]||t["@@iterator"],typeof t=="function"?t:null)}var fe=Symbol.for("react.client.reference");function me(t){if(t==null)return null;if(typeof t=="function")return t.$$typeof===fe?null:t.displayName||t.name||null;if(typeof t=="string")return t;switch(t){case C:return"Fragment";case x:return"Profiler";case y:return"StrictMode";case B:return"Suspense";case U:return"SuspenseList";case P:return"Activity"}if(typeof t=="object")switch(t.$$typeof){case b:return"Portal";case I:return t.displayName||"Context";case O:return(t._context.displayName||"Context")+".Consumer";case w:var n=t.render;return t=t.displayName,t||(t=n.displayName||n.name||"",t=t!==""?"ForwardRef("+t+")":"ForwardRef"),t;case F:return n=t.displayName||null,n!==null?n:me(t.type)||"Memo";case T:n=t._payload,t=t._init;try{return me(t(n))}catch{}}return null}var j=Array.isArray,L=e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,H=i.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,$={pending:!1,data:null,method:null,action:null},_e=[],be=-1;function N(t){return{current:t}}function Y(t){0>be||(t.current=_e[be],_e[be]=null,be--)}function de(t,n){be++,_e[be]=t.current,t.current=n}var Te=N(null),Ce=N(null),ee=N(null),Me=N(null);function ve(t,n){switch(de(ee,n),de(Ce,t),de(Te,null),n.nodeType){case 9:case 11:t=(t=n.documentElement)&&(t=t.namespaceURI)?H0(t):0;break;default:if(t=n.tagName,n=n.namespaceURI)n=H0(n),t=G0(n,t);else switch(t){case"svg":t=1;break;case"math":t=2;break;default:t=0}}Y(Te),de(Te,t)}function He(){Y(Te),Y(Ce),Y(ee)}function nt(t){t.memoizedState!==null&&de(Me,t);var n=Te.current,r=G0(n,t.type);n!==r&&(de(Ce,t),de(Te,r))}function je(t){Ce.current===t&&(Y(Te),Y(Ce)),Me.current===t&&(Y(Me),Wo._currentValue=$)}var Dt,ut;function pt(t){if(Dt===void 0)try{throw Error()}catch(r){var n=r.stack.trim().match(/\n( *(at )?)/);Dt=n&&n[1]||"",ut=-1<r.stack.indexOf(`
    at`)?" (<anonymous>)":-1<r.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Dt+t+ut}var mt=!1;function dt(t,n){if(!t||mt)return"";mt=!0;var r=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var o={DetermineComponentFrameRoot:function(){try{if(n){var Ee=function(){throw Error()};if(Object.defineProperty(Ee.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(Ee,[])}catch(ue){var le=ue}Reflect.construct(t,[],Ee)}else{try{Ee.call()}catch(ue){le=ue}t.call(Ee.prototype)}}else{try{throw Error()}catch(ue){le=ue}(Ee=t())&&typeof Ee.catch=="function"&&Ee.catch(function(){})}}catch(ue){if(ue&&le&&typeof ue.stack=="string")return[ue.stack,le.stack]}return[null,null]}};o.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var u=Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot,"name");u&&u.configurable&&Object.defineProperty(o.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var d=o.DetermineComponentFrameRoot(),S=d[0],R=d[1];if(S&&R){var z=S.split(`
`),ie=R.split(`
`);for(u=o=0;o<z.length&&!z[o].includes("DetermineComponentFrameRoot");)o++;for(;u<ie.length&&!ie[u].includes("DetermineComponentFrameRoot");)u++;if(o===z.length||u===ie.length)for(o=z.length-1,u=ie.length-1;1<=o&&0<=u&&z[o]!==ie[u];)u--;for(;1<=o&&0<=u;o--,u--)if(z[o]!==ie[u]){if(o!==1||u!==1)do if(o--,u--,0>u||z[o]!==ie[u]){var xe=`
`+z[o].replace(" at new "," at ");return t.displayName&&xe.includes("<anonymous>")&&(xe=xe.replace("<anonymous>",t.displayName)),xe}while(1<=o&&0<=u);break}}}finally{mt=!1,Error.prepareStackTrace=r}return(r=t?t.displayName||t.name:"")?pt(r):""}function qt(t,n){switch(t.tag){case 26:case 27:case 5:return pt(t.type);case 16:return pt("Lazy");case 13:return t.child!==n&&n!==null?pt("Suspense Fallback"):pt("Suspense");case 19:return pt("SuspenseList");case 0:case 15:return dt(t.type,!1);case 11:return dt(t.type.render,!1);case 1:return dt(t.type,!0);case 31:return pt("Activity");default:return""}}function $t(t){try{var n="",r=null;do n+=qt(t,r),r=t,t=t.return;while(t);return n}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}var Ut=Object.prototype.hasOwnProperty,cn=a.unstable_scheduleCallback,Yt=a.unstable_cancelCallback,St=a.unstable_shouldYield,X=a.unstable_requestPaint,Bt=a.unstable_now,Ct=a.unstable_getCurrentPriorityLevel,D=a.unstable_ImmediatePriority,E=a.unstable_UserBlockingPriority,K=a.unstable_NormalPriority,se=a.unstable_LowPriority,he=a.unstable_IdlePriority,De=a.log,Le=a.unstable_setDisableYieldValue,pe=null,ge=null;function Ne(t){if(typeof De=="function"&&Le(t),ge&&typeof ge.setStrictMode=="function")try{ge.setStrictMode(pe,t)}catch{}}var Ve=Math.clz32?Math.clz32:Ye,Be=Math.log,Ie=Math.LN2;function Ye(t){return t>>>=0,t===0?32:31-(Be(t)/Ie|0)|0}var $e=256,at=262144,k=4194304;function Ue(t){var n=t&42;if(n!==0)return n;switch(t&-t){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return t&261888;case 262144:case 524288:case 1048576:case 2097152:return t&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return t&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return t}}function te(t,n,r){var o=t.pendingLanes;if(o===0)return 0;var u=0,d=t.suspendedLanes,S=t.pingedLanes;t=t.warmLanes;var R=o&134217727;return R!==0?(o=R&~d,o!==0?u=Ue(o):(S&=R,S!==0?u=Ue(S):r||(r=R&~t,r!==0&&(u=Ue(r))))):(R=o&~d,R!==0?u=Ue(R):S!==0?u=Ue(S):r||(r=o&~t,r!==0&&(u=Ue(r)))),u===0?0:n!==0&&n!==u&&(n&d)===0&&(d=u&-u,r=n&-n,d>=r||d===32&&(r&4194048)!==0)?n:u}function Ae(t,n){return(t.pendingLanes&~(t.suspendedLanes&~t.pingedLanes)&n)===0}function we(t,n){switch(t){case 1:case 2:case 4:case 8:case 64:return n+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Se(){var t=k;return k<<=1,(k&62914560)===0&&(k=4194304),t}function We(t){for(var n=[],r=0;31>r;r++)n.push(t);return n}function Oe(t,n){t.pendingLanes|=n,n!==268435456&&(t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0)}function gt(t,n,r,o,u,d){var S=t.pendingLanes;t.pendingLanes=r,t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0,t.expiredLanes&=r,t.entangledLanes&=r,t.errorRecoveryDisabledLanes&=r,t.shellSuspendCounter=0;var R=t.entanglements,z=t.expirationTimes,ie=t.hiddenUpdates;for(r=S&~r;0<r;){var xe=31-Ve(r),Ee=1<<xe;R[xe]=0,z[xe]=-1;var le=ie[xe];if(le!==null)for(ie[xe]=null,xe=0;xe<le.length;xe++){var ue=le[xe];ue!==null&&(ue.lane&=-536870913)}r&=~Ee}o!==0&&Rt(t,o,0),d!==0&&u===0&&t.tag!==0&&(t.suspendedLanes|=d&~(S&~n))}function Rt(t,n,r){t.pendingLanes|=n,t.suspendedLanes&=~n;var o=31-Ve(n);t.entangledLanes|=n,t.entanglements[o]=t.entanglements[o]|1073741824|r&261930}function en(t,n){var r=t.entangledLanes|=n;for(t=t.entanglements;r;){var o=31-Ve(r),u=1<<o;u&n|t[o]&n&&(t[o]|=n),r&=~u}}function tn(t,n){var r=n&-n;return r=(r&42)!==0?1:Ha(r),(r&(t.suspendedLanes|n))!==0?0:r}function Ha(t){switch(t){case 2:t=1;break;case 8:t=4;break;case 32:t=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:t=128;break;case 268435456:t=134217728;break;default:t=0}return t}function ei(t){return t&=-t,2<t?8<t?(t&134217727)!==0?32:268435456:8:2}function ns(){var t=H.p;return t!==0?t:(t=window.event,t===void 0?32:uv(t.type))}function is(t,n){var r=H.p;try{return H.p=t,n()}finally{H.p=r}}var ki=Math.random().toString(36).slice(2),mn="__reactFiber$"+ki,Dn="__reactProps$"+ki,Xn="__reactContainer$"+ki,Er="__reactEvents$"+ki,_l="__reactListeners$"+ki,xl="__reactHandles$"+ki,br="__reactResources$"+ki,Ga="__reactMarker$"+ki;function Va(t){delete t[mn],delete t[Dn],delete t[Er],delete t[_l],delete t[xl]}function sa(t){var n=t[mn];if(n)return n;for(var r=t.parentNode;r;){if(n=r[Xn]||r[mn]){if(r=n.alternate,n.child!==null||r!==null&&r.child!==null)for(t=Z0(t);t!==null;){if(r=t[mn])return r;t=Z0(t)}return n}t=r,r=t.parentNode}return null}function oa(t){if(t=t[mn]||t[Xn]){var n=t.tag;if(n===5||n===6||n===13||n===31||n===26||n===27||n===3)return t}return null}function Tr(t){var n=t.tag;if(n===5||n===26||n===27||n===6)return t.stateNode;throw Error(s(33))}function ka(t){var n=t[br];return n||(n=t[br]={hoistableStyles:new Map,hoistableScripts:new Map}),n}function gn(t){t[Ga]=!0}var Sl=new Set,A={};function W(t,n){oe(t,n),oe(t+"Capture",n)}function oe(t,n){for(A[t]=n,t=0;t<n.length;t++)Sl.add(n[t])}var ae=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),re={},ze={};function Xe(t){return Ut.call(ze,t)?!0:Ut.call(re,t)?!1:ae.test(t)?ze[t]=!0:(re[t]=!0,!1)}function Fe(t,n,r){if(Xe(n))if(r===null)t.removeAttribute(n);else{switch(typeof r){case"undefined":case"function":case"symbol":t.removeAttribute(n);return;case"boolean":var o=n.toLowerCase().slice(0,5);if(o!=="data-"&&o!=="aria-"){t.removeAttribute(n);return}}t.setAttribute(n,""+r)}}function Ze(t,n,r){if(r===null)t.removeAttribute(n);else{switch(typeof r){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(n);return}t.setAttribute(n,""+r)}}function qe(t,n,r,o){if(o===null)t.removeAttribute(r);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(r);return}t.setAttributeNS(n,r,""+o)}}function et(t){switch(typeof t){case"bigint":case"boolean":case"number":case"string":case"undefined":return t;case"object":return t;default:return""}}function lt(t){var n=t.type;return(t=t.nodeName)&&t.toLowerCase()==="input"&&(n==="checkbox"||n==="radio")}function Je(t,n,r){var o=Object.getOwnPropertyDescriptor(t.constructor.prototype,n);if(!t.hasOwnProperty(n)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var u=o.get,d=o.set;return Object.defineProperty(t,n,{configurable:!0,get:function(){return u.call(this)},set:function(S){r=""+S,d.call(this,S)}}),Object.defineProperty(t,n,{enumerable:o.enumerable}),{getValue:function(){return r},setValue:function(S){r=""+S},stopTracking:function(){t._valueTracker=null,delete t[n]}}}}function Nt(t){if(!t._valueTracker){var n=lt(t)?"checked":"value";t._valueTracker=Je(t,n,""+t[n])}}function rn(t){if(!t)return!1;var n=t._valueTracker;if(!n)return!0;var r=n.getValue(),o="";return t&&(o=lt(t)?t.checked?"true":"false":t.value),t=o,t!==r?(n.setValue(t),!0):!1}function jt(t){if(t=t||(typeof document<"u"?document:void 0),typeof t>"u")return null;try{return t.activeElement||t.body}catch{return t.body}}var Ht=/[\n"\\]/g;function Gt(t){return t.replace(Ht,function(n){return"\\"+n.charCodeAt(0).toString(16)+" "})}function ke(t,n,r,o,u,d,S,R){t.name="",S!=null&&typeof S!="function"&&typeof S!="symbol"&&typeof S!="boolean"?t.type=S:t.removeAttribute("type"),n!=null?S==="number"?(n===0&&t.value===""||t.value!=n)&&(t.value=""+et(n)):t.value!==""+et(n)&&(t.value=""+et(n)):S!=="submit"&&S!=="reset"||t.removeAttribute("value"),n!=null?vt(t,S,et(n)):r!=null?vt(t,S,et(r)):o!=null&&t.removeAttribute("value"),u==null&&d!=null&&(t.defaultChecked=!!d),u!=null&&(t.checked=u&&typeof u!="function"&&typeof u!="symbol"),R!=null&&typeof R!="function"&&typeof R!="symbol"&&typeof R!="boolean"?t.name=""+et(R):t.removeAttribute("name")}function In(t,n,r,o,u,d,S,R){if(d!=null&&typeof d!="function"&&typeof d!="symbol"&&typeof d!="boolean"&&(t.type=d),n!=null||r!=null){if(!(d!=="submit"&&d!=="reset"||n!=null)){Nt(t);return}r=r!=null?""+et(r):"",n=n!=null?""+et(n):r,R||n===t.value||(t.value=n),t.defaultValue=n}o=o??u,o=typeof o!="function"&&typeof o!="symbol"&&!!o,t.checked=R?t.checked:!!o,t.defaultChecked=!!o,S!=null&&typeof S!="function"&&typeof S!="symbol"&&typeof S!="boolean"&&(t.name=S),Nt(t)}function vt(t,n,r){n==="number"&&jt(t.ownerDocument)===t||t.defaultValue===""+r||(t.defaultValue=""+r)}function En(t,n,r,o){if(t=t.options,n){n={};for(var u=0;u<r.length;u++)n["$"+r[u]]=!0;for(r=0;r<t.length;r++)u=n.hasOwnProperty("$"+t[r].value),t[r].selected!==u&&(t[r].selected=u),u&&o&&(t[r].defaultSelected=!0)}else{for(r=""+et(r),n=null,u=0;u<t.length;u++){if(t[u].value===r){t[u].selected=!0,o&&(t[u].defaultSelected=!0);return}n!==null||t[u].disabled||(n=t[u])}n!==null&&(n.selected=!0)}}function ti(t,n,r){if(n!=null&&(n=""+et(n),n!==t.value&&(t.value=n),r==null)){t.defaultValue!==n&&(t.defaultValue=n);return}t.defaultValue=r!=null?""+et(r):""}function wi(t,n,r,o){if(n==null){if(o!=null){if(r!=null)throw Error(s(92));if(j(o)){if(1<o.length)throw Error(s(93));o=o[0]}r=o}r==null&&(r=""),n=r}r=et(n),t.defaultValue=r,o=t.textContent,o===r&&o!==""&&o!==null&&(t.value=o),Nt(t)}function ni(t,n){if(n){var r=t.firstChild;if(r&&r===t.lastChild&&r.nodeType===3){r.nodeValue=n;return}}t.textContent=n}var Vt=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function sn(t,n,r){var o=n.indexOf("--")===0;r==null||typeof r=="boolean"||r===""?o?t.setProperty(n,""):n==="float"?t.cssFloat="":t[n]="":o?t.setProperty(n,r):typeof r!="number"||r===0||Vt.has(n)?n==="float"?t.cssFloat=r:t[n]=(""+r).trim():t[n]=r+"px"}function Di(t,n,r){if(n!=null&&typeof n!="object")throw Error(s(62));if(t=t.style,r!=null){for(var o in r)!r.hasOwnProperty(o)||n!=null&&n.hasOwnProperty(o)||(o.indexOf("--")===0?t.setProperty(o,""):o==="float"?t.cssFloat="":t[o]="");for(var u in n)o=n[u],n.hasOwnProperty(u)&&r[u]!==o&&sn(t,u,o)}else for(var d in n)n.hasOwnProperty(d)&&sn(t,d,n[d])}function Ft(t){if(t.indexOf("-")===-1)return!1;switch(t){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Xi=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Xa=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Ar(t){return Xa.test(""+t)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":t}function la(){}var Ru=null;function Cu(t){return t=t.target||t.srcElement||window,t.correspondingUseElement&&(t=t.correspondingUseElement),t.nodeType===3?t.parentNode:t}var as=null,rs=null;function zp(t){var n=oa(t);if(n&&(t=n.stateNode)){var r=t[Dn]||null;e:switch(t=n.stateNode,n.type){case"input":if(ke(t,r.value,r.defaultValue,r.defaultValue,r.checked,r.defaultChecked,r.type,r.name),n=r.name,r.type==="radio"&&n!=null){for(r=t;r.parentNode;)r=r.parentNode;for(r=r.querySelectorAll('input[name="'+Gt(""+n)+'"][type="radio"]'),n=0;n<r.length;n++){var o=r[n];if(o!==t&&o.form===t.form){var u=o[Dn]||null;if(!u)throw Error(s(90));ke(o,u.value,u.defaultValue,u.defaultValue,u.checked,u.defaultChecked,u.type,u.name)}}for(n=0;n<r.length;n++)o=r[n],o.form===t.form&&rn(o)}break e;case"textarea":ti(t,r.value,r.defaultValue);break e;case"select":n=r.value,n!=null&&En(t,!!r.multiple,n,!1)}}}var wu=!1;function Hp(t,n,r){if(wu)return t(n,r);wu=!0;try{var o=t(n);return o}finally{if(wu=!1,(as!==null||rs!==null)&&(oc(),as&&(n=as,t=rs,rs=as=null,zp(n),t)))for(n=0;n<t.length;n++)zp(t[n])}}function oo(t,n){var r=t.stateNode;if(r===null)return null;var o=r[Dn]||null;if(o===null)return null;r=o[n];e:switch(n){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(t=t.type,o=!(t==="button"||t==="input"||t==="select"||t==="textarea")),t=!o;break e;default:t=!1}if(t)return null;if(r&&typeof r!="function")throw Error(s(231,n,typeof r));return r}var ca=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Du=!1;if(ca)try{var lo={};Object.defineProperty(lo,"passive",{get:function(){Du=!0}}),window.addEventListener("test",lo,lo),window.removeEventListener("test",lo,lo)}catch{Du=!1}var Wa=null,Uu=null,yl=null;function Gp(){if(yl)return yl;var t,n=Uu,r=n.length,o,u="value"in Wa?Wa.value:Wa.textContent,d=u.length;for(t=0;t<r&&n[t]===u[t];t++);var S=r-t;for(o=1;o<=S&&n[r-o]===u[d-o];o++);return yl=u.slice(t,1<o?1-o:void 0)}function Ml(t){var n=t.keyCode;return"charCode"in t?(t=t.charCode,t===0&&n===13&&(t=13)):t=n,t===10&&(t=13),32<=t||t===13?t:0}function El(){return!0}function Vp(){return!1}function Wn(t){function n(r,o,u,d,S){this._reactName=r,this._targetInst=u,this.type=o,this.nativeEvent=d,this.target=S,this.currentTarget=null;for(var R in t)t.hasOwnProperty(R)&&(r=t[R],this[R]=r?r(d):d[R]);return this.isDefaultPrevented=(d.defaultPrevented!=null?d.defaultPrevented:d.returnValue===!1)?El:Vp,this.isPropagationStopped=Vp,this}return g(n.prototype,{preventDefault:function(){this.defaultPrevented=!0;var r=this.nativeEvent;r&&(r.preventDefault?r.preventDefault():typeof r.returnValue!="unknown"&&(r.returnValue=!1),this.isDefaultPrevented=El)},stopPropagation:function(){var r=this.nativeEvent;r&&(r.stopPropagation?r.stopPropagation():typeof r.cancelBubble!="unknown"&&(r.cancelBubble=!0),this.isPropagationStopped=El)},persist:function(){},isPersistent:El}),n}var Rr={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(t){return t.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},bl=Wn(Rr),co=g({},Rr,{view:0,detail:0}),qx=Wn(co),Nu,Lu,uo,Tl=g({},co,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Pu,button:0,buttons:0,relatedTarget:function(t){return t.relatedTarget===void 0?t.fromElement===t.srcElement?t.toElement:t.fromElement:t.relatedTarget},movementX:function(t){return"movementX"in t?t.movementX:(t!==uo&&(uo&&t.type==="mousemove"?(Nu=t.screenX-uo.screenX,Lu=t.screenY-uo.screenY):Lu=Nu=0,uo=t),Nu)},movementY:function(t){return"movementY"in t?t.movementY:Lu}}),kp=Wn(Tl),Yx=g({},Tl,{dataTransfer:0}),Zx=Wn(Yx),Kx=g({},co,{relatedTarget:0}),Ou=Wn(Kx),Qx=g({},Rr,{animationName:0,elapsedTime:0,pseudoElement:0}),jx=Wn(Qx),Jx=g({},Rr,{clipboardData:function(t){return"clipboardData"in t?t.clipboardData:window.clipboardData}}),$x=Wn(Jx),eS=g({},Rr,{data:0}),Xp=Wn(eS),tS={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},nS={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},iS={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function aS(t){var n=this.nativeEvent;return n.getModifierState?n.getModifierState(t):(t=iS[t])?!!n[t]:!1}function Pu(){return aS}var rS=g({},co,{key:function(t){if(t.key){var n=tS[t.key]||t.key;if(n!=="Unidentified")return n}return t.type==="keypress"?(t=Ml(t),t===13?"Enter":String.fromCharCode(t)):t.type==="keydown"||t.type==="keyup"?nS[t.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Pu,charCode:function(t){return t.type==="keypress"?Ml(t):0},keyCode:function(t){return t.type==="keydown"||t.type==="keyup"?t.keyCode:0},which:function(t){return t.type==="keypress"?Ml(t):t.type==="keydown"||t.type==="keyup"?t.keyCode:0}}),sS=Wn(rS),oS=g({},Tl,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Wp=Wn(oS),lS=g({},co,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Pu}),cS=Wn(lS),uS=g({},Rr,{propertyName:0,elapsedTime:0,pseudoElement:0}),fS=Wn(uS),dS=g({},Tl,{deltaX:function(t){return"deltaX"in t?t.deltaX:"wheelDeltaX"in t?-t.wheelDeltaX:0},deltaY:function(t){return"deltaY"in t?t.deltaY:"wheelDeltaY"in t?-t.wheelDeltaY:"wheelDelta"in t?-t.wheelDelta:0},deltaZ:0,deltaMode:0}),hS=Wn(dS),pS=g({},Rr,{newState:0,oldState:0}),mS=Wn(pS),gS=[9,13,27,32],Iu=ca&&"CompositionEvent"in window,fo=null;ca&&"documentMode"in document&&(fo=document.documentMode);var vS=ca&&"TextEvent"in window&&!fo,qp=ca&&(!Iu||fo&&8<fo&&11>=fo),Yp=" ",Zp=!1;function Kp(t,n){switch(t){case"keyup":return gS.indexOf(n.keyCode)!==-1;case"keydown":return n.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Qp(t){return t=t.detail,typeof t=="object"&&"data"in t?t.data:null}var ss=!1;function _S(t,n){switch(t){case"compositionend":return Qp(n);case"keypress":return n.which!==32?null:(Zp=!0,Yp);case"textInput":return t=n.data,t===Yp&&Zp?null:t;default:return null}}function xS(t,n){if(ss)return t==="compositionend"||!Iu&&Kp(t,n)?(t=Gp(),yl=Uu=Wa=null,ss=!1,t):null;switch(t){case"paste":return null;case"keypress":if(!(n.ctrlKey||n.altKey||n.metaKey)||n.ctrlKey&&n.altKey){if(n.char&&1<n.char.length)return n.char;if(n.which)return String.fromCharCode(n.which)}return null;case"compositionend":return qp&&n.locale!=="ko"?null:n.data;default:return null}}var SS={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function jp(t){var n=t&&t.nodeName&&t.nodeName.toLowerCase();return n==="input"?!!SS[t.type]:n==="textarea"}function Jp(t,n,r,o){as?rs?rs.push(o):rs=[o]:as=o,n=pc(n,"onChange"),0<n.length&&(r=new bl("onChange","change",null,r,o),t.push({event:r,listeners:n}))}var ho=null,po=null;function yS(t){O0(t,0)}function Al(t){var n=Tr(t);if(rn(n))return t}function $p(t,n){if(t==="change")return n}var em=!1;if(ca){var Bu;if(ca){var Fu="oninput"in document;if(!Fu){var tm=document.createElement("div");tm.setAttribute("oninput","return;"),Fu=typeof tm.oninput=="function"}Bu=Fu}else Bu=!1;em=Bu&&(!document.documentMode||9<document.documentMode)}function nm(){ho&&(ho.detachEvent("onpropertychange",im),po=ho=null)}function im(t){if(t.propertyName==="value"&&Al(po)){var n=[];Jp(n,po,t,Cu(t)),Hp(yS,n)}}function MS(t,n,r){t==="focusin"?(nm(),ho=n,po=r,ho.attachEvent("onpropertychange",im)):t==="focusout"&&nm()}function ES(t){if(t==="selectionchange"||t==="keyup"||t==="keydown")return Al(po)}function bS(t,n){if(t==="click")return Al(n)}function TS(t,n){if(t==="input"||t==="change")return Al(n)}function AS(t,n){return t===n&&(t!==0||1/t===1/n)||t!==t&&n!==n}var ii=typeof Object.is=="function"?Object.is:AS;function mo(t,n){if(ii(t,n))return!0;if(typeof t!="object"||t===null||typeof n!="object"||n===null)return!1;var r=Object.keys(t),o=Object.keys(n);if(r.length!==o.length)return!1;for(o=0;o<r.length;o++){var u=r[o];if(!Ut.call(n,u)||!ii(t[u],n[u]))return!1}return!0}function am(t){for(;t&&t.firstChild;)t=t.firstChild;return t}function rm(t,n){var r=am(t);t=0;for(var o;r;){if(r.nodeType===3){if(o=t+r.textContent.length,t<=n&&o>=n)return{node:r,offset:n-t};t=o}e:{for(;r;){if(r.nextSibling){r=r.nextSibling;break e}r=r.parentNode}r=void 0}r=am(r)}}function sm(t,n){return t&&n?t===n?!0:t&&t.nodeType===3?!1:n&&n.nodeType===3?sm(t,n.parentNode):"contains"in t?t.contains(n):t.compareDocumentPosition?!!(t.compareDocumentPosition(n)&16):!1:!1}function om(t){t=t!=null&&t.ownerDocument!=null&&t.ownerDocument.defaultView!=null?t.ownerDocument.defaultView:window;for(var n=jt(t.document);n instanceof t.HTMLIFrameElement;){try{var r=typeof n.contentWindow.location.href=="string"}catch{r=!1}if(r)t=n.contentWindow;else break;n=jt(t.document)}return n}function zu(t){var n=t&&t.nodeName&&t.nodeName.toLowerCase();return n&&(n==="input"&&(t.type==="text"||t.type==="search"||t.type==="tel"||t.type==="url"||t.type==="password")||n==="textarea"||t.contentEditable==="true")}var RS=ca&&"documentMode"in document&&11>=document.documentMode,os=null,Hu=null,go=null,Gu=!1;function lm(t,n,r){var o=r.window===r?r.document:r.nodeType===9?r:r.ownerDocument;Gu||os==null||os!==jt(o)||(o=os,"selectionStart"in o&&zu(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),go&&mo(go,o)||(go=o,o=pc(Hu,"onSelect"),0<o.length&&(n=new bl("onSelect","select",null,n,r),t.push({event:n,listeners:o}),n.target=os)))}function Cr(t,n){var r={};return r[t.toLowerCase()]=n.toLowerCase(),r["Webkit"+t]="webkit"+n,r["Moz"+t]="moz"+n,r}var ls={animationend:Cr("Animation","AnimationEnd"),animationiteration:Cr("Animation","AnimationIteration"),animationstart:Cr("Animation","AnimationStart"),transitionrun:Cr("Transition","TransitionRun"),transitionstart:Cr("Transition","TransitionStart"),transitioncancel:Cr("Transition","TransitionCancel"),transitionend:Cr("Transition","TransitionEnd")},Vu={},cm={};ca&&(cm=document.createElement("div").style,"AnimationEvent"in window||(delete ls.animationend.animation,delete ls.animationiteration.animation,delete ls.animationstart.animation),"TransitionEvent"in window||delete ls.transitionend.transition);function wr(t){if(Vu[t])return Vu[t];if(!ls[t])return t;var n=ls[t],r;for(r in n)if(n.hasOwnProperty(r)&&r in cm)return Vu[t]=n[r];return t}var um=wr("animationend"),fm=wr("animationiteration"),dm=wr("animationstart"),CS=wr("transitionrun"),wS=wr("transitionstart"),DS=wr("transitioncancel"),hm=wr("transitionend"),pm=new Map,ku="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");ku.push("scrollEnd");function Ui(t,n){pm.set(t,n),W(n,[t])}var Rl=typeof reportError=="function"?reportError:function(t){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var n=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof t=="object"&&t!==null&&typeof t.message=="string"?String(t.message):String(t),error:t});if(!window.dispatchEvent(n))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",t);return}console.error(t)},gi=[],cs=0,Xu=0;function Cl(){for(var t=cs,n=Xu=cs=0;n<t;){var r=gi[n];gi[n++]=null;var o=gi[n];gi[n++]=null;var u=gi[n];gi[n++]=null;var d=gi[n];if(gi[n++]=null,o!==null&&u!==null){var S=o.pending;S===null?u.next=u:(u.next=S.next,S.next=u),o.pending=u}d!==0&&mm(r,u,d)}}function wl(t,n,r,o){gi[cs++]=t,gi[cs++]=n,gi[cs++]=r,gi[cs++]=o,Xu|=o,t.lanes|=o,t=t.alternate,t!==null&&(t.lanes|=o)}function Wu(t,n,r,o){return wl(t,n,r,o),Dl(t)}function Dr(t,n){return wl(t,null,null,n),Dl(t)}function mm(t,n,r){t.lanes|=r;var o=t.alternate;o!==null&&(o.lanes|=r);for(var u=!1,d=t.return;d!==null;)d.childLanes|=r,o=d.alternate,o!==null&&(o.childLanes|=r),d.tag===22&&(t=d.stateNode,t===null||t._visibility&1||(u=!0)),t=d,d=d.return;return t.tag===3?(d=t.stateNode,u&&n!==null&&(u=31-Ve(r),t=d.hiddenUpdates,o=t[u],o===null?t[u]=[n]:o.push(n),n.lane=r|536870912),d):null}function Dl(t){if(50<Fo)throw Fo=0,td=null,Error(s(185));for(var n=t.return;n!==null;)t=n,n=t.return;return t.tag===3?t.stateNode:null}var us={};function US(t,n,r,o){this.tag=t,this.key=r,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=n,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function ai(t,n,r,o){return new US(t,n,r,o)}function qu(t){return t=t.prototype,!(!t||!t.isReactComponent)}function ua(t,n){var r=t.alternate;return r===null?(r=ai(t.tag,n,t.key,t.mode),r.elementType=t.elementType,r.type=t.type,r.stateNode=t.stateNode,r.alternate=t,t.alternate=r):(r.pendingProps=n,r.type=t.type,r.flags=0,r.subtreeFlags=0,r.deletions=null),r.flags=t.flags&65011712,r.childLanes=t.childLanes,r.lanes=t.lanes,r.child=t.child,r.memoizedProps=t.memoizedProps,r.memoizedState=t.memoizedState,r.updateQueue=t.updateQueue,n=t.dependencies,r.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext},r.sibling=t.sibling,r.index=t.index,r.ref=t.ref,r.refCleanup=t.refCleanup,r}function gm(t,n){t.flags&=65011714;var r=t.alternate;return r===null?(t.childLanes=0,t.lanes=n,t.child=null,t.subtreeFlags=0,t.memoizedProps=null,t.memoizedState=null,t.updateQueue=null,t.dependencies=null,t.stateNode=null):(t.childLanes=r.childLanes,t.lanes=r.lanes,t.child=r.child,t.subtreeFlags=0,t.deletions=null,t.memoizedProps=r.memoizedProps,t.memoizedState=r.memoizedState,t.updateQueue=r.updateQueue,t.type=r.type,n=r.dependencies,t.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),t}function Ul(t,n,r,o,u,d){var S=0;if(o=t,typeof t=="function")qu(t)&&(S=1);else if(typeof t=="string")S=Iy(t,r,Te.current)?26:t==="html"||t==="head"||t==="body"?27:5;else e:switch(t){case P:return t=ai(31,r,n,u),t.elementType=P,t.lanes=d,t;case C:return Ur(r.children,u,d,n);case y:S=8,u|=24;break;case x:return t=ai(12,r,n,u|2),t.elementType=x,t.lanes=d,t;case B:return t=ai(13,r,n,u),t.elementType=B,t.lanes=d,t;case U:return t=ai(19,r,n,u),t.elementType=U,t.lanes=d,t;default:if(typeof t=="object"&&t!==null)switch(t.$$typeof){case I:S=10;break e;case O:S=9;break e;case w:S=11;break e;case F:S=14;break e;case T:S=16,o=null;break e}S=29,r=Error(s(130,t===null?"null":typeof t,"")),o=null}return n=ai(S,r,n,u),n.elementType=t,n.type=o,n.lanes=d,n}function Ur(t,n,r,o){return t=ai(7,t,o,n),t.lanes=r,t}function Yu(t,n,r){return t=ai(6,t,null,n),t.lanes=r,t}function vm(t){var n=ai(18,null,null,0);return n.stateNode=t,n}function Zu(t,n,r){return n=ai(4,t.children!==null?t.children:[],t.key,n),n.lanes=r,n.stateNode={containerInfo:t.containerInfo,pendingChildren:null,implementation:t.implementation},n}var _m=new WeakMap;function vi(t,n){if(typeof t=="object"&&t!==null){var r=_m.get(t);return r!==void 0?r:(n={value:t,source:n,stack:$t(n)},_m.set(t,n),n)}return{value:t,source:n,stack:$t(n)}}var fs=[],ds=0,Nl=null,vo=0,_i=[],xi=0,qa=null,Wi=1,qi="";function fa(t,n){fs[ds++]=vo,fs[ds++]=Nl,Nl=t,vo=n}function xm(t,n,r){_i[xi++]=Wi,_i[xi++]=qi,_i[xi++]=qa,qa=t;var o=Wi;t=qi;var u=32-Ve(o)-1;o&=~(1<<u),r+=1;var d=32-Ve(n)+u;if(30<d){var S=u-u%5;d=(o&(1<<S)-1).toString(32),o>>=S,u-=S,Wi=1<<32-Ve(n)+u|r<<u|o,qi=d+t}else Wi=1<<d|r<<u|o,qi=t}function Ku(t){t.return!==null&&(fa(t,1),xm(t,1,0))}function Qu(t){for(;t===Nl;)Nl=fs[--ds],fs[ds]=null,vo=fs[--ds],fs[ds]=null;for(;t===qa;)qa=_i[--xi],_i[xi]=null,qi=_i[--xi],_i[xi]=null,Wi=_i[--xi],_i[xi]=null}function Sm(t,n){_i[xi++]=Wi,_i[xi++]=qi,_i[xi++]=qa,Wi=n.id,qi=n.overflow,qa=t}var Un=null,nn=null,Et=!1,Ya=null,Si=!1,ju=Error(s(519));function Za(t){var n=Error(s(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw _o(vi(n,t)),ju}function ym(t){var n=t.stateNode,r=t.type,o=t.memoizedProps;switch(n[mn]=t,n[Dn]=o,r){case"dialog":xt("cancel",n),xt("close",n);break;case"iframe":case"object":case"embed":xt("load",n);break;case"video":case"audio":for(r=0;r<Ho.length;r++)xt(Ho[r],n);break;case"source":xt("error",n);break;case"img":case"image":case"link":xt("error",n),xt("load",n);break;case"details":xt("toggle",n);break;case"input":xt("invalid",n),In(n,o.value,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name,!0);break;case"select":xt("invalid",n);break;case"textarea":xt("invalid",n),wi(n,o.value,o.defaultValue,o.children)}r=o.children,typeof r!="string"&&typeof r!="number"&&typeof r!="bigint"||n.textContent===""+r||o.suppressHydrationWarning===!0||F0(n.textContent,r)?(o.popover!=null&&(xt("beforetoggle",n),xt("toggle",n)),o.onScroll!=null&&xt("scroll",n),o.onScrollEnd!=null&&xt("scrollend",n),o.onClick!=null&&(n.onclick=la),n=!0):n=!1,n||Za(t,!0)}function Mm(t){for(Un=t.return;Un;)switch(Un.tag){case 5:case 31:case 13:Si=!1;return;case 27:case 3:Si=!0;return;default:Un=Un.return}}function hs(t){if(t!==Un)return!1;if(!Et)return Mm(t),Et=!0,!1;var n=t.tag,r;if((r=n!==3&&n!==27)&&((r=n===5)&&(r=t.type,r=!(r!=="form"&&r!=="button")||gd(t.type,t.memoizedProps)),r=!r),r&&nn&&Za(t),Mm(t),n===13){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(s(317));nn=Y0(t)}else if(n===31){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(s(317));nn=Y0(t)}else n===27?(n=nn,lr(t.type)?(t=yd,yd=null,nn=t):nn=n):nn=Un?Mi(t.stateNode.nextSibling):null;return!0}function Nr(){nn=Un=null,Et=!1}function Ju(){var t=Ya;return t!==null&&(Kn===null?Kn=t:Kn.push.apply(Kn,t),Ya=null),t}function _o(t){Ya===null?Ya=[t]:Ya.push(t)}var $u=N(null),Lr=null,da=null;function Ka(t,n,r){de($u,n._currentValue),n._currentValue=r}function ha(t){t._currentValue=$u.current,Y($u)}function ef(t,n,r){for(;t!==null;){var o=t.alternate;if((t.childLanes&n)!==n?(t.childLanes|=n,o!==null&&(o.childLanes|=n)):o!==null&&(o.childLanes&n)!==n&&(o.childLanes|=n),t===r)break;t=t.return}}function tf(t,n,r,o){var u=t.child;for(u!==null&&(u.return=t);u!==null;){var d=u.dependencies;if(d!==null){var S=u.child;d=d.firstContext;e:for(;d!==null;){var R=d;d=u;for(var z=0;z<n.length;z++)if(R.context===n[z]){d.lanes|=r,R=d.alternate,R!==null&&(R.lanes|=r),ef(d.return,r,t),o||(S=null);break e}d=R.next}}else if(u.tag===18){if(S=u.return,S===null)throw Error(s(341));S.lanes|=r,d=S.alternate,d!==null&&(d.lanes|=r),ef(S,r,t),S=null}else S=u.child;if(S!==null)S.return=u;else for(S=u;S!==null;){if(S===t){S=null;break}if(u=S.sibling,u!==null){u.return=S.return,S=u;break}S=S.return}u=S}}function ps(t,n,r,o){t=null;for(var u=n,d=!1;u!==null;){if(!d){if((u.flags&524288)!==0)d=!0;else if((u.flags&262144)!==0)break}if(u.tag===10){var S=u.alternate;if(S===null)throw Error(s(387));if(S=S.memoizedProps,S!==null){var R=u.type;ii(u.pendingProps.value,S.value)||(t!==null?t.push(R):t=[R])}}else if(u===Me.current){if(S=u.alternate,S===null)throw Error(s(387));S.memoizedState.memoizedState!==u.memoizedState.memoizedState&&(t!==null?t.push(Wo):t=[Wo])}u=u.return}t!==null&&tf(n,t,r,o),n.flags|=262144}function Ll(t){for(t=t.firstContext;t!==null;){if(!ii(t.context._currentValue,t.memoizedValue))return!0;t=t.next}return!1}function Or(t){Lr=t,da=null,t=t.dependencies,t!==null&&(t.firstContext=null)}function Nn(t){return Em(Lr,t)}function Ol(t,n){return Lr===null&&Or(t),Em(t,n)}function Em(t,n){var r=n._currentValue;if(n={context:n,memoizedValue:r,next:null},da===null){if(t===null)throw Error(s(308));da=n,t.dependencies={lanes:0,firstContext:n},t.flags|=524288}else da=da.next=n;return r}var NS=typeof AbortController<"u"?AbortController:function(){var t=[],n=this.signal={aborted:!1,addEventListener:function(r,o){t.push(o)}};this.abort=function(){n.aborted=!0,t.forEach(function(r){return r()})}},LS=a.unstable_scheduleCallback,OS=a.unstable_NormalPriority,vn={$$typeof:I,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function nf(){return{controller:new NS,data:new Map,refCount:0}}function xo(t){t.refCount--,t.refCount===0&&LS(OS,function(){t.controller.abort()})}var So=null,af=0,ms=0,gs=null;function PS(t,n){if(So===null){var r=So=[];af=0,ms=od(),gs={status:"pending",value:void 0,then:function(o){r.push(o)}}}return af++,n.then(bm,bm),n}function bm(){if(--af===0&&So!==null){gs!==null&&(gs.status="fulfilled");var t=So;So=null,ms=0,gs=null;for(var n=0;n<t.length;n++)(0,t[n])()}}function IS(t,n){var r=[],o={status:"pending",value:null,reason:null,then:function(u){r.push(u)}};return t.then(function(){o.status="fulfilled",o.value=n;for(var u=0;u<r.length;u++)(0,r[u])(n)},function(u){for(o.status="rejected",o.reason=u,u=0;u<r.length;u++)(0,r[u])(void 0)}),o}var Tm=L.S;L.S=function(t,n){l0=Bt(),typeof n=="object"&&n!==null&&typeof n.then=="function"&&PS(t,n),Tm!==null&&Tm(t,n)};var Pr=N(null);function rf(){var t=Pr.current;return t!==null?t:Jt.pooledCache}function Pl(t,n){n===null?de(Pr,Pr.current):de(Pr,n.pool)}function Am(){var t=rf();return t===null?null:{parent:vn._currentValue,pool:t}}var vs=Error(s(460)),sf=Error(s(474)),Il=Error(s(542)),Bl={then:function(){}};function Rm(t){return t=t.status,t==="fulfilled"||t==="rejected"}function Cm(t,n,r){switch(r=t[r],r===void 0?t.push(n):r!==n&&(n.then(la,la),n=r),n.status){case"fulfilled":return n.value;case"rejected":throw t=n.reason,Dm(t),t;default:if(typeof n.status=="string")n.then(la,la);else{if(t=Jt,t!==null&&100<t.shellSuspendCounter)throw Error(s(482));t=n,t.status="pending",t.then(function(o){if(n.status==="pending"){var u=n;u.status="fulfilled",u.value=o}},function(o){if(n.status==="pending"){var u=n;u.status="rejected",u.reason=o}})}switch(n.status){case"fulfilled":return n.value;case"rejected":throw t=n.reason,Dm(t),t}throw Br=n,vs}}function Ir(t){try{var n=t._init;return n(t._payload)}catch(r){throw r!==null&&typeof r=="object"&&typeof r.then=="function"?(Br=r,vs):r}}var Br=null;function wm(){if(Br===null)throw Error(s(459));var t=Br;return Br=null,t}function Dm(t){if(t===vs||t===Il)throw Error(s(483))}var _s=null,yo=0;function Fl(t){var n=yo;return yo+=1,_s===null&&(_s=[]),Cm(_s,t,n)}function Mo(t,n){n=n.props.ref,t.ref=n!==void 0?n:null}function zl(t,n){throw n.$$typeof===v?Error(s(525)):(t=Object.prototype.toString.call(n),Error(s(31,t==="[object Object]"?"object with keys {"+Object.keys(n).join(", ")+"}":t)))}function Um(t){function n(Z,G){if(t){var ne=Z.deletions;ne===null?(Z.deletions=[G],Z.flags|=16):ne.push(G)}}function r(Z,G){if(!t)return null;for(;G!==null;)n(Z,G),G=G.sibling;return null}function o(Z){for(var G=new Map;Z!==null;)Z.key!==null?G.set(Z.key,Z):G.set(Z.index,Z),Z=Z.sibling;return G}function u(Z,G){return Z=ua(Z,G),Z.index=0,Z.sibling=null,Z}function d(Z,G,ne){return Z.index=ne,t?(ne=Z.alternate,ne!==null?(ne=ne.index,ne<G?(Z.flags|=67108866,G):ne):(Z.flags|=67108866,G)):(Z.flags|=1048576,G)}function S(Z){return t&&Z.alternate===null&&(Z.flags|=67108866),Z}function R(Z,G,ne,ye){return G===null||G.tag!==6?(G=Yu(ne,Z.mode,ye),G.return=Z,G):(G=u(G,ne),G.return=Z,G)}function z(Z,G,ne,ye){var tt=ne.type;return tt===C?xe(Z,G,ne.props.children,ye,ne.key):G!==null&&(G.elementType===tt||typeof tt=="object"&&tt!==null&&tt.$$typeof===T&&Ir(tt)===G.type)?(G=u(G,ne.props),Mo(G,ne),G.return=Z,G):(G=Ul(ne.type,ne.key,ne.props,null,Z.mode,ye),Mo(G,ne),G.return=Z,G)}function ie(Z,G,ne,ye){return G===null||G.tag!==4||G.stateNode.containerInfo!==ne.containerInfo||G.stateNode.implementation!==ne.implementation?(G=Zu(ne,Z.mode,ye),G.return=Z,G):(G=u(G,ne.children||[]),G.return=Z,G)}function xe(Z,G,ne,ye,tt){return G===null||G.tag!==7?(G=Ur(ne,Z.mode,ye,tt),G.return=Z,G):(G=u(G,ne),G.return=Z,G)}function Ee(Z,G,ne){if(typeof G=="string"&&G!==""||typeof G=="number"||typeof G=="bigint")return G=Yu(""+G,Z.mode,ne),G.return=Z,G;if(typeof G=="object"&&G!==null){switch(G.$$typeof){case M:return ne=Ul(G.type,G.key,G.props,null,Z.mode,ne),Mo(ne,G),ne.return=Z,ne;case b:return G=Zu(G,Z.mode,ne),G.return=Z,G;case T:return G=Ir(G),Ee(Z,G,ne)}if(j(G)||Q(G))return G=Ur(G,Z.mode,ne,null),G.return=Z,G;if(typeof G.then=="function")return Ee(Z,Fl(G),ne);if(G.$$typeof===I)return Ee(Z,Ol(Z,G),ne);zl(Z,G)}return null}function le(Z,G,ne,ye){var tt=G!==null?G.key:null;if(typeof ne=="string"&&ne!==""||typeof ne=="number"||typeof ne=="bigint")return tt!==null?null:R(Z,G,""+ne,ye);if(typeof ne=="object"&&ne!==null){switch(ne.$$typeof){case M:return ne.key===tt?z(Z,G,ne,ye):null;case b:return ne.key===tt?ie(Z,G,ne,ye):null;case T:return ne=Ir(ne),le(Z,G,ne,ye)}if(j(ne)||Q(ne))return tt!==null?null:xe(Z,G,ne,ye,null);if(typeof ne.then=="function")return le(Z,G,Fl(ne),ye);if(ne.$$typeof===I)return le(Z,G,Ol(Z,ne),ye);zl(Z,ne)}return null}function ue(Z,G,ne,ye,tt){if(typeof ye=="string"&&ye!==""||typeof ye=="number"||typeof ye=="bigint")return Z=Z.get(ne)||null,R(G,Z,""+ye,tt);if(typeof ye=="object"&&ye!==null){switch(ye.$$typeof){case M:return Z=Z.get(ye.key===null?ne:ye.key)||null,z(G,Z,ye,tt);case b:return Z=Z.get(ye.key===null?ne:ye.key)||null,ie(G,Z,ye,tt);case T:return ye=Ir(ye),ue(Z,G,ne,ye,tt)}if(j(ye)||Q(ye))return Z=Z.get(ne)||null,xe(G,Z,ye,tt,null);if(typeof ye.then=="function")return ue(Z,G,ne,Fl(ye),tt);if(ye.$$typeof===I)return ue(Z,G,ne,Ol(G,ye),tt);zl(G,ye)}return null}function Ke(Z,G,ne,ye){for(var tt=null,Lt=null,Qe=G,ft=G=0,Mt=null;Qe!==null&&ft<ne.length;ft++){Qe.index>ft?(Mt=Qe,Qe=null):Mt=Qe.sibling;var Ot=le(Z,Qe,ne[ft],ye);if(Ot===null){Qe===null&&(Qe=Mt);break}t&&Qe&&Ot.alternate===null&&n(Z,Qe),G=d(Ot,G,ft),Lt===null?tt=Ot:Lt.sibling=Ot,Lt=Ot,Qe=Mt}if(ft===ne.length)return r(Z,Qe),Et&&fa(Z,ft),tt;if(Qe===null){for(;ft<ne.length;ft++)Qe=Ee(Z,ne[ft],ye),Qe!==null&&(G=d(Qe,G,ft),Lt===null?tt=Qe:Lt.sibling=Qe,Lt=Qe);return Et&&fa(Z,ft),tt}for(Qe=o(Qe);ft<ne.length;ft++)Mt=ue(Qe,Z,ft,ne[ft],ye),Mt!==null&&(t&&Mt.alternate!==null&&Qe.delete(Mt.key===null?ft:Mt.key),G=d(Mt,G,ft),Lt===null?tt=Mt:Lt.sibling=Mt,Lt=Mt);return t&&Qe.forEach(function(hr){return n(Z,hr)}),Et&&fa(Z,ft),tt}function it(Z,G,ne,ye){if(ne==null)throw Error(s(151));for(var tt=null,Lt=null,Qe=G,ft=G=0,Mt=null,Ot=ne.next();Qe!==null&&!Ot.done;ft++,Ot=ne.next()){Qe.index>ft?(Mt=Qe,Qe=null):Mt=Qe.sibling;var hr=le(Z,Qe,Ot.value,ye);if(hr===null){Qe===null&&(Qe=Mt);break}t&&Qe&&hr.alternate===null&&n(Z,Qe),G=d(hr,G,ft),Lt===null?tt=hr:Lt.sibling=hr,Lt=hr,Qe=Mt}if(Ot.done)return r(Z,Qe),Et&&fa(Z,ft),tt;if(Qe===null){for(;!Ot.done;ft++,Ot=ne.next())Ot=Ee(Z,Ot.value,ye),Ot!==null&&(G=d(Ot,G,ft),Lt===null?tt=Ot:Lt.sibling=Ot,Lt=Ot);return Et&&fa(Z,ft),tt}for(Qe=o(Qe);!Ot.done;ft++,Ot=ne.next())Ot=ue(Qe,Z,ft,Ot.value,ye),Ot!==null&&(t&&Ot.alternate!==null&&Qe.delete(Ot.key===null?ft:Ot.key),G=d(Ot,G,ft),Lt===null?tt=Ot:Lt.sibling=Ot,Lt=Ot);return t&&Qe.forEach(function(Yy){return n(Z,Yy)}),Et&&fa(Z,ft),tt}function Qt(Z,G,ne,ye){if(typeof ne=="object"&&ne!==null&&ne.type===C&&ne.key===null&&(ne=ne.props.children),typeof ne=="object"&&ne!==null){switch(ne.$$typeof){case M:e:{for(var tt=ne.key;G!==null;){if(G.key===tt){if(tt=ne.type,tt===C){if(G.tag===7){r(Z,G.sibling),ye=u(G,ne.props.children),ye.return=Z,Z=ye;break e}}else if(G.elementType===tt||typeof tt=="object"&&tt!==null&&tt.$$typeof===T&&Ir(tt)===G.type){r(Z,G.sibling),ye=u(G,ne.props),Mo(ye,ne),ye.return=Z,Z=ye;break e}r(Z,G);break}else n(Z,G);G=G.sibling}ne.type===C?(ye=Ur(ne.props.children,Z.mode,ye,ne.key),ye.return=Z,Z=ye):(ye=Ul(ne.type,ne.key,ne.props,null,Z.mode,ye),Mo(ye,ne),ye.return=Z,Z=ye)}return S(Z);case b:e:{for(tt=ne.key;G!==null;){if(G.key===tt)if(G.tag===4&&G.stateNode.containerInfo===ne.containerInfo&&G.stateNode.implementation===ne.implementation){r(Z,G.sibling),ye=u(G,ne.children||[]),ye.return=Z,Z=ye;break e}else{r(Z,G);break}else n(Z,G);G=G.sibling}ye=Zu(ne,Z.mode,ye),ye.return=Z,Z=ye}return S(Z);case T:return ne=Ir(ne),Qt(Z,G,ne,ye)}if(j(ne))return Ke(Z,G,ne,ye);if(Q(ne)){if(tt=Q(ne),typeof tt!="function")throw Error(s(150));return ne=tt.call(ne),it(Z,G,ne,ye)}if(typeof ne.then=="function")return Qt(Z,G,Fl(ne),ye);if(ne.$$typeof===I)return Qt(Z,G,Ol(Z,ne),ye);zl(Z,ne)}return typeof ne=="string"&&ne!==""||typeof ne=="number"||typeof ne=="bigint"?(ne=""+ne,G!==null&&G.tag===6?(r(Z,G.sibling),ye=u(G,ne),ye.return=Z,Z=ye):(r(Z,G),ye=Yu(ne,Z.mode,ye),ye.return=Z,Z=ye),S(Z)):r(Z,G)}return function(Z,G,ne,ye){try{yo=0;var tt=Qt(Z,G,ne,ye);return _s=null,tt}catch(Qe){if(Qe===vs||Qe===Il)throw Qe;var Lt=ai(29,Qe,null,Z.mode);return Lt.lanes=ye,Lt.return=Z,Lt}}}var Fr=Um(!0),Nm=Um(!1),Qa=!1;function of(t){t.updateQueue={baseState:t.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function lf(t,n){t=t.updateQueue,n.updateQueue===t&&(n.updateQueue={baseState:t.baseState,firstBaseUpdate:t.firstBaseUpdate,lastBaseUpdate:t.lastBaseUpdate,shared:t.shared,callbacks:null})}function ja(t){return{lane:t,tag:0,payload:null,callback:null,next:null}}function Ja(t,n,r){var o=t.updateQueue;if(o===null)return null;if(o=o.shared,(It&2)!==0){var u=o.pending;return u===null?n.next=n:(n.next=u.next,u.next=n),o.pending=n,n=Dl(t),mm(t,null,r),n}return wl(t,o,n,r),Dl(t)}function Eo(t,n,r){if(n=n.updateQueue,n!==null&&(n=n.shared,(r&4194048)!==0)){var o=n.lanes;o&=t.pendingLanes,r|=o,n.lanes=r,en(t,r)}}function cf(t,n){var r=t.updateQueue,o=t.alternate;if(o!==null&&(o=o.updateQueue,r===o)){var u=null,d=null;if(r=r.firstBaseUpdate,r!==null){do{var S={lane:r.lane,tag:r.tag,payload:r.payload,callback:null,next:null};d===null?u=d=S:d=d.next=S,r=r.next}while(r!==null);d===null?u=d=n:d=d.next=n}else u=d=n;r={baseState:o.baseState,firstBaseUpdate:u,lastBaseUpdate:d,shared:o.shared,callbacks:o.callbacks},t.updateQueue=r;return}t=r.lastBaseUpdate,t===null?r.firstBaseUpdate=n:t.next=n,r.lastBaseUpdate=n}var uf=!1;function bo(){if(uf){var t=gs;if(t!==null)throw t}}function To(t,n,r,o){uf=!1;var u=t.updateQueue;Qa=!1;var d=u.firstBaseUpdate,S=u.lastBaseUpdate,R=u.shared.pending;if(R!==null){u.shared.pending=null;var z=R,ie=z.next;z.next=null,S===null?d=ie:S.next=ie,S=z;var xe=t.alternate;xe!==null&&(xe=xe.updateQueue,R=xe.lastBaseUpdate,R!==S&&(R===null?xe.firstBaseUpdate=ie:R.next=ie,xe.lastBaseUpdate=z))}if(d!==null){var Ee=u.baseState;S=0,xe=ie=z=null,R=d;do{var le=R.lane&-536870913,ue=le!==R.lane;if(ue?(yt&le)===le:(o&le)===le){le!==0&&le===ms&&(uf=!0),xe!==null&&(xe=xe.next={lane:0,tag:R.tag,payload:R.payload,callback:null,next:null});e:{var Ke=t,it=R;le=n;var Qt=r;switch(it.tag){case 1:if(Ke=it.payload,typeof Ke=="function"){Ee=Ke.call(Qt,Ee,le);break e}Ee=Ke;break e;case 3:Ke.flags=Ke.flags&-65537|128;case 0:if(Ke=it.payload,le=typeof Ke=="function"?Ke.call(Qt,Ee,le):Ke,le==null)break e;Ee=g({},Ee,le);break e;case 2:Qa=!0}}le=R.callback,le!==null&&(t.flags|=64,ue&&(t.flags|=8192),ue=u.callbacks,ue===null?u.callbacks=[le]:ue.push(le))}else ue={lane:le,tag:R.tag,payload:R.payload,callback:R.callback,next:null},xe===null?(ie=xe=ue,z=Ee):xe=xe.next=ue,S|=le;if(R=R.next,R===null){if(R=u.shared.pending,R===null)break;ue=R,R=ue.next,ue.next=null,u.lastBaseUpdate=ue,u.shared.pending=null}}while(!0);xe===null&&(z=Ee),u.baseState=z,u.firstBaseUpdate=ie,u.lastBaseUpdate=xe,d===null&&(u.shared.lanes=0),ir|=S,t.lanes=S,t.memoizedState=Ee}}function Lm(t,n){if(typeof t!="function")throw Error(s(191,t));t.call(n)}function Om(t,n){var r=t.callbacks;if(r!==null)for(t.callbacks=null,t=0;t<r.length;t++)Lm(r[t],n)}var xs=N(null),Hl=N(0);function Pm(t,n){t=Ma,de(Hl,t),de(xs,n),Ma=t|n.baseLanes}function ff(){de(Hl,Ma),de(xs,xs.current)}function df(){Ma=Hl.current,Y(xs),Y(Hl)}var ri=N(null),yi=null;function $a(t){var n=t.alternate;de(hn,hn.current&1),de(ri,t),yi===null&&(n===null||xs.current!==null||n.memoizedState!==null)&&(yi=t)}function hf(t){de(hn,hn.current),de(ri,t),yi===null&&(yi=t)}function Im(t){t.tag===22?(de(hn,hn.current),de(ri,t),yi===null&&(yi=t)):er()}function er(){de(hn,hn.current),de(ri,ri.current)}function si(t){Y(ri),yi===t&&(yi=null),Y(hn)}var hn=N(0);function Gl(t){for(var n=t;n!==null;){if(n.tag===13){var r=n.memoizedState;if(r!==null&&(r=r.dehydrated,r===null||xd(r)||Sd(r)))return n}else if(n.tag===19&&(n.memoizedProps.revealOrder==="forwards"||n.memoizedProps.revealOrder==="backwards"||n.memoizedProps.revealOrder==="unstable_legacy-backwards"||n.memoizedProps.revealOrder==="together")){if((n.flags&128)!==0)return n}else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return null;n=n.return}n.sibling.return=n.return,n=n.sibling}return null}var pa=0,ct=null,Zt=null,_n=null,Vl=!1,Ss=!1,zr=!1,kl=0,Ao=0,ys=null,BS=0;function un(){throw Error(s(321))}function pf(t,n){if(n===null)return!1;for(var r=0;r<n.length&&r<t.length;r++)if(!ii(t[r],n[r]))return!1;return!0}function mf(t,n,r,o,u,d){return pa=d,ct=n,n.memoizedState=null,n.updateQueue=null,n.lanes=0,L.H=t===null||t.memoizedState===null?xg:Df,zr=!1,d=r(o,u),zr=!1,Ss&&(d=Fm(n,r,o,u)),Bm(t),d}function Bm(t){L.H=wo;var n=Zt!==null&&Zt.next!==null;if(pa=0,_n=Zt=ct=null,Vl=!1,Ao=0,ys=null,n)throw Error(s(300));t===null||xn||(t=t.dependencies,t!==null&&Ll(t)&&(xn=!0))}function Fm(t,n,r,o){ct=t;var u=0;do{if(Ss&&(ys=null),Ao=0,Ss=!1,25<=u)throw Error(s(301));if(u+=1,_n=Zt=null,t.updateQueue!=null){var d=t.updateQueue;d.lastEffect=null,d.events=null,d.stores=null,d.memoCache!=null&&(d.memoCache.index=0)}L.H=Sg,d=n(r,o)}while(Ss);return d}function FS(){var t=L.H,n=t.useState()[0];return n=typeof n.then=="function"?Ro(n):n,t=t.useState()[0],(Zt!==null?Zt.memoizedState:null)!==t&&(ct.flags|=1024),n}function gf(){var t=kl!==0;return kl=0,t}function vf(t,n,r){n.updateQueue=t.updateQueue,n.flags&=-2053,t.lanes&=~r}function _f(t){if(Vl){for(t=t.memoizedState;t!==null;){var n=t.queue;n!==null&&(n.pending=null),t=t.next}Vl=!1}pa=0,_n=Zt=ct=null,Ss=!1,Ao=kl=0,ys=null}function Gn(){var t={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return _n===null?ct.memoizedState=_n=t:_n=_n.next=t,_n}function pn(){if(Zt===null){var t=ct.alternate;t=t!==null?t.memoizedState:null}else t=Zt.next;var n=_n===null?ct.memoizedState:_n.next;if(n!==null)_n=n,Zt=t;else{if(t===null)throw ct.alternate===null?Error(s(467)):Error(s(310));Zt=t,t={memoizedState:Zt.memoizedState,baseState:Zt.baseState,baseQueue:Zt.baseQueue,queue:Zt.queue,next:null},_n===null?ct.memoizedState=_n=t:_n=_n.next=t}return _n}function Xl(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Ro(t){var n=Ao;return Ao+=1,ys===null&&(ys=[]),t=Cm(ys,t,n),n=ct,(_n===null?n.memoizedState:_n.next)===null&&(n=n.alternate,L.H=n===null||n.memoizedState===null?xg:Df),t}function Wl(t){if(t!==null&&typeof t=="object"){if(typeof t.then=="function")return Ro(t);if(t.$$typeof===I)return Nn(t)}throw Error(s(438,String(t)))}function xf(t){var n=null,r=ct.updateQueue;if(r!==null&&(n=r.memoCache),n==null){var o=ct.alternate;o!==null&&(o=o.updateQueue,o!==null&&(o=o.memoCache,o!=null&&(n={data:o.data.map(function(u){return u.slice()}),index:0})))}if(n==null&&(n={data:[],index:0}),r===null&&(r=Xl(),ct.updateQueue=r),r.memoCache=n,r=n.data[n.index],r===void 0)for(r=n.data[n.index]=Array(t),o=0;o<t;o++)r[o]=q;return n.index++,r}function ma(t,n){return typeof n=="function"?n(t):n}function ql(t){var n=pn();return Sf(n,Zt,t)}function Sf(t,n,r){var o=t.queue;if(o===null)throw Error(s(311));o.lastRenderedReducer=r;var u=t.baseQueue,d=o.pending;if(d!==null){if(u!==null){var S=u.next;u.next=d.next,d.next=S}n.baseQueue=u=d,o.pending=null}if(d=t.baseState,u===null)t.memoizedState=d;else{n=u.next;var R=S=null,z=null,ie=n,xe=!1;do{var Ee=ie.lane&-536870913;if(Ee!==ie.lane?(yt&Ee)===Ee:(pa&Ee)===Ee){var le=ie.revertLane;if(le===0)z!==null&&(z=z.next={lane:0,revertLane:0,gesture:null,action:ie.action,hasEagerState:ie.hasEagerState,eagerState:ie.eagerState,next:null}),Ee===ms&&(xe=!0);else if((pa&le)===le){ie=ie.next,le===ms&&(xe=!0);continue}else Ee={lane:0,revertLane:ie.revertLane,gesture:null,action:ie.action,hasEagerState:ie.hasEagerState,eagerState:ie.eagerState,next:null},z===null?(R=z=Ee,S=d):z=z.next=Ee,ct.lanes|=le,ir|=le;Ee=ie.action,zr&&r(d,Ee),d=ie.hasEagerState?ie.eagerState:r(d,Ee)}else le={lane:Ee,revertLane:ie.revertLane,gesture:ie.gesture,action:ie.action,hasEagerState:ie.hasEagerState,eagerState:ie.eagerState,next:null},z===null?(R=z=le,S=d):z=z.next=le,ct.lanes|=Ee,ir|=Ee;ie=ie.next}while(ie!==null&&ie!==n);if(z===null?S=d:z.next=R,!ii(d,t.memoizedState)&&(xn=!0,xe&&(r=gs,r!==null)))throw r;t.memoizedState=d,t.baseState=S,t.baseQueue=z,o.lastRenderedState=d}return u===null&&(o.lanes=0),[t.memoizedState,o.dispatch]}function yf(t){var n=pn(),r=n.queue;if(r===null)throw Error(s(311));r.lastRenderedReducer=t;var o=r.dispatch,u=r.pending,d=n.memoizedState;if(u!==null){r.pending=null;var S=u=u.next;do d=t(d,S.action),S=S.next;while(S!==u);ii(d,n.memoizedState)||(xn=!0),n.memoizedState=d,n.baseQueue===null&&(n.baseState=d),r.lastRenderedState=d}return[d,o]}function zm(t,n,r){var o=ct,u=pn(),d=Et;if(d){if(r===void 0)throw Error(s(407));r=r()}else r=n();var S=!ii((Zt||u).memoizedState,r);if(S&&(u.memoizedState=r,xn=!0),u=u.queue,bf(Vm.bind(null,o,u,t),[t]),u.getSnapshot!==n||S||_n!==null&&_n.memoizedState.tag&1){if(o.flags|=2048,Ms(9,{destroy:void 0},Gm.bind(null,o,u,r,n),null),Jt===null)throw Error(s(349));d||(pa&127)!==0||Hm(o,n,r)}return r}function Hm(t,n,r){t.flags|=16384,t={getSnapshot:n,value:r},n=ct.updateQueue,n===null?(n=Xl(),ct.updateQueue=n,n.stores=[t]):(r=n.stores,r===null?n.stores=[t]:r.push(t))}function Gm(t,n,r,o){n.value=r,n.getSnapshot=o,km(n)&&Xm(t)}function Vm(t,n,r){return r(function(){km(n)&&Xm(t)})}function km(t){var n=t.getSnapshot;t=t.value;try{var r=n();return!ii(t,r)}catch{return!0}}function Xm(t){var n=Dr(t,2);n!==null&&Qn(n,t,2)}function Mf(t){var n=Gn();if(typeof t=="function"){var r=t;if(t=r(),zr){Ne(!0);try{r()}finally{Ne(!1)}}}return n.memoizedState=n.baseState=t,n.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:ma,lastRenderedState:t},n}function Wm(t,n,r,o){return t.baseState=r,Sf(t,Zt,typeof o=="function"?o:ma)}function zS(t,n,r,o,u){if(Kl(t))throw Error(s(485));if(t=n.action,t!==null){var d={payload:u,action:t,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(S){d.listeners.push(S)}};L.T!==null?r(!0):d.isTransition=!1,o(d),r=n.pending,r===null?(d.next=n.pending=d,qm(n,d)):(d.next=r.next,n.pending=r.next=d)}}function qm(t,n){var r=n.action,o=n.payload,u=t.state;if(n.isTransition){var d=L.T,S={};L.T=S;try{var R=r(u,o),z=L.S;z!==null&&z(S,R),Ym(t,n,R)}catch(ie){Ef(t,n,ie)}finally{d!==null&&S.types!==null&&(d.types=S.types),L.T=d}}else try{d=r(u,o),Ym(t,n,d)}catch(ie){Ef(t,n,ie)}}function Ym(t,n,r){r!==null&&typeof r=="object"&&typeof r.then=="function"?r.then(function(o){Zm(t,n,o)},function(o){return Ef(t,n,o)}):Zm(t,n,r)}function Zm(t,n,r){n.status="fulfilled",n.value=r,Km(n),t.state=r,n=t.pending,n!==null&&(r=n.next,r===n?t.pending=null:(r=r.next,n.next=r,qm(t,r)))}function Ef(t,n,r){var o=t.pending;if(t.pending=null,o!==null){o=o.next;do n.status="rejected",n.reason=r,Km(n),n=n.next;while(n!==o)}t.action=null}function Km(t){t=t.listeners;for(var n=0;n<t.length;n++)(0,t[n])()}function Qm(t,n){return n}function jm(t,n){if(Et){var r=Jt.formState;if(r!==null){e:{var o=ct;if(Et){if(nn){t:{for(var u=nn,d=Si;u.nodeType!==8;){if(!d){u=null;break t}if(u=Mi(u.nextSibling),u===null){u=null;break t}}d=u.data,u=d==="F!"||d==="F"?u:null}if(u){nn=Mi(u.nextSibling),o=u.data==="F!";break e}}Za(o)}o=!1}o&&(n=r[0])}}return r=Gn(),r.memoizedState=r.baseState=n,o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Qm,lastRenderedState:n},r.queue=o,r=gg.bind(null,ct,o),o.dispatch=r,o=Mf(!1),d=wf.bind(null,ct,!1,o.queue),o=Gn(),u={state:n,dispatch:null,action:t,pending:null},o.queue=u,r=zS.bind(null,ct,u,d,r),u.dispatch=r,o.memoizedState=t,[n,r,!1]}function Jm(t){var n=pn();return $m(n,Zt,t)}function $m(t,n,r){if(n=Sf(t,n,Qm)[0],t=ql(ma)[0],typeof n=="object"&&n!==null&&typeof n.then=="function")try{var o=Ro(n)}catch(S){throw S===vs?Il:S}else o=n;n=pn();var u=n.queue,d=u.dispatch;return r!==n.memoizedState&&(ct.flags|=2048,Ms(9,{destroy:void 0},HS.bind(null,u,r),null)),[o,d,t]}function HS(t,n){t.action=n}function eg(t){var n=pn(),r=Zt;if(r!==null)return $m(n,r,t);pn(),n=n.memoizedState,r=pn();var o=r.queue.dispatch;return r.memoizedState=t,[n,o,!1]}function Ms(t,n,r,o){return t={tag:t,create:r,deps:o,inst:n,next:null},n=ct.updateQueue,n===null&&(n=Xl(),ct.updateQueue=n),r=n.lastEffect,r===null?n.lastEffect=t.next=t:(o=r.next,r.next=t,t.next=o,n.lastEffect=t),t}function tg(){return pn().memoizedState}function Yl(t,n,r,o){var u=Gn();ct.flags|=t,u.memoizedState=Ms(1|n,{destroy:void 0},r,o===void 0?null:o)}function Zl(t,n,r,o){var u=pn();o=o===void 0?null:o;var d=u.memoizedState.inst;Zt!==null&&o!==null&&pf(o,Zt.memoizedState.deps)?u.memoizedState=Ms(n,d,r,o):(ct.flags|=t,u.memoizedState=Ms(1|n,d,r,o))}function ng(t,n){Yl(8390656,8,t,n)}function bf(t,n){Zl(2048,8,t,n)}function GS(t){ct.flags|=4;var n=ct.updateQueue;if(n===null)n=Xl(),ct.updateQueue=n,n.events=[t];else{var r=n.events;r===null?n.events=[t]:r.push(t)}}function ig(t){var n=pn().memoizedState;return GS({ref:n,nextImpl:t}),function(){if((It&2)!==0)throw Error(s(440));return n.impl.apply(void 0,arguments)}}function ag(t,n){return Zl(4,2,t,n)}function rg(t,n){return Zl(4,4,t,n)}function sg(t,n){if(typeof n=="function"){t=t();var r=n(t);return function(){typeof r=="function"?r():n(null)}}if(n!=null)return t=t(),n.current=t,function(){n.current=null}}function og(t,n,r){r=r!=null?r.concat([t]):null,Zl(4,4,sg.bind(null,n,t),r)}function Tf(){}function lg(t,n){var r=pn();n=n===void 0?null:n;var o=r.memoizedState;return n!==null&&pf(n,o[1])?o[0]:(r.memoizedState=[t,n],t)}function cg(t,n){var r=pn();n=n===void 0?null:n;var o=r.memoizedState;if(n!==null&&pf(n,o[1]))return o[0];if(o=t(),zr){Ne(!0);try{t()}finally{Ne(!1)}}return r.memoizedState=[o,n],o}function Af(t,n,r){return r===void 0||(pa&1073741824)!==0&&(yt&261930)===0?t.memoizedState=n:(t.memoizedState=r,t=u0(),ct.lanes|=t,ir|=t,r)}function ug(t,n,r,o){return ii(r,n)?r:xs.current!==null?(t=Af(t,r,o),ii(t,n)||(xn=!0),t):(pa&42)===0||(pa&1073741824)!==0&&(yt&261930)===0?(xn=!0,t.memoizedState=r):(t=u0(),ct.lanes|=t,ir|=t,n)}function fg(t,n,r,o,u){var d=H.p;H.p=d!==0&&8>d?d:8;var S=L.T,R={};L.T=R,wf(t,!1,n,r);try{var z=u(),ie=L.S;if(ie!==null&&ie(R,z),z!==null&&typeof z=="object"&&typeof z.then=="function"){var xe=IS(z,o);Co(t,n,xe,ci(t))}else Co(t,n,o,ci(t))}catch(Ee){Co(t,n,{then:function(){},status:"rejected",reason:Ee},ci())}finally{H.p=d,S!==null&&R.types!==null&&(S.types=R.types),L.T=S}}function VS(){}function Rf(t,n,r,o){if(t.tag!==5)throw Error(s(476));var u=dg(t).queue;fg(t,u,n,$,r===null?VS:function(){return hg(t),r(o)})}function dg(t){var n=t.memoizedState;if(n!==null)return n;n={memoizedState:$,baseState:$,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ma,lastRenderedState:$},next:null};var r={};return n.next={memoizedState:r,baseState:r,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ma,lastRenderedState:r},next:null},t.memoizedState=n,t=t.alternate,t!==null&&(t.memoizedState=n),n}function hg(t){var n=dg(t);n.next===null&&(n=t.alternate.memoizedState),Co(t,n.next.queue,{},ci())}function Cf(){return Nn(Wo)}function pg(){return pn().memoizedState}function mg(){return pn().memoizedState}function kS(t){for(var n=t.return;n!==null;){switch(n.tag){case 24:case 3:var r=ci();t=ja(r);var o=Ja(n,t,r);o!==null&&(Qn(o,n,r),Eo(o,n,r)),n={cache:nf()},t.payload=n;return}n=n.return}}function XS(t,n,r){var o=ci();r={lane:o,revertLane:0,gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null},Kl(t)?vg(n,r):(r=Wu(t,n,r,o),r!==null&&(Qn(r,t,o),_g(r,n,o)))}function gg(t,n,r){var o=ci();Co(t,n,r,o)}function Co(t,n,r,o){var u={lane:o,revertLane:0,gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null};if(Kl(t))vg(n,u);else{var d=t.alternate;if(t.lanes===0&&(d===null||d.lanes===0)&&(d=n.lastRenderedReducer,d!==null))try{var S=n.lastRenderedState,R=d(S,r);if(u.hasEagerState=!0,u.eagerState=R,ii(R,S))return wl(t,n,u,0),Jt===null&&Cl(),!1}catch{}if(r=Wu(t,n,u,o),r!==null)return Qn(r,t,o),_g(r,n,o),!0}return!1}function wf(t,n,r,o){if(o={lane:2,revertLane:od(),gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null},Kl(t)){if(n)throw Error(s(479))}else n=Wu(t,r,o,2),n!==null&&Qn(n,t,2)}function Kl(t){var n=t.alternate;return t===ct||n!==null&&n===ct}function vg(t,n){Ss=Vl=!0;var r=t.pending;r===null?n.next=n:(n.next=r.next,r.next=n),t.pending=n}function _g(t,n,r){if((r&4194048)!==0){var o=n.lanes;o&=t.pendingLanes,r|=o,n.lanes=r,en(t,r)}}var wo={readContext:Nn,use:Wl,useCallback:un,useContext:un,useEffect:un,useImperativeHandle:un,useLayoutEffect:un,useInsertionEffect:un,useMemo:un,useReducer:un,useRef:un,useState:un,useDebugValue:un,useDeferredValue:un,useTransition:un,useSyncExternalStore:un,useId:un,useHostTransitionStatus:un,useFormState:un,useActionState:un,useOptimistic:un,useMemoCache:un,useCacheRefresh:un};wo.useEffectEvent=un;var xg={readContext:Nn,use:Wl,useCallback:function(t,n){return Gn().memoizedState=[t,n===void 0?null:n],t},useContext:Nn,useEffect:ng,useImperativeHandle:function(t,n,r){r=r!=null?r.concat([t]):null,Yl(4194308,4,sg.bind(null,n,t),r)},useLayoutEffect:function(t,n){return Yl(4194308,4,t,n)},useInsertionEffect:function(t,n){Yl(4,2,t,n)},useMemo:function(t,n){var r=Gn();n=n===void 0?null:n;var o=t();if(zr){Ne(!0);try{t()}finally{Ne(!1)}}return r.memoizedState=[o,n],o},useReducer:function(t,n,r){var o=Gn();if(r!==void 0){var u=r(n);if(zr){Ne(!0);try{r(n)}finally{Ne(!1)}}}else u=n;return o.memoizedState=o.baseState=u,t={pending:null,lanes:0,dispatch:null,lastRenderedReducer:t,lastRenderedState:u},o.queue=t,t=t.dispatch=XS.bind(null,ct,t),[o.memoizedState,t]},useRef:function(t){var n=Gn();return t={current:t},n.memoizedState=t},useState:function(t){t=Mf(t);var n=t.queue,r=gg.bind(null,ct,n);return n.dispatch=r,[t.memoizedState,r]},useDebugValue:Tf,useDeferredValue:function(t,n){var r=Gn();return Af(r,t,n)},useTransition:function(){var t=Mf(!1);return t=fg.bind(null,ct,t.queue,!0,!1),Gn().memoizedState=t,[!1,t]},useSyncExternalStore:function(t,n,r){var o=ct,u=Gn();if(Et){if(r===void 0)throw Error(s(407));r=r()}else{if(r=n(),Jt===null)throw Error(s(349));(yt&127)!==0||Hm(o,n,r)}u.memoizedState=r;var d={value:r,getSnapshot:n};return u.queue=d,ng(Vm.bind(null,o,d,t),[t]),o.flags|=2048,Ms(9,{destroy:void 0},Gm.bind(null,o,d,r,n),null),r},useId:function(){var t=Gn(),n=Jt.identifierPrefix;if(Et){var r=qi,o=Wi;r=(o&~(1<<32-Ve(o)-1)).toString(32)+r,n="_"+n+"R_"+r,r=kl++,0<r&&(n+="H"+r.toString(32)),n+="_"}else r=BS++,n="_"+n+"r_"+r.toString(32)+"_";return t.memoizedState=n},useHostTransitionStatus:Cf,useFormState:jm,useActionState:jm,useOptimistic:function(t){var n=Gn();n.memoizedState=n.baseState=t;var r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return n.queue=r,n=wf.bind(null,ct,!0,r),r.dispatch=n,[t,n]},useMemoCache:xf,useCacheRefresh:function(){return Gn().memoizedState=kS.bind(null,ct)},useEffectEvent:function(t){var n=Gn(),r={impl:t};return n.memoizedState=r,function(){if((It&2)!==0)throw Error(s(440));return r.impl.apply(void 0,arguments)}}},Df={readContext:Nn,use:Wl,useCallback:lg,useContext:Nn,useEffect:bf,useImperativeHandle:og,useInsertionEffect:ag,useLayoutEffect:rg,useMemo:cg,useReducer:ql,useRef:tg,useState:function(){return ql(ma)},useDebugValue:Tf,useDeferredValue:function(t,n){var r=pn();return ug(r,Zt.memoizedState,t,n)},useTransition:function(){var t=ql(ma)[0],n=pn().memoizedState;return[typeof t=="boolean"?t:Ro(t),n]},useSyncExternalStore:zm,useId:pg,useHostTransitionStatus:Cf,useFormState:Jm,useActionState:Jm,useOptimistic:function(t,n){var r=pn();return Wm(r,Zt,t,n)},useMemoCache:xf,useCacheRefresh:mg};Df.useEffectEvent=ig;var Sg={readContext:Nn,use:Wl,useCallback:lg,useContext:Nn,useEffect:bf,useImperativeHandle:og,useInsertionEffect:ag,useLayoutEffect:rg,useMemo:cg,useReducer:yf,useRef:tg,useState:function(){return yf(ma)},useDebugValue:Tf,useDeferredValue:function(t,n){var r=pn();return Zt===null?Af(r,t,n):ug(r,Zt.memoizedState,t,n)},useTransition:function(){var t=yf(ma)[0],n=pn().memoizedState;return[typeof t=="boolean"?t:Ro(t),n]},useSyncExternalStore:zm,useId:pg,useHostTransitionStatus:Cf,useFormState:eg,useActionState:eg,useOptimistic:function(t,n){var r=pn();return Zt!==null?Wm(r,Zt,t,n):(r.baseState=t,[t,r.queue.dispatch])},useMemoCache:xf,useCacheRefresh:mg};Sg.useEffectEvent=ig;function Uf(t,n,r,o){n=t.memoizedState,r=r(o,n),r=r==null?n:g({},n,r),t.memoizedState=r,t.lanes===0&&(t.updateQueue.baseState=r)}var Nf={enqueueSetState:function(t,n,r){t=t._reactInternals;var o=ci(),u=ja(o);u.payload=n,r!=null&&(u.callback=r),n=Ja(t,u,o),n!==null&&(Qn(n,t,o),Eo(n,t,o))},enqueueReplaceState:function(t,n,r){t=t._reactInternals;var o=ci(),u=ja(o);u.tag=1,u.payload=n,r!=null&&(u.callback=r),n=Ja(t,u,o),n!==null&&(Qn(n,t,o),Eo(n,t,o))},enqueueForceUpdate:function(t,n){t=t._reactInternals;var r=ci(),o=ja(r);o.tag=2,n!=null&&(o.callback=n),n=Ja(t,o,r),n!==null&&(Qn(n,t,r),Eo(n,t,r))}};function yg(t,n,r,o,u,d,S){return t=t.stateNode,typeof t.shouldComponentUpdate=="function"?t.shouldComponentUpdate(o,d,S):n.prototype&&n.prototype.isPureReactComponent?!mo(r,o)||!mo(u,d):!0}function Mg(t,n,r,o){t=n.state,typeof n.componentWillReceiveProps=="function"&&n.componentWillReceiveProps(r,o),typeof n.UNSAFE_componentWillReceiveProps=="function"&&n.UNSAFE_componentWillReceiveProps(r,o),n.state!==t&&Nf.enqueueReplaceState(n,n.state,null)}function Hr(t,n){var r=n;if("ref"in n){r={};for(var o in n)o!=="ref"&&(r[o]=n[o])}if(t=t.defaultProps){r===n&&(r=g({},r));for(var u in t)r[u]===void 0&&(r[u]=t[u])}return r}function Eg(t){Rl(t)}function bg(t){console.error(t)}function Tg(t){Rl(t)}function Ql(t,n){try{var r=t.onUncaughtError;r(n.value,{componentStack:n.stack})}catch(o){setTimeout(function(){throw o})}}function Ag(t,n,r){try{var o=t.onCaughtError;o(r.value,{componentStack:r.stack,errorBoundary:n.tag===1?n.stateNode:null})}catch(u){setTimeout(function(){throw u})}}function Lf(t,n,r){return r=ja(r),r.tag=3,r.payload={element:null},r.callback=function(){Ql(t,n)},r}function Rg(t){return t=ja(t),t.tag=3,t}function Cg(t,n,r,o){var u=r.type.getDerivedStateFromError;if(typeof u=="function"){var d=o.value;t.payload=function(){return u(d)},t.callback=function(){Ag(n,r,o)}}var S=r.stateNode;S!==null&&typeof S.componentDidCatch=="function"&&(t.callback=function(){Ag(n,r,o),typeof u!="function"&&(ar===null?ar=new Set([this]):ar.add(this));var R=o.stack;this.componentDidCatch(o.value,{componentStack:R!==null?R:""})})}function WS(t,n,r,o,u){if(r.flags|=32768,o!==null&&typeof o=="object"&&typeof o.then=="function"){if(n=r.alternate,n!==null&&ps(n,r,u,!0),r=ri.current,r!==null){switch(r.tag){case 31:case 13:return yi===null?lc():r.alternate===null&&fn===0&&(fn=3),r.flags&=-257,r.flags|=65536,r.lanes=u,o===Bl?r.flags|=16384:(n=r.updateQueue,n===null?r.updateQueue=new Set([o]):n.add(o),ad(t,o,u)),!1;case 22:return r.flags|=65536,o===Bl?r.flags|=16384:(n=r.updateQueue,n===null?(n={transitions:null,markerInstances:null,retryQueue:new Set([o])},r.updateQueue=n):(r=n.retryQueue,r===null?n.retryQueue=new Set([o]):r.add(o)),ad(t,o,u)),!1}throw Error(s(435,r.tag))}return ad(t,o,u),lc(),!1}if(Et)return n=ri.current,n!==null?((n.flags&65536)===0&&(n.flags|=256),n.flags|=65536,n.lanes=u,o!==ju&&(t=Error(s(422),{cause:o}),_o(vi(t,r)))):(o!==ju&&(n=Error(s(423),{cause:o}),_o(vi(n,r))),t=t.current.alternate,t.flags|=65536,u&=-u,t.lanes|=u,o=vi(o,r),u=Lf(t.stateNode,o,u),cf(t,u),fn!==4&&(fn=2)),!1;var d=Error(s(520),{cause:o});if(d=vi(d,r),Bo===null?Bo=[d]:Bo.push(d),fn!==4&&(fn=2),n===null)return!0;o=vi(o,r),r=n;do{switch(r.tag){case 3:return r.flags|=65536,t=u&-u,r.lanes|=t,t=Lf(r.stateNode,o,t),cf(r,t),!1;case 1:if(n=r.type,d=r.stateNode,(r.flags&128)===0&&(typeof n.getDerivedStateFromError=="function"||d!==null&&typeof d.componentDidCatch=="function"&&(ar===null||!ar.has(d))))return r.flags|=65536,u&=-u,r.lanes|=u,u=Rg(u),Cg(u,t,r,o),cf(r,u),!1}r=r.return}while(r!==null);return!1}var Of=Error(s(461)),xn=!1;function Ln(t,n,r,o){n.child=t===null?Nm(n,null,r,o):Fr(n,t.child,r,o)}function wg(t,n,r,o,u){r=r.render;var d=n.ref;if("ref"in o){var S={};for(var R in o)R!=="ref"&&(S[R]=o[R])}else S=o;return Or(n),o=mf(t,n,r,S,d,u),R=gf(),t!==null&&!xn?(vf(t,n,u),ga(t,n,u)):(Et&&R&&Ku(n),n.flags|=1,Ln(t,n,o,u),n.child)}function Dg(t,n,r,o,u){if(t===null){var d=r.type;return typeof d=="function"&&!qu(d)&&d.defaultProps===void 0&&r.compare===null?(n.tag=15,n.type=d,Ug(t,n,d,o,u)):(t=Ul(r.type,null,o,n,n.mode,u),t.ref=n.ref,t.return=n,n.child=t)}if(d=t.child,!Vf(t,u)){var S=d.memoizedProps;if(r=r.compare,r=r!==null?r:mo,r(S,o)&&t.ref===n.ref)return ga(t,n,u)}return n.flags|=1,t=ua(d,o),t.ref=n.ref,t.return=n,n.child=t}function Ug(t,n,r,o,u){if(t!==null){var d=t.memoizedProps;if(mo(d,o)&&t.ref===n.ref)if(xn=!1,n.pendingProps=o=d,Vf(t,u))(t.flags&131072)!==0&&(xn=!0);else return n.lanes=t.lanes,ga(t,n,u)}return Pf(t,n,r,o,u)}function Ng(t,n,r,o){var u=o.children,d=t!==null?t.memoizedState:null;if(t===null&&n.stateNode===null&&(n.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),o.mode==="hidden"){if((n.flags&128)!==0){if(d=d!==null?d.baseLanes|r:r,t!==null){for(o=n.child=t.child,u=0;o!==null;)u=u|o.lanes|o.childLanes,o=o.sibling;o=u&~d}else o=0,n.child=null;return Lg(t,n,d,r,o)}if((r&536870912)!==0)n.memoizedState={baseLanes:0,cachePool:null},t!==null&&Pl(n,d!==null?d.cachePool:null),d!==null?Pm(n,d):ff(),Im(n);else return o=n.lanes=536870912,Lg(t,n,d!==null?d.baseLanes|r:r,r,o)}else d!==null?(Pl(n,d.cachePool),Pm(n,d),er(),n.memoizedState=null):(t!==null&&Pl(n,null),ff(),er());return Ln(t,n,u,r),n.child}function Do(t,n){return t!==null&&t.tag===22||n.stateNode!==null||(n.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),n.sibling}function Lg(t,n,r,o,u){var d=rf();return d=d===null?null:{parent:vn._currentValue,pool:d},n.memoizedState={baseLanes:r,cachePool:d},t!==null&&Pl(n,null),ff(),Im(n),t!==null&&ps(t,n,o,!0),n.childLanes=u,null}function jl(t,n){return n=$l({mode:n.mode,children:n.children},t.mode),n.ref=t.ref,t.child=n,n.return=t,n}function Og(t,n,r){return Fr(n,t.child,null,r),t=jl(n,n.pendingProps),t.flags|=2,si(n),n.memoizedState=null,t}function qS(t,n,r){var o=n.pendingProps,u=(n.flags&128)!==0;if(n.flags&=-129,t===null){if(Et){if(o.mode==="hidden")return t=jl(n,o),n.lanes=536870912,Do(null,t);if(hf(n),(t=nn)?(t=q0(t,Si),t=t!==null&&t.data==="&"?t:null,t!==null&&(n.memoizedState={dehydrated:t,treeContext:qa!==null?{id:Wi,overflow:qi}:null,retryLane:536870912,hydrationErrors:null},r=vm(t),r.return=n,n.child=r,Un=n,nn=null)):t=null,t===null)throw Za(n);return n.lanes=536870912,null}return jl(n,o)}var d=t.memoizedState;if(d!==null){var S=d.dehydrated;if(hf(n),u)if(n.flags&256)n.flags&=-257,n=Og(t,n,r);else if(n.memoizedState!==null)n.child=t.child,n.flags|=128,n=null;else throw Error(s(558));else if(xn||ps(t,n,r,!1),u=(r&t.childLanes)!==0,xn||u){if(o=Jt,o!==null&&(S=tn(o,r),S!==0&&S!==d.retryLane))throw d.retryLane=S,Dr(t,S),Qn(o,t,S),Of;lc(),n=Og(t,n,r)}else t=d.treeContext,nn=Mi(S.nextSibling),Un=n,Et=!0,Ya=null,Si=!1,t!==null&&Sm(n,t),n=jl(n,o),n.flags|=4096;return n}return t=ua(t.child,{mode:o.mode,children:o.children}),t.ref=n.ref,n.child=t,t.return=n,t}function Jl(t,n){var r=n.ref;if(r===null)t!==null&&t.ref!==null&&(n.flags|=4194816);else{if(typeof r!="function"&&typeof r!="object")throw Error(s(284));(t===null||t.ref!==r)&&(n.flags|=4194816)}}function Pf(t,n,r,o,u){return Or(n),r=mf(t,n,r,o,void 0,u),o=gf(),t!==null&&!xn?(vf(t,n,u),ga(t,n,u)):(Et&&o&&Ku(n),n.flags|=1,Ln(t,n,r,u),n.child)}function Pg(t,n,r,o,u,d){return Or(n),n.updateQueue=null,r=Fm(n,o,r,u),Bm(t),o=gf(),t!==null&&!xn?(vf(t,n,d),ga(t,n,d)):(Et&&o&&Ku(n),n.flags|=1,Ln(t,n,r,d),n.child)}function Ig(t,n,r,o,u){if(Or(n),n.stateNode===null){var d=us,S=r.contextType;typeof S=="object"&&S!==null&&(d=Nn(S)),d=new r(o,d),n.memoizedState=d.state!==null&&d.state!==void 0?d.state:null,d.updater=Nf,n.stateNode=d,d._reactInternals=n,d=n.stateNode,d.props=o,d.state=n.memoizedState,d.refs={},of(n),S=r.contextType,d.context=typeof S=="object"&&S!==null?Nn(S):us,d.state=n.memoizedState,S=r.getDerivedStateFromProps,typeof S=="function"&&(Uf(n,r,S,o),d.state=n.memoizedState),typeof r.getDerivedStateFromProps=="function"||typeof d.getSnapshotBeforeUpdate=="function"||typeof d.UNSAFE_componentWillMount!="function"&&typeof d.componentWillMount!="function"||(S=d.state,typeof d.componentWillMount=="function"&&d.componentWillMount(),typeof d.UNSAFE_componentWillMount=="function"&&d.UNSAFE_componentWillMount(),S!==d.state&&Nf.enqueueReplaceState(d,d.state,null),To(n,o,d,u),bo(),d.state=n.memoizedState),typeof d.componentDidMount=="function"&&(n.flags|=4194308),o=!0}else if(t===null){d=n.stateNode;var R=n.memoizedProps,z=Hr(r,R);d.props=z;var ie=d.context,xe=r.contextType;S=us,typeof xe=="object"&&xe!==null&&(S=Nn(xe));var Ee=r.getDerivedStateFromProps;xe=typeof Ee=="function"||typeof d.getSnapshotBeforeUpdate=="function",R=n.pendingProps!==R,xe||typeof d.UNSAFE_componentWillReceiveProps!="function"&&typeof d.componentWillReceiveProps!="function"||(R||ie!==S)&&Mg(n,d,o,S),Qa=!1;var le=n.memoizedState;d.state=le,To(n,o,d,u),bo(),ie=n.memoizedState,R||le!==ie||Qa?(typeof Ee=="function"&&(Uf(n,r,Ee,o),ie=n.memoizedState),(z=Qa||yg(n,r,z,o,le,ie,S))?(xe||typeof d.UNSAFE_componentWillMount!="function"&&typeof d.componentWillMount!="function"||(typeof d.componentWillMount=="function"&&d.componentWillMount(),typeof d.UNSAFE_componentWillMount=="function"&&d.UNSAFE_componentWillMount()),typeof d.componentDidMount=="function"&&(n.flags|=4194308)):(typeof d.componentDidMount=="function"&&(n.flags|=4194308),n.memoizedProps=o,n.memoizedState=ie),d.props=o,d.state=ie,d.context=S,o=z):(typeof d.componentDidMount=="function"&&(n.flags|=4194308),o=!1)}else{d=n.stateNode,lf(t,n),S=n.memoizedProps,xe=Hr(r,S),d.props=xe,Ee=n.pendingProps,le=d.context,ie=r.contextType,z=us,typeof ie=="object"&&ie!==null&&(z=Nn(ie)),R=r.getDerivedStateFromProps,(ie=typeof R=="function"||typeof d.getSnapshotBeforeUpdate=="function")||typeof d.UNSAFE_componentWillReceiveProps!="function"&&typeof d.componentWillReceiveProps!="function"||(S!==Ee||le!==z)&&Mg(n,d,o,z),Qa=!1,le=n.memoizedState,d.state=le,To(n,o,d,u),bo();var ue=n.memoizedState;S!==Ee||le!==ue||Qa||t!==null&&t.dependencies!==null&&Ll(t.dependencies)?(typeof R=="function"&&(Uf(n,r,R,o),ue=n.memoizedState),(xe=Qa||yg(n,r,xe,o,le,ue,z)||t!==null&&t.dependencies!==null&&Ll(t.dependencies))?(ie||typeof d.UNSAFE_componentWillUpdate!="function"&&typeof d.componentWillUpdate!="function"||(typeof d.componentWillUpdate=="function"&&d.componentWillUpdate(o,ue,z),typeof d.UNSAFE_componentWillUpdate=="function"&&d.UNSAFE_componentWillUpdate(o,ue,z)),typeof d.componentDidUpdate=="function"&&(n.flags|=4),typeof d.getSnapshotBeforeUpdate=="function"&&(n.flags|=1024)):(typeof d.componentDidUpdate!="function"||S===t.memoizedProps&&le===t.memoizedState||(n.flags|=4),typeof d.getSnapshotBeforeUpdate!="function"||S===t.memoizedProps&&le===t.memoizedState||(n.flags|=1024),n.memoizedProps=o,n.memoizedState=ue),d.props=o,d.state=ue,d.context=z,o=xe):(typeof d.componentDidUpdate!="function"||S===t.memoizedProps&&le===t.memoizedState||(n.flags|=4),typeof d.getSnapshotBeforeUpdate!="function"||S===t.memoizedProps&&le===t.memoizedState||(n.flags|=1024),o=!1)}return d=o,Jl(t,n),o=(n.flags&128)!==0,d||o?(d=n.stateNode,r=o&&typeof r.getDerivedStateFromError!="function"?null:d.render(),n.flags|=1,t!==null&&o?(n.child=Fr(n,t.child,null,u),n.child=Fr(n,null,r,u)):Ln(t,n,r,u),n.memoizedState=d.state,t=n.child):t=ga(t,n,u),t}function Bg(t,n,r,o){return Nr(),n.flags|=256,Ln(t,n,r,o),n.child}var If={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Bf(t){return{baseLanes:t,cachePool:Am()}}function Ff(t,n,r){return t=t!==null?t.childLanes&~r:0,n&&(t|=li),t}function Fg(t,n,r){var o=n.pendingProps,u=!1,d=(n.flags&128)!==0,S;if((S=d)||(S=t!==null&&t.memoizedState===null?!1:(hn.current&2)!==0),S&&(u=!0,n.flags&=-129),S=(n.flags&32)!==0,n.flags&=-33,t===null){if(Et){if(u?$a(n):er(),(t=nn)?(t=q0(t,Si),t=t!==null&&t.data!=="&"?t:null,t!==null&&(n.memoizedState={dehydrated:t,treeContext:qa!==null?{id:Wi,overflow:qi}:null,retryLane:536870912,hydrationErrors:null},r=vm(t),r.return=n,n.child=r,Un=n,nn=null)):t=null,t===null)throw Za(n);return Sd(t)?n.lanes=32:n.lanes=536870912,null}var R=o.children;return o=o.fallback,u?(er(),u=n.mode,R=$l({mode:"hidden",children:R},u),o=Ur(o,u,r,null),R.return=n,o.return=n,R.sibling=o,n.child=R,o=n.child,o.memoizedState=Bf(r),o.childLanes=Ff(t,S,r),n.memoizedState=If,Do(null,o)):($a(n),zf(n,R))}var z=t.memoizedState;if(z!==null&&(R=z.dehydrated,R!==null)){if(d)n.flags&256?($a(n),n.flags&=-257,n=Hf(t,n,r)):n.memoizedState!==null?(er(),n.child=t.child,n.flags|=128,n=null):(er(),R=o.fallback,u=n.mode,o=$l({mode:"visible",children:o.children},u),R=Ur(R,u,r,null),R.flags|=2,o.return=n,R.return=n,o.sibling=R,n.child=o,Fr(n,t.child,null,r),o=n.child,o.memoizedState=Bf(r),o.childLanes=Ff(t,S,r),n.memoizedState=If,n=Do(null,o));else if($a(n),Sd(R)){if(S=R.nextSibling&&R.nextSibling.dataset,S)var ie=S.dgst;S=ie,o=Error(s(419)),o.stack="",o.digest=S,_o({value:o,source:null,stack:null}),n=Hf(t,n,r)}else if(xn||ps(t,n,r,!1),S=(r&t.childLanes)!==0,xn||S){if(S=Jt,S!==null&&(o=tn(S,r),o!==0&&o!==z.retryLane))throw z.retryLane=o,Dr(t,o),Qn(S,t,o),Of;xd(R)||lc(),n=Hf(t,n,r)}else xd(R)?(n.flags|=192,n.child=t.child,n=null):(t=z.treeContext,nn=Mi(R.nextSibling),Un=n,Et=!0,Ya=null,Si=!1,t!==null&&Sm(n,t),n=zf(n,o.children),n.flags|=4096);return n}return u?(er(),R=o.fallback,u=n.mode,z=t.child,ie=z.sibling,o=ua(z,{mode:"hidden",children:o.children}),o.subtreeFlags=z.subtreeFlags&65011712,ie!==null?R=ua(ie,R):(R=Ur(R,u,r,null),R.flags|=2),R.return=n,o.return=n,o.sibling=R,n.child=o,Do(null,o),o=n.child,R=t.child.memoizedState,R===null?R=Bf(r):(u=R.cachePool,u!==null?(z=vn._currentValue,u=u.parent!==z?{parent:z,pool:z}:u):u=Am(),R={baseLanes:R.baseLanes|r,cachePool:u}),o.memoizedState=R,o.childLanes=Ff(t,S,r),n.memoizedState=If,Do(t.child,o)):($a(n),r=t.child,t=r.sibling,r=ua(r,{mode:"visible",children:o.children}),r.return=n,r.sibling=null,t!==null&&(S=n.deletions,S===null?(n.deletions=[t],n.flags|=16):S.push(t)),n.child=r,n.memoizedState=null,r)}function zf(t,n){return n=$l({mode:"visible",children:n},t.mode),n.return=t,t.child=n}function $l(t,n){return t=ai(22,t,null,n),t.lanes=0,t}function Hf(t,n,r){return Fr(n,t.child,null,r),t=zf(n,n.pendingProps.children),t.flags|=2,n.memoizedState=null,t}function zg(t,n,r){t.lanes|=n;var o=t.alternate;o!==null&&(o.lanes|=n),ef(t.return,n,r)}function Gf(t,n,r,o,u,d){var S=t.memoizedState;S===null?t.memoizedState={isBackwards:n,rendering:null,renderingStartTime:0,last:o,tail:r,tailMode:u,treeForkCount:d}:(S.isBackwards=n,S.rendering=null,S.renderingStartTime=0,S.last=o,S.tail=r,S.tailMode=u,S.treeForkCount=d)}function Hg(t,n,r){var o=n.pendingProps,u=o.revealOrder,d=o.tail;o=o.children;var S=hn.current,R=(S&2)!==0;if(R?(S=S&1|2,n.flags|=128):S&=1,de(hn,S),Ln(t,n,o,r),o=Et?vo:0,!R&&t!==null&&(t.flags&128)!==0)e:for(t=n.child;t!==null;){if(t.tag===13)t.memoizedState!==null&&zg(t,r,n);else if(t.tag===19)zg(t,r,n);else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===n)break e;for(;t.sibling===null;){if(t.return===null||t.return===n)break e;t=t.return}t.sibling.return=t.return,t=t.sibling}switch(u){case"forwards":for(r=n.child,u=null;r!==null;)t=r.alternate,t!==null&&Gl(t)===null&&(u=r),r=r.sibling;r=u,r===null?(u=n.child,n.child=null):(u=r.sibling,r.sibling=null),Gf(n,!1,u,r,d,o);break;case"backwards":case"unstable_legacy-backwards":for(r=null,u=n.child,n.child=null;u!==null;){if(t=u.alternate,t!==null&&Gl(t)===null){n.child=u;break}t=u.sibling,u.sibling=r,r=u,u=t}Gf(n,!0,r,null,d,o);break;case"together":Gf(n,!1,null,null,void 0,o);break;default:n.memoizedState=null}return n.child}function ga(t,n,r){if(t!==null&&(n.dependencies=t.dependencies),ir|=n.lanes,(r&n.childLanes)===0)if(t!==null){if(ps(t,n,r,!1),(r&n.childLanes)===0)return null}else return null;if(t!==null&&n.child!==t.child)throw Error(s(153));if(n.child!==null){for(t=n.child,r=ua(t,t.pendingProps),n.child=r,r.return=n;t.sibling!==null;)t=t.sibling,r=r.sibling=ua(t,t.pendingProps),r.return=n;r.sibling=null}return n.child}function Vf(t,n){return(t.lanes&n)!==0?!0:(t=t.dependencies,!!(t!==null&&Ll(t)))}function YS(t,n,r){switch(n.tag){case 3:ve(n,n.stateNode.containerInfo),Ka(n,vn,t.memoizedState.cache),Nr();break;case 27:case 5:nt(n);break;case 4:ve(n,n.stateNode.containerInfo);break;case 10:Ka(n,n.type,n.memoizedProps.value);break;case 31:if(n.memoizedState!==null)return n.flags|=128,hf(n),null;break;case 13:var o=n.memoizedState;if(o!==null)return o.dehydrated!==null?($a(n),n.flags|=128,null):(r&n.child.childLanes)!==0?Fg(t,n,r):($a(n),t=ga(t,n,r),t!==null?t.sibling:null);$a(n);break;case 19:var u=(t.flags&128)!==0;if(o=(r&n.childLanes)!==0,o||(ps(t,n,r,!1),o=(r&n.childLanes)!==0),u){if(o)return Hg(t,n,r);n.flags|=128}if(u=n.memoizedState,u!==null&&(u.rendering=null,u.tail=null,u.lastEffect=null),de(hn,hn.current),o)break;return null;case 22:return n.lanes=0,Ng(t,n,r,n.pendingProps);case 24:Ka(n,vn,t.memoizedState.cache)}return ga(t,n,r)}function Gg(t,n,r){if(t!==null)if(t.memoizedProps!==n.pendingProps)xn=!0;else{if(!Vf(t,r)&&(n.flags&128)===0)return xn=!1,YS(t,n,r);xn=(t.flags&131072)!==0}else xn=!1,Et&&(n.flags&1048576)!==0&&xm(n,vo,n.index);switch(n.lanes=0,n.tag){case 16:e:{var o=n.pendingProps;if(t=Ir(n.elementType),n.type=t,typeof t=="function")qu(t)?(o=Hr(t,o),n.tag=1,n=Ig(null,n,t,o,r)):(n.tag=0,n=Pf(null,n,t,o,r));else{if(t!=null){var u=t.$$typeof;if(u===w){n.tag=11,n=wg(null,n,t,o,r);break e}else if(u===F){n.tag=14,n=Dg(null,n,t,o,r);break e}}throw n=me(t)||t,Error(s(306,n,""))}}return n;case 0:return Pf(t,n,n.type,n.pendingProps,r);case 1:return o=n.type,u=Hr(o,n.pendingProps),Ig(t,n,o,u,r);case 3:e:{if(ve(n,n.stateNode.containerInfo),t===null)throw Error(s(387));o=n.pendingProps;var d=n.memoizedState;u=d.element,lf(t,n),To(n,o,null,r);var S=n.memoizedState;if(o=S.cache,Ka(n,vn,o),o!==d.cache&&tf(n,[vn],r,!0),bo(),o=S.element,d.isDehydrated)if(d={element:o,isDehydrated:!1,cache:S.cache},n.updateQueue.baseState=d,n.memoizedState=d,n.flags&256){n=Bg(t,n,o,r);break e}else if(o!==u){u=vi(Error(s(424)),n),_o(u),n=Bg(t,n,o,r);break e}else for(t=n.stateNode.containerInfo,t.nodeType===9?t=t.body:t=t.nodeName==="HTML"?t.ownerDocument.body:t,nn=Mi(t.firstChild),Un=n,Et=!0,Ya=null,Si=!0,r=Nm(n,null,o,r),n.child=r;r;)r.flags=r.flags&-3|4096,r=r.sibling;else{if(Nr(),o===u){n=ga(t,n,r);break e}Ln(t,n,o,r)}n=n.child}return n;case 26:return Jl(t,n),t===null?(r=J0(n.type,null,n.pendingProps,null))?n.memoizedState=r:Et||(r=n.type,t=n.pendingProps,o=mc(ee.current).createElement(r),o[mn]=n,o[Dn]=t,On(o,r,t),gn(o),n.stateNode=o):n.memoizedState=J0(n.type,t.memoizedProps,n.pendingProps,t.memoizedState),null;case 27:return nt(n),t===null&&Et&&(o=n.stateNode=K0(n.type,n.pendingProps,ee.current),Un=n,Si=!0,u=nn,lr(n.type)?(yd=u,nn=Mi(o.firstChild)):nn=u),Ln(t,n,n.pendingProps.children,r),Jl(t,n),t===null&&(n.flags|=4194304),n.child;case 5:return t===null&&Et&&((u=o=nn)&&(o=Ey(o,n.type,n.pendingProps,Si),o!==null?(n.stateNode=o,Un=n,nn=Mi(o.firstChild),Si=!1,u=!0):u=!1),u||Za(n)),nt(n),u=n.type,d=n.pendingProps,S=t!==null?t.memoizedProps:null,o=d.children,gd(u,d)?o=null:S!==null&&gd(u,S)&&(n.flags|=32),n.memoizedState!==null&&(u=mf(t,n,FS,null,null,r),Wo._currentValue=u),Jl(t,n),Ln(t,n,o,r),n.child;case 6:return t===null&&Et&&((t=r=nn)&&(r=by(r,n.pendingProps,Si),r!==null?(n.stateNode=r,Un=n,nn=null,t=!0):t=!1),t||Za(n)),null;case 13:return Fg(t,n,r);case 4:return ve(n,n.stateNode.containerInfo),o=n.pendingProps,t===null?n.child=Fr(n,null,o,r):Ln(t,n,o,r),n.child;case 11:return wg(t,n,n.type,n.pendingProps,r);case 7:return Ln(t,n,n.pendingProps,r),n.child;case 8:return Ln(t,n,n.pendingProps.children,r),n.child;case 12:return Ln(t,n,n.pendingProps.children,r),n.child;case 10:return o=n.pendingProps,Ka(n,n.type,o.value),Ln(t,n,o.children,r),n.child;case 9:return u=n.type._context,o=n.pendingProps.children,Or(n),u=Nn(u),o=o(u),n.flags|=1,Ln(t,n,o,r),n.child;case 14:return Dg(t,n,n.type,n.pendingProps,r);case 15:return Ug(t,n,n.type,n.pendingProps,r);case 19:return Hg(t,n,r);case 31:return qS(t,n,r);case 22:return Ng(t,n,r,n.pendingProps);case 24:return Or(n),o=Nn(vn),t===null?(u=rf(),u===null&&(u=Jt,d=nf(),u.pooledCache=d,d.refCount++,d!==null&&(u.pooledCacheLanes|=r),u=d),n.memoizedState={parent:o,cache:u},of(n),Ka(n,vn,u)):((t.lanes&r)!==0&&(lf(t,n),To(n,null,null,r),bo()),u=t.memoizedState,d=n.memoizedState,u.parent!==o?(u={parent:o,cache:o},n.memoizedState=u,n.lanes===0&&(n.memoizedState=n.updateQueue.baseState=u),Ka(n,vn,o)):(o=d.cache,Ka(n,vn,o),o!==u.cache&&tf(n,[vn],r,!0))),Ln(t,n,n.pendingProps.children,r),n.child;case 29:throw n.pendingProps}throw Error(s(156,n.tag))}function va(t){t.flags|=4}function kf(t,n,r,o,u){if((n=(t.mode&32)!==0)&&(n=!1),n){if(t.flags|=16777216,(u&335544128)===u)if(t.stateNode.complete)t.flags|=8192;else if(p0())t.flags|=8192;else throw Br=Bl,sf}else t.flags&=-16777217}function Vg(t,n){if(n.type!=="stylesheet"||(n.state.loading&4)!==0)t.flags&=-16777217;else if(t.flags|=16777216,!iv(n))if(p0())t.flags|=8192;else throw Br=Bl,sf}function ec(t,n){n!==null&&(t.flags|=4),t.flags&16384&&(n=t.tag!==22?Se():536870912,t.lanes|=n,As|=n)}function Uo(t,n){if(!Et)switch(t.tailMode){case"hidden":n=t.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t.tail=null:r.sibling=null;break;case"collapsed":r=t.tail;for(var o=null;r!==null;)r.alternate!==null&&(o=r),r=r.sibling;o===null?n||t.tail===null?t.tail=null:t.tail.sibling=null:o.sibling=null}}function an(t){var n=t.alternate!==null&&t.alternate.child===t.child,r=0,o=0;if(n)for(var u=t.child;u!==null;)r|=u.lanes|u.childLanes,o|=u.subtreeFlags&65011712,o|=u.flags&65011712,u.return=t,u=u.sibling;else for(u=t.child;u!==null;)r|=u.lanes|u.childLanes,o|=u.subtreeFlags,o|=u.flags,u.return=t,u=u.sibling;return t.subtreeFlags|=o,t.childLanes=r,n}function ZS(t,n,r){var o=n.pendingProps;switch(Qu(n),n.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return an(n),null;case 1:return an(n),null;case 3:return r=n.stateNode,o=null,t!==null&&(o=t.memoizedState.cache),n.memoizedState.cache!==o&&(n.flags|=2048),ha(vn),He(),r.pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),(t===null||t.child===null)&&(hs(n)?va(n):t===null||t.memoizedState.isDehydrated&&(n.flags&256)===0||(n.flags|=1024,Ju())),an(n),null;case 26:var u=n.type,d=n.memoizedState;return t===null?(va(n),d!==null?(an(n),Vg(n,d)):(an(n),kf(n,u,null,o,r))):d?d!==t.memoizedState?(va(n),an(n),Vg(n,d)):(an(n),n.flags&=-16777217):(t=t.memoizedProps,t!==o&&va(n),an(n),kf(n,u,t,o,r)),null;case 27:if(je(n),r=ee.current,u=n.type,t!==null&&n.stateNode!=null)t.memoizedProps!==o&&va(n);else{if(!o){if(n.stateNode===null)throw Error(s(166));return an(n),null}t=Te.current,hs(n)?ym(n):(t=K0(u,o,r),n.stateNode=t,va(n))}return an(n),null;case 5:if(je(n),u=n.type,t!==null&&n.stateNode!=null)t.memoizedProps!==o&&va(n);else{if(!o){if(n.stateNode===null)throw Error(s(166));return an(n),null}if(d=Te.current,hs(n))ym(n);else{var S=mc(ee.current);switch(d){case 1:d=S.createElementNS("http://www.w3.org/2000/svg",u);break;case 2:d=S.createElementNS("http://www.w3.org/1998/Math/MathML",u);break;default:switch(u){case"svg":d=S.createElementNS("http://www.w3.org/2000/svg",u);break;case"math":d=S.createElementNS("http://www.w3.org/1998/Math/MathML",u);break;case"script":d=S.createElement("div"),d.innerHTML="<script><\/script>",d=d.removeChild(d.firstChild);break;case"select":d=typeof o.is=="string"?S.createElement("select",{is:o.is}):S.createElement("select"),o.multiple?d.multiple=!0:o.size&&(d.size=o.size);break;default:d=typeof o.is=="string"?S.createElement(u,{is:o.is}):S.createElement(u)}}d[mn]=n,d[Dn]=o;e:for(S=n.child;S!==null;){if(S.tag===5||S.tag===6)d.appendChild(S.stateNode);else if(S.tag!==4&&S.tag!==27&&S.child!==null){S.child.return=S,S=S.child;continue}if(S===n)break e;for(;S.sibling===null;){if(S.return===null||S.return===n)break e;S=S.return}S.sibling.return=S.return,S=S.sibling}n.stateNode=d;e:switch(On(d,u,o),u){case"button":case"input":case"select":case"textarea":o=!!o.autoFocus;break e;case"img":o=!0;break e;default:o=!1}o&&va(n)}}return an(n),kf(n,n.type,t===null?null:t.memoizedProps,n.pendingProps,r),null;case 6:if(t&&n.stateNode!=null)t.memoizedProps!==o&&va(n);else{if(typeof o!="string"&&n.stateNode===null)throw Error(s(166));if(t=ee.current,hs(n)){if(t=n.stateNode,r=n.memoizedProps,o=null,u=Un,u!==null)switch(u.tag){case 27:case 5:o=u.memoizedProps}t[mn]=n,t=!!(t.nodeValue===r||o!==null&&o.suppressHydrationWarning===!0||F0(t.nodeValue,r)),t||Za(n,!0)}else t=mc(t).createTextNode(o),t[mn]=n,n.stateNode=t}return an(n),null;case 31:if(r=n.memoizedState,t===null||t.memoizedState!==null){if(o=hs(n),r!==null){if(t===null){if(!o)throw Error(s(318));if(t=n.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(s(557));t[mn]=n}else Nr(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;an(n),t=!1}else r=Ju(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=r),t=!0;if(!t)return n.flags&256?(si(n),n):(si(n),null);if((n.flags&128)!==0)throw Error(s(558))}return an(n),null;case 13:if(o=n.memoizedState,t===null||t.memoizedState!==null&&t.memoizedState.dehydrated!==null){if(u=hs(n),o!==null&&o.dehydrated!==null){if(t===null){if(!u)throw Error(s(318));if(u=n.memoizedState,u=u!==null?u.dehydrated:null,!u)throw Error(s(317));u[mn]=n}else Nr(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;an(n),u=!1}else u=Ju(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=u),u=!0;if(!u)return n.flags&256?(si(n),n):(si(n),null)}return si(n),(n.flags&128)!==0?(n.lanes=r,n):(r=o!==null,t=t!==null&&t.memoizedState!==null,r&&(o=n.child,u=null,o.alternate!==null&&o.alternate.memoizedState!==null&&o.alternate.memoizedState.cachePool!==null&&(u=o.alternate.memoizedState.cachePool.pool),d=null,o.memoizedState!==null&&o.memoizedState.cachePool!==null&&(d=o.memoizedState.cachePool.pool),d!==u&&(o.flags|=2048)),r!==t&&r&&(n.child.flags|=8192),ec(n,n.updateQueue),an(n),null);case 4:return He(),t===null&&fd(n.stateNode.containerInfo),an(n),null;case 10:return ha(n.type),an(n),null;case 19:if(Y(hn),o=n.memoizedState,o===null)return an(n),null;if(u=(n.flags&128)!==0,d=o.rendering,d===null)if(u)Uo(o,!1);else{if(fn!==0||t!==null&&(t.flags&128)!==0)for(t=n.child;t!==null;){if(d=Gl(t),d!==null){for(n.flags|=128,Uo(o,!1),t=d.updateQueue,n.updateQueue=t,ec(n,t),n.subtreeFlags=0,t=r,r=n.child;r!==null;)gm(r,t),r=r.sibling;return de(hn,hn.current&1|2),Et&&fa(n,o.treeForkCount),n.child}t=t.sibling}o.tail!==null&&Bt()>rc&&(n.flags|=128,u=!0,Uo(o,!1),n.lanes=4194304)}else{if(!u)if(t=Gl(d),t!==null){if(n.flags|=128,u=!0,t=t.updateQueue,n.updateQueue=t,ec(n,t),Uo(o,!0),o.tail===null&&o.tailMode==="hidden"&&!d.alternate&&!Et)return an(n),null}else 2*Bt()-o.renderingStartTime>rc&&r!==536870912&&(n.flags|=128,u=!0,Uo(o,!1),n.lanes=4194304);o.isBackwards?(d.sibling=n.child,n.child=d):(t=o.last,t!==null?t.sibling=d:n.child=d,o.last=d)}return o.tail!==null?(t=o.tail,o.rendering=t,o.tail=t.sibling,o.renderingStartTime=Bt(),t.sibling=null,r=hn.current,de(hn,u?r&1|2:r&1),Et&&fa(n,o.treeForkCount),t):(an(n),null);case 22:case 23:return si(n),df(),o=n.memoizedState!==null,t!==null?t.memoizedState!==null!==o&&(n.flags|=8192):o&&(n.flags|=8192),o?(r&536870912)!==0&&(n.flags&128)===0&&(an(n),n.subtreeFlags&6&&(n.flags|=8192)):an(n),r=n.updateQueue,r!==null&&ec(n,r.retryQueue),r=null,t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(r=t.memoizedState.cachePool.pool),o=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(o=n.memoizedState.cachePool.pool),o!==r&&(n.flags|=2048),t!==null&&Y(Pr),null;case 24:return r=null,t!==null&&(r=t.memoizedState.cache),n.memoizedState.cache!==r&&(n.flags|=2048),ha(vn),an(n),null;case 25:return null;case 30:return null}throw Error(s(156,n.tag))}function KS(t,n){switch(Qu(n),n.tag){case 1:return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 3:return ha(vn),He(),t=n.flags,(t&65536)!==0&&(t&128)===0?(n.flags=t&-65537|128,n):null;case 26:case 27:case 5:return je(n),null;case 31:if(n.memoizedState!==null){if(si(n),n.alternate===null)throw Error(s(340));Nr()}return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 13:if(si(n),t=n.memoizedState,t!==null&&t.dehydrated!==null){if(n.alternate===null)throw Error(s(340));Nr()}return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 19:return Y(hn),null;case 4:return He(),null;case 10:return ha(n.type),null;case 22:case 23:return si(n),df(),t!==null&&Y(Pr),t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 24:return ha(vn),null;case 25:return null;default:return null}}function kg(t,n){switch(Qu(n),n.tag){case 3:ha(vn),He();break;case 26:case 27:case 5:je(n);break;case 4:He();break;case 31:n.memoizedState!==null&&si(n);break;case 13:si(n);break;case 19:Y(hn);break;case 10:ha(n.type);break;case 22:case 23:si(n),df(),t!==null&&Y(Pr);break;case 24:ha(vn)}}function No(t,n){try{var r=n.updateQueue,o=r!==null?r.lastEffect:null;if(o!==null){var u=o.next;r=u;do{if((r.tag&t)===t){o=void 0;var d=r.create,S=r.inst;o=d(),S.destroy=o}r=r.next}while(r!==u)}}catch(R){Xt(n,n.return,R)}}function tr(t,n,r){try{var o=n.updateQueue,u=o!==null?o.lastEffect:null;if(u!==null){var d=u.next;o=d;do{if((o.tag&t)===t){var S=o.inst,R=S.destroy;if(R!==void 0){S.destroy=void 0,u=n;var z=r,ie=R;try{ie()}catch(xe){Xt(u,z,xe)}}}o=o.next}while(o!==d)}}catch(xe){Xt(n,n.return,xe)}}function Xg(t){var n=t.updateQueue;if(n!==null){var r=t.stateNode;try{Om(n,r)}catch(o){Xt(t,t.return,o)}}}function Wg(t,n,r){r.props=Hr(t.type,t.memoizedProps),r.state=t.memoizedState;try{r.componentWillUnmount()}catch(o){Xt(t,n,o)}}function Lo(t,n){try{var r=t.ref;if(r!==null){switch(t.tag){case 26:case 27:case 5:var o=t.stateNode;break;case 30:o=t.stateNode;break;default:o=t.stateNode}typeof r=="function"?t.refCleanup=r(o):r.current=o}}catch(u){Xt(t,n,u)}}function Yi(t,n){var r=t.ref,o=t.refCleanup;if(r!==null)if(typeof o=="function")try{o()}catch(u){Xt(t,n,u)}finally{t.refCleanup=null,t=t.alternate,t!=null&&(t.refCleanup=null)}else if(typeof r=="function")try{r(null)}catch(u){Xt(t,n,u)}else r.current=null}function qg(t){var n=t.type,r=t.memoizedProps,o=t.stateNode;try{e:switch(n){case"button":case"input":case"select":case"textarea":r.autoFocus&&o.focus();break e;case"img":r.src?o.src=r.src:r.srcSet&&(o.srcset=r.srcSet)}}catch(u){Xt(t,t.return,u)}}function Xf(t,n,r){try{var o=t.stateNode;vy(o,t.type,r,n),o[Dn]=n}catch(u){Xt(t,t.return,u)}}function Yg(t){return t.tag===5||t.tag===3||t.tag===26||t.tag===27&&lr(t.type)||t.tag===4}function Wf(t){e:for(;;){for(;t.sibling===null;){if(t.return===null||Yg(t.return))return null;t=t.return}for(t.sibling.return=t.return,t=t.sibling;t.tag!==5&&t.tag!==6&&t.tag!==18;){if(t.tag===27&&lr(t.type)||t.flags&2||t.child===null||t.tag===4)continue e;t.child.return=t,t=t.child}if(!(t.flags&2))return t.stateNode}}function qf(t,n,r){var o=t.tag;if(o===5||o===6)t=t.stateNode,n?(r.nodeType===9?r.body:r.nodeName==="HTML"?r.ownerDocument.body:r).insertBefore(t,n):(n=r.nodeType===9?r.body:r.nodeName==="HTML"?r.ownerDocument.body:r,n.appendChild(t),r=r._reactRootContainer,r!=null||n.onclick!==null||(n.onclick=la));else if(o!==4&&(o===27&&lr(t.type)&&(r=t.stateNode,n=null),t=t.child,t!==null))for(qf(t,n,r),t=t.sibling;t!==null;)qf(t,n,r),t=t.sibling}function tc(t,n,r){var o=t.tag;if(o===5||o===6)t=t.stateNode,n?r.insertBefore(t,n):r.appendChild(t);else if(o!==4&&(o===27&&lr(t.type)&&(r=t.stateNode),t=t.child,t!==null))for(tc(t,n,r),t=t.sibling;t!==null;)tc(t,n,r),t=t.sibling}function Zg(t){var n=t.stateNode,r=t.memoizedProps;try{for(var o=t.type,u=n.attributes;u.length;)n.removeAttributeNode(u[0]);On(n,o,r),n[mn]=t,n[Dn]=r}catch(d){Xt(t,t.return,d)}}var _a=!1,Sn=!1,Yf=!1,Kg=typeof WeakSet=="function"?WeakSet:Set,Cn=null;function QS(t,n){if(t=t.containerInfo,pd=Mc,t=om(t),zu(t)){if("selectionStart"in t)var r={start:t.selectionStart,end:t.selectionEnd};else e:{r=(r=t.ownerDocument)&&r.defaultView||window;var o=r.getSelection&&r.getSelection();if(o&&o.rangeCount!==0){r=o.anchorNode;var u=o.anchorOffset,d=o.focusNode;o=o.focusOffset;try{r.nodeType,d.nodeType}catch{r=null;break e}var S=0,R=-1,z=-1,ie=0,xe=0,Ee=t,le=null;t:for(;;){for(var ue;Ee!==r||u!==0&&Ee.nodeType!==3||(R=S+u),Ee!==d||o!==0&&Ee.nodeType!==3||(z=S+o),Ee.nodeType===3&&(S+=Ee.nodeValue.length),(ue=Ee.firstChild)!==null;)le=Ee,Ee=ue;for(;;){if(Ee===t)break t;if(le===r&&++ie===u&&(R=S),le===d&&++xe===o&&(z=S),(ue=Ee.nextSibling)!==null)break;Ee=le,le=Ee.parentNode}Ee=ue}r=R===-1||z===-1?null:{start:R,end:z}}else r=null}r=r||{start:0,end:0}}else r=null;for(md={focusedElem:t,selectionRange:r},Mc=!1,Cn=n;Cn!==null;)if(n=Cn,t=n.child,(n.subtreeFlags&1028)!==0&&t!==null)t.return=n,Cn=t;else for(;Cn!==null;){switch(n=Cn,d=n.alternate,t=n.flags,n.tag){case 0:if((t&4)!==0&&(t=n.updateQueue,t=t!==null?t.events:null,t!==null))for(r=0;r<t.length;r++)u=t[r],u.ref.impl=u.nextImpl;break;case 11:case 15:break;case 1:if((t&1024)!==0&&d!==null){t=void 0,r=n,u=d.memoizedProps,d=d.memoizedState,o=r.stateNode;try{var Ke=Hr(r.type,u);t=o.getSnapshotBeforeUpdate(Ke,d),o.__reactInternalSnapshotBeforeUpdate=t}catch(it){Xt(r,r.return,it)}}break;case 3:if((t&1024)!==0){if(t=n.stateNode.containerInfo,r=t.nodeType,r===9)_d(t);else if(r===1)switch(t.nodeName){case"HEAD":case"HTML":case"BODY":_d(t);break;default:t.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((t&1024)!==0)throw Error(s(163))}if(t=n.sibling,t!==null){t.return=n.return,Cn=t;break}Cn=n.return}}function Qg(t,n,r){var o=r.flags;switch(r.tag){case 0:case 11:case 15:Sa(t,r),o&4&&No(5,r);break;case 1:if(Sa(t,r),o&4)if(t=r.stateNode,n===null)try{t.componentDidMount()}catch(S){Xt(r,r.return,S)}else{var u=Hr(r.type,n.memoizedProps);n=n.memoizedState;try{t.componentDidUpdate(u,n,t.__reactInternalSnapshotBeforeUpdate)}catch(S){Xt(r,r.return,S)}}o&64&&Xg(r),o&512&&Lo(r,r.return);break;case 3:if(Sa(t,r),o&64&&(t=r.updateQueue,t!==null)){if(n=null,r.child!==null)switch(r.child.tag){case 27:case 5:n=r.child.stateNode;break;case 1:n=r.child.stateNode}try{Om(t,n)}catch(S){Xt(r,r.return,S)}}break;case 27:n===null&&o&4&&Zg(r);case 26:case 5:Sa(t,r),n===null&&o&4&&qg(r),o&512&&Lo(r,r.return);break;case 12:Sa(t,r);break;case 31:Sa(t,r),o&4&&$g(t,r);break;case 13:Sa(t,r),o&4&&e0(t,r),o&64&&(t=r.memoizedState,t!==null&&(t=t.dehydrated,t!==null&&(r=ry.bind(null,r),Ty(t,r))));break;case 22:if(o=r.memoizedState!==null||_a,!o){n=n!==null&&n.memoizedState!==null||Sn,u=_a;var d=Sn;_a=o,(Sn=n)&&!d?ya(t,r,(r.subtreeFlags&8772)!==0):Sa(t,r),_a=u,Sn=d}break;case 30:break;default:Sa(t,r)}}function jg(t){var n=t.alternate;n!==null&&(t.alternate=null,jg(n)),t.child=null,t.deletions=null,t.sibling=null,t.tag===5&&(n=t.stateNode,n!==null&&Va(n)),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}var on=null,qn=!1;function xa(t,n,r){for(r=r.child;r!==null;)Jg(t,n,r),r=r.sibling}function Jg(t,n,r){if(ge&&typeof ge.onCommitFiberUnmount=="function")try{ge.onCommitFiberUnmount(pe,r)}catch{}switch(r.tag){case 26:Sn||Yi(r,n),xa(t,n,r),r.memoizedState?r.memoizedState.count--:r.stateNode&&(r=r.stateNode,r.parentNode.removeChild(r));break;case 27:Sn||Yi(r,n);var o=on,u=qn;lr(r.type)&&(on=r.stateNode,qn=!1),xa(t,n,r),Vo(r.stateNode),on=o,qn=u;break;case 5:Sn||Yi(r,n);case 6:if(o=on,u=qn,on=null,xa(t,n,r),on=o,qn=u,on!==null)if(qn)try{(on.nodeType===9?on.body:on.nodeName==="HTML"?on.ownerDocument.body:on).removeChild(r.stateNode)}catch(d){Xt(r,n,d)}else try{on.removeChild(r.stateNode)}catch(d){Xt(r,n,d)}break;case 18:on!==null&&(qn?(t=on,X0(t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,r.stateNode),Os(t)):X0(on,r.stateNode));break;case 4:o=on,u=qn,on=r.stateNode.containerInfo,qn=!0,xa(t,n,r),on=o,qn=u;break;case 0:case 11:case 14:case 15:tr(2,r,n),Sn||tr(4,r,n),xa(t,n,r);break;case 1:Sn||(Yi(r,n),o=r.stateNode,typeof o.componentWillUnmount=="function"&&Wg(r,n,o)),xa(t,n,r);break;case 21:xa(t,n,r);break;case 22:Sn=(o=Sn)||r.memoizedState!==null,xa(t,n,r),Sn=o;break;default:xa(t,n,r)}}function $g(t,n){if(n.memoizedState===null&&(t=n.alternate,t!==null&&(t=t.memoizedState,t!==null))){t=t.dehydrated;try{Os(t)}catch(r){Xt(n,n.return,r)}}}function e0(t,n){if(n.memoizedState===null&&(t=n.alternate,t!==null&&(t=t.memoizedState,t!==null&&(t=t.dehydrated,t!==null))))try{Os(t)}catch(r){Xt(n,n.return,r)}}function jS(t){switch(t.tag){case 31:case 13:case 19:var n=t.stateNode;return n===null&&(n=t.stateNode=new Kg),n;case 22:return t=t.stateNode,n=t._retryCache,n===null&&(n=t._retryCache=new Kg),n;default:throw Error(s(435,t.tag))}}function nc(t,n){var r=jS(t);n.forEach(function(o){if(!r.has(o)){r.add(o);var u=sy.bind(null,t,o);o.then(u,u)}})}function Yn(t,n){var r=n.deletions;if(r!==null)for(var o=0;o<r.length;o++){var u=r[o],d=t,S=n,R=S;e:for(;R!==null;){switch(R.tag){case 27:if(lr(R.type)){on=R.stateNode,qn=!1;break e}break;case 5:on=R.stateNode,qn=!1;break e;case 3:case 4:on=R.stateNode.containerInfo,qn=!0;break e}R=R.return}if(on===null)throw Error(s(160));Jg(d,S,u),on=null,qn=!1,d=u.alternate,d!==null&&(d.return=null),u.return=null}if(n.subtreeFlags&13886)for(n=n.child;n!==null;)t0(n,t),n=n.sibling}var Ni=null;function t0(t,n){var r=t.alternate,o=t.flags;switch(t.tag){case 0:case 11:case 14:case 15:Yn(n,t),Zn(t),o&4&&(tr(3,t,t.return),No(3,t),tr(5,t,t.return));break;case 1:Yn(n,t),Zn(t),o&512&&(Sn||r===null||Yi(r,r.return)),o&64&&_a&&(t=t.updateQueue,t!==null&&(o=t.callbacks,o!==null&&(r=t.shared.hiddenCallbacks,t.shared.hiddenCallbacks=r===null?o:r.concat(o))));break;case 26:var u=Ni;if(Yn(n,t),Zn(t),o&512&&(Sn||r===null||Yi(r,r.return)),o&4){var d=r!==null?r.memoizedState:null;if(o=t.memoizedState,r===null)if(o===null)if(t.stateNode===null){e:{o=t.type,r=t.memoizedProps,u=u.ownerDocument||u;t:switch(o){case"title":d=u.getElementsByTagName("title")[0],(!d||d[Ga]||d[mn]||d.namespaceURI==="http://www.w3.org/2000/svg"||d.hasAttribute("itemprop"))&&(d=u.createElement(o),u.head.insertBefore(d,u.querySelector("head > title"))),On(d,o,r),d[mn]=t,gn(d),o=d;break e;case"link":var S=tv("link","href",u).get(o+(r.href||""));if(S){for(var R=0;R<S.length;R++)if(d=S[R],d.getAttribute("href")===(r.href==null||r.href===""?null:r.href)&&d.getAttribute("rel")===(r.rel==null?null:r.rel)&&d.getAttribute("title")===(r.title==null?null:r.title)&&d.getAttribute("crossorigin")===(r.crossOrigin==null?null:r.crossOrigin)){S.splice(R,1);break t}}d=u.createElement(o),On(d,o,r),u.head.appendChild(d);break;case"meta":if(S=tv("meta","content",u).get(o+(r.content||""))){for(R=0;R<S.length;R++)if(d=S[R],d.getAttribute("content")===(r.content==null?null:""+r.content)&&d.getAttribute("name")===(r.name==null?null:r.name)&&d.getAttribute("property")===(r.property==null?null:r.property)&&d.getAttribute("http-equiv")===(r.httpEquiv==null?null:r.httpEquiv)&&d.getAttribute("charset")===(r.charSet==null?null:r.charSet)){S.splice(R,1);break t}}d=u.createElement(o),On(d,o,r),u.head.appendChild(d);break;default:throw Error(s(468,o))}d[mn]=t,gn(d),o=d}t.stateNode=o}else nv(u,t.type,t.stateNode);else t.stateNode=ev(u,o,t.memoizedProps);else d!==o?(d===null?r.stateNode!==null&&(r=r.stateNode,r.parentNode.removeChild(r)):d.count--,o===null?nv(u,t.type,t.stateNode):ev(u,o,t.memoizedProps)):o===null&&t.stateNode!==null&&Xf(t,t.memoizedProps,r.memoizedProps)}break;case 27:Yn(n,t),Zn(t),o&512&&(Sn||r===null||Yi(r,r.return)),r!==null&&o&4&&Xf(t,t.memoizedProps,r.memoizedProps);break;case 5:if(Yn(n,t),Zn(t),o&512&&(Sn||r===null||Yi(r,r.return)),t.flags&32){u=t.stateNode;try{ni(u,"")}catch(Ke){Xt(t,t.return,Ke)}}o&4&&t.stateNode!=null&&(u=t.memoizedProps,Xf(t,u,r!==null?r.memoizedProps:u)),o&1024&&(Yf=!0);break;case 6:if(Yn(n,t),Zn(t),o&4){if(t.stateNode===null)throw Error(s(162));o=t.memoizedProps,r=t.stateNode;try{r.nodeValue=o}catch(Ke){Xt(t,t.return,Ke)}}break;case 3:if(_c=null,u=Ni,Ni=gc(n.containerInfo),Yn(n,t),Ni=u,Zn(t),o&4&&r!==null&&r.memoizedState.isDehydrated)try{Os(n.containerInfo)}catch(Ke){Xt(t,t.return,Ke)}Yf&&(Yf=!1,n0(t));break;case 4:o=Ni,Ni=gc(t.stateNode.containerInfo),Yn(n,t),Zn(t),Ni=o;break;case 12:Yn(n,t),Zn(t);break;case 31:Yn(n,t),Zn(t),o&4&&(o=t.updateQueue,o!==null&&(t.updateQueue=null,nc(t,o)));break;case 13:Yn(n,t),Zn(t),t.child.flags&8192&&t.memoizedState!==null!=(r!==null&&r.memoizedState!==null)&&(ac=Bt()),o&4&&(o=t.updateQueue,o!==null&&(t.updateQueue=null,nc(t,o)));break;case 22:u=t.memoizedState!==null;var z=r!==null&&r.memoizedState!==null,ie=_a,xe=Sn;if(_a=ie||u,Sn=xe||z,Yn(n,t),Sn=xe,_a=ie,Zn(t),o&8192)e:for(n=t.stateNode,n._visibility=u?n._visibility&-2:n._visibility|1,u&&(r===null||z||_a||Sn||Gr(t)),r=null,n=t;;){if(n.tag===5||n.tag===26){if(r===null){z=r=n;try{if(d=z.stateNode,u)S=d.style,typeof S.setProperty=="function"?S.setProperty("display","none","important"):S.display="none";else{R=z.stateNode;var Ee=z.memoizedProps.style,le=Ee!=null&&Ee.hasOwnProperty("display")?Ee.display:null;R.style.display=le==null||typeof le=="boolean"?"":(""+le).trim()}}catch(Ke){Xt(z,z.return,Ke)}}}else if(n.tag===6){if(r===null){z=n;try{z.stateNode.nodeValue=u?"":z.memoizedProps}catch(Ke){Xt(z,z.return,Ke)}}}else if(n.tag===18){if(r===null){z=n;try{var ue=z.stateNode;u?W0(ue,!0):W0(z.stateNode,!1)}catch(Ke){Xt(z,z.return,Ke)}}}else if((n.tag!==22&&n.tag!==23||n.memoizedState===null||n===t)&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break e;for(;n.sibling===null;){if(n.return===null||n.return===t)break e;r===n&&(r=null),n=n.return}r===n&&(r=null),n.sibling.return=n.return,n=n.sibling}o&4&&(o=t.updateQueue,o!==null&&(r=o.retryQueue,r!==null&&(o.retryQueue=null,nc(t,r))));break;case 19:Yn(n,t),Zn(t),o&4&&(o=t.updateQueue,o!==null&&(t.updateQueue=null,nc(t,o)));break;case 30:break;case 21:break;default:Yn(n,t),Zn(t)}}function Zn(t){var n=t.flags;if(n&2){try{for(var r,o=t.return;o!==null;){if(Yg(o)){r=o;break}o=o.return}if(r==null)throw Error(s(160));switch(r.tag){case 27:var u=r.stateNode,d=Wf(t);tc(t,d,u);break;case 5:var S=r.stateNode;r.flags&32&&(ni(S,""),r.flags&=-33);var R=Wf(t);tc(t,R,S);break;case 3:case 4:var z=r.stateNode.containerInfo,ie=Wf(t);qf(t,ie,z);break;default:throw Error(s(161))}}catch(xe){Xt(t,t.return,xe)}t.flags&=-3}n&4096&&(t.flags&=-4097)}function n0(t){if(t.subtreeFlags&1024)for(t=t.child;t!==null;){var n=t;n0(n),n.tag===5&&n.flags&1024&&n.stateNode.reset(),t=t.sibling}}function Sa(t,n){if(n.subtreeFlags&8772)for(n=n.child;n!==null;)Qg(t,n.alternate,n),n=n.sibling}function Gr(t){for(t=t.child;t!==null;){var n=t;switch(n.tag){case 0:case 11:case 14:case 15:tr(4,n,n.return),Gr(n);break;case 1:Yi(n,n.return);var r=n.stateNode;typeof r.componentWillUnmount=="function"&&Wg(n,n.return,r),Gr(n);break;case 27:Vo(n.stateNode);case 26:case 5:Yi(n,n.return),Gr(n);break;case 22:n.memoizedState===null&&Gr(n);break;case 30:Gr(n);break;default:Gr(n)}t=t.sibling}}function ya(t,n,r){for(r=r&&(n.subtreeFlags&8772)!==0,n=n.child;n!==null;){var o=n.alternate,u=t,d=n,S=d.flags;switch(d.tag){case 0:case 11:case 15:ya(u,d,r),No(4,d);break;case 1:if(ya(u,d,r),o=d,u=o.stateNode,typeof u.componentDidMount=="function")try{u.componentDidMount()}catch(ie){Xt(o,o.return,ie)}if(o=d,u=o.updateQueue,u!==null){var R=o.stateNode;try{var z=u.shared.hiddenCallbacks;if(z!==null)for(u.shared.hiddenCallbacks=null,u=0;u<z.length;u++)Lm(z[u],R)}catch(ie){Xt(o,o.return,ie)}}r&&S&64&&Xg(d),Lo(d,d.return);break;case 27:Zg(d);case 26:case 5:ya(u,d,r),r&&o===null&&S&4&&qg(d),Lo(d,d.return);break;case 12:ya(u,d,r);break;case 31:ya(u,d,r),r&&S&4&&$g(u,d);break;case 13:ya(u,d,r),r&&S&4&&e0(u,d);break;case 22:d.memoizedState===null&&ya(u,d,r),Lo(d,d.return);break;case 30:break;default:ya(u,d,r)}n=n.sibling}}function Zf(t,n){var r=null;t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(r=t.memoizedState.cachePool.pool),t=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(t=n.memoizedState.cachePool.pool),t!==r&&(t!=null&&t.refCount++,r!=null&&xo(r))}function Kf(t,n){t=null,n.alternate!==null&&(t=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==t&&(n.refCount++,t!=null&&xo(t))}function Li(t,n,r,o){if(n.subtreeFlags&10256)for(n=n.child;n!==null;)i0(t,n,r,o),n=n.sibling}function i0(t,n,r,o){var u=n.flags;switch(n.tag){case 0:case 11:case 15:Li(t,n,r,o),u&2048&&No(9,n);break;case 1:Li(t,n,r,o);break;case 3:Li(t,n,r,o),u&2048&&(t=null,n.alternate!==null&&(t=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==t&&(n.refCount++,t!=null&&xo(t)));break;case 12:if(u&2048){Li(t,n,r,o),t=n.stateNode;try{var d=n.memoizedProps,S=d.id,R=d.onPostCommit;typeof R=="function"&&R(S,n.alternate===null?"mount":"update",t.passiveEffectDuration,-0)}catch(z){Xt(n,n.return,z)}}else Li(t,n,r,o);break;case 31:Li(t,n,r,o);break;case 13:Li(t,n,r,o);break;case 23:break;case 22:d=n.stateNode,S=n.alternate,n.memoizedState!==null?d._visibility&2?Li(t,n,r,o):Oo(t,n):d._visibility&2?Li(t,n,r,o):(d._visibility|=2,Es(t,n,r,o,(n.subtreeFlags&10256)!==0||!1)),u&2048&&Zf(S,n);break;case 24:Li(t,n,r,o),u&2048&&Kf(n.alternate,n);break;default:Li(t,n,r,o)}}function Es(t,n,r,o,u){for(u=u&&((n.subtreeFlags&10256)!==0||!1),n=n.child;n!==null;){var d=t,S=n,R=r,z=o,ie=S.flags;switch(S.tag){case 0:case 11:case 15:Es(d,S,R,z,u),No(8,S);break;case 23:break;case 22:var xe=S.stateNode;S.memoizedState!==null?xe._visibility&2?Es(d,S,R,z,u):Oo(d,S):(xe._visibility|=2,Es(d,S,R,z,u)),u&&ie&2048&&Zf(S.alternate,S);break;case 24:Es(d,S,R,z,u),u&&ie&2048&&Kf(S.alternate,S);break;default:Es(d,S,R,z,u)}n=n.sibling}}function Oo(t,n){if(n.subtreeFlags&10256)for(n=n.child;n!==null;){var r=t,o=n,u=o.flags;switch(o.tag){case 22:Oo(r,o),u&2048&&Zf(o.alternate,o);break;case 24:Oo(r,o),u&2048&&Kf(o.alternate,o);break;default:Oo(r,o)}n=n.sibling}}var Po=8192;function bs(t,n,r){if(t.subtreeFlags&Po)for(t=t.child;t!==null;)a0(t,n,r),t=t.sibling}function a0(t,n,r){switch(t.tag){case 26:bs(t,n,r),t.flags&Po&&t.memoizedState!==null&&By(r,Ni,t.memoizedState,t.memoizedProps);break;case 5:bs(t,n,r);break;case 3:case 4:var o=Ni;Ni=gc(t.stateNode.containerInfo),bs(t,n,r),Ni=o;break;case 22:t.memoizedState===null&&(o=t.alternate,o!==null&&o.memoizedState!==null?(o=Po,Po=16777216,bs(t,n,r),Po=o):bs(t,n,r));break;default:bs(t,n,r)}}function r0(t){var n=t.alternate;if(n!==null&&(t=n.child,t!==null)){n.child=null;do n=t.sibling,t.sibling=null,t=n;while(t!==null)}}function Io(t){var n=t.deletions;if((t.flags&16)!==0){if(n!==null)for(var r=0;r<n.length;r++){var o=n[r];Cn=o,o0(o,t)}r0(t)}if(t.subtreeFlags&10256)for(t=t.child;t!==null;)s0(t),t=t.sibling}function s0(t){switch(t.tag){case 0:case 11:case 15:Io(t),t.flags&2048&&tr(9,t,t.return);break;case 3:Io(t);break;case 12:Io(t);break;case 22:var n=t.stateNode;t.memoizedState!==null&&n._visibility&2&&(t.return===null||t.return.tag!==13)?(n._visibility&=-3,ic(t)):Io(t);break;default:Io(t)}}function ic(t){var n=t.deletions;if((t.flags&16)!==0){if(n!==null)for(var r=0;r<n.length;r++){var o=n[r];Cn=o,o0(o,t)}r0(t)}for(t=t.child;t!==null;){switch(n=t,n.tag){case 0:case 11:case 15:tr(8,n,n.return),ic(n);break;case 22:r=n.stateNode,r._visibility&2&&(r._visibility&=-3,ic(n));break;default:ic(n)}t=t.sibling}}function o0(t,n){for(;Cn!==null;){var r=Cn;switch(r.tag){case 0:case 11:case 15:tr(8,r,n);break;case 23:case 22:if(r.memoizedState!==null&&r.memoizedState.cachePool!==null){var o=r.memoizedState.cachePool.pool;o!=null&&o.refCount++}break;case 24:xo(r.memoizedState.cache)}if(o=r.child,o!==null)o.return=r,Cn=o;else e:for(r=t;Cn!==null;){o=Cn;var u=o.sibling,d=o.return;if(jg(o),o===r){Cn=null;break e}if(u!==null){u.return=d,Cn=u;break e}Cn=d}}}var JS={getCacheForType:function(t){var n=Nn(vn),r=n.data.get(t);return r===void 0&&(r=t(),n.data.set(t,r)),r},cacheSignal:function(){return Nn(vn).controller.signal}},$S=typeof WeakMap=="function"?WeakMap:Map,It=0,Jt=null,_t=null,yt=0,kt=0,oi=null,nr=!1,Ts=!1,Qf=!1,Ma=0,fn=0,ir=0,Vr=0,jf=0,li=0,As=0,Bo=null,Kn=null,Jf=!1,ac=0,l0=0,rc=1/0,sc=null,ar=null,bn=0,rr=null,Rs=null,Ea=0,$f=0,ed=null,c0=null,Fo=0,td=null;function ci(){return(It&2)!==0&&yt!==0?yt&-yt:L.T!==null?od():ns()}function u0(){if(li===0)if((yt&536870912)===0||Et){var t=at;at<<=1,(at&3932160)===0&&(at=262144),li=t}else li=536870912;return t=ri.current,t!==null&&(t.flags|=32),li}function Qn(t,n,r){(t===Jt&&(kt===2||kt===9)||t.cancelPendingCommit!==null)&&(Cs(t,0),sr(t,yt,li,!1)),Oe(t,r),((It&2)===0||t!==Jt)&&(t===Jt&&((It&2)===0&&(Vr|=r),fn===4&&sr(t,yt,li,!1)),Zi(t))}function f0(t,n,r){if((It&6)!==0)throw Error(s(327));var o=!r&&(n&127)===0&&(n&t.expiredLanes)===0||Ae(t,n),u=o?ny(t,n):id(t,n,!0),d=o;do{if(u===0){Ts&&!o&&sr(t,n,0,!1);break}else{if(r=t.current.alternate,d&&!ey(r)){u=id(t,n,!1),d=!1;continue}if(u===2){if(d=n,t.errorRecoveryDisabledLanes&d)var S=0;else S=t.pendingLanes&-536870913,S=S!==0?S:S&536870912?536870912:0;if(S!==0){n=S;e:{var R=t;u=Bo;var z=R.current.memoizedState.isDehydrated;if(z&&(Cs(R,S).flags|=256),S=id(R,S,!1),S!==2){if(Qf&&!z){R.errorRecoveryDisabledLanes|=d,Vr|=d,u=4;break e}d=Kn,Kn=u,d!==null&&(Kn===null?Kn=d:Kn.push.apply(Kn,d))}u=S}if(d=!1,u!==2)continue}}if(u===1){Cs(t,0),sr(t,n,0,!0);break}e:{switch(o=t,d=u,d){case 0:case 1:throw Error(s(345));case 4:if((n&4194048)!==n)break;case 6:sr(o,n,li,!nr);break e;case 2:Kn=null;break;case 3:case 5:break;default:throw Error(s(329))}if((n&62914560)===n&&(u=ac+300-Bt(),10<u)){if(sr(o,n,li,!nr),te(o,0,!0)!==0)break e;Ea=n,o.timeoutHandle=V0(d0.bind(null,o,r,Kn,sc,Jf,n,li,Vr,As,nr,d,"Throttled",-0,0),u);break e}d0(o,r,Kn,sc,Jf,n,li,Vr,As,nr,d,null,-0,0)}}break}while(!0);Zi(t)}function d0(t,n,r,o,u,d,S,R,z,ie,xe,Ee,le,ue){if(t.timeoutHandle=-1,Ee=n.subtreeFlags,Ee&8192||(Ee&16785408)===16785408){Ee={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:la},a0(n,d,Ee);var Ke=(d&62914560)===d?ac-Bt():(d&4194048)===d?l0-Bt():0;if(Ke=Fy(Ee,Ke),Ke!==null){Ea=d,t.cancelPendingCommit=Ke(S0.bind(null,t,n,d,r,o,u,S,R,z,xe,Ee,null,le,ue)),sr(t,d,S,!ie);return}}S0(t,n,d,r,o,u,S,R,z)}function ey(t){for(var n=t;;){var r=n.tag;if((r===0||r===11||r===15)&&n.flags&16384&&(r=n.updateQueue,r!==null&&(r=r.stores,r!==null)))for(var o=0;o<r.length;o++){var u=r[o],d=u.getSnapshot;u=u.value;try{if(!ii(d(),u))return!1}catch{return!1}}if(r=n.child,n.subtreeFlags&16384&&r!==null)r.return=n,n=r;else{if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return!0;n=n.return}n.sibling.return=n.return,n=n.sibling}}return!0}function sr(t,n,r,o){n&=~jf,n&=~Vr,t.suspendedLanes|=n,t.pingedLanes&=~n,o&&(t.warmLanes|=n),o=t.expirationTimes;for(var u=n;0<u;){var d=31-Ve(u),S=1<<d;o[d]=-1,u&=~S}r!==0&&Rt(t,r,n)}function oc(){return(It&6)===0?(zo(0),!1):!0}function nd(){if(_t!==null){if(kt===0)var t=_t.return;else t=_t,da=Lr=null,_f(t),_s=null,yo=0,t=_t;for(;t!==null;)kg(t.alternate,t),t=t.return;_t=null}}function Cs(t,n){var r=t.timeoutHandle;r!==-1&&(t.timeoutHandle=-1,Sy(r)),r=t.cancelPendingCommit,r!==null&&(t.cancelPendingCommit=null,r()),Ea=0,nd(),Jt=t,_t=r=ua(t.current,null),yt=n,kt=0,oi=null,nr=!1,Ts=Ae(t,n),Qf=!1,As=li=jf=Vr=ir=fn=0,Kn=Bo=null,Jf=!1,(n&8)!==0&&(n|=n&32);var o=t.entangledLanes;if(o!==0)for(t=t.entanglements,o&=n;0<o;){var u=31-Ve(o),d=1<<u;n|=t[u],o&=~d}return Ma=n,Cl(),r}function h0(t,n){ct=null,L.H=wo,n===vs||n===Il?(n=wm(),kt=3):n===sf?(n=wm(),kt=4):kt=n===Of?8:n!==null&&typeof n=="object"&&typeof n.then=="function"?6:1,oi=n,_t===null&&(fn=1,Ql(t,vi(n,t.current)))}function p0(){var t=ri.current;return t===null?!0:(yt&4194048)===yt?yi===null:(yt&62914560)===yt||(yt&536870912)!==0?t===yi:!1}function m0(){var t=L.H;return L.H=wo,t===null?wo:t}function g0(){var t=L.A;return L.A=JS,t}function lc(){fn=4,nr||(yt&4194048)!==yt&&ri.current!==null||(Ts=!0),(ir&134217727)===0&&(Vr&134217727)===0||Jt===null||sr(Jt,yt,li,!1)}function id(t,n,r){var o=It;It|=2;var u=m0(),d=g0();(Jt!==t||yt!==n)&&(sc=null,Cs(t,n)),n=!1;var S=fn;e:do try{if(kt!==0&&_t!==null){var R=_t,z=oi;switch(kt){case 8:nd(),S=6;break e;case 3:case 2:case 9:case 6:ri.current===null&&(n=!0);var ie=kt;if(kt=0,oi=null,ws(t,R,z,ie),r&&Ts){S=0;break e}break;default:ie=kt,kt=0,oi=null,ws(t,R,z,ie)}}ty(),S=fn;break}catch(xe){h0(t,xe)}while(!0);return n&&t.shellSuspendCounter++,da=Lr=null,It=o,L.H=u,L.A=d,_t===null&&(Jt=null,yt=0,Cl()),S}function ty(){for(;_t!==null;)v0(_t)}function ny(t,n){var r=It;It|=2;var o=m0(),u=g0();Jt!==t||yt!==n?(sc=null,rc=Bt()+500,Cs(t,n)):Ts=Ae(t,n);e:do try{if(kt!==0&&_t!==null){n=_t;var d=oi;t:switch(kt){case 1:kt=0,oi=null,ws(t,n,d,1);break;case 2:case 9:if(Rm(d)){kt=0,oi=null,_0(n);break}n=function(){kt!==2&&kt!==9||Jt!==t||(kt=7),Zi(t)},d.then(n,n);break e;case 3:kt=7;break e;case 4:kt=5;break e;case 7:Rm(d)?(kt=0,oi=null,_0(n)):(kt=0,oi=null,ws(t,n,d,7));break;case 5:var S=null;switch(_t.tag){case 26:S=_t.memoizedState;case 5:case 27:var R=_t;if(S?iv(S):R.stateNode.complete){kt=0,oi=null;var z=R.sibling;if(z!==null)_t=z;else{var ie=R.return;ie!==null?(_t=ie,cc(ie)):_t=null}break t}}kt=0,oi=null,ws(t,n,d,5);break;case 6:kt=0,oi=null,ws(t,n,d,6);break;case 8:nd(),fn=6;break e;default:throw Error(s(462))}}iy();break}catch(xe){h0(t,xe)}while(!0);return da=Lr=null,L.H=o,L.A=u,It=r,_t!==null?0:(Jt=null,yt=0,Cl(),fn)}function iy(){for(;_t!==null&&!St();)v0(_t)}function v0(t){var n=Gg(t.alternate,t,Ma);t.memoizedProps=t.pendingProps,n===null?cc(t):_t=n}function _0(t){var n=t,r=n.alternate;switch(n.tag){case 15:case 0:n=Pg(r,n,n.pendingProps,n.type,void 0,yt);break;case 11:n=Pg(r,n,n.pendingProps,n.type.render,n.ref,yt);break;case 5:_f(n);default:kg(r,n),n=_t=gm(n,Ma),n=Gg(r,n,Ma)}t.memoizedProps=t.pendingProps,n===null?cc(t):_t=n}function ws(t,n,r,o){da=Lr=null,_f(n),_s=null,yo=0;var u=n.return;try{if(WS(t,u,n,r,yt)){fn=1,Ql(t,vi(r,t.current)),_t=null;return}}catch(d){if(u!==null)throw _t=u,d;fn=1,Ql(t,vi(r,t.current)),_t=null;return}n.flags&32768?(Et||o===1?t=!0:Ts||(yt&536870912)!==0?t=!1:(nr=t=!0,(o===2||o===9||o===3||o===6)&&(o=ri.current,o!==null&&o.tag===13&&(o.flags|=16384))),x0(n,t)):cc(n)}function cc(t){var n=t;do{if((n.flags&32768)!==0){x0(n,nr);return}t=n.return;var r=ZS(n.alternate,n,Ma);if(r!==null){_t=r;return}if(n=n.sibling,n!==null){_t=n;return}_t=n=t}while(n!==null);fn===0&&(fn=5)}function x0(t,n){do{var r=KS(t.alternate,t);if(r!==null){r.flags&=32767,_t=r;return}if(r=t.return,r!==null&&(r.flags|=32768,r.subtreeFlags=0,r.deletions=null),!n&&(t=t.sibling,t!==null)){_t=t;return}_t=t=r}while(t!==null);fn=6,_t=null}function S0(t,n,r,o,u,d,S,R,z){t.cancelPendingCommit=null;do uc();while(bn!==0);if((It&6)!==0)throw Error(s(327));if(n!==null){if(n===t.current)throw Error(s(177));if(d=n.lanes|n.childLanes,d|=Xu,gt(t,r,d,S,R,z),t===Jt&&(_t=Jt=null,yt=0),Rs=n,rr=t,Ea=r,$f=d,ed=u,c0=o,(n.subtreeFlags&10256)!==0||(n.flags&10256)!==0?(t.callbackNode=null,t.callbackPriority=0,oy(K,function(){return T0(),null})):(t.callbackNode=null,t.callbackPriority=0),o=(n.flags&13878)!==0,(n.subtreeFlags&13878)!==0||o){o=L.T,L.T=null,u=H.p,H.p=2,S=It,It|=4;try{QS(t,n,r)}finally{It=S,H.p=u,L.T=o}}bn=1,y0(),M0(),E0()}}function y0(){if(bn===1){bn=0;var t=rr,n=Rs,r=(n.flags&13878)!==0;if((n.subtreeFlags&13878)!==0||r){r=L.T,L.T=null;var o=H.p;H.p=2;var u=It;It|=4;try{t0(n,t);var d=md,S=om(t.containerInfo),R=d.focusedElem,z=d.selectionRange;if(S!==R&&R&&R.ownerDocument&&sm(R.ownerDocument.documentElement,R)){if(z!==null&&zu(R)){var ie=z.start,xe=z.end;if(xe===void 0&&(xe=ie),"selectionStart"in R)R.selectionStart=ie,R.selectionEnd=Math.min(xe,R.value.length);else{var Ee=R.ownerDocument||document,le=Ee&&Ee.defaultView||window;if(le.getSelection){var ue=le.getSelection(),Ke=R.textContent.length,it=Math.min(z.start,Ke),Qt=z.end===void 0?it:Math.min(z.end,Ke);!ue.extend&&it>Qt&&(S=Qt,Qt=it,it=S);var Z=rm(R,it),G=rm(R,Qt);if(Z&&G&&(ue.rangeCount!==1||ue.anchorNode!==Z.node||ue.anchorOffset!==Z.offset||ue.focusNode!==G.node||ue.focusOffset!==G.offset)){var ne=Ee.createRange();ne.setStart(Z.node,Z.offset),ue.removeAllRanges(),it>Qt?(ue.addRange(ne),ue.extend(G.node,G.offset)):(ne.setEnd(G.node,G.offset),ue.addRange(ne))}}}}for(Ee=[],ue=R;ue=ue.parentNode;)ue.nodeType===1&&Ee.push({element:ue,left:ue.scrollLeft,top:ue.scrollTop});for(typeof R.focus=="function"&&R.focus(),R=0;R<Ee.length;R++){var ye=Ee[R];ye.element.scrollLeft=ye.left,ye.element.scrollTop=ye.top}}Mc=!!pd,md=pd=null}finally{It=u,H.p=o,L.T=r}}t.current=n,bn=2}}function M0(){if(bn===2){bn=0;var t=rr,n=Rs,r=(n.flags&8772)!==0;if((n.subtreeFlags&8772)!==0||r){r=L.T,L.T=null;var o=H.p;H.p=2;var u=It;It|=4;try{Qg(t,n.alternate,n)}finally{It=u,H.p=o,L.T=r}}bn=3}}function E0(){if(bn===4||bn===3){bn=0,X();var t=rr,n=Rs,r=Ea,o=c0;(n.subtreeFlags&10256)!==0||(n.flags&10256)!==0?bn=5:(bn=0,Rs=rr=null,b0(t,t.pendingLanes));var u=t.pendingLanes;if(u===0&&(ar=null),ei(r),n=n.stateNode,ge&&typeof ge.onCommitFiberRoot=="function")try{ge.onCommitFiberRoot(pe,n,void 0,(n.current.flags&128)===128)}catch{}if(o!==null){n=L.T,u=H.p,H.p=2,L.T=null;try{for(var d=t.onRecoverableError,S=0;S<o.length;S++){var R=o[S];d(R.value,{componentStack:R.stack})}}finally{L.T=n,H.p=u}}(Ea&3)!==0&&uc(),Zi(t),u=t.pendingLanes,(r&261930)!==0&&(u&42)!==0?t===td?Fo++:(Fo=0,td=t):Fo=0,zo(0)}}function b0(t,n){(t.pooledCacheLanes&=n)===0&&(n=t.pooledCache,n!=null&&(t.pooledCache=null,xo(n)))}function uc(){return y0(),M0(),E0(),T0()}function T0(){if(bn!==5)return!1;var t=rr,n=$f;$f=0;var r=ei(Ea),o=L.T,u=H.p;try{H.p=32>r?32:r,L.T=null,r=ed,ed=null;var d=rr,S=Ea;if(bn=0,Rs=rr=null,Ea=0,(It&6)!==0)throw Error(s(331));var R=It;if(It|=4,s0(d.current),i0(d,d.current,S,r),It=R,zo(0,!1),ge&&typeof ge.onPostCommitFiberRoot=="function")try{ge.onPostCommitFiberRoot(pe,d)}catch{}return!0}finally{H.p=u,L.T=o,b0(t,n)}}function A0(t,n,r){n=vi(r,n),n=Lf(t.stateNode,n,2),t=Ja(t,n,2),t!==null&&(Oe(t,2),Zi(t))}function Xt(t,n,r){if(t.tag===3)A0(t,t,r);else for(;n!==null;){if(n.tag===3){A0(n,t,r);break}else if(n.tag===1){var o=n.stateNode;if(typeof n.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(ar===null||!ar.has(o))){t=vi(r,t),r=Rg(2),o=Ja(n,r,2),o!==null&&(Cg(r,o,n,t),Oe(o,2),Zi(o));break}}n=n.return}}function ad(t,n,r){var o=t.pingCache;if(o===null){o=t.pingCache=new $S;var u=new Set;o.set(n,u)}else u=o.get(n),u===void 0&&(u=new Set,o.set(n,u));u.has(r)||(Qf=!0,u.add(r),t=ay.bind(null,t,n,r),n.then(t,t))}function ay(t,n,r){var o=t.pingCache;o!==null&&o.delete(n),t.pingedLanes|=t.suspendedLanes&r,t.warmLanes&=~r,Jt===t&&(yt&r)===r&&(fn===4||fn===3&&(yt&62914560)===yt&&300>Bt()-ac?(It&2)===0&&Cs(t,0):jf|=r,As===yt&&(As=0)),Zi(t)}function R0(t,n){n===0&&(n=Se()),t=Dr(t,n),t!==null&&(Oe(t,n),Zi(t))}function ry(t){var n=t.memoizedState,r=0;n!==null&&(r=n.retryLane),R0(t,r)}function sy(t,n){var r=0;switch(t.tag){case 31:case 13:var o=t.stateNode,u=t.memoizedState;u!==null&&(r=u.retryLane);break;case 19:o=t.stateNode;break;case 22:o=t.stateNode._retryCache;break;default:throw Error(s(314))}o!==null&&o.delete(n),R0(t,r)}function oy(t,n){return cn(t,n)}var fc=null,Ds=null,rd=!1,dc=!1,sd=!1,or=0;function Zi(t){t!==Ds&&t.next===null&&(Ds===null?fc=Ds=t:Ds=Ds.next=t),dc=!0,rd||(rd=!0,cy())}function zo(t,n){if(!sd&&dc){sd=!0;do for(var r=!1,o=fc;o!==null;){if(t!==0){var u=o.pendingLanes;if(u===0)var d=0;else{var S=o.suspendedLanes,R=o.pingedLanes;d=(1<<31-Ve(42|t)+1)-1,d&=u&~(S&~R),d=d&201326741?d&201326741|1:d?d|2:0}d!==0&&(r=!0,U0(o,d))}else d=yt,d=te(o,o===Jt?d:0,o.cancelPendingCommit!==null||o.timeoutHandle!==-1),(d&3)===0||Ae(o,d)||(r=!0,U0(o,d));o=o.next}while(r);sd=!1}}function ly(){C0()}function C0(){dc=rd=!1;var t=0;or!==0&&xy()&&(t=or);for(var n=Bt(),r=null,o=fc;o!==null;){var u=o.next,d=w0(o,n);d===0?(o.next=null,r===null?fc=u:r.next=u,u===null&&(Ds=r)):(r=o,(t!==0||(d&3)!==0)&&(dc=!0)),o=u}bn!==0&&bn!==5||zo(t),or!==0&&(or=0)}function w0(t,n){for(var r=t.suspendedLanes,o=t.pingedLanes,u=t.expirationTimes,d=t.pendingLanes&-62914561;0<d;){var S=31-Ve(d),R=1<<S,z=u[S];z===-1?((R&r)===0||(R&o)!==0)&&(u[S]=we(R,n)):z<=n&&(t.expiredLanes|=R),d&=~R}if(n=Jt,r=yt,r=te(t,t===n?r:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),o=t.callbackNode,r===0||t===n&&(kt===2||kt===9)||t.cancelPendingCommit!==null)return o!==null&&o!==null&&Yt(o),t.callbackNode=null,t.callbackPriority=0;if((r&3)===0||Ae(t,r)){if(n=r&-r,n===t.callbackPriority)return n;switch(o!==null&&Yt(o),ei(r)){case 2:case 8:r=E;break;case 32:r=K;break;case 268435456:r=he;break;default:r=K}return o=D0.bind(null,t),r=cn(r,o),t.callbackPriority=n,t.callbackNode=r,n}return o!==null&&o!==null&&Yt(o),t.callbackPriority=2,t.callbackNode=null,2}function D0(t,n){if(bn!==0&&bn!==5)return t.callbackNode=null,t.callbackPriority=0,null;var r=t.callbackNode;if(uc()&&t.callbackNode!==r)return null;var o=yt;return o=te(t,t===Jt?o:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),o===0?null:(f0(t,o,n),w0(t,Bt()),t.callbackNode!=null&&t.callbackNode===r?D0.bind(null,t):null)}function U0(t,n){if(uc())return null;f0(t,n,!0)}function cy(){yy(function(){(It&6)!==0?cn(D,ly):C0()})}function od(){if(or===0){var t=ms;t===0&&(t=$e,$e<<=1,($e&261888)===0&&($e=256)),or=t}return or}function N0(t){return t==null||typeof t=="symbol"||typeof t=="boolean"?null:typeof t=="function"?t:Ar(""+t)}function L0(t,n){var r=n.ownerDocument.createElement("input");return r.name=n.name,r.value=n.value,t.id&&r.setAttribute("form",t.id),n.parentNode.insertBefore(r,n),t=new FormData(t),r.parentNode.removeChild(r),t}function uy(t,n,r,o,u){if(n==="submit"&&r&&r.stateNode===u){var d=N0((u[Dn]||null).action),S=o.submitter;S&&(n=(n=S[Dn]||null)?N0(n.formAction):S.getAttribute("formAction"),n!==null&&(d=n,S=null));var R=new bl("action","action",null,o,u);t.push({event:R,listeners:[{instance:null,listener:function(){if(o.defaultPrevented){if(or!==0){var z=S?L0(u,S):new FormData(u);Rf(r,{pending:!0,data:z,method:u.method,action:d},null,z)}}else typeof d=="function"&&(R.preventDefault(),z=S?L0(u,S):new FormData(u),Rf(r,{pending:!0,data:z,method:u.method,action:d},d,z))},currentTarget:u}]})}}for(var ld=0;ld<ku.length;ld++){var cd=ku[ld],fy=cd.toLowerCase(),dy=cd[0].toUpperCase()+cd.slice(1);Ui(fy,"on"+dy)}Ui(um,"onAnimationEnd"),Ui(fm,"onAnimationIteration"),Ui(dm,"onAnimationStart"),Ui("dblclick","onDoubleClick"),Ui("focusin","onFocus"),Ui("focusout","onBlur"),Ui(CS,"onTransitionRun"),Ui(wS,"onTransitionStart"),Ui(DS,"onTransitionCancel"),Ui(hm,"onTransitionEnd"),oe("onMouseEnter",["mouseout","mouseover"]),oe("onMouseLeave",["mouseout","mouseover"]),oe("onPointerEnter",["pointerout","pointerover"]),oe("onPointerLeave",["pointerout","pointerover"]),W("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),W("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),W("onBeforeInput",["compositionend","keypress","textInput","paste"]),W("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),W("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),W("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Ho="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),hy=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Ho));function O0(t,n){n=(n&4)!==0;for(var r=0;r<t.length;r++){var o=t[r],u=o.event;o=o.listeners;e:{var d=void 0;if(n)for(var S=o.length-1;0<=S;S--){var R=o[S],z=R.instance,ie=R.currentTarget;if(R=R.listener,z!==d&&u.isPropagationStopped())break e;d=R,u.currentTarget=ie;try{d(u)}catch(xe){Rl(xe)}u.currentTarget=null,d=z}else for(S=0;S<o.length;S++){if(R=o[S],z=R.instance,ie=R.currentTarget,R=R.listener,z!==d&&u.isPropagationStopped())break e;d=R,u.currentTarget=ie;try{d(u)}catch(xe){Rl(xe)}u.currentTarget=null,d=z}}}}function xt(t,n){var r=n[Er];r===void 0&&(r=n[Er]=new Set);var o=t+"__bubble";r.has(o)||(P0(n,t,2,!1),r.add(o))}function ud(t,n,r){var o=0;n&&(o|=4),P0(r,t,o,n)}var hc="_reactListening"+Math.random().toString(36).slice(2);function fd(t){if(!t[hc]){t[hc]=!0,Sl.forEach(function(r){r!=="selectionchange"&&(hy.has(r)||ud(r,!1,t),ud(r,!0,t))});var n=t.nodeType===9?t:t.ownerDocument;n===null||n[hc]||(n[hc]=!0,ud("selectionchange",!1,n))}}function P0(t,n,r,o){switch(uv(n)){case 2:var u=Gy;break;case 8:u=Vy;break;default:u=Ad}r=u.bind(null,n,r,t),u=void 0,!Du||n!=="touchstart"&&n!=="touchmove"&&n!=="wheel"||(u=!0),o?u!==void 0?t.addEventListener(n,r,{capture:!0,passive:u}):t.addEventListener(n,r,!0):u!==void 0?t.addEventListener(n,r,{passive:u}):t.addEventListener(n,r,!1)}function dd(t,n,r,o,u){var d=o;if((n&1)===0&&(n&2)===0&&o!==null)e:for(;;){if(o===null)return;var S=o.tag;if(S===3||S===4){var R=o.stateNode.containerInfo;if(R===u)break;if(S===4)for(S=o.return;S!==null;){var z=S.tag;if((z===3||z===4)&&S.stateNode.containerInfo===u)return;S=S.return}for(;R!==null;){if(S=sa(R),S===null)return;if(z=S.tag,z===5||z===6||z===26||z===27){o=d=S;continue e}R=R.parentNode}}o=o.return}Hp(function(){var ie=d,xe=Cu(r),Ee=[];e:{var le=pm.get(t);if(le!==void 0){var ue=bl,Ke=t;switch(t){case"keypress":if(Ml(r)===0)break e;case"keydown":case"keyup":ue=sS;break;case"focusin":Ke="focus",ue=Ou;break;case"focusout":Ke="blur",ue=Ou;break;case"beforeblur":case"afterblur":ue=Ou;break;case"click":if(r.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":ue=kp;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":ue=Zx;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":ue=cS;break;case um:case fm:case dm:ue=jx;break;case hm:ue=fS;break;case"scroll":case"scrollend":ue=qx;break;case"wheel":ue=hS;break;case"copy":case"cut":case"paste":ue=$x;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":ue=Wp;break;case"toggle":case"beforetoggle":ue=mS}var it=(n&4)!==0,Qt=!it&&(t==="scroll"||t==="scrollend"),Z=it?le!==null?le+"Capture":null:le;it=[];for(var G=ie,ne;G!==null;){var ye=G;if(ne=ye.stateNode,ye=ye.tag,ye!==5&&ye!==26&&ye!==27||ne===null||Z===null||(ye=oo(G,Z),ye!=null&&it.push(Go(G,ye,ne))),Qt)break;G=G.return}0<it.length&&(le=new ue(le,Ke,null,r,xe),Ee.push({event:le,listeners:it}))}}if((n&7)===0){e:{if(le=t==="mouseover"||t==="pointerover",ue=t==="mouseout"||t==="pointerout",le&&r!==Ru&&(Ke=r.relatedTarget||r.fromElement)&&(sa(Ke)||Ke[Xn]))break e;if((ue||le)&&(le=xe.window===xe?xe:(le=xe.ownerDocument)?le.defaultView||le.parentWindow:window,ue?(Ke=r.relatedTarget||r.toElement,ue=ie,Ke=Ke?sa(Ke):null,Ke!==null&&(Qt=c(Ke),it=Ke.tag,Ke!==Qt||it!==5&&it!==27&&it!==6)&&(Ke=null)):(ue=null,Ke=ie),ue!==Ke)){if(it=kp,ye="onMouseLeave",Z="onMouseEnter",G="mouse",(t==="pointerout"||t==="pointerover")&&(it=Wp,ye="onPointerLeave",Z="onPointerEnter",G="pointer"),Qt=ue==null?le:Tr(ue),ne=Ke==null?le:Tr(Ke),le=new it(ye,G+"leave",ue,r,xe),le.target=Qt,le.relatedTarget=ne,ye=null,sa(xe)===ie&&(it=new it(Z,G+"enter",Ke,r,xe),it.target=ne,it.relatedTarget=Qt,ye=it),Qt=ye,ue&&Ke)t:{for(it=py,Z=ue,G=Ke,ne=0,ye=Z;ye;ye=it(ye))ne++;ye=0;for(var tt=G;tt;tt=it(tt))ye++;for(;0<ne-ye;)Z=it(Z),ne--;for(;0<ye-ne;)G=it(G),ye--;for(;ne--;){if(Z===G||G!==null&&Z===G.alternate){it=Z;break t}Z=it(Z),G=it(G)}it=null}else it=null;ue!==null&&I0(Ee,le,ue,it,!1),Ke!==null&&Qt!==null&&I0(Ee,Qt,Ke,it,!0)}}e:{if(le=ie?Tr(ie):window,ue=le.nodeName&&le.nodeName.toLowerCase(),ue==="select"||ue==="input"&&le.type==="file")var Lt=$p;else if(jp(le))if(em)Lt=TS;else{Lt=ES;var Qe=MS}else ue=le.nodeName,!ue||ue.toLowerCase()!=="input"||le.type!=="checkbox"&&le.type!=="radio"?ie&&Ft(ie.elementType)&&(Lt=$p):Lt=bS;if(Lt&&(Lt=Lt(t,ie))){Jp(Ee,Lt,r,xe);break e}Qe&&Qe(t,le,ie),t==="focusout"&&ie&&le.type==="number"&&ie.memoizedProps.value!=null&&vt(le,"number",le.value)}switch(Qe=ie?Tr(ie):window,t){case"focusin":(jp(Qe)||Qe.contentEditable==="true")&&(os=Qe,Hu=ie,go=null);break;case"focusout":go=Hu=os=null;break;case"mousedown":Gu=!0;break;case"contextmenu":case"mouseup":case"dragend":Gu=!1,lm(Ee,r,xe);break;case"selectionchange":if(RS)break;case"keydown":case"keyup":lm(Ee,r,xe)}var ft;if(Iu)e:{switch(t){case"compositionstart":var Mt="onCompositionStart";break e;case"compositionend":Mt="onCompositionEnd";break e;case"compositionupdate":Mt="onCompositionUpdate";break e}Mt=void 0}else ss?Kp(t,r)&&(Mt="onCompositionEnd"):t==="keydown"&&r.keyCode===229&&(Mt="onCompositionStart");Mt&&(qp&&r.locale!=="ko"&&(ss||Mt!=="onCompositionStart"?Mt==="onCompositionEnd"&&ss&&(ft=Gp()):(Wa=xe,Uu="value"in Wa?Wa.value:Wa.textContent,ss=!0)),Qe=pc(ie,Mt),0<Qe.length&&(Mt=new Xp(Mt,t,null,r,xe),Ee.push({event:Mt,listeners:Qe}),ft?Mt.data=ft:(ft=Qp(r),ft!==null&&(Mt.data=ft)))),(ft=vS?_S(t,r):xS(t,r))&&(Mt=pc(ie,"onBeforeInput"),0<Mt.length&&(Qe=new Xp("onBeforeInput","beforeinput",null,r,xe),Ee.push({event:Qe,listeners:Mt}),Qe.data=ft)),uy(Ee,t,ie,r,xe)}O0(Ee,n)})}function Go(t,n,r){return{instance:t,listener:n,currentTarget:r}}function pc(t,n){for(var r=n+"Capture",o=[];t!==null;){var u=t,d=u.stateNode;if(u=u.tag,u!==5&&u!==26&&u!==27||d===null||(u=oo(t,r),u!=null&&o.unshift(Go(t,u,d)),u=oo(t,n),u!=null&&o.push(Go(t,u,d))),t.tag===3)return o;t=t.return}return[]}function py(t){if(t===null)return null;do t=t.return;while(t&&t.tag!==5&&t.tag!==27);return t||null}function I0(t,n,r,o,u){for(var d=n._reactName,S=[];r!==null&&r!==o;){var R=r,z=R.alternate,ie=R.stateNode;if(R=R.tag,z!==null&&z===o)break;R!==5&&R!==26&&R!==27||ie===null||(z=ie,u?(ie=oo(r,d),ie!=null&&S.unshift(Go(r,ie,z))):u||(ie=oo(r,d),ie!=null&&S.push(Go(r,ie,z)))),r=r.return}S.length!==0&&t.push({event:n,listeners:S})}var my=/\r\n?/g,gy=/\u0000|\uFFFD/g;function B0(t){return(typeof t=="string"?t:""+t).replace(my,`
`).replace(gy,"")}function F0(t,n){return n=B0(n),B0(t)===n}function Kt(t,n,r,o,u,d){switch(r){case"children":typeof o=="string"?n==="body"||n==="textarea"&&o===""||ni(t,o):(typeof o=="number"||typeof o=="bigint")&&n!=="body"&&ni(t,""+o);break;case"className":Ze(t,"class",o);break;case"tabIndex":Ze(t,"tabindex",o);break;case"dir":case"role":case"viewBox":case"width":case"height":Ze(t,r,o);break;case"style":Di(t,o,d);break;case"data":if(n!=="object"){Ze(t,"data",o);break}case"src":case"href":if(o===""&&(n!=="a"||r!=="href")){t.removeAttribute(r);break}if(o==null||typeof o=="function"||typeof o=="symbol"||typeof o=="boolean"){t.removeAttribute(r);break}o=Ar(""+o),t.setAttribute(r,o);break;case"action":case"formAction":if(typeof o=="function"){t.setAttribute(r,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof d=="function"&&(r==="formAction"?(n!=="input"&&Kt(t,n,"name",u.name,u,null),Kt(t,n,"formEncType",u.formEncType,u,null),Kt(t,n,"formMethod",u.formMethod,u,null),Kt(t,n,"formTarget",u.formTarget,u,null)):(Kt(t,n,"encType",u.encType,u,null),Kt(t,n,"method",u.method,u,null),Kt(t,n,"target",u.target,u,null)));if(o==null||typeof o=="symbol"||typeof o=="boolean"){t.removeAttribute(r);break}o=Ar(""+o),t.setAttribute(r,o);break;case"onClick":o!=null&&(t.onclick=la);break;case"onScroll":o!=null&&xt("scroll",t);break;case"onScrollEnd":o!=null&&xt("scrollend",t);break;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(s(61));if(r=o.__html,r!=null){if(u.children!=null)throw Error(s(60));t.innerHTML=r}}break;case"multiple":t.multiple=o&&typeof o!="function"&&typeof o!="symbol";break;case"muted":t.muted=o&&typeof o!="function"&&typeof o!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(o==null||typeof o=="function"||typeof o=="boolean"||typeof o=="symbol"){t.removeAttribute("xlink:href");break}r=Ar(""+o),t.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",r);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":o!=null&&typeof o!="function"&&typeof o!="symbol"?t.setAttribute(r,""+o):t.removeAttribute(r);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":o&&typeof o!="function"&&typeof o!="symbol"?t.setAttribute(r,""):t.removeAttribute(r);break;case"capture":case"download":o===!0?t.setAttribute(r,""):o!==!1&&o!=null&&typeof o!="function"&&typeof o!="symbol"?t.setAttribute(r,o):t.removeAttribute(r);break;case"cols":case"rows":case"size":case"span":o!=null&&typeof o!="function"&&typeof o!="symbol"&&!isNaN(o)&&1<=o?t.setAttribute(r,o):t.removeAttribute(r);break;case"rowSpan":case"start":o==null||typeof o=="function"||typeof o=="symbol"||isNaN(o)?t.removeAttribute(r):t.setAttribute(r,o);break;case"popover":xt("beforetoggle",t),xt("toggle",t),Fe(t,"popover",o);break;case"xlinkActuate":qe(t,"http://www.w3.org/1999/xlink","xlink:actuate",o);break;case"xlinkArcrole":qe(t,"http://www.w3.org/1999/xlink","xlink:arcrole",o);break;case"xlinkRole":qe(t,"http://www.w3.org/1999/xlink","xlink:role",o);break;case"xlinkShow":qe(t,"http://www.w3.org/1999/xlink","xlink:show",o);break;case"xlinkTitle":qe(t,"http://www.w3.org/1999/xlink","xlink:title",o);break;case"xlinkType":qe(t,"http://www.w3.org/1999/xlink","xlink:type",o);break;case"xmlBase":qe(t,"http://www.w3.org/XML/1998/namespace","xml:base",o);break;case"xmlLang":qe(t,"http://www.w3.org/XML/1998/namespace","xml:lang",o);break;case"xmlSpace":qe(t,"http://www.w3.org/XML/1998/namespace","xml:space",o);break;case"is":Fe(t,"is",o);break;case"innerText":case"textContent":break;default:(!(2<r.length)||r[0]!=="o"&&r[0]!=="O"||r[1]!=="n"&&r[1]!=="N")&&(r=Xi.get(r)||r,Fe(t,r,o))}}function hd(t,n,r,o,u,d){switch(r){case"style":Di(t,o,d);break;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(s(61));if(r=o.__html,r!=null){if(u.children!=null)throw Error(s(60));t.innerHTML=r}}break;case"children":typeof o=="string"?ni(t,o):(typeof o=="number"||typeof o=="bigint")&&ni(t,""+o);break;case"onScroll":o!=null&&xt("scroll",t);break;case"onScrollEnd":o!=null&&xt("scrollend",t);break;case"onClick":o!=null&&(t.onclick=la);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!A.hasOwnProperty(r))e:{if(r[0]==="o"&&r[1]==="n"&&(u=r.endsWith("Capture"),n=r.slice(2,u?r.length-7:void 0),d=t[Dn]||null,d=d!=null?d[r]:null,typeof d=="function"&&t.removeEventListener(n,d,u),typeof o=="function")){typeof d!="function"&&d!==null&&(r in t?t[r]=null:t.hasAttribute(r)&&t.removeAttribute(r)),t.addEventListener(n,o,u);break e}r in t?t[r]=o:o===!0?t.setAttribute(r,""):Fe(t,r,o)}}}function On(t,n,r){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":xt("error",t),xt("load",t);var o=!1,u=!1,d;for(d in r)if(r.hasOwnProperty(d)){var S=r[d];if(S!=null)switch(d){case"src":o=!0;break;case"srcSet":u=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(s(137,n));default:Kt(t,n,d,S,r,null)}}u&&Kt(t,n,"srcSet",r.srcSet,r,null),o&&Kt(t,n,"src",r.src,r,null);return;case"input":xt("invalid",t);var R=d=S=u=null,z=null,ie=null;for(o in r)if(r.hasOwnProperty(o)){var xe=r[o];if(xe!=null)switch(o){case"name":u=xe;break;case"type":S=xe;break;case"checked":z=xe;break;case"defaultChecked":ie=xe;break;case"value":d=xe;break;case"defaultValue":R=xe;break;case"children":case"dangerouslySetInnerHTML":if(xe!=null)throw Error(s(137,n));break;default:Kt(t,n,o,xe,r,null)}}In(t,d,R,z,ie,S,u,!1);return;case"select":xt("invalid",t),o=S=d=null;for(u in r)if(r.hasOwnProperty(u)&&(R=r[u],R!=null))switch(u){case"value":d=R;break;case"defaultValue":S=R;break;case"multiple":o=R;default:Kt(t,n,u,R,r,null)}n=d,r=S,t.multiple=!!o,n!=null?En(t,!!o,n,!1):r!=null&&En(t,!!o,r,!0);return;case"textarea":xt("invalid",t),d=u=o=null;for(S in r)if(r.hasOwnProperty(S)&&(R=r[S],R!=null))switch(S){case"value":o=R;break;case"defaultValue":u=R;break;case"children":d=R;break;case"dangerouslySetInnerHTML":if(R!=null)throw Error(s(91));break;default:Kt(t,n,S,R,r,null)}wi(t,o,u,d);return;case"option":for(z in r)r.hasOwnProperty(z)&&(o=r[z],o!=null)&&(z==="selected"?t.selected=o&&typeof o!="function"&&typeof o!="symbol":Kt(t,n,z,o,r,null));return;case"dialog":xt("beforetoggle",t),xt("toggle",t),xt("cancel",t),xt("close",t);break;case"iframe":case"object":xt("load",t);break;case"video":case"audio":for(o=0;o<Ho.length;o++)xt(Ho[o],t);break;case"image":xt("error",t),xt("load",t);break;case"details":xt("toggle",t);break;case"embed":case"source":case"link":xt("error",t),xt("load",t);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(ie in r)if(r.hasOwnProperty(ie)&&(o=r[ie],o!=null))switch(ie){case"children":case"dangerouslySetInnerHTML":throw Error(s(137,n));default:Kt(t,n,ie,o,r,null)}return;default:if(Ft(n)){for(xe in r)r.hasOwnProperty(xe)&&(o=r[xe],o!==void 0&&hd(t,n,xe,o,r,void 0));return}}for(R in r)r.hasOwnProperty(R)&&(o=r[R],o!=null&&Kt(t,n,R,o,r,null))}function vy(t,n,r,o){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var u=null,d=null,S=null,R=null,z=null,ie=null,xe=null;for(ue in r){var Ee=r[ue];if(r.hasOwnProperty(ue)&&Ee!=null)switch(ue){case"checked":break;case"value":break;case"defaultValue":z=Ee;default:o.hasOwnProperty(ue)||Kt(t,n,ue,null,o,Ee)}}for(var le in o){var ue=o[le];if(Ee=r[le],o.hasOwnProperty(le)&&(ue!=null||Ee!=null))switch(le){case"type":d=ue;break;case"name":u=ue;break;case"checked":ie=ue;break;case"defaultChecked":xe=ue;break;case"value":S=ue;break;case"defaultValue":R=ue;break;case"children":case"dangerouslySetInnerHTML":if(ue!=null)throw Error(s(137,n));break;default:ue!==Ee&&Kt(t,n,le,ue,o,Ee)}}ke(t,S,R,z,ie,xe,d,u);return;case"select":ue=S=R=le=null;for(d in r)if(z=r[d],r.hasOwnProperty(d)&&z!=null)switch(d){case"value":break;case"multiple":ue=z;default:o.hasOwnProperty(d)||Kt(t,n,d,null,o,z)}for(u in o)if(d=o[u],z=r[u],o.hasOwnProperty(u)&&(d!=null||z!=null))switch(u){case"value":le=d;break;case"defaultValue":R=d;break;case"multiple":S=d;default:d!==z&&Kt(t,n,u,d,o,z)}n=R,r=S,o=ue,le!=null?En(t,!!r,le,!1):!!o!=!!r&&(n!=null?En(t,!!r,n,!0):En(t,!!r,r?[]:"",!1));return;case"textarea":ue=le=null;for(R in r)if(u=r[R],r.hasOwnProperty(R)&&u!=null&&!o.hasOwnProperty(R))switch(R){case"value":break;case"children":break;default:Kt(t,n,R,null,o,u)}for(S in o)if(u=o[S],d=r[S],o.hasOwnProperty(S)&&(u!=null||d!=null))switch(S){case"value":le=u;break;case"defaultValue":ue=u;break;case"children":break;case"dangerouslySetInnerHTML":if(u!=null)throw Error(s(91));break;default:u!==d&&Kt(t,n,S,u,o,d)}ti(t,le,ue);return;case"option":for(var Ke in r)le=r[Ke],r.hasOwnProperty(Ke)&&le!=null&&!o.hasOwnProperty(Ke)&&(Ke==="selected"?t.selected=!1:Kt(t,n,Ke,null,o,le));for(z in o)le=o[z],ue=r[z],o.hasOwnProperty(z)&&le!==ue&&(le!=null||ue!=null)&&(z==="selected"?t.selected=le&&typeof le!="function"&&typeof le!="symbol":Kt(t,n,z,le,o,ue));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var it in r)le=r[it],r.hasOwnProperty(it)&&le!=null&&!o.hasOwnProperty(it)&&Kt(t,n,it,null,o,le);for(ie in o)if(le=o[ie],ue=r[ie],o.hasOwnProperty(ie)&&le!==ue&&(le!=null||ue!=null))switch(ie){case"children":case"dangerouslySetInnerHTML":if(le!=null)throw Error(s(137,n));break;default:Kt(t,n,ie,le,o,ue)}return;default:if(Ft(n)){for(var Qt in r)le=r[Qt],r.hasOwnProperty(Qt)&&le!==void 0&&!o.hasOwnProperty(Qt)&&hd(t,n,Qt,void 0,o,le);for(xe in o)le=o[xe],ue=r[xe],!o.hasOwnProperty(xe)||le===ue||le===void 0&&ue===void 0||hd(t,n,xe,le,o,ue);return}}for(var Z in r)le=r[Z],r.hasOwnProperty(Z)&&le!=null&&!o.hasOwnProperty(Z)&&Kt(t,n,Z,null,o,le);for(Ee in o)le=o[Ee],ue=r[Ee],!o.hasOwnProperty(Ee)||le===ue||le==null&&ue==null||Kt(t,n,Ee,le,o,ue)}function z0(t){switch(t){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function _y(){if(typeof performance.getEntriesByType=="function"){for(var t=0,n=0,r=performance.getEntriesByType("resource"),o=0;o<r.length;o++){var u=r[o],d=u.transferSize,S=u.initiatorType,R=u.duration;if(d&&R&&z0(S)){for(S=0,R=u.responseEnd,o+=1;o<r.length;o++){var z=r[o],ie=z.startTime;if(ie>R)break;var xe=z.transferSize,Ee=z.initiatorType;xe&&z0(Ee)&&(z=z.responseEnd,S+=xe*(z<R?1:(R-ie)/(z-ie)))}if(--o,n+=8*(d+S)/(u.duration/1e3),t++,10<t)break}}if(0<t)return n/t/1e6}return navigator.connection&&(t=navigator.connection.downlink,typeof t=="number")?t:5}var pd=null,md=null;function mc(t){return t.nodeType===9?t:t.ownerDocument}function H0(t){switch(t){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function G0(t,n){if(t===0)switch(n){case"svg":return 1;case"math":return 2;default:return 0}return t===1&&n==="foreignObject"?0:t}function gd(t,n){return t==="textarea"||t==="noscript"||typeof n.children=="string"||typeof n.children=="number"||typeof n.children=="bigint"||typeof n.dangerouslySetInnerHTML=="object"&&n.dangerouslySetInnerHTML!==null&&n.dangerouslySetInnerHTML.__html!=null}var vd=null;function xy(){var t=window.event;return t&&t.type==="popstate"?t===vd?!1:(vd=t,!0):(vd=null,!1)}var V0=typeof setTimeout=="function"?setTimeout:void 0,Sy=typeof clearTimeout=="function"?clearTimeout:void 0,k0=typeof Promise=="function"?Promise:void 0,yy=typeof queueMicrotask=="function"?queueMicrotask:typeof k0<"u"?function(t){return k0.resolve(null).then(t).catch(My)}:V0;function My(t){setTimeout(function(){throw t})}function lr(t){return t==="head"}function X0(t,n){var r=n,o=0;do{var u=r.nextSibling;if(t.removeChild(r),u&&u.nodeType===8)if(r=u.data,r==="/$"||r==="/&"){if(o===0){t.removeChild(u),Os(n);return}o--}else if(r==="$"||r==="$?"||r==="$~"||r==="$!"||r==="&")o++;else if(r==="html")Vo(t.ownerDocument.documentElement);else if(r==="head"){r=t.ownerDocument.head,Vo(r);for(var d=r.firstChild;d;){var S=d.nextSibling,R=d.nodeName;d[Ga]||R==="SCRIPT"||R==="STYLE"||R==="LINK"&&d.rel.toLowerCase()==="stylesheet"||r.removeChild(d),d=S}}else r==="body"&&Vo(t.ownerDocument.body);r=u}while(r);Os(n)}function W0(t,n){var r=t;t=0;do{var o=r.nextSibling;if(r.nodeType===1?n?(r._stashedDisplay=r.style.display,r.style.display="none"):(r.style.display=r._stashedDisplay||"",r.getAttribute("style")===""&&r.removeAttribute("style")):r.nodeType===3&&(n?(r._stashedText=r.nodeValue,r.nodeValue=""):r.nodeValue=r._stashedText||""),o&&o.nodeType===8)if(r=o.data,r==="/$"){if(t===0)break;t--}else r!=="$"&&r!=="$?"&&r!=="$~"&&r!=="$!"||t++;r=o}while(r)}function _d(t){var n=t.firstChild;for(n&&n.nodeType===10&&(n=n.nextSibling);n;){var r=n;switch(n=n.nextSibling,r.nodeName){case"HTML":case"HEAD":case"BODY":_d(r),Va(r);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(r.rel.toLowerCase()==="stylesheet")continue}t.removeChild(r)}}function Ey(t,n,r,o){for(;t.nodeType===1;){var u=r;if(t.nodeName.toLowerCase()!==n.toLowerCase()){if(!o&&(t.nodeName!=="INPUT"||t.type!=="hidden"))break}else if(o){if(!t[Ga])switch(n){case"meta":if(!t.hasAttribute("itemprop"))break;return t;case"link":if(d=t.getAttribute("rel"),d==="stylesheet"&&t.hasAttribute("data-precedence"))break;if(d!==u.rel||t.getAttribute("href")!==(u.href==null||u.href===""?null:u.href)||t.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin)||t.getAttribute("title")!==(u.title==null?null:u.title))break;return t;case"style":if(t.hasAttribute("data-precedence"))break;return t;case"script":if(d=t.getAttribute("src"),(d!==(u.src==null?null:u.src)||t.getAttribute("type")!==(u.type==null?null:u.type)||t.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin))&&d&&t.hasAttribute("async")&&!t.hasAttribute("itemprop"))break;return t;default:return t}}else if(n==="input"&&t.type==="hidden"){var d=u.name==null?null:""+u.name;if(u.type==="hidden"&&t.getAttribute("name")===d)return t}else return t;if(t=Mi(t.nextSibling),t===null)break}return null}function by(t,n,r){if(n==="")return null;for(;t.nodeType!==3;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!r||(t=Mi(t.nextSibling),t===null))return null;return t}function q0(t,n){for(;t.nodeType!==8;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!n||(t=Mi(t.nextSibling),t===null))return null;return t}function xd(t){return t.data==="$?"||t.data==="$~"}function Sd(t){return t.data==="$!"||t.data==="$?"&&t.ownerDocument.readyState!=="loading"}function Ty(t,n){var r=t.ownerDocument;if(t.data==="$~")t._reactRetry=n;else if(t.data!=="$?"||r.readyState!=="loading")n();else{var o=function(){n(),r.removeEventListener("DOMContentLoaded",o)};r.addEventListener("DOMContentLoaded",o),t._reactRetry=o}}function Mi(t){for(;t!=null;t=t.nextSibling){var n=t.nodeType;if(n===1||n===3)break;if(n===8){if(n=t.data,n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"||n==="F!"||n==="F")break;if(n==="/$"||n==="/&")return null}}return t}var yd=null;function Y0(t){t=t.nextSibling;for(var n=0;t;){if(t.nodeType===8){var r=t.data;if(r==="/$"||r==="/&"){if(n===0)return Mi(t.nextSibling);n--}else r!=="$"&&r!=="$!"&&r!=="$?"&&r!=="$~"&&r!=="&"||n++}t=t.nextSibling}return null}function Z0(t){t=t.previousSibling;for(var n=0;t;){if(t.nodeType===8){var r=t.data;if(r==="$"||r==="$!"||r==="$?"||r==="$~"||r==="&"){if(n===0)return t;n--}else r!=="/$"&&r!=="/&"||n++}t=t.previousSibling}return null}function K0(t,n,r){switch(n=mc(r),t){case"html":if(t=n.documentElement,!t)throw Error(s(452));return t;case"head":if(t=n.head,!t)throw Error(s(453));return t;case"body":if(t=n.body,!t)throw Error(s(454));return t;default:throw Error(s(451))}}function Vo(t){for(var n=t.attributes;n.length;)t.removeAttributeNode(n[0]);Va(t)}var Ei=new Map,Q0=new Set;function gc(t){return typeof t.getRootNode=="function"?t.getRootNode():t.nodeType===9?t:t.ownerDocument}var ba=H.d;H.d={f:Ay,r:Ry,D:Cy,C:wy,L:Dy,m:Uy,X:Ly,S:Ny,M:Oy};function Ay(){var t=ba.f(),n=oc();return t||n}function Ry(t){var n=oa(t);n!==null&&n.tag===5&&n.type==="form"?hg(n):ba.r(t)}var Us=typeof document>"u"?null:document;function j0(t,n,r){var o=Us;if(o&&typeof n=="string"&&n){var u=Gt(n);u='link[rel="'+t+'"][href="'+u+'"]',typeof r=="string"&&(u+='[crossorigin="'+r+'"]'),Q0.has(u)||(Q0.add(u),t={rel:t,crossOrigin:r,href:n},o.querySelector(u)===null&&(n=o.createElement("link"),On(n,"link",t),gn(n),o.head.appendChild(n)))}}function Cy(t){ba.D(t),j0("dns-prefetch",t,null)}function wy(t,n){ba.C(t,n),j0("preconnect",t,n)}function Dy(t,n,r){ba.L(t,n,r);var o=Us;if(o&&t&&n){var u='link[rel="preload"][as="'+Gt(n)+'"]';n==="image"&&r&&r.imageSrcSet?(u+='[imagesrcset="'+Gt(r.imageSrcSet)+'"]',typeof r.imageSizes=="string"&&(u+='[imagesizes="'+Gt(r.imageSizes)+'"]')):u+='[href="'+Gt(t)+'"]';var d=u;switch(n){case"style":d=Ns(t);break;case"script":d=Ls(t)}Ei.has(d)||(t=g({rel:"preload",href:n==="image"&&r&&r.imageSrcSet?void 0:t,as:n},r),Ei.set(d,t),o.querySelector(u)!==null||n==="style"&&o.querySelector(ko(d))||n==="script"&&o.querySelector(Xo(d))||(n=o.createElement("link"),On(n,"link",t),gn(n),o.head.appendChild(n)))}}function Uy(t,n){ba.m(t,n);var r=Us;if(r&&t){var o=n&&typeof n.as=="string"?n.as:"script",u='link[rel="modulepreload"][as="'+Gt(o)+'"][href="'+Gt(t)+'"]',d=u;switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":d=Ls(t)}if(!Ei.has(d)&&(t=g({rel:"modulepreload",href:t},n),Ei.set(d,t),r.querySelector(u)===null)){switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(r.querySelector(Xo(d)))return}o=r.createElement("link"),On(o,"link",t),gn(o),r.head.appendChild(o)}}}function Ny(t,n,r){ba.S(t,n,r);var o=Us;if(o&&t){var u=ka(o).hoistableStyles,d=Ns(t);n=n||"default";var S=u.get(d);if(!S){var R={loading:0,preload:null};if(S=o.querySelector(ko(d)))R.loading=5;else{t=g({rel:"stylesheet",href:t,"data-precedence":n},r),(r=Ei.get(d))&&Md(t,r);var z=S=o.createElement("link");gn(z),On(z,"link",t),z._p=new Promise(function(ie,xe){z.onload=ie,z.onerror=xe}),z.addEventListener("load",function(){R.loading|=1}),z.addEventListener("error",function(){R.loading|=2}),R.loading|=4,vc(S,n,o)}S={type:"stylesheet",instance:S,count:1,state:R},u.set(d,S)}}}function Ly(t,n){ba.X(t,n);var r=Us;if(r&&t){var o=ka(r).hoistableScripts,u=Ls(t),d=o.get(u);d||(d=r.querySelector(Xo(u)),d||(t=g({src:t,async:!0},n),(n=Ei.get(u))&&Ed(t,n),d=r.createElement("script"),gn(d),On(d,"link",t),r.head.appendChild(d)),d={type:"script",instance:d,count:1,state:null},o.set(u,d))}}function Oy(t,n){ba.M(t,n);var r=Us;if(r&&t){var o=ka(r).hoistableScripts,u=Ls(t),d=o.get(u);d||(d=r.querySelector(Xo(u)),d||(t=g({src:t,async:!0,type:"module"},n),(n=Ei.get(u))&&Ed(t,n),d=r.createElement("script"),gn(d),On(d,"link",t),r.head.appendChild(d)),d={type:"script",instance:d,count:1,state:null},o.set(u,d))}}function J0(t,n,r,o){var u=(u=ee.current)?gc(u):null;if(!u)throw Error(s(446));switch(t){case"meta":case"title":return null;case"style":return typeof r.precedence=="string"&&typeof r.href=="string"?(n=Ns(r.href),r=ka(u).hoistableStyles,o=r.get(n),o||(o={type:"style",instance:null,count:0,state:null},r.set(n,o)),o):{type:"void",instance:null,count:0,state:null};case"link":if(r.rel==="stylesheet"&&typeof r.href=="string"&&typeof r.precedence=="string"){t=Ns(r.href);var d=ka(u).hoistableStyles,S=d.get(t);if(S||(u=u.ownerDocument||u,S={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},d.set(t,S),(d=u.querySelector(ko(t)))&&!d._p&&(S.instance=d,S.state.loading=5),Ei.has(t)||(r={rel:"preload",as:"style",href:r.href,crossOrigin:r.crossOrigin,integrity:r.integrity,media:r.media,hrefLang:r.hrefLang,referrerPolicy:r.referrerPolicy},Ei.set(t,r),d||Py(u,t,r,S.state))),n&&o===null)throw Error(s(528,""));return S}if(n&&o!==null)throw Error(s(529,""));return null;case"script":return n=r.async,r=r.src,typeof r=="string"&&n&&typeof n!="function"&&typeof n!="symbol"?(n=Ls(r),r=ka(u).hoistableScripts,o=r.get(n),o||(o={type:"script",instance:null,count:0,state:null},r.set(n,o)),o):{type:"void",instance:null,count:0,state:null};default:throw Error(s(444,t))}}function Ns(t){return'href="'+Gt(t)+'"'}function ko(t){return'link[rel="stylesheet"]['+t+"]"}function $0(t){return g({},t,{"data-precedence":t.precedence,precedence:null})}function Py(t,n,r,o){t.querySelector('link[rel="preload"][as="style"]['+n+"]")?o.loading=1:(n=t.createElement("link"),o.preload=n,n.addEventListener("load",function(){return o.loading|=1}),n.addEventListener("error",function(){return o.loading|=2}),On(n,"link",r),gn(n),t.head.appendChild(n))}function Ls(t){return'[src="'+Gt(t)+'"]'}function Xo(t){return"script[async]"+t}function ev(t,n,r){if(n.count++,n.instance===null)switch(n.type){case"style":var o=t.querySelector('style[data-href~="'+Gt(r.href)+'"]');if(o)return n.instance=o,gn(o),o;var u=g({},r,{"data-href":r.href,"data-precedence":r.precedence,href:null,precedence:null});return o=(t.ownerDocument||t).createElement("style"),gn(o),On(o,"style",u),vc(o,r.precedence,t),n.instance=o;case"stylesheet":u=Ns(r.href);var d=t.querySelector(ko(u));if(d)return n.state.loading|=4,n.instance=d,gn(d),d;o=$0(r),(u=Ei.get(u))&&Md(o,u),d=(t.ownerDocument||t).createElement("link"),gn(d);var S=d;return S._p=new Promise(function(R,z){S.onload=R,S.onerror=z}),On(d,"link",o),n.state.loading|=4,vc(d,r.precedence,t),n.instance=d;case"script":return d=Ls(r.src),(u=t.querySelector(Xo(d)))?(n.instance=u,gn(u),u):(o=r,(u=Ei.get(d))&&(o=g({},r),Ed(o,u)),t=t.ownerDocument||t,u=t.createElement("script"),gn(u),On(u,"link",o),t.head.appendChild(u),n.instance=u);case"void":return null;default:throw Error(s(443,n.type))}else n.type==="stylesheet"&&(n.state.loading&4)===0&&(o=n.instance,n.state.loading|=4,vc(o,r.precedence,t));return n.instance}function vc(t,n,r){for(var o=r.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),u=o.length?o[o.length-1]:null,d=u,S=0;S<o.length;S++){var R=o[S];if(R.dataset.precedence===n)d=R;else if(d!==u)break}d?d.parentNode.insertBefore(t,d.nextSibling):(n=r.nodeType===9?r.head:r,n.insertBefore(t,n.firstChild))}function Md(t,n){t.crossOrigin==null&&(t.crossOrigin=n.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=n.referrerPolicy),t.title==null&&(t.title=n.title)}function Ed(t,n){t.crossOrigin==null&&(t.crossOrigin=n.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=n.referrerPolicy),t.integrity==null&&(t.integrity=n.integrity)}var _c=null;function tv(t,n,r){if(_c===null){var o=new Map,u=_c=new Map;u.set(r,o)}else u=_c,o=u.get(r),o||(o=new Map,u.set(r,o));if(o.has(t))return o;for(o.set(t,null),r=r.getElementsByTagName(t),u=0;u<r.length;u++){var d=r[u];if(!(d[Ga]||d[mn]||t==="link"&&d.getAttribute("rel")==="stylesheet")&&d.namespaceURI!=="http://www.w3.org/2000/svg"){var S=d.getAttribute(n)||"";S=t+S;var R=o.get(S);R?R.push(d):o.set(S,[d])}}return o}function nv(t,n,r){t=t.ownerDocument||t,t.head.insertBefore(r,n==="title"?t.querySelector("head > title"):null)}function Iy(t,n,r){if(r===1||n.itemProp!=null)return!1;switch(t){case"meta":case"title":return!0;case"style":if(typeof n.precedence!="string"||typeof n.href!="string"||n.href==="")break;return!0;case"link":if(typeof n.rel!="string"||typeof n.href!="string"||n.href===""||n.onLoad||n.onError)break;return n.rel==="stylesheet"?(t=n.disabled,typeof n.precedence=="string"&&t==null):!0;case"script":if(n.async&&typeof n.async!="function"&&typeof n.async!="symbol"&&!n.onLoad&&!n.onError&&n.src&&typeof n.src=="string")return!0}return!1}function iv(t){return!(t.type==="stylesheet"&&(t.state.loading&3)===0)}function By(t,n,r,o){if(r.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(r.state.loading&4)===0){if(r.instance===null){var u=Ns(o.href),d=n.querySelector(ko(u));if(d){n=d._p,n!==null&&typeof n=="object"&&typeof n.then=="function"&&(t.count++,t=xc.bind(t),n.then(t,t)),r.state.loading|=4,r.instance=d,gn(d);return}d=n.ownerDocument||n,o=$0(o),(u=Ei.get(u))&&Md(o,u),d=d.createElement("link"),gn(d);var S=d;S._p=new Promise(function(R,z){S.onload=R,S.onerror=z}),On(d,"link",o),r.instance=d}t.stylesheets===null&&(t.stylesheets=new Map),t.stylesheets.set(r,n),(n=r.state.preload)&&(r.state.loading&3)===0&&(t.count++,r=xc.bind(t),n.addEventListener("load",r),n.addEventListener("error",r))}}var bd=0;function Fy(t,n){return t.stylesheets&&t.count===0&&yc(t,t.stylesheets),0<t.count||0<t.imgCount?function(r){var o=setTimeout(function(){if(t.stylesheets&&yc(t,t.stylesheets),t.unsuspend){var d=t.unsuspend;t.unsuspend=null,d()}},6e4+n);0<t.imgBytes&&bd===0&&(bd=62500*_y());var u=setTimeout(function(){if(t.waitingForImages=!1,t.count===0&&(t.stylesheets&&yc(t,t.stylesheets),t.unsuspend)){var d=t.unsuspend;t.unsuspend=null,d()}},(t.imgBytes>bd?50:800)+n);return t.unsuspend=r,function(){t.unsuspend=null,clearTimeout(o),clearTimeout(u)}}:null}function xc(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)yc(this,this.stylesheets);else if(this.unsuspend){var t=this.unsuspend;this.unsuspend=null,t()}}}var Sc=null;function yc(t,n){t.stylesheets=null,t.unsuspend!==null&&(t.count++,Sc=new Map,n.forEach(zy,t),Sc=null,xc.call(t))}function zy(t,n){if(!(n.state.loading&4)){var r=Sc.get(t);if(r)var o=r.get(null);else{r=new Map,Sc.set(t,r);for(var u=t.querySelectorAll("link[data-precedence],style[data-precedence]"),d=0;d<u.length;d++){var S=u[d];(S.nodeName==="LINK"||S.getAttribute("media")!=="not all")&&(r.set(S.dataset.precedence,S),o=S)}o&&r.set(null,o)}u=n.instance,S=u.getAttribute("data-precedence"),d=r.get(S)||o,d===o&&r.set(null,u),r.set(S,u),this.count++,o=xc.bind(this),u.addEventListener("load",o),u.addEventListener("error",o),d?d.parentNode.insertBefore(u,d.nextSibling):(t=t.nodeType===9?t.head:t,t.insertBefore(u,t.firstChild)),n.state.loading|=4}}var Wo={$$typeof:I,Provider:null,Consumer:null,_currentValue:$,_currentValue2:$,_threadCount:0};function Hy(t,n,r,o,u,d,S,R,z){this.tag=1,this.containerInfo=t,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=We(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=We(0),this.hiddenUpdates=We(null),this.identifierPrefix=o,this.onUncaughtError=u,this.onCaughtError=d,this.onRecoverableError=S,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=z,this.incompleteTransitions=new Map}function av(t,n,r,o,u,d,S,R,z,ie,xe,Ee){return t=new Hy(t,n,r,S,z,ie,xe,Ee,R),n=1,d===!0&&(n|=24),d=ai(3,null,null,n),t.current=d,d.stateNode=t,n=nf(),n.refCount++,t.pooledCache=n,n.refCount++,d.memoizedState={element:o,isDehydrated:r,cache:n},of(d),t}function rv(t){return t?(t=us,t):us}function sv(t,n,r,o,u,d){u=rv(u),o.context===null?o.context=u:o.pendingContext=u,o=ja(n),o.payload={element:r},d=d===void 0?null:d,d!==null&&(o.callback=d),r=Ja(t,o,n),r!==null&&(Qn(r,t,n),Eo(r,t,n))}function ov(t,n){if(t=t.memoizedState,t!==null&&t.dehydrated!==null){var r=t.retryLane;t.retryLane=r!==0&&r<n?r:n}}function Td(t,n){ov(t,n),(t=t.alternate)&&ov(t,n)}function lv(t){if(t.tag===13||t.tag===31){var n=Dr(t,67108864);n!==null&&Qn(n,t,67108864),Td(t,67108864)}}function cv(t){if(t.tag===13||t.tag===31){var n=ci();n=Ha(n);var r=Dr(t,n);r!==null&&Qn(r,t,n),Td(t,n)}}var Mc=!0;function Gy(t,n,r,o){var u=L.T;L.T=null;var d=H.p;try{H.p=2,Ad(t,n,r,o)}finally{H.p=d,L.T=u}}function Vy(t,n,r,o){var u=L.T;L.T=null;var d=H.p;try{H.p=8,Ad(t,n,r,o)}finally{H.p=d,L.T=u}}function Ad(t,n,r,o){if(Mc){var u=Rd(o);if(u===null)dd(t,n,o,Ec,r),fv(t,o);else if(Xy(u,t,n,r,o))o.stopPropagation();else if(fv(t,o),n&4&&-1<ky.indexOf(t)){for(;u!==null;){var d=oa(u);if(d!==null)switch(d.tag){case 3:if(d=d.stateNode,d.current.memoizedState.isDehydrated){var S=Ue(d.pendingLanes);if(S!==0){var R=d;for(R.pendingLanes|=2,R.entangledLanes|=2;S;){var z=1<<31-Ve(S);R.entanglements[1]|=z,S&=~z}Zi(d),(It&6)===0&&(rc=Bt()+500,zo(0))}}break;case 31:case 13:R=Dr(d,2),R!==null&&Qn(R,d,2),oc(),Td(d,2)}if(d=Rd(o),d===null&&dd(t,n,o,Ec,r),d===u)break;u=d}u!==null&&o.stopPropagation()}else dd(t,n,o,null,r)}}function Rd(t){return t=Cu(t),Cd(t)}var Ec=null;function Cd(t){if(Ec=null,t=sa(t),t!==null){var n=c(t);if(n===null)t=null;else{var r=n.tag;if(r===13){if(t=f(n),t!==null)return t;t=null}else if(r===31){if(t=p(n),t!==null)return t;t=null}else if(r===3){if(n.stateNode.current.memoizedState.isDehydrated)return n.tag===3?n.stateNode.containerInfo:null;t=null}else n!==t&&(t=null)}}return Ec=t,null}function uv(t){switch(t){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Ct()){case D:return 2;case E:return 8;case K:case se:return 32;case he:return 268435456;default:return 32}default:return 32}}var wd=!1,cr=null,ur=null,fr=null,qo=new Map,Yo=new Map,dr=[],ky="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function fv(t,n){switch(t){case"focusin":case"focusout":cr=null;break;case"dragenter":case"dragleave":ur=null;break;case"mouseover":case"mouseout":fr=null;break;case"pointerover":case"pointerout":qo.delete(n.pointerId);break;case"gotpointercapture":case"lostpointercapture":Yo.delete(n.pointerId)}}function Zo(t,n,r,o,u,d){return t===null||t.nativeEvent!==d?(t={blockedOn:n,domEventName:r,eventSystemFlags:o,nativeEvent:d,targetContainers:[u]},n!==null&&(n=oa(n),n!==null&&lv(n)),t):(t.eventSystemFlags|=o,n=t.targetContainers,u!==null&&n.indexOf(u)===-1&&n.push(u),t)}function Xy(t,n,r,o,u){switch(n){case"focusin":return cr=Zo(cr,t,n,r,o,u),!0;case"dragenter":return ur=Zo(ur,t,n,r,o,u),!0;case"mouseover":return fr=Zo(fr,t,n,r,o,u),!0;case"pointerover":var d=u.pointerId;return qo.set(d,Zo(qo.get(d)||null,t,n,r,o,u)),!0;case"gotpointercapture":return d=u.pointerId,Yo.set(d,Zo(Yo.get(d)||null,t,n,r,o,u)),!0}return!1}function dv(t){var n=sa(t.target);if(n!==null){var r=c(n);if(r!==null){if(n=r.tag,n===13){if(n=f(r),n!==null){t.blockedOn=n,is(t.priority,function(){cv(r)});return}}else if(n===31){if(n=p(r),n!==null){t.blockedOn=n,is(t.priority,function(){cv(r)});return}}else if(n===3&&r.stateNode.current.memoizedState.isDehydrated){t.blockedOn=r.tag===3?r.stateNode.containerInfo:null;return}}}t.blockedOn=null}function bc(t){if(t.blockedOn!==null)return!1;for(var n=t.targetContainers;0<n.length;){var r=Rd(t.nativeEvent);if(r===null){r=t.nativeEvent;var o=new r.constructor(r.type,r);Ru=o,r.target.dispatchEvent(o),Ru=null}else return n=oa(r),n!==null&&lv(n),t.blockedOn=r,!1;n.shift()}return!0}function hv(t,n,r){bc(t)&&r.delete(n)}function Wy(){wd=!1,cr!==null&&bc(cr)&&(cr=null),ur!==null&&bc(ur)&&(ur=null),fr!==null&&bc(fr)&&(fr=null),qo.forEach(hv),Yo.forEach(hv)}function Tc(t,n){t.blockedOn===n&&(t.blockedOn=null,wd||(wd=!0,a.unstable_scheduleCallback(a.unstable_NormalPriority,Wy)))}var Ac=null;function pv(t){Ac!==t&&(Ac=t,a.unstable_scheduleCallback(a.unstable_NormalPriority,function(){Ac===t&&(Ac=null);for(var n=0;n<t.length;n+=3){var r=t[n],o=t[n+1],u=t[n+2];if(typeof o!="function"){if(Cd(o||r)===null)continue;break}var d=oa(r);d!==null&&(t.splice(n,3),n-=3,Rf(d,{pending:!0,data:u,method:r.method,action:o},o,u))}}))}function Os(t){function n(z){return Tc(z,t)}cr!==null&&Tc(cr,t),ur!==null&&Tc(ur,t),fr!==null&&Tc(fr,t),qo.forEach(n),Yo.forEach(n);for(var r=0;r<dr.length;r++){var o=dr[r];o.blockedOn===t&&(o.blockedOn=null)}for(;0<dr.length&&(r=dr[0],r.blockedOn===null);)dv(r),r.blockedOn===null&&dr.shift();if(r=(t.ownerDocument||t).$$reactFormReplay,r!=null)for(o=0;o<r.length;o+=3){var u=r[o],d=r[o+1],S=u[Dn]||null;if(typeof d=="function")S||pv(r);else if(S){var R=null;if(d&&d.hasAttribute("formAction")){if(u=d,S=d[Dn]||null)R=S.formAction;else if(Cd(u)!==null)continue}else R=S.action;typeof R=="function"?r[o+1]=R:(r.splice(o,3),o-=3),pv(r)}}}function mv(){function t(d){d.canIntercept&&d.info==="react-transition"&&d.intercept({handler:function(){return new Promise(function(S){return u=S})},focusReset:"manual",scroll:"manual"})}function n(){u!==null&&(u(),u=null),o||setTimeout(r,20)}function r(){if(!o&&!navigation.transition){var d=navigation.currentEntry;d&&d.url!=null&&navigation.navigate(d.url,{state:d.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var o=!1,u=null;return navigation.addEventListener("navigate",t),navigation.addEventListener("navigatesuccess",n),navigation.addEventListener("navigateerror",n),setTimeout(r,100),function(){o=!0,navigation.removeEventListener("navigate",t),navigation.removeEventListener("navigatesuccess",n),navigation.removeEventListener("navigateerror",n),u!==null&&(u(),u=null)}}}function Dd(t){this._internalRoot=t}Rc.prototype.render=Dd.prototype.render=function(t){var n=this._internalRoot;if(n===null)throw Error(s(409));var r=n.current,o=ci();sv(r,o,t,n,null,null)},Rc.prototype.unmount=Dd.prototype.unmount=function(){var t=this._internalRoot;if(t!==null){this._internalRoot=null;var n=t.containerInfo;sv(t.current,2,null,t,null,null),oc(),n[Xn]=null}};function Rc(t){this._internalRoot=t}Rc.prototype.unstable_scheduleHydration=function(t){if(t){var n=ns();t={blockedOn:null,target:t,priority:n};for(var r=0;r<dr.length&&n!==0&&n<dr[r].priority;r++);dr.splice(r,0,t),r===0&&dv(t)}};var gv=e.version;if(gv!=="19.2.7")throw Error(s(527,gv,"19.2.7"));H.findDOMNode=function(t){var n=t._reactInternals;if(n===void 0)throw typeof t.render=="function"?Error(s(188)):(t=Object.keys(t).join(","),Error(s(268,t)));return t=h(n),t=t!==null?_(t):null,t=t===null?null:t.stateNode,t};var qy={bundleType:0,version:"19.2.7",rendererPackageName:"react-dom",currentDispatcherRef:L,reconcilerVersion:"19.2.7"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Cc=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Cc.isDisabled&&Cc.supportsFiber)try{pe=Cc.inject(qy),ge=Cc}catch{}}return Qo.createRoot=function(t,n){if(!l(t))throw Error(s(299));var r=!1,o="",u=Eg,d=bg,S=Tg;return n!=null&&(n.unstable_strictMode===!0&&(r=!0),n.identifierPrefix!==void 0&&(o=n.identifierPrefix),n.onUncaughtError!==void 0&&(u=n.onUncaughtError),n.onCaughtError!==void 0&&(d=n.onCaughtError),n.onRecoverableError!==void 0&&(S=n.onRecoverableError)),n=av(t,1,!1,null,null,r,o,null,u,d,S,mv),t[Xn]=n.current,fd(t),new Dd(n)},Qo.hydrateRoot=function(t,n,r){if(!l(t))throw Error(s(299));var o=!1,u="",d=Eg,S=bg,R=Tg,z=null;return r!=null&&(r.unstable_strictMode===!0&&(o=!0),r.identifierPrefix!==void 0&&(u=r.identifierPrefix),r.onUncaughtError!==void 0&&(d=r.onUncaughtError),r.onCaughtError!==void 0&&(S=r.onCaughtError),r.onRecoverableError!==void 0&&(R=r.onRecoverableError),r.formState!==void 0&&(z=r.formState)),n=av(t,1,!0,n,r??null,o,u,z,d,S,R,mv),n.context=rv(null),r=n.current,o=ci(),o=Ha(o),u=ja(o),u.callback=null,Ja(r,u,o),r=o,n.current.lanes=r,Oe(n,r),Zi(n),t[Xn]=n.current,fd(t),new Rc(n)},Qo.version="19.2.7",Qo}var Av;function tM(){if(Av)return Nd.exports;Av=1;function a(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(a)}catch(e){console.error(e)}}return a(),Nd.exports=eM(),Nd.exports}var nM=tM();const iM="modulepreload",aM=function(a){return"/"+a},Rv={},Vi=function(e,i,s){let l=Promise.resolve();if(i&&i.length>0){let m=function(h){return Promise.all(h.map(_=>Promise.resolve(_).then(g=>({status:"fulfilled",value:g}),g=>({status:"rejected",reason:g}))))};document.getElementsByTagName("link");const f=document.querySelector("meta[property=csp-nonce]"),p=f?.nonce||f?.getAttribute("nonce");l=m(i.map(h=>{if(h=aM(h),h in Rv)return;Rv[h]=!0;const _=h.endsWith(".css"),g=_?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${h}"]${g}`))return;const v=document.createElement("link");if(v.rel=_?"stylesheet":iM,_||(v.as="script"),v.crossOrigin="",v.href=h,p&&v.setAttribute("nonce",p),document.head.appendChild(v),_)return new Promise((M,b)=>{v.addEventListener("load",M),v.addEventListener("error",()=>b(new Error(`Unable to preload CSS for ${h}`)))})}))}function c(f){const p=new Event("vite:preloadError",{cancelable:!0});if(p.payload=f,window.dispatchEvent(p),!p.defaultPrevented)throw f}return l.then(f=>{for(const p of f||[])p.status==="rejected"&&c(p.reason);return e().catch(c)})};var J=hp();const Pe=z_(J);var pp=/^(?:[a-z][a-z0-9+.-]*:|[\\/]{2})/i,G_=/^[\\/]{2}/;function rM(a,e){return e+a.replace(/\\/g,"/")}var Cv="popstate";function wv(a){return typeof a=="object"&&a!=null&&"pathname"in a&&"search"in a&&"hash"in a&&"state"in a&&"key"in a}function sM(a={}){function e(s,l){let c=l.state?.masked,{pathname:f,search:p,hash:m}=c||s.location;return xh("",{pathname:f,search:p,hash:m},l.state&&l.state.usr||null,l.state&&l.state.key||"default",c?{pathname:s.location.pathname,search:s.location.search,hash:s.location.hash}:void 0)}function i(s,l){return typeof l=="string"?l:ol(l)}return lM(e,i,null,a)}function ln(a,e){if(a===!1||a===null||typeof a>"u")throw new Error(e)}function Ri(a,e){if(!a){typeof console<"u"&&console.warn(e);try{throw new Error(e)}catch{}}}function oM(){return Math.random().toString(36).substring(2,10)}function Dv(a,e){return{usr:a.state,key:a.key,idx:e,masked:a.mask?{pathname:a.pathname,search:a.search,hash:a.hash}:void 0}}function xh(a,e,i=null,s,l){return{pathname:typeof a=="string"?a:a.pathname,search:"",hash:"",...typeof e=="string"?no(e):e,state:i,key:e&&e.key||s||oM(),mask:l}}function ol({pathname:a="/",search:e="",hash:i=""}){return e&&e!=="?"&&(a+=e.charAt(0)==="?"?e:"?"+e),i&&i!=="#"&&(a+=i.charAt(0)==="#"?i:"#"+i),a}function no(a){let e={};if(a){let i=a.indexOf("#");i>=0&&(e.hash=a.substring(i),a=a.substring(0,i));let s=a.indexOf("?");s>=0&&(e.search=a.substring(s),a=a.substring(0,s)),a&&(e.pathname=a)}return e}function lM(a,e,i,s={}){let{window:l=document.defaultView,v5Compat:c=!1}=s,f=l.history,p="POP",m=null,h=_();h==null&&(h=0,f.replaceState({...f.state,idx:h},""));function _(){return(f.state||{idx:null}).idx}function g(){p="POP";let y=_(),x=y==null?null:y-h;h=y,m&&m({action:p,location:C.location,delta:x})}function v(y,x){p="PUSH";let O=wv(y)?y:xh(C.location,y,x);h=_()+1;let I=Dv(O,h),w=C.createHref(O.mask||O);try{f.pushState(I,"",w)}catch(B){if(B instanceof DOMException&&B.name==="DataCloneError")throw B;l.location.assign(w)}c&&m&&m({action:p,location:C.location,delta:1})}function M(y,x){p="REPLACE";let O=wv(y)?y:xh(C.location,y,x);h=_();let I=Dv(O,h),w=C.createHref(O.mask||O);f.replaceState(I,"",w),c&&m&&m({action:p,location:C.location,delta:0})}function b(y){return cM(l,y)}let C={get action(){return p},get location(){return a(l,f)},listen(y){if(m)throw new Error("A history only accepts one active listener");return l.addEventListener(Cv,g),m=y,()=>{l.removeEventListener(Cv,g),m=null}},createHref(y){return e(l,y)},createURL:b,encodeLocation(y){let x=b(y);return{pathname:x.pathname,search:x.search,hash:x.hash}},push:v,replace:M,go(y){return f.go(y)}};return C}function cM(a,e,i=!1){let s="http://localhost";a&&(s=a.location.origin!=="null"?a.location.origin:a.location.href),ln(s,"No window.location.(origin|href) available to create URL");let l=typeof e=="string"?e:ol(e);return l=l.replace(/ $/,"%20"),!i&&G_.test(l)&&(l=s+l),new URL(l,s)}function V_(a,e,i="/"){return uM(a,e,i,!1)}function uM(a,e,i,s,l){let c=typeof e=="string"?no(e):e,f=Ia(c.pathname||"/",i);if(f==null)return null;let p=fM(a),m=null,h=MM(f);for(let _=0;m==null&&_<p.length;++_)m=yM(p[_],h,s);return m}function fM(a){let e=k_(a);return dM(e),e}function k_(a,e=[],i=[],s="",l=!1){let c=(f,p,m=l,h)=>{let _={relativePath:h===void 0?f.path||"":h,caseSensitive:f.caseSensitive===!0,childrenIndex:p,route:f};if(_.relativePath.startsWith("/")){if(!_.relativePath.startsWith(s)&&m)return;ln(_.relativePath.startsWith(s),`Absolute route path "${_.relativePath}" nested under path "${s}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`),_.relativePath=_.relativePath.slice(s.length)}let g=Hi([s,_.relativePath]),v=i.concat(_);f.children&&f.children.length>0&&(ln(f.index!==!0,`Index routes must not have child routes. Please remove all child routes from route path "${g}".`),k_(f.children,e,v,g,m)),!(f.path==null&&!f.index)&&e.push({path:g,score:xM(g,f.index),routesMeta:v.map((M,b)=>{let[C,y]=q_(M.relativePath,M.caseSensitive,b===v.length-1);return{...M,matcher:C,compiledParams:y}})})};return a.forEach((f,p)=>{if(f.path===""||!f.path?.includes("?"))c(f,p);else for(let m of X_(f.path))c(f,p,!0,m)}),e}function X_(a){let e=a.split("/");if(e.length===0)return[];let[i,...s]=e,l=i.endsWith("?"),c=i.replace(/\?$/,"");if(s.length===0)return l?[c,""]:[c];let f=X_(s.join("/")),p=[];return p.push(...f.map(m=>m===""?c:[c,m].join("/"))),l&&p.push(...f),p.map(m=>a.startsWith("/")&&m===""?"/":m)}function dM(a){a.sort((e,i)=>e.score!==i.score?i.score-e.score:SM(e.routesMeta.map(s=>s.childrenIndex),i.routesMeta.map(s=>s.childrenIndex)))}var hM=/^:[\w-]+$/,pM=3,mM=2,gM=1,vM=10,_M=-2,Uv=a=>a==="*";function xM(a,e){let i=a.split("/"),s=i.length;return i.some(Uv)&&(s+=_M),e&&(s+=mM),i.filter(l=>!Uv(l)).reduce((l,c)=>l+(hM.test(c)?pM:c===""?gM:vM),s)}function SM(a,e){return a.length===e.length&&a.slice(0,-1).every((s,l)=>s===e[l])?a[a.length-1]-e[e.length-1]:0}function yM(a,e,i=!1){let{routesMeta:s}=a,l={},c="/",f=[];for(let p=0;p<s.length;++p){let m=s[p],h=p===s.length-1,_=c==="/"?e:e.slice(c.length)||"/",g={path:m.relativePath,caseSensitive:m.caseSensitive,end:h},v=m.matcher&&m.compiledParams?W_(g,_,m.matcher,m.compiledParams):uu(g,_),M=m.route;if(!v&&h&&i&&!s[s.length-1].route.index&&(v=uu({path:m.relativePath,caseSensitive:m.caseSensitive,end:!1},_)),!v)return null;Object.assign(l,v.params),f.push({params:l,pathname:Hi([c,v.pathname]),pathnameBase:TM(Hi([c,v.pathnameBase])),route:M}),v.pathnameBase!=="/"&&(c=Hi([c,v.pathnameBase]))}return f}function uu(a,e){typeof a=="string"&&(a={path:a,caseSensitive:!1,end:!0});let[i,s]=q_(a.path,a.caseSensitive,a.end);return W_(a,e,i,s)}function W_(a,e,i,s){let l=e.match(i);if(!l)return null;let c=l[0],f=c.replace(/(.)\/+$/,"$1"),p=l.slice(1);return{params:s.reduce((h,{paramName:_,isOptional:g},v)=>{if(_==="*"){let b=p[v]||"";f=c.slice(0,c.length-b.length).replace(/(.)\/+$/,"$1")}const M=p[v];return g&&!M?h[_]=void 0:h[_]=(M||"").replace(/%2F/g,"/"),h},{}),pathname:c,pathnameBase:f,pattern:a}}function q_(a,e=!1,i=!0){Ri(a==="*"||!a.endsWith("*")||a.endsWith("/*"),`Route path "${a}" will be treated as if it were "${a.replace(/\*$/,"/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${a.replace(/\*$/,"/*")}".`);let s=[],l="^"+a.replace(/\/*\*?$/,"").replace(/^\/*/,"/").replace(/[\\.*+^${}|()[\]]/g,"\\$&").replace(/\/:([\w-]+)(\?)?/g,(f,p,m,h,_)=>{if(s.push({paramName:p,isOptional:m!=null}),m){let g=_.charAt(h+f.length);return g&&g!=="/"?"/([^\\/]*)":"(?:/([^\\/]*))?"}return"/([^\\/]+)"}).replace(/\/([\w-]+)\?(\/|$)/g,"(/$1)?$2");return a.endsWith("*")?(s.push({paramName:"*"}),l+=a==="*"||a==="/*"?"(.*)$":"(?:\\/(.+)|\\/*)$"):i?l+="\\/*$":a!==""&&a!=="/"&&(l+="(?:(?=\\/|$))"),[new RegExp(l,e?void 0:"i"),s]}function MM(a){try{return a.split("/").map(e=>decodeURIComponent(e).replace(/\//g,"%2F")).join("/")}catch(e){return Ri(!1,`The URL path "${a}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${e}).`),a}}function Ia(a,e){if(e==="/")return a;if(!a.toLowerCase().startsWith(e.toLowerCase()))return null;let i=e.endsWith("/")?e.length-1:e.length,s=a.charAt(i);return s&&s!=="/"?null:a.slice(i)||"/"}function EM(a,e="/"){let{pathname:i,search:s="",hash:l=""}=typeof a=="string"?no(a):a,c;return i?(i=Y_(i),i.startsWith("/")?c=Nv(i.substring(1),"/"):c=Nv(i,e)):c=e,{pathname:c,search:AM(s),hash:RM(l)}}function Nv(a,e){let i=fu(e).split("/");return a.split("/").forEach(l=>{l===".."?i.length>1&&i.pop():l!=="."&&i.push(l)}),i.length>1?i.join("/"):"/"}function Bd(a,e,i,s){return`Cannot include a '${a}' character in a manually specified \`to.${e}\` field [${JSON.stringify(s)}].  Please separate it out to the \`to.${i}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`}function bM(a){return a.filter((e,i)=>i===0||e.route.path&&e.route.path.length>0)}function mp(a){let e=bM(a);return e.map((i,s)=>s===e.length-1?i.pathname:i.pathnameBase)}function xu(a,e,i,s=!1){let l;typeof a=="string"?l=no(a):(l={...a},ln(!l.pathname||!l.pathname.includes("?"),Bd("?","pathname","search",l)),ln(!l.pathname||!l.pathname.includes("#"),Bd("#","pathname","hash",l)),ln(!l.search||!l.search.includes("#"),Bd("#","search","hash",l)));let c=a===""||l.pathname==="",f=c?"/":l.pathname,p;if(f==null)p=i;else{let g=e.length-1;if(!s&&f.startsWith("..")){let v=f.split("/");for(;v[0]==="..";)v.shift(),g-=1;l.pathname=v.join("/")}p=g>=0?e[g]:"/"}let m=EM(l,p),h=f&&f!=="/"&&f.endsWith("/"),_=(c||f===".")&&i.endsWith("/");return!m.pathname.endsWith("/")&&(h||_)&&(m.pathname+="/"),m}var Y_=a=>a.replace(/[\\/]{2,}/g,"/"),Hi=a=>Y_(a.join("/")),fu=a=>a.replace(/\/+$/,""),TM=a=>fu(a).replace(/^\/*/,"/"),AM=a=>!a||a==="?"?"":a.startsWith("?")?a:"?"+a,RM=a=>!a||a==="#"?"":a.startsWith("#")?a:"#"+a,CM=class{constructor(a,e,i,s=!1){this.status=a,this.statusText=e||"",this.internal=s,i instanceof Error?(this.data=i.toString(),this.error=i):this.data=i}};function wM(a){return a!=null&&typeof a.status=="number"&&typeof a.statusText=="string"&&typeof a.internal=="boolean"&&"data"in a}function DM(a){let e=a.map(i=>i.route.path).filter(Boolean);return Hi(e)||"/"}var Z_=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";function K_(a,e){let i=a;if(typeof i!="string"||!pp.test(i))return{absoluteURL:void 0,isExternal:!1,to:i};let s=i,l=!1;if(Z_)try{let c=new URL(window.location.href),f=G_.test(i)?new URL(rM(i,c.protocol)):new URL(i),p=Ia(f.pathname,e);f.origin===c.origin&&p!=null?i=p+f.search+f.hash:l=!0}catch{Ri(!1,`<Link to="${i}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)}return{absoluteURL:s,isExternal:l,to:i}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");var Q_=["POST","PUT","PATCH","DELETE"];new Set(Q_);var UM=["GET",...Q_];new Set(UM);var NM=["about:","blob:","chrome:","chrome-untrusted:","content:","data:","devtools:","file:","filesystem:","javascript:"];function LM(a){try{return NM.includes(new URL(a).protocol)}catch{return!1}}var io=J.createContext(null);io.displayName="DataRouter";var Su=J.createContext(null);Su.displayName="DataRouterState";var j_=J.createContext(!1);function OM(){return J.useContext(j_)}var J_=J.createContext({isTransitioning:!1});J_.displayName="ViewTransition";var PM=J.createContext(new Map);PM.displayName="Fetchers";var IM=J.createContext(null);IM.displayName="Await";var pi=J.createContext(null);pi.displayName="Navigation";var fl=J.createContext(null);fl.displayName="Location";var Ci=J.createContext({outlet:null,matches:[],isDataRoute:!1});Ci.displayName="Route";var gp=J.createContext(null);gp.displayName="RouteError";var $_="REACT_ROUTER_ERROR",BM="REDIRECT",FM="ROUTE_ERROR_RESPONSE";function zM(a){if(a.startsWith(`${$_}:${BM}:{`))try{let e=JSON.parse(a.slice(28));if(typeof e=="object"&&e&&typeof e.status=="number"&&typeof e.statusText=="string"&&typeof e.location=="string"&&typeof e.reloadDocument=="boolean"&&typeof e.replace=="boolean")return e}catch{}}function HM(a){if(a.startsWith(`${$_}:${FM}:{`))try{let e=JSON.parse(a.slice(40));if(typeof e=="object"&&e&&typeof e.status=="number"&&typeof e.statusText=="string")return new CM(e.status,e.statusText,e.data)}catch{}}function GM(a,{relative:e}={}){ln(ao(),"useHref() may be used only in the context of a <Router> component.");let{basename:i,navigator:s}=J.useContext(pi),{hash:l,pathname:c,search:f}=hl(a,{relative:e}),p=c;return i!=="/"&&(p=c==="/"?i:Hi([i,c])),s.createHref({pathname:p,search:f,hash:l})}function ao(){return J.useContext(fl)!=null}function mi(){return ln(ao(),"useLocation() may be used only in the context of a <Router> component."),J.useContext(fl).location}var ex="You should call navigate() in a React.useEffect(), not when your component is first rendered.";function tx(a){J.useContext(pi).static||J.useLayoutEffect(a)}function dl(){let{isDataRoute:a}=J.useContext(Ci);return a?nE():VM()}function VM(){ln(ao(),"useNavigate() may be used only in the context of a <Router> component.");let a=J.useContext(io),{basename:e,navigator:i}=J.useContext(pi),{matches:s}=J.useContext(Ci),{pathname:l}=mi(),c=JSON.stringify(mp(s)),f=J.useRef(!1);return tx(()=>{f.current=!0}),J.useCallback((m,h={})=>{if(Ri(f.current,ex),!f.current)return;if(typeof m=="number"){i.go(m);return}let _=xu(m,JSON.parse(c),l,h.relative==="path");a==null&&e!=="/"&&(_.pathname=_.pathname==="/"?e:Hi([e,_.pathname])),(h.replace?i.replace:i.push)(_,h.state,h)},[e,i,c,l,a])}var kM=J.createContext(null);function XM(a){let e=J.useContext(Ci).outlet;return J.useMemo(()=>e&&J.createElement(kM.Provider,{value:a},e),[e,a])}function jC(){let{matches:a}=J.useContext(Ci);return a[a.length-1]?.params??{}}function hl(a,{relative:e}={}){let{matches:i}=J.useContext(Ci),{pathname:s}=mi(),l=JSON.stringify(mp(i));return J.useMemo(()=>xu(a,JSON.parse(l),s,e==="path"),[a,l,s,e])}function WM(a,e){return nx(a,e)}function nx(a,e,i){ln(ao(),"useRoutes() may be used only in the context of a <Router> component.");let{navigator:s}=J.useContext(pi),{matches:l}=J.useContext(Ci),c=l[l.length-1],f=c?c.params:{},p=c?c.pathname:"/",m=c?c.pathnameBase:"/",h=c&&c.route;{let y=h&&h.path||"";ax(p,!h||y.endsWith("*")||y.endsWith("*?"),`You rendered descendant <Routes> (or called \`useRoutes()\`) at "${p}" (under <Route path="${y}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${y}"> to <Route path="${y==="/"?"*":`${y}/*`}">.`)}let _=mi(),g;if(e){let y=typeof e=="string"?no(e):e;ln(m==="/"||y.pathname?.startsWith(m),`When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${m}" but pathname "${y.pathname}" was given in the \`location\` prop.`),g=y}else g=_;let v=g.pathname||"/",M=v;if(m!=="/"){let y=m.replace(/^\//,"").split("/");M="/"+v.replace(/^\//,"").split("/").slice(y.length).join("/")}let b=i&&i.state.matches.length?i.state.matches.map(y=>Object.assign(y,{route:i.manifest[y.route.id]||y.route})):V_(a,{pathname:M});Ri(h||b!=null,`No routes matched location "${g.pathname}${g.search}${g.hash}" `),Ri(b==null||b[b.length-1].route.element!==void 0||b[b.length-1].route.Component!==void 0||b[b.length-1].route.lazy!==void 0,`Matched leaf route at location "${g.pathname}${g.search}${g.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);let C=QM(b&&b.map(y=>Object.assign({},y,{params:Object.assign({},f,y.params),pathname:Hi([m,s.encodeLocation?s.encodeLocation(y.pathname.replace(/%/g,"%25").replace(/\?/g,"%3F").replace(/#/g,"%23")).pathname:y.pathname]),pathnameBase:y.pathnameBase==="/"?m:Hi([m,s.encodeLocation?s.encodeLocation(y.pathnameBase.replace(/%/g,"%25").replace(/\?/g,"%3F").replace(/#/g,"%23")).pathname:y.pathnameBase])})),l,i);return e&&C?J.createElement(fl.Provider,{value:{location:{pathname:"/",search:"",hash:"",state:null,key:"default",mask:void 0,...g},navigationType:"POP"}},C):C}function qM(){let a=tE(),e=wM(a)?`${a.status} ${a.statusText}`:a instanceof Error?a.message:JSON.stringify(a),i=a instanceof Error?a.stack:null,s="rgba(200,200,200, 0.5)",l={padding:"0.5rem",backgroundColor:s},c={padding:"2px 4px",backgroundColor:s},f=null;return console.error("Error handled by React Router default ErrorBoundary:",a),f=J.createElement(J.Fragment,null,J.createElement("p",null,"💿 Hey developer 👋"),J.createElement("p",null,"You can provide a way better UX than this when your app throws errors by providing your own ",J.createElement("code",{style:c},"ErrorBoundary")," or"," ",J.createElement("code",{style:c},"errorElement")," prop on your route.")),J.createElement(J.Fragment,null,J.createElement("h2",null,"Unexpected Application Error!"),J.createElement("h3",{style:{fontStyle:"italic"}},e),i?J.createElement("pre",{style:l},i):null,f)}var YM=J.createElement(qM,null),ix=class extends J.Component{constructor(a){super(a),this.state={location:a.location,revalidation:a.revalidation,error:a.error}}static getDerivedStateFromError(a){return{error:a}}static getDerivedStateFromProps(a,e){return e.location!==a.location||e.revalidation!=="idle"&&a.revalidation==="idle"?{error:a.error,location:a.location,revalidation:a.revalidation}:{error:a.error!==void 0?a.error:e.error,location:e.location,revalidation:a.revalidation||e.revalidation}}componentDidCatch(a,e){this.props.onError?this.props.onError(a,e):console.error("React Router caught the following error during render",a)}render(){let a=this.state.error;if(this.context&&typeof a=="object"&&a&&"digest"in a&&typeof a.digest=="string"){const i=HM(a.digest);i&&(a=i)}let e=a!==void 0?J.createElement(Ci.Provider,{value:this.props.routeContext},J.createElement(gp.Provider,{value:a,children:this.props.component})):this.props.children;return this.context?J.createElement(ZM,{error:a},e):e}};ix.contextType=j_;var Fd=new WeakMap;function ZM({children:a,error:e}){let{basename:i}=J.useContext(pi);if(typeof e=="object"&&e&&"digest"in e&&typeof e.digest=="string"){let s=zM(e.digest);if(s){let l=Fd.get(e);if(l)throw l;let c=K_(s.location,i),f=c.absoluteURL||c.to;if(LM(f))throw new Error("Invalid redirect location");if(Z_&&!Fd.get(e))if(c.isExternal||s.reloadDocument)window.location.href=f;else{const p=Promise.resolve().then(()=>window.__reactRouterDataRouter.navigate(c.to,{replace:s.replace}));throw Fd.set(e,p),p}return J.createElement("meta",{httpEquiv:"refresh",content:`0;url=${f}`})}}return a}function KM({routeContext:a,match:e,children:i}){let s=J.useContext(io);return s&&s.static&&s.staticContext&&(e.route.errorElement||e.route.ErrorBoundary)&&(s.staticContext._deepestRenderedBoundaryId=e.route.id),J.createElement(Ci.Provider,{value:a},i)}function QM(a,e=[],i){let s=i?.state;if(a==null){if(!s)return null;if(s.errors)a=s.matches;else if(e.length===0&&!s.initialized&&s.matches.length>0)a=s.matches;else return null}let l=a,c=s?.errors;if(c!=null){let _=l.findIndex(g=>g.route.id&&c?.[g.route.id]!==void 0);ln(_>=0,`Could not find a matching route for errors on route IDs: ${Object.keys(c).join(",")}`),l=l.slice(0,Math.min(l.length,_+1))}let f=!1,p=-1;if(i&&s){f=s.renderFallback;for(let _=0;_<l.length;_++){let g=l[_];if((g.route.HydrateFallback||g.route.hydrateFallbackElement)&&(p=_),g.route.id){let{loaderData:v,errors:M}=s,b=g.route.loader&&!v.hasOwnProperty(g.route.id)&&(!M||M[g.route.id]===void 0);if(g.route.lazy||b){i.isStatic&&(f=!0),p>=0?l=l.slice(0,p+1):l=[l[0]];break}}}}let m=i?.onError,h=s&&m?(_,g)=>{m(_,{location:s.location,params:s.matches?.[0]?.params??{},pattern:DM(s.matches),errorInfo:g})}:void 0;return l.reduceRight((_,g,v)=>{let M,b=!1,C=null,y=null;s&&(M=c&&g.route.id?c[g.route.id]:void 0,C=g.route.errorElement||YM,f&&(p<0&&v===0?(ax("route-fallback",!1,"No `HydrateFallback` element provided to render during initial hydration"),b=!0,y=null):p===v&&(b=!0,y=g.route.hydrateFallbackElement||null)));let x=e.concat(l.slice(0,v+1)),O=()=>{let I;return M?I=C:b?I=y:g.route.Component?I=J.createElement(g.route.Component,null):g.route.element?I=g.route.element:I=_,J.createElement(KM,{match:g,routeContext:{outlet:_,matches:x,isDataRoute:s!=null},children:I})};return s&&(g.route.ErrorBoundary||g.route.errorElement||v===0)?J.createElement(ix,{location:s.location,revalidation:s.revalidation,component:C,error:M,children:O(),routeContext:{outlet:null,matches:x,isDataRoute:!0},onError:h}):O()},null)}function vp(a){return`${a} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function jM(a){let e=J.useContext(io);return ln(e,vp(a)),e}function JM(a){let e=J.useContext(Su);return ln(e,vp(a)),e}function $M(a){let e=J.useContext(Ci);return ln(e,vp(a)),e}function _p(a){let e=$M(a),i=e.matches[e.matches.length-1];return ln(i.route.id,`${a} can only be used on routes that contain a unique "id"`),i.route.id}function eE(){return _p("useRouteId")}function tE(){let a=J.useContext(gp),e=JM("useRouteError"),i=_p("useRouteError");return a!==void 0?a:e.errors?.[i]}function nE(){let{router:a}=jM("useNavigate"),e=_p("useNavigate"),i=J.useRef(!1);return tx(()=>{i.current=!0}),J.useCallback(async(l,c={})=>{Ri(i.current,ex),i.current&&(typeof l=="number"?await a.navigate(l):await a.navigate(l,{fromRouteId:e,...c}))},[a,e])}var Lv={};function ax(a,e,i){!e&&!Lv[a]&&(Lv[a]=!0,Ri(!1,i))}J.memo(iE);function iE({routes:a,manifest:e,future:i,state:s,isStatic:l,onError:c}){return nx(a,void 0,{manifest:e,state:s,isStatic:l,onError:c})}function Ta({to:a,replace:e,state:i,relative:s}){ln(ao(),"<Navigate> may be used only in the context of a <Router> component.");let{static:l}=J.useContext(pi);Ri(!l,"<Navigate> must not be used on the initial render in a <StaticRouter>. This is a no-op, but you should modify your code so the <Navigate> is only ever rendered in response to some user interaction or state change.");let{matches:c}=J.useContext(Ci),{pathname:f}=mi(),p=dl(),m=xu(a,mp(c),f,s==="path"),h=JSON.stringify(m);return J.useEffect(()=>{p(JSON.parse(h),{replace:e,state:i,relative:s})},[p,h,s,e,i]),null}function aE(a){return XM(a.context)}function di(a){ln(!1,"A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.")}function rE({basename:a="/",children:e=null,location:i,navigationType:s="POP",navigator:l,static:c=!1,useTransitions:f}){ln(!ao(),"You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");let p=a.replace(/^\/*/,"/"),m=J.useMemo(()=>({basename:p,navigator:l,static:c,useTransitions:f,future:{}}),[p,l,c,f]);typeof i=="string"&&(i=no(i));let{pathname:h="/",search:_="",hash:g="",state:v=null,key:M="default",mask:b}=i,C=J.useMemo(()=>{let y=Ia(h,p);return y==null?null:{location:{pathname:y,search:_,hash:g,state:v,key:M,mask:b},navigationType:s}},[p,h,_,g,v,M,s,b]);return Ri(C!=null,`<Router basename="${p}"> is not able to match the URL "${h}${_}${g}" because it does not start with the basename, so the <Router> won't render anything.`),C==null?null:J.createElement(pi.Provider,{value:m},J.createElement(fl.Provider,{children:e,value:C}))}function sE({children:a,location:e}){return WM(Sh(a),e)}function Sh(a,e=[]){let i=[];return J.Children.forEach(a,(s,l)=>{if(!J.isValidElement(s))return;let c=[...e,l];if(s.type===J.Fragment){i.push.apply(i,Sh(s.props.children,c));return}ln(s.type===di,`[${typeof s.type=="string"?s.type:s.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`),ln(!s.props.index||!s.props.children,"An index route cannot have child routes.");let f={id:s.props.id||c.join("-"),caseSensitive:s.props.caseSensitive,element:s.props.element,Component:s.props.Component,index:s.props.index,path:s.props.path,middleware:s.props.middleware,loader:s.props.loader,action:s.props.action,hydrateFallbackElement:s.props.hydrateFallbackElement,HydrateFallback:s.props.HydrateFallback,errorElement:s.props.errorElement,ErrorBoundary:s.props.ErrorBoundary,hasErrorBoundary:s.props.hasErrorBoundary===!0||s.props.ErrorBoundary!=null||s.props.errorElement!=null,shouldRevalidate:s.props.shouldRevalidate,handle:s.props.handle,lazy:s.props.lazy};s.props.children&&(f.children=Sh(s.props.children,c)),i.push(f)}),i}var eu="get",tu="application/x-www-form-urlencoded";function yu(a){return typeof HTMLElement<"u"&&a instanceof HTMLElement}function oE(a){return yu(a)&&a.tagName.toLowerCase()==="button"}function lE(a){return yu(a)&&a.tagName.toLowerCase()==="form"}function cE(a){return yu(a)&&a.tagName.toLowerCase()==="input"}function uE(a){return!!(a.metaKey||a.altKey||a.ctrlKey||a.shiftKey)}function fE(a,e){return a.button===0&&(!e||e==="_self")&&!uE(a)}function yh(a=""){return new URLSearchParams(typeof a=="string"||Array.isArray(a)||a instanceof URLSearchParams?a:Object.keys(a).reduce((e,i)=>{let s=a[i];return e.concat(Array.isArray(s)?s.map(l=>[i,l]):[[i,s]])},[]))}function dE(a,e){let i=yh(a);return e&&e.forEach((s,l)=>{i.has(l)||e.getAll(l).forEach(c=>{i.append(l,c)})}),i}var wc=null;function hE(){if(wc===null)try{new FormData(document.createElement("form"),0),wc=!1}catch{wc=!0}return wc}var pE=new Set(["application/x-www-form-urlencoded","multipart/form-data","text/plain"]);function zd(a){return a!=null&&!pE.has(a)?(Ri(!1,`"${a}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${tu}"`),null):a}function mE(a,e){let i,s,l,c,f;if(lE(a)){let p=a.getAttribute("action");s=p?Ia(p,e):null,i=a.getAttribute("method")||eu,l=zd(a.getAttribute("enctype"))||tu,c=new FormData(a)}else if(oE(a)||cE(a)&&(a.type==="submit"||a.type==="image")){let p=a.form;if(p==null)throw new Error('Cannot submit a <button> or <input type="submit"> without a <form>');let m=a.getAttribute("formaction")||p.getAttribute("action");if(s=m?Ia(m,e):null,i=a.getAttribute("formmethod")||p.getAttribute("method")||eu,l=zd(a.getAttribute("formenctype"))||zd(p.getAttribute("enctype"))||tu,c=new FormData(p,a),!hE()){let{name:h,type:_,value:g}=a;if(_==="image"){let v=h?`${h}.`:"";c.append(`${v}x`,"0"),c.append(`${v}y`,"0")}else h&&c.append(h,g)}}else{if(yu(a))throw new Error('Cannot submit element that is not <form>, <button>, or <input type="submit|image">');i=eu,s=null,l=tu,f=a}return c&&l==="text/plain"&&(f=c,c=void 0),{action:s,method:i.toLowerCase(),encType:l,formData:c,body:f}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");function xp(a,e){if(a===!1||a===null||typeof a>"u")throw new Error(e)}function rx(a,e,i,s){let l=typeof a=="string"?new URL(a,typeof window>"u"?"server://singlefetch/":window.location.origin):a;return i?l.pathname.endsWith("/")?l.pathname=`${l.pathname}_.${s}`:l.pathname=`${l.pathname}.${s}`:l.pathname==="/"?l.pathname=`_root.${s}`:e&&Ia(l.pathname,e)==="/"?l.pathname=`${fu(e)}/_root.${s}`:l.pathname=`${fu(l.pathname)}.${s}`,l}async function gE(a,e){if(a.id in e)return e[a.id];try{let i=await import(a.module);return e[a.id]=i,i}catch(i){return console.error(`Error loading route module \`${a.module}\`, reloading page...`),console.error(i),window.__reactRouterContext&&window.__reactRouterContext.isSpaMode,window.location.reload(),new Promise(()=>{})}}function vE(a){return a==null?!1:a.href==null?a.rel==="preload"&&typeof a.imageSrcSet=="string"&&typeof a.imageSizes=="string":typeof a.rel=="string"&&typeof a.href=="string"}async function _E(a,e,i){let s=await Promise.all(a.map(async l=>{let c=e.routes[l.route.id];if(c){let f=await gE(c,i);return f.links?f.links():[]}return[]}));return ME(s.flat(1).filter(vE).filter(l=>l.rel==="stylesheet"||l.rel==="preload").map(l=>l.rel==="stylesheet"?{...l,rel:"prefetch",as:"style"}:{...l,rel:"prefetch"}))}function Ov(a,e,i,s,l,c){let f=(m,h)=>i[h]?m.route.id!==i[h].route.id:!0,p=(m,h)=>i[h].pathname!==m.pathname||i[h].route.path?.endsWith("*")&&i[h].params["*"]!==m.params["*"];return c==="assets"?e.filter((m,h)=>f(m,h)||p(m,h)):c==="data"?e.filter((m,h)=>{let _=s.routes[m.route.id];if(!_||!_.hasLoader)return!1;if(f(m,h)||p(m,h))return!0;if(m.route.shouldRevalidate){let g=m.route.shouldRevalidate({currentUrl:new URL(l.pathname+l.search+l.hash,window.origin),currentParams:i[0]?.params||{},nextUrl:new URL(a,window.origin),nextParams:m.params,defaultShouldRevalidate:!0});if(typeof g=="boolean")return g}return!0}):[]}function xE(a,e,{includeHydrateFallback:i}={}){return SE(a.map(s=>{let l=e.routes[s.route.id];if(!l)return[];let c=[l.module];return l.clientActionModule&&(c=c.concat(l.clientActionModule)),l.clientLoaderModule&&(c=c.concat(l.clientLoaderModule)),i&&l.hydrateFallbackModule&&(c=c.concat(l.hydrateFallbackModule)),l.imports&&(c=c.concat(l.imports)),c}).flat(1))}function SE(a){return[...new Set(a)]}function yE(a){let e={},i=Object.keys(a).sort();for(let s of i)e[s]=a[s];return e}function ME(a,e){let i=new Set;return new Set(e),a.reduce((s,l)=>{let c=JSON.stringify(yE(l));return i.has(c)||(i.add(c),s.push({key:c,link:l})),s},[])}function Sp(){let a=J.useContext(io);return xp(a,"You must render this element inside a <DataRouterContext.Provider> element"),a}function EE(){let a=J.useContext(Su);return xp(a,"You must render this element inside a <DataRouterStateContext.Provider> element"),a}var yp=J.createContext(void 0);yp.displayName="FrameworkContext";function Mu(){let a=J.useContext(yp);return xp(a,"You must render this element inside a <HydratedRouter> element"),a}function bE(a,e){let i=J.useContext(yp),[s,l]=J.useState(!1),[c,f]=J.useState(!1),{onFocus:p,onBlur:m,onMouseEnter:h,onMouseLeave:_,onTouchStart:g}=e,v=J.useRef(null);J.useEffect(()=>{if(a==="render"&&f(!0),a==="viewport"){let C=x=>{x.forEach(O=>{f(O.isIntersecting)})},y=new IntersectionObserver(C,{threshold:.5});return v.current&&y.observe(v.current),()=>{y.disconnect()}}},[a]),J.useEffect(()=>{if(s){let C=setTimeout(()=>{f(!0)},100);return()=>{clearTimeout(C)}}},[s]);let M=()=>{l(!0)},b=()=>{l(!1),f(!1)};return i?a!=="intent"?[c,v,{}]:[c,v,{onFocus:jo(p,M),onBlur:jo(m,b),onMouseEnter:jo(h,M),onMouseLeave:jo(_,b),onTouchStart:jo(g,M)}]:[!1,v,{}]}function jo(a,e){return i=>{a&&a(i),i.defaultPrevented||e(i)}}function TE({page:a,...e}){let i=OM(),{nonce:s}=Mu(),{router:l}=Sp(),c=J.useMemo(()=>V_(l.routes,a,l.basename),[l.routes,a,l.basename]);return c?(e.nonce==null&&s&&(e={...e,nonce:s}),i?J.createElement(RE,{page:a,matches:c,...e}):J.createElement(CE,{page:a,matches:c,...e})):null}function AE(a){let{manifest:e,routeModules:i}=Mu(),[s,l]=J.useState([]);return J.useEffect(()=>{let c=!1;return _E(a,e,i).then(f=>{c||l(f)}),()=>{c=!0}},[a,e,i]),s}function RE({page:a,matches:e,...i}){let s=mi(),{future:l}=Mu(),{basename:c}=Sp(),f=J.useMemo(()=>{if(a===s.pathname+s.search+s.hash)return[];let p=rx(a,c,l.v8_trailingSlashAwareDataRequests,"rsc"),m=!1,h=[];for(let _ of e)typeof _.route.shouldRevalidate=="function"?m=!0:h.push(_.route.id);return m&&h.length>0&&p.searchParams.set("_routes",h.join(",")),[p.pathname+p.search]},[c,l.v8_trailingSlashAwareDataRequests,a,s,e]);return J.createElement(J.Fragment,null,f.map(p=>J.createElement("link",{key:p,rel:"prefetch",as:"fetch",href:p,...i})))}function CE({page:a,matches:e,...i}){let s=mi(),{future:l,manifest:c,routeModules:f}=Mu(),{basename:p}=Sp(),{loaderData:m,matches:h}=EE(),_=J.useMemo(()=>Ov(a,e,h,c,s,"data"),[a,e,h,c,s]),g=J.useMemo(()=>Ov(a,e,h,c,s,"assets"),[a,e,h,c,s]),v=J.useMemo(()=>{if(a===s.pathname+s.search+s.hash)return[];let C=new Set,y=!1;if(e.forEach(O=>{let I=c.routes[O.route.id];!I||!I.hasLoader||(!_.some(w=>w.route.id===O.route.id)&&O.route.id in m&&f[O.route.id]?.shouldRevalidate||I.hasClientLoader?y=!0:C.add(O.route.id))}),C.size===0)return[];let x=rx(a,p,l.v8_trailingSlashAwareDataRequests,"data");return y&&C.size>0&&x.searchParams.set("_routes",e.filter(O=>C.has(O.route.id)).map(O=>O.route.id).join(",")),[x.pathname+x.search]},[p,l.v8_trailingSlashAwareDataRequests,m,s,c,_,e,a,f]),M=J.useMemo(()=>xE(g,c),[g,c]),b=AE(g);return J.createElement(J.Fragment,null,v.map(C=>J.createElement("link",{key:C,rel:"prefetch",as:"fetch",href:C,...i})),M.map(C=>J.createElement("link",{key:C,rel:"modulepreload",href:C,...i})),b.map(({key:C,link:y})=>J.createElement("link",{key:C,nonce:i.nonce,...y,crossOrigin:y.crossOrigin??i.crossOrigin})))}function wE(...a){return e=>{a.forEach(i=>{typeof i=="function"?i(e):i!=null&&(i.current=e)})}}var DE=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";try{DE&&(window.__reactRouterVersion="7.18.0")}catch{}function UE({basename:a,children:e,useTransitions:i,window:s}){let l=J.useRef();l.current==null&&(l.current=sM({window:s,v5Compat:!0}));let c=l.current,[f,p]=J.useState({action:c.action,location:c.location}),m=J.useCallback(h=>{i===!1?p(h):J.startTransition(()=>p(h))},[i]);return J.useLayoutEffect(()=>c.listen(m),[c,m]),J.createElement(rE,{basename:a,children:e,location:f.location,navigationType:f.action,navigator:c,useTransitions:i})}var sx=J.forwardRef(function({onClick:e,discover:i="render",prefetch:s="none",relative:l,reloadDocument:c,replace:f,mask:p,state:m,target:h,to:_,preventScrollReset:g,viewTransition:v,defaultShouldRevalidate:M,...b},C){let{basename:y,navigator:x,useTransitions:O}=J.useContext(pi),I=typeof _=="string"&&pp.test(_),w=K_(_,y);_=w.to;let B=GM(_,{relative:l}),U=mi(),F=null;if(p){let j=xu(p,[],U.mask?U.mask.pathname:"/",!0);y!=="/"&&(j.pathname=j.pathname==="/"?y:Hi([y,j.pathname])),F=x.createHref(j)}let[T,P,q]=bE(s,b),V=PE(_,{replace:f,mask:p,state:m,target:h,preventScrollReset:g,relative:l,viewTransition:v,defaultShouldRevalidate:M,useTransitions:O});function Q(j){e&&e(j),j.defaultPrevented||V(j)}let fe=!(w.isExternal||c),me=J.createElement("a",{...b,...q,href:(fe?F:void 0)||w.absoluteURL||B,onClick:fe?Q:e,ref:wE(C,P),target:h,"data-discover":!I&&i==="render"?"true":void 0});return T&&!I?J.createElement(J.Fragment,null,me,J.createElement(TE,{page:B})):me});sx.displayName="Link";var NE=J.forwardRef(function({"aria-current":e="page",caseSensitive:i=!1,className:s="",end:l=!1,style:c,to:f,viewTransition:p,children:m,...h},_){let g=hl(f,{relative:h.relative}),v=mi(),M=J.useContext(Su),{navigator:b,basename:C}=J.useContext(pi),y=M!=null&&HE(g)&&p===!0,x=b.encodeLocation?b.encodeLocation(g).pathname:g.pathname,O=v.pathname,I=M&&M.navigation&&M.navigation.location?M.navigation.location.pathname:null;i||(O=O.toLowerCase(),I=I?I.toLowerCase():null,x=x.toLowerCase()),I&&C&&(I=Ia(I,C)||I);const w=x!=="/"&&x.endsWith("/")?x.length-1:x.length;let B=O===x||!l&&O.startsWith(x)&&O.charAt(w)==="/",U=I!=null&&(I===x||!l&&I.startsWith(x)&&I.charAt(x.length)==="/"),F={isActive:B,isPending:U,isTransitioning:y},T=B?e:void 0,P;typeof s=="function"?P=s(F):P=[s,B?"active":null,U?"pending":null,y?"transitioning":null].filter(Boolean).join(" ");let q=typeof c=="function"?c(F):c;return J.createElement(sx,{...h,"aria-current":T,className:P,ref:_,style:q,to:f,viewTransition:p},typeof m=="function"?m(F):m)});NE.displayName="NavLink";var LE=J.forwardRef(({discover:a="render",fetcherKey:e,navigate:i,reloadDocument:s,replace:l,state:c,method:f=eu,action:p,onSubmit:m,relative:h,preventScrollReset:_,viewTransition:g,defaultShouldRevalidate:v,...M},b)=>{let{useTransitions:C}=J.useContext(pi),y=FE(),x=zE(p,{relative:h}),O=f.toLowerCase()==="get"?"get":"post",I=typeof p=="string"&&pp.test(p),w=B=>{if(m&&m(B),B.defaultPrevented)return;B.preventDefault();let U=B.nativeEvent.submitter,F=U?.getAttribute("formmethod")||f,T=()=>y(U||B.currentTarget,{fetcherKey:e,method:F,navigate:i,replace:l,state:c,relative:h,preventScrollReset:_,viewTransition:g,defaultShouldRevalidate:v});C&&i!==!1?J.startTransition(()=>T()):T()};return J.createElement("form",{ref:b,method:O,action:x,onSubmit:s?m:w,...M,"data-discover":!I&&a==="render"?"true":void 0})});LE.displayName="Form";function OE(a){return`${a} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function ox(a){let e=J.useContext(io);return ln(e,OE(a)),e}function PE(a,{target:e,replace:i,mask:s,state:l,preventScrollReset:c,relative:f,viewTransition:p,defaultShouldRevalidate:m,useTransitions:h}={}){let _=dl(),g=mi(),v=hl(a,{relative:f});return J.useCallback(M=>{if(fE(M,e)){M.preventDefault();let b=i!==void 0?i:ol(g)===ol(v),C=()=>_(a,{replace:b,mask:s,state:l,preventScrollReset:c,relative:f,viewTransition:p,defaultShouldRevalidate:m});h?J.startTransition(()=>C()):C()}},[g,_,v,i,s,l,e,a,c,f,p,m,h])}function JC(a){Ri(typeof URLSearchParams<"u","You cannot use the `useSearchParams` hook in a browser that does not support the URLSearchParams API. If you need to support Internet Explorer 11, we recommend you load a polyfill such as https://github.com/ungap/url-search-params.");let e=J.useRef(yh(a)),i=J.useRef(!1),s=mi(),l=J.useMemo(()=>dE(s.search,i.current?null:e.current),[s.search]),c=dl(),f=J.useCallback((p,m)=>{const h=yh(typeof p=="function"?p(new URLSearchParams(l)):p);i.current=!0,c("?"+h,m)},[c,l]);return[l,f]}var IE=0,BE=()=>`__${String(++IE)}__`;function FE(){let{router:a}=ox("useSubmit"),{basename:e}=J.useContext(pi),i=eE(),s=a.fetch,l=a.navigate;return J.useCallback(async(c,f={})=>{let{action:p,method:m,encType:h,formData:_,body:g}=mE(c,e);if(f.navigate===!1){let v=f.fetcherKey||BE();await s(v,i,f.action||p,{defaultShouldRevalidate:f.defaultShouldRevalidate,preventScrollReset:f.preventScrollReset,formData:_,body:g,formMethod:f.method||m,formEncType:f.encType||h,flushSync:f.flushSync})}else await l(f.action||p,{defaultShouldRevalidate:f.defaultShouldRevalidate,preventScrollReset:f.preventScrollReset,formData:_,body:g,formMethod:f.method||m,formEncType:f.encType||h,replace:f.replace,state:f.state,fromRouteId:i,flushSync:f.flushSync,viewTransition:f.viewTransition})},[s,l,e,i])}function zE(a,{relative:e}={}){let{basename:i}=J.useContext(pi),s=J.useContext(Ci);ln(s,"useFormAction must be used inside a RouteContext");let[l]=s.matches.slice(-1),c={...hl(a||".",{relative:e})},f=mi();if(a==null){c.search=f.search;let p=new URLSearchParams(c.search),m=p.getAll("index");if(m.some(_=>_==="")){p.delete("index"),m.filter(g=>g).forEach(g=>p.append("index",g));let _=p.toString();c.search=_?`?${_}`:""}}return(!a||a===".")&&l.route.index&&(c.search=c.search?c.search.replace(/^\?/,"?index&"):"?index"),i!=="/"&&(c.pathname=c.pathname==="/"?i:Hi([i,c.pathname])),ol(c)}function HE(a,{relative:e}={}){let i=J.useContext(J_);ln(i!=null,"`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");let{basename:s}=ox("useViewTransitionState"),l=hl(a,{relative:e});if(!i.isTransitioning)return!1;let c=Ia(i.currentLocation.pathname,s)||i.currentLocation.pathname,f=Ia(i.nextLocation.pathname,s)||i.nextLocation.pathname;return uu(l.pathname,f)!=null||uu(l.pathname,c)!=null}var GE=H_();const VE=z_(GE),Pv=a=>{let e;const i=new Set,s=(h,_)=>{const g=typeof h=="function"?h(e):h;if(!Object.is(g,e)){const v=e;e=_??(typeof g!="object"||g===null)?g:Object.assign({},e,g),i.forEach(M=>M(e,v))}},l=()=>e,p={setState:s,getState:l,getInitialState:()=>m,subscribe:h=>(i.add(h),()=>i.delete(h))},m=e=a(s,l,p);return p},kE=(a=>a?Pv(a):Pv),XE=a=>a;function WE(a,e=XE){const i=Pe.useSyncExternalStore(a.subscribe,Pe.useCallback(()=>e(a.getState()),[a,e]),Pe.useCallback(()=>e(a.getInitialState()),[a,e]));return Pe.useDebugValue(i),i}const Iv=a=>{const e=kE(a),i=s=>WE(e,s);return Object.assign(i,e),i},qE=(a=>a?Iv(a):Iv),ll=qE(a=>({user:JSON.parse(localStorage.getItem("user")||"null"),token:localStorage.getItem("token"),isAuthenticated:!!localStorage.getItem("token"),setUser:e=>a({user:e}),setToken:e=>a({token:e,isAuthenticated:!!e}),login:(e,i)=>{localStorage.setItem("token",e),localStorage.setItem("user",JSON.stringify(i)),a({token:e,user:i,isAuthenticated:!0})},logout:()=>{localStorage.removeItem("token"),localStorage.removeItem("user"),a({token:null,user:null,isAuthenticated:!1,posts:[],conversations:[],notifications:[]})},posts:[],setPosts:e=>a({posts:e}),updatePost:e=>a(i=>({posts:i.posts.map(s=>s.id===e.id?e:s)})),removePost:e=>a(i=>({posts:i.posts.filter(s=>s.id!==e)})),conversations:[],setConversations:e=>a({conversations:e}),updateConversation:e=>a(i=>({conversations:i.conversations.map(s=>s.id===e.id?e:s)})),notifications:[],setNotifications:e=>a({notifications:e}),unreadCount:0,setUnreadCount:e=>a({unreadCount:e}),currentMessages:[],setCurrentMessages:e=>a({currentMessages:e}),addMessage:e=>a(i=>({currentMessages:[...i.currentMessages,e]})),theme:localStorage.getItem("theme")||"light",setTheme:e=>{localStorage.setItem("theme",e),a({theme:e})},toggleTheme:()=>a(e=>{const i=e.theme==="light"?"dark":"light";return localStorage.setItem("theme",i),{theme:i}}),language:localStorage.getItem("language")||"en",setLanguage:e=>{localStorage.setItem("language",e),a({language:e})},loading:!1,setLoading:e=>a({loading:e}),adminStats:null,setAdminStats:e=>a({adminStats:e}),currentScreen:"home",setCurrentScreen:e=>a({currentScreen:e}),previousScreen:null,setPreviousScreen:e=>a({previousScreen:e})})),nu="https://gk-uploader.shamsahmadzai06.workers.dev";function YE(){let a=localStorage.getItem("guestId");return a||(a=crypto.randomUUID(),localStorage.setItem("guestId",a)),a}function iu(){return localStorage.getItem("token")}async function bt(a,e={}){const i=`${nu}${a}`,s={"Content-Type":"application/json","X-Guest-Id":YE(),...e.headers||{}},l=iu();l&&(s.Authorization=`Bearer ${l}`);const c=await fetch(i,{...e,headers:s});if(c.status===401&&(localStorage.removeItem("token"),localStorage.removeItem("user")),!c.ok){const f=await c.json().catch(()=>({error:"Network error"}));throw new Error(f.error||`HTTP ${c.status}`)}return c.json()}const Bv={signup:a=>bt("/api/auth/signup",{method:"POST",body:JSON.stringify(a)}),login:a=>bt("/api/auth/login",{method:"POST",body:JSON.stringify(a)}),me:()=>bt("/api/auth/me"),uploadAvatar:a=>fetch(`${nu}/api/auth/avatar`,{method:"POST",headers:{Authorization:`Bearer ${iu()}`},body:a}).then(e=>e.json()),uploadCover:a=>fetch(`${nu}/api/users/cover`,{method:"POST",headers:{Authorization:`Bearer ${iu()}`},body:a}).then(e=>e.json()),updateProfile:a=>bt("/api/users/profile",{method:"PATCH",body:JSON.stringify(a)}),getPosts:a=>{const e=new URLSearchParams;return a?.page&&e.set("page",String(a.page)),a?.limit&&e.set("limit",String(a.limit)),a?.search&&e.set("search",a.search),a?.authorId&&e.set("authorId",a.authorId),bt(`/api/posts?${e.toString()}`)},getPost:a=>bt(`/api/posts/${a}`),createPost:a=>fetch(`${nu}/api/posts`,{method:"POST",headers:{Authorization:`Bearer ${iu()}`},body:a}).then(e=>e.json()),likePost:a=>bt(`/api/posts/${a}/like`,{method:"POST"}),toggleSold:a=>bt(`/api/posts/${a}/sold`,{method:"PATCH"}),deletePost:a=>bt(`/api/posts/${a}`,{method:"DELETE"}),getUserPosts:a=>bt(`/api/posts/user/${a}`),batchViews:a=>bt("/api/posts/views/batch",{method:"POST",body:JSON.stringify({postIds:a})}),getConversations:()=>bt("/api/messages/conversations"),getAdminConversation:()=>bt("/api/messages/admin-conversation",{method:"POST"}),getMessages:a=>bt(`/api/messages?conversationId=${a}`),sendMessage:a=>bt("/api/messages",{method:"POST",body:JSON.stringify(a)}),getNotifications:()=>bt("/api/notifications"),getUnreadCount:()=>bt("/api/notifications/unread"),markRead:a=>bt(`/api/notifications/${a}/read`,{method:"PATCH"}),markAllRead:()=>bt("/api/notifications/read-all",{method:"POST"}),applySeller:a=>bt("/api/seller-requests",{method:"POST",body:JSON.stringify(a)}),getAdminStats:()=>bt("/api/admin/stats"),getPendingRequests:()=>bt("/api/admin/seller-requests"),approveRequest:a=>bt(`/api/admin/seller-requests/${a}/approve`,{method:"POST"}),rejectRequest:a=>bt(`/api/admin/seller-requests/${a}/reject`,{method:"POST"}),getSellers:()=>bt("/api/admin/sellers"),revokeSeller:a=>bt(`/api/admin/sellers/${a}/revoke`,{method:"PATCH"}),getAllUsers:()=>bt("/api/admin/users"),deleteUser:a=>bt(`/api/admin/users/${a}`,{method:"DELETE"}),getAllPosts:()=>bt("/api/admin/posts"),saveSettings:a=>bt("/api/admin/settings",{method:"POST",body:JSON.stringify(a)}),track:a=>bt("/api/track",{method:"POST",body:JSON.stringify(a)}),trackInstall:a=>bt("/api/track/install",{method:"POST",body:JSON.stringify(a)}),heartbeat:()=>bt("/api/online",{method:"POST",body:JSON.stringify({})}),getSettings:()=>bt("/api/settings"),getVersion:()=>bt("/api/version")};const Mp="185",ZE=0,Fv=1,KE=2,au=1,QE=2,rl=3,Mr=0,$n=1,Ua=2,La=0,Ks=1,zv=2,Hv=3,Gv=4,jE=5,Zr=100,JE=101,$E=102,eb=103,tb=104,nb=200,ib=201,ab=202,rb=203,Mh=204,Eh=205,sb=206,ob=207,lb=208,cb=209,ub=210,fb=211,db=212,hb=213,pb=214,bh=0,Th=1,Ah=2,Js=3,Rh=4,Ch=5,wh=6,Dh=7,lx=0,mb=1,gb=2,ta=0,cx=1,ux=2,fx=3,dx=4,hx=5,px=6,mx=7,gx=300,Jr=301,$s=302,Hd=303,Gd=304,Eu=306,Uh=1e3,Na=1001,Nh=1002,Pn=1003,vb=1004,Dc=1005,Hn=1006,Vd=1007,Qr=1008,Ai=1009,vx=1010,_x=1011,cl=1012,Ep=1013,aa=1014,$i=1015,Ba=1016,bp=1017,Tp=1018,ul=1020,xx=35902,Sx=35899,yx=1021,Mx=1022,zi=1023,Fa=1026,jr=1027,Ex=1028,Ap=1029,$r=1030,Rp=1031,Cp=1033,ru=33776,su=33777,ou=33778,lu=33779,Lh=35840,Oh=35841,Ph=35842,Ih=35843,Bh=36196,Fh=37492,zh=37496,Hh=37488,Gh=37489,du=37490,Vh=37491,kh=37808,Xh=37809,Wh=37810,qh=37811,Yh=37812,Zh=37813,Kh=37814,Qh=37815,jh=37816,Jh=37817,$h=37818,ep=37819,tp=37820,np=37821,ip=36492,ap=36494,rp=36495,sp=36283,op=36284,hu=36285,lp=36286,_b=3200,Vv=0,xb=1,Sr="",Ti="srgb",pu="srgb-linear",mu="linear",Wt="srgb",Ps=7680,kv=519,Sb=512,yb=513,Mb=514,wp=515,Eb=516,bb=517,Dp=518,Tb=519,Xv=35044,Wv="300 es",ea=2e3,gu=2001;function Ab(a){for(let e=a.length-1;e>=0;--e)if(a[e]>=65535)return!0;return!1}function vu(a){return document.createElementNS("http://www.w3.org/1999/xhtml",a)}function Rb(){const a=vu("canvas");return a.style.display="block",a}const qv={};function Yv(...a){const e="THREE."+a.shift();console.log(e,...a)}function bx(a){const e=a[0];if(typeof e=="string"&&e.startsWith("TSL:")){const i=a[1];i&&i.isStackTrace?a[0]+=" "+i.getLocation():a[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return a}function rt(...a){a=bx(a);const e="THREE."+a.shift();{const i=a[0];i&&i.isStackTrace?console.warn(i.getError(e)):console.warn(e,...a)}}function wt(...a){a=bx(a);const e="THREE."+a.shift();{const i=a[0];i&&i.isStackTrace?console.error(i.getError(e)):console.error(e,...a)}}function Qs(...a){const e=a.join(" ");e in qv||(qv[e]=!0,rt(...a))}function Cb(a,e,i){return new Promise(function(s,l){function c(){switch(a.clientWaitSync(e,a.SYNC_FLUSH_COMMANDS_BIT,0)){case a.WAIT_FAILED:l();break;case a.TIMEOUT_EXPIRED:setTimeout(c,i);break;default:s()}}setTimeout(c,i)})}const wb={[bh]:Th,[Ah]:wh,[Rh]:Dh,[Js]:Ch,[Th]:bh,[wh]:Ah,[Dh]:Rh,[Ch]:Js};class ts{addEventListener(e,i){this._listeners===void 0&&(this._listeners={});const s=this._listeners;s[e]===void 0&&(s[e]=[]),s[e].indexOf(i)===-1&&s[e].push(i)}hasEventListener(e,i){const s=this._listeners;return s===void 0?!1:s[e]!==void 0&&s[e].indexOf(i)!==-1}removeEventListener(e,i){const s=this._listeners;if(s===void 0)return;const l=s[e];if(l!==void 0){const c=l.indexOf(i);c!==-1&&l.splice(c,1)}}dispatchEvent(e){const i=this._listeners;if(i===void 0)return;const s=i[e.type];if(s!==void 0){e.target=this;const l=s.slice(0);for(let c=0,f=l.length;c<f;c++)l[c].call(this,e);e.target=null}}}const Fn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],kd=Math.PI/180,cp=180/Math.PI;function pl(){const a=Math.random()*4294967295|0,e=Math.random()*4294967295|0,i=Math.random()*4294967295|0,s=Math.random()*4294967295|0;return(Fn[a&255]+Fn[a>>8&255]+Fn[a>>16&255]+Fn[a>>24&255]+"-"+Fn[e&255]+Fn[e>>8&255]+"-"+Fn[e>>16&15|64]+Fn[e>>24&255]+"-"+Fn[i&63|128]+Fn[i>>8&255]+"-"+Fn[i>>16&255]+Fn[i>>24&255]+Fn[s&255]+Fn[s>>8&255]+Fn[s>>16&255]+Fn[s>>24&255]).toLowerCase()}function At(a,e,i){return Math.max(e,Math.min(i,a))}function Db(a,e){return(a%e+e)%e}function Xd(a,e,i){return(1-i)*a+i*e}function Jo(a,e){switch(e.constructor){case Float32Array:return a;case Uint32Array:return a/4294967295;case Uint16Array:return a/65535;case Uint8Array:return a/255;case Int32Array:return Math.max(a/2147483647,-1);case Int16Array:return Math.max(a/32767,-1);case Int8Array:return Math.max(a/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function jn(a,e){switch(e.constructor){case Float32Array:return a;case Uint32Array:return Math.round(a*4294967295);case Uint16Array:return Math.round(a*65535);case Uint8Array:return Math.round(a*255);case Int32Array:return Math.round(a*2147483647);case Int16Array:return Math.round(a*32767);case Int8Array:return Math.round(a*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}const Op=class Op{constructor(e=0,i=0){this.x=e,this.y=i}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,i){return this.x=e,this.y=i,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,i){switch(e){case 0:this.x=i;break;case 1:this.y=i;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,i){return this.x=e.x+i.x,this.y=e.y+i.y,this}addScaledVector(e,i){return this.x+=e.x*i,this.y+=e.y*i,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,i){return this.x=e.x-i.x,this.y=e.y-i.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const i=this.x,s=this.y,l=e.elements;return this.x=l[0]*i+l[3]*s+l[6],this.y=l[1]*i+l[4]*s+l[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,i){return this.x=At(this.x,e.x,i.x),this.y=At(this.y,e.y,i.y),this}clampScalar(e,i){return this.x=At(this.x,e,i),this.y=At(this.y,e,i),this}clampLength(e,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(At(s,e,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const i=Math.sqrt(this.lengthSq()*e.lengthSq());if(i===0)return Math.PI/2;const s=this.dot(e)/i;return Math.acos(At(s,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const i=this.x-e.x,s=this.y-e.y;return i*i+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,i){return this.x+=(e.x-this.x)*i,this.y+=(e.y-this.y)*i,this}lerpVectors(e,i,s){return this.x=e.x+(i.x-e.x)*s,this.y=e.y+(i.y-e.y)*s,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,i=0){return this.x=e[i],this.y=e[i+1],this}toArray(e=[],i=0){return e[i]=this.x,e[i+1]=this.y,e}fromBufferAttribute(e,i){return this.x=e.getX(i),this.y=e.getY(i),this}rotateAround(e,i){const s=Math.cos(i),l=Math.sin(i),c=this.x-e.x,f=this.y-e.y;return this.x=c*s-f*l+e.x,this.y=c*l+f*s+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};Op.prototype.isVector2=!0;let Pt=Op;class ro{constructor(e=0,i=0,s=0,l=1){this.isQuaternion=!0,this._x=e,this._y=i,this._z=s,this._w=l}static slerpFlat(e,i,s,l,c,f,p){let m=s[l+0],h=s[l+1],_=s[l+2],g=s[l+3],v=c[f+0],M=c[f+1],b=c[f+2],C=c[f+3];if(g!==C||m!==v||h!==M||_!==b){let y=m*v+h*M+_*b+g*C;y<0&&(v=-v,M=-M,b=-b,C=-C,y=-y);let x=1-p;if(y<.9995){const O=Math.acos(y),I=Math.sin(O);x=Math.sin(x*O)/I,p=Math.sin(p*O)/I,m=m*x+v*p,h=h*x+M*p,_=_*x+b*p,g=g*x+C*p}else{m=m*x+v*p,h=h*x+M*p,_=_*x+b*p,g=g*x+C*p;const O=1/Math.sqrt(m*m+h*h+_*_+g*g);m*=O,h*=O,_*=O,g*=O}}e[i]=m,e[i+1]=h,e[i+2]=_,e[i+3]=g}static multiplyQuaternionsFlat(e,i,s,l,c,f){const p=s[l],m=s[l+1],h=s[l+2],_=s[l+3],g=c[f],v=c[f+1],M=c[f+2],b=c[f+3];return e[i]=p*b+_*g+m*M-h*v,e[i+1]=m*b+_*v+h*g-p*M,e[i+2]=h*b+_*M+p*v-m*g,e[i+3]=_*b-p*g-m*v-h*M,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,i,s,l){return this._x=e,this._y=i,this._z=s,this._w=l,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,i=!0){const s=e._x,l=e._y,c=e._z,f=e._order,p=Math.cos,m=Math.sin,h=p(s/2),_=p(l/2),g=p(c/2),v=m(s/2),M=m(l/2),b=m(c/2);switch(f){case"XYZ":this._x=v*_*g+h*M*b,this._y=h*M*g-v*_*b,this._z=h*_*b+v*M*g,this._w=h*_*g-v*M*b;break;case"YXZ":this._x=v*_*g+h*M*b,this._y=h*M*g-v*_*b,this._z=h*_*b-v*M*g,this._w=h*_*g+v*M*b;break;case"ZXY":this._x=v*_*g-h*M*b,this._y=h*M*g+v*_*b,this._z=h*_*b+v*M*g,this._w=h*_*g-v*M*b;break;case"ZYX":this._x=v*_*g-h*M*b,this._y=h*M*g+v*_*b,this._z=h*_*b-v*M*g,this._w=h*_*g+v*M*b;break;case"YZX":this._x=v*_*g+h*M*b,this._y=h*M*g+v*_*b,this._z=h*_*b-v*M*g,this._w=h*_*g-v*M*b;break;case"XZY":this._x=v*_*g-h*M*b,this._y=h*M*g-v*_*b,this._z=h*_*b+v*M*g,this._w=h*_*g+v*M*b;break;default:rt("Quaternion: .setFromEuler() encountered an unknown order: "+f)}return i===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,i){const s=i/2,l=Math.sin(s);return this._x=e.x*l,this._y=e.y*l,this._z=e.z*l,this._w=Math.cos(s),this._onChangeCallback(),this}setFromRotationMatrix(e){const i=e.elements,s=i[0],l=i[4],c=i[8],f=i[1],p=i[5],m=i[9],h=i[2],_=i[6],g=i[10],v=s+p+g;if(v>0){const M=.5/Math.sqrt(v+1);this._w=.25/M,this._x=(_-m)*M,this._y=(c-h)*M,this._z=(f-l)*M}else if(s>p&&s>g){const M=2*Math.sqrt(1+s-p-g);this._w=(_-m)/M,this._x=.25*M,this._y=(l+f)/M,this._z=(c+h)/M}else if(p>g){const M=2*Math.sqrt(1+p-s-g);this._w=(c-h)/M,this._x=(l+f)/M,this._y=.25*M,this._z=(m+_)/M}else{const M=2*Math.sqrt(1+g-s-p);this._w=(f-l)/M,this._x=(c+h)/M,this._y=(m+_)/M,this._z=.25*M}return this._onChangeCallback(),this}setFromUnitVectors(e,i){let s=e.dot(i)+1;return s<1e-8?(s=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=s):(this._x=0,this._y=-e.z,this._z=e.y,this._w=s)):(this._x=e.y*i.z-e.z*i.y,this._y=e.z*i.x-e.x*i.z,this._z=e.x*i.y-e.y*i.x,this._w=s),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(At(this.dot(e),-1,1)))}rotateTowards(e,i){const s=this.angleTo(e);if(s===0)return this;const l=Math.min(1,i/s);return this.slerp(e,l),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,i){const s=e._x,l=e._y,c=e._z,f=e._w,p=i._x,m=i._y,h=i._z,_=i._w;return this._x=s*_+f*p+l*h-c*m,this._y=l*_+f*m+c*p-s*h,this._z=c*_+f*h+s*m-l*p,this._w=f*_-s*p-l*m-c*h,this._onChangeCallback(),this}slerp(e,i){let s=e._x,l=e._y,c=e._z,f=e._w,p=this.dot(e);p<0&&(s=-s,l=-l,c=-c,f=-f,p=-p);let m=1-i;if(p<.9995){const h=Math.acos(p),_=Math.sin(h);m=Math.sin(m*h)/_,i=Math.sin(i*h)/_,this._x=this._x*m+s*i,this._y=this._y*m+l*i,this._z=this._z*m+c*i,this._w=this._w*m+f*i,this._onChangeCallback()}else this._x=this._x*m+s*i,this._y=this._y*m+l*i,this._z=this._z*m+c*i,this._w=this._w*m+f*i,this.normalize();return this}slerpQuaternions(e,i,s){return this.copy(e).slerp(i,s)}random(){const e=2*Math.PI*Math.random(),i=2*Math.PI*Math.random(),s=Math.random(),l=Math.sqrt(1-s),c=Math.sqrt(s);return this.set(l*Math.sin(e),l*Math.cos(e),c*Math.sin(i),c*Math.cos(i))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,i=0){return this._x=e[i],this._y=e[i+1],this._z=e[i+2],this._w=e[i+3],this._onChangeCallback(),this}toArray(e=[],i=0){return e[i]=this._x,e[i+1]=this._y,e[i+2]=this._z,e[i+3]=this._w,e}fromBufferAttribute(e,i){return this._x=e.getX(i),this._y=e.getY(i),this._z=e.getZ(i),this._w=e.getW(i),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const Pp=class Pp{constructor(e=0,i=0,s=0){this.x=e,this.y=i,this.z=s}set(e,i,s){return s===void 0&&(s=this.z),this.x=e,this.y=i,this.z=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,i){switch(e){case 0:this.x=i;break;case 1:this.y=i;break;case 2:this.z=i;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,i){return this.x=e.x+i.x,this.y=e.y+i.y,this.z=e.z+i.z,this}addScaledVector(e,i){return this.x+=e.x*i,this.y+=e.y*i,this.z+=e.z*i,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,i){return this.x=e.x-i.x,this.y=e.y-i.y,this.z=e.z-i.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,i){return this.x=e.x*i.x,this.y=e.y*i.y,this.z=e.z*i.z,this}applyEuler(e){return this.applyQuaternion(Zv.setFromEuler(e))}applyAxisAngle(e,i){return this.applyQuaternion(Zv.setFromAxisAngle(e,i))}applyMatrix3(e){const i=this.x,s=this.y,l=this.z,c=e.elements;return this.x=c[0]*i+c[3]*s+c[6]*l,this.y=c[1]*i+c[4]*s+c[7]*l,this.z=c[2]*i+c[5]*s+c[8]*l,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const i=this.x,s=this.y,l=this.z,c=e.elements,f=1/(c[3]*i+c[7]*s+c[11]*l+c[15]);return this.x=(c[0]*i+c[4]*s+c[8]*l+c[12])*f,this.y=(c[1]*i+c[5]*s+c[9]*l+c[13])*f,this.z=(c[2]*i+c[6]*s+c[10]*l+c[14])*f,this}applyQuaternion(e){const i=this.x,s=this.y,l=this.z,c=e.x,f=e.y,p=e.z,m=e.w,h=2*(f*l-p*s),_=2*(p*i-c*l),g=2*(c*s-f*i);return this.x=i+m*h+f*g-p*_,this.y=s+m*_+p*h-c*g,this.z=l+m*g+c*_-f*h,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const i=this.x,s=this.y,l=this.z,c=e.elements;return this.x=c[0]*i+c[4]*s+c[8]*l,this.y=c[1]*i+c[5]*s+c[9]*l,this.z=c[2]*i+c[6]*s+c[10]*l,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,i){return this.x=At(this.x,e.x,i.x),this.y=At(this.y,e.y,i.y),this.z=At(this.z,e.z,i.z),this}clampScalar(e,i){return this.x=At(this.x,e,i),this.y=At(this.y,e,i),this.z=At(this.z,e,i),this}clampLength(e,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(At(s,e,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,i){return this.x+=(e.x-this.x)*i,this.y+=(e.y-this.y)*i,this.z+=(e.z-this.z)*i,this}lerpVectors(e,i,s){return this.x=e.x+(i.x-e.x)*s,this.y=e.y+(i.y-e.y)*s,this.z=e.z+(i.z-e.z)*s,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,i){const s=e.x,l=e.y,c=e.z,f=i.x,p=i.y,m=i.z;return this.x=l*m-c*p,this.y=c*f-s*m,this.z=s*p-l*f,this}projectOnVector(e){const i=e.lengthSq();if(i===0)return this.set(0,0,0);const s=e.dot(this)/i;return this.copy(e).multiplyScalar(s)}projectOnPlane(e){return Wd.copy(this).projectOnVector(e),this.sub(Wd)}reflect(e){return this.sub(Wd.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const i=Math.sqrt(this.lengthSq()*e.lengthSq());if(i===0)return Math.PI/2;const s=this.dot(e)/i;return Math.acos(At(s,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const i=this.x-e.x,s=this.y-e.y,l=this.z-e.z;return i*i+s*s+l*l}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,i,s){const l=Math.sin(i)*e;return this.x=l*Math.sin(s),this.y=Math.cos(i)*e,this.z=l*Math.cos(s),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,i,s){return this.x=e*Math.sin(i),this.y=s,this.z=e*Math.cos(i),this}setFromMatrixPosition(e){const i=e.elements;return this.x=i[12],this.y=i[13],this.z=i[14],this}setFromMatrixScale(e){const i=this.setFromMatrixColumn(e,0).length(),s=this.setFromMatrixColumn(e,1).length(),l=this.setFromMatrixColumn(e,2).length();return this.x=i,this.y=s,this.z=l,this}setFromMatrixColumn(e,i){return this.fromArray(e.elements,i*4)}setFromMatrix3Column(e,i){return this.fromArray(e.elements,i*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,i=0){return this.x=e[i],this.y=e[i+1],this.z=e[i+2],this}toArray(e=[],i=0){return e[i]=this.x,e[i+1]=this.y,e[i+2]=this.z,e}fromBufferAttribute(e,i){return this.x=e.getX(i),this.y=e.getY(i),this.z=e.getZ(i),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,i=Math.random()*2-1,s=Math.sqrt(1-i*i);return this.x=s*Math.cos(e),this.y=i,this.z=s*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};Pp.prototype.isVector3=!0;let ce=Pp;const Wd=new ce,Zv=new ro,Ip=class Ip{constructor(e,i,s,l,c,f,p,m,h){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,i,s,l,c,f,p,m,h)}set(e,i,s,l,c,f,p,m,h){const _=this.elements;return _[0]=e,_[1]=l,_[2]=p,_[3]=i,_[4]=c,_[5]=m,_[6]=s,_[7]=f,_[8]=h,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const i=this.elements,s=e.elements;return i[0]=s[0],i[1]=s[1],i[2]=s[2],i[3]=s[3],i[4]=s[4],i[5]=s[5],i[6]=s[6],i[7]=s[7],i[8]=s[8],this}extractBasis(e,i,s){return e.setFromMatrix3Column(this,0),i.setFromMatrix3Column(this,1),s.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const i=e.elements;return this.set(i[0],i[4],i[8],i[1],i[5],i[9],i[2],i[6],i[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,i){const s=e.elements,l=i.elements,c=this.elements,f=s[0],p=s[3],m=s[6],h=s[1],_=s[4],g=s[7],v=s[2],M=s[5],b=s[8],C=l[0],y=l[3],x=l[6],O=l[1],I=l[4],w=l[7],B=l[2],U=l[5],F=l[8];return c[0]=f*C+p*O+m*B,c[3]=f*y+p*I+m*U,c[6]=f*x+p*w+m*F,c[1]=h*C+_*O+g*B,c[4]=h*y+_*I+g*U,c[7]=h*x+_*w+g*F,c[2]=v*C+M*O+b*B,c[5]=v*y+M*I+b*U,c[8]=v*x+M*w+b*F,this}multiplyScalar(e){const i=this.elements;return i[0]*=e,i[3]*=e,i[6]*=e,i[1]*=e,i[4]*=e,i[7]*=e,i[2]*=e,i[5]*=e,i[8]*=e,this}determinant(){const e=this.elements,i=e[0],s=e[1],l=e[2],c=e[3],f=e[4],p=e[5],m=e[6],h=e[7],_=e[8];return i*f*_-i*p*h-s*c*_+s*p*m+l*c*h-l*f*m}invert(){const e=this.elements,i=e[0],s=e[1],l=e[2],c=e[3],f=e[4],p=e[5],m=e[6],h=e[7],_=e[8],g=_*f-p*h,v=p*m-_*c,M=h*c-f*m,b=i*g+s*v+l*M;if(b===0)return this.set(0,0,0,0,0,0,0,0,0);const C=1/b;return e[0]=g*C,e[1]=(l*h-_*s)*C,e[2]=(p*s-l*f)*C,e[3]=v*C,e[4]=(_*i-l*m)*C,e[5]=(l*c-p*i)*C,e[6]=M*C,e[7]=(s*m-h*i)*C,e[8]=(f*i-s*c)*C,this}transpose(){let e;const i=this.elements;return e=i[1],i[1]=i[3],i[3]=e,e=i[2],i[2]=i[6],i[6]=e,e=i[5],i[5]=i[7],i[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const i=this.elements;return e[0]=i[0],e[1]=i[3],e[2]=i[6],e[3]=i[1],e[4]=i[4],e[5]=i[7],e[6]=i[2],e[7]=i[5],e[8]=i[8],this}setUvTransform(e,i,s,l,c,f,p){const m=Math.cos(c),h=Math.sin(c);return this.set(s*m,s*h,-s*(m*f+h*p)+f+e,-l*h,l*m,-l*(-h*f+m*p)+p+i,0,0,1),this}scale(e,i){return Qs("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(qd.makeScale(e,i)),this}rotate(e){return Qs("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(qd.makeRotation(-e)),this}translate(e,i){return Qs("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(qd.makeTranslation(e,i)),this}makeTranslation(e,i){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,i,0,0,1),this}makeRotation(e){const i=Math.cos(e),s=Math.sin(e);return this.set(i,-s,0,s,i,0,0,0,1),this}makeScale(e,i){return this.set(e,0,0,0,i,0,0,0,1),this}equals(e){const i=this.elements,s=e.elements;for(let l=0;l<9;l++)if(i[l]!==s[l])return!1;return!0}fromArray(e,i=0){for(let s=0;s<9;s++)this.elements[s]=e[s+i];return this}toArray(e=[],i=0){const s=this.elements;return e[i]=s[0],e[i+1]=s[1],e[i+2]=s[2],e[i+3]=s[3],e[i+4]=s[4],e[i+5]=s[5],e[i+6]=s[6],e[i+7]=s[7],e[i+8]=s[8],e}clone(){return new this.constructor().fromArray(this.elements)}};Ip.prototype.isMatrix3=!0;let ot=Ip;const qd=new ot,Kv=new ot().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Qv=new ot().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Ub(){const a={enabled:!0,workingColorSpace:pu,spaces:{},convert:function(l,c,f){return this.enabled===!1||c===f||!c||!f||(this.spaces[c].transfer===Wt&&(l.r=Oa(l.r),l.g=Oa(l.g),l.b=Oa(l.b)),this.spaces[c].primaries!==this.spaces[f].primaries&&(l.applyMatrix3(this.spaces[c].toXYZ),l.applyMatrix3(this.spaces[f].fromXYZ)),this.spaces[f].transfer===Wt&&(l.r=js(l.r),l.g=js(l.g),l.b=js(l.b))),l},workingToColorSpace:function(l,c){return this.convert(l,this.workingColorSpace,c)},colorSpaceToWorking:function(l,c){return this.convert(l,c,this.workingColorSpace)},getPrimaries:function(l){return this.spaces[l].primaries},getTransfer:function(l){return l===Sr?mu:this.spaces[l].transfer},getToneMappingMode:function(l){return this.spaces[l].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(l,c=this.workingColorSpace){return l.fromArray(this.spaces[c].luminanceCoefficients)},define:function(l){Object.assign(this.spaces,l)},_getMatrix:function(l,c,f){return l.copy(this.spaces[c].toXYZ).multiply(this.spaces[f].fromXYZ)},_getDrawingBufferColorSpace:function(l){return this.spaces[l].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(l=this.workingColorSpace){return this.spaces[l].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(l,c){return Qs("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),a.workingToColorSpace(l,c)},toWorkingColorSpace:function(l,c){return Qs("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),a.colorSpaceToWorking(l,c)}},e=[.64,.33,.3,.6,.15,.06],i=[.2126,.7152,.0722],s=[.3127,.329];return a.define({[pu]:{primaries:e,whitePoint:s,transfer:mu,toXYZ:Kv,fromXYZ:Qv,luminanceCoefficients:i,workingColorSpaceConfig:{unpackColorSpace:Ti},outputColorSpaceConfig:{drawingBufferColorSpace:Ti}},[Ti]:{primaries:e,whitePoint:s,transfer:Wt,toXYZ:Kv,fromXYZ:Qv,luminanceCoefficients:i,outputColorSpaceConfig:{drawingBufferColorSpace:Ti}}}),a}const Tt=Ub();function Oa(a){return a<.04045?a*.0773993808:Math.pow(a*.9478672986+.0521327014,2.4)}function js(a){return a<.0031308?a*12.92:1.055*Math.pow(a,.41666)-.055}let Is;class Nb{static getDataURL(e,i="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let s;if(e instanceof HTMLCanvasElement)s=e;else{Is===void 0&&(Is=vu("canvas")),Is.width=e.width,Is.height=e.height;const l=Is.getContext("2d");e instanceof ImageData?l.putImageData(e,0,0):l.drawImage(e,0,0,e.width,e.height),s=Is}return s.toDataURL(i)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const i=vu("canvas");i.width=e.width,i.height=e.height;const s=i.getContext("2d");s.drawImage(e,0,0,e.width,e.height);const l=s.getImageData(0,0,e.width,e.height),c=l.data;for(let f=0;f<c.length;f++)c[f]=Oa(c[f]/255)*255;return s.putImageData(l,0,0),i}else if(e.data){const i=e.data.slice(0);for(let s=0;s<i.length;s++)i instanceof Uint8Array||i instanceof Uint8ClampedArray?i[s]=Math.floor(Oa(i[s]/255)*255):i[s]=Oa(i[s]);return{data:i,width:e.width,height:e.height}}else return rt("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let Lb=0;class Up{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Lb++}),this.uuid=pl(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const i=this.data;return typeof HTMLVideoElement<"u"&&i instanceof HTMLVideoElement?e.set(i.videoWidth,i.videoHeight,0):typeof VideoFrame<"u"&&i instanceof VideoFrame?e.set(i.displayWidth,i.displayHeight,0):i!==null?e.set(i.width,i.height,i.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const i=e===void 0||typeof e=="string";if(!i&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const s={uuid:this.uuid,url:""},l=this.data;if(l!==null){let c;if(Array.isArray(l)){c=[];for(let f=0,p=l.length;f<p;f++)l[f].isDataTexture?c.push(Yd(l[f].image)):c.push(Yd(l[f]))}else c=Yd(l);s.url=c}return i||(e.images[this.uuid]=s),s}}function Yd(a){return typeof HTMLImageElement<"u"&&a instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&a instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&a instanceof ImageBitmap?Nb.getDataURL(a):a.data?{data:Array.from(a.data),width:a.width,height:a.height,type:a.data.constructor.name}:(rt("Texture: Unable to serialize Texture."),{})}let Ob=0;const Zd=new ce;class kn extends ts{constructor(e=kn.DEFAULT_IMAGE,i=kn.DEFAULT_MAPPING,s=Na,l=Na,c=Hn,f=Qr,p=zi,m=Ai,h=kn.DEFAULT_ANISOTROPY,_=Sr){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Ob++}),this.uuid=pl(),this.name="",this.source=new Up(e),this.mipmaps=[],this.mapping=i,this.channel=0,this.wrapS=s,this.wrapT=l,this.magFilter=c,this.minFilter=f,this.anisotropy=h,this.format=p,this.internalFormat=null,this.type=m,this.offset=new Pt(0,0),this.repeat=new Pt(1,1),this.center=new Pt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new ot,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=_,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(Zd).x}get height(){return this.source.getSize(Zd).y}get depth(){return this.source.getSize(Zd).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,i){this.updateRanges.push({start:e,count:i})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const i in e){const s=e[i];if(s===void 0){rt(`Texture.setValues(): parameter '${i}' has value of undefined.`);continue}const l=this[i];if(l===void 0){rt(`Texture.setValues(): property '${i}' does not exist.`);continue}l&&s&&l.isVector2&&s.isVector2||l&&s&&l.isVector3&&s.isVector3||l&&s&&l.isMatrix3&&s.isMatrix3?l.copy(s):this[i]=s}}toJSON(e){const i=e===void 0||typeof e=="string";if(!i&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const s={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(s.userData=this.userData),i||(e.textures[this.uuid]=s),s}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==gx)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Uh:e.x=e.x-Math.floor(e.x);break;case Na:e.x=e.x<0?0:1;break;case Nh:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Uh:e.y=e.y-Math.floor(e.y);break;case Na:e.y=e.y<0?0:1;break;case Nh:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}kn.DEFAULT_IMAGE=null;kn.DEFAULT_MAPPING=gx;kn.DEFAULT_ANISOTROPY=1;const Bp=class Bp{constructor(e=0,i=0,s=0,l=1){this.x=e,this.y=i,this.z=s,this.w=l}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,i,s,l){return this.x=e,this.y=i,this.z=s,this.w=l,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,i){switch(e){case 0:this.x=i;break;case 1:this.y=i;break;case 2:this.z=i;break;case 3:this.w=i;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,i){return this.x=e.x+i.x,this.y=e.y+i.y,this.z=e.z+i.z,this.w=e.w+i.w,this}addScaledVector(e,i){return this.x+=e.x*i,this.y+=e.y*i,this.z+=e.z*i,this.w+=e.w*i,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,i){return this.x=e.x-i.x,this.y=e.y-i.y,this.z=e.z-i.z,this.w=e.w-i.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const i=this.x,s=this.y,l=this.z,c=this.w,f=e.elements;return this.x=f[0]*i+f[4]*s+f[8]*l+f[12]*c,this.y=f[1]*i+f[5]*s+f[9]*l+f[13]*c,this.z=f[2]*i+f[6]*s+f[10]*l+f[14]*c,this.w=f[3]*i+f[7]*s+f[11]*l+f[15]*c,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const i=Math.sqrt(1-e.w*e.w);return i<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/i,this.y=e.y/i,this.z=e.z/i),this}setAxisAngleFromRotationMatrix(e){let i,s,l,c;const m=e.elements,h=m[0],_=m[4],g=m[8],v=m[1],M=m[5],b=m[9],C=m[2],y=m[6],x=m[10];if(Math.abs(_-v)<.01&&Math.abs(g-C)<.01&&Math.abs(b-y)<.01){if(Math.abs(_+v)<.1&&Math.abs(g+C)<.1&&Math.abs(b+y)<.1&&Math.abs(h+M+x-3)<.1)return this.set(1,0,0,0),this;i=Math.PI;const I=(h+1)/2,w=(M+1)/2,B=(x+1)/2,U=(_+v)/4,F=(g+C)/4,T=(b+y)/4;return I>w&&I>B?I<.01?(s=0,l=.707106781,c=.707106781):(s=Math.sqrt(I),l=U/s,c=F/s):w>B?w<.01?(s=.707106781,l=0,c=.707106781):(l=Math.sqrt(w),s=U/l,c=T/l):B<.01?(s=.707106781,l=.707106781,c=0):(c=Math.sqrt(B),s=F/c,l=T/c),this.set(s,l,c,i),this}let O=Math.sqrt((y-b)*(y-b)+(g-C)*(g-C)+(v-_)*(v-_));return Math.abs(O)<.001&&(O=1),this.x=(y-b)/O,this.y=(g-C)/O,this.z=(v-_)/O,this.w=Math.acos((h+M+x-1)/2),this}setFromMatrixPosition(e){const i=e.elements;return this.x=i[12],this.y=i[13],this.z=i[14],this.w=i[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,i){return this.x=At(this.x,e.x,i.x),this.y=At(this.y,e.y,i.y),this.z=At(this.z,e.z,i.z),this.w=At(this.w,e.w,i.w),this}clampScalar(e,i){return this.x=At(this.x,e,i),this.y=At(this.y,e,i),this.z=At(this.z,e,i),this.w=At(this.w,e,i),this}clampLength(e,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(At(s,e,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,i){return this.x+=(e.x-this.x)*i,this.y+=(e.y-this.y)*i,this.z+=(e.z-this.z)*i,this.w+=(e.w-this.w)*i,this}lerpVectors(e,i,s){return this.x=e.x+(i.x-e.x)*s,this.y=e.y+(i.y-e.y)*s,this.z=e.z+(i.z-e.z)*s,this.w=e.w+(i.w-e.w)*s,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,i=0){return this.x=e[i],this.y=e[i+1],this.z=e[i+2],this.w=e[i+3],this}toArray(e=[],i=0){return e[i]=this.x,e[i+1]=this.y,e[i+2]=this.z,e[i+3]=this.w,e}fromBufferAttribute(e,i){return this.x=e.getX(i),this.y=e.getY(i),this.z=e.getZ(i),this.w=e.getW(i),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};Bp.prototype.isVector4=!0;let dn=Bp;class Pb extends ts{constructor(e=1,i=1,s={}){super(),s=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Hn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},s),this.isRenderTarget=!0,this.width=e,this.height=i,this.depth=s.depth,this.scissor=new dn(0,0,e,i),this.scissorTest=!1,this.viewport=new dn(0,0,e,i),this.textures=[];const l={width:e,height:i,depth:s.depth},c=new kn(l),f=s.count;for(let p=0;p<f;p++)this.textures[p]=c.clone(),this.textures[p].isRenderTargetTexture=!0,this.textures[p].renderTarget=this;this._setTextureOptions(s),this.depthBuffer=s.depthBuffer,this.stencilBuffer=s.stencilBuffer,this.resolveDepthBuffer=s.resolveDepthBuffer,this.resolveStencilBuffer=s.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=s.depthTexture,this.samples=s.samples,this.multiview=s.multiview,this.useArrayDepthTexture=s.useArrayDepthTexture}_setTextureOptions(e={}){const i={minFilter:Hn,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(i.mapping=e.mapping),e.wrapS!==void 0&&(i.wrapS=e.wrapS),e.wrapT!==void 0&&(i.wrapT=e.wrapT),e.wrapR!==void 0&&(i.wrapR=e.wrapR),e.magFilter!==void 0&&(i.magFilter=e.magFilter),e.minFilter!==void 0&&(i.minFilter=e.minFilter),e.format!==void 0&&(i.format=e.format),e.type!==void 0&&(i.type=e.type),e.anisotropy!==void 0&&(i.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(i.colorSpace=e.colorSpace),e.flipY!==void 0&&(i.flipY=e.flipY),e.generateMipmaps!==void 0&&(i.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(i.internalFormat=e.internalFormat);for(let s=0;s<this.textures.length;s++)this.textures[s].setValues(i)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,i,s=1){if(this.width!==e||this.height!==i||this.depth!==s){this.width=e,this.height=i,this.depth=s;for(let l=0,c=this.textures.length;l<c;l++)this.textures[l].image.width=e,this.textures[l].image.height=i,this.textures[l].image.depth=s,this.textures[l].isData3DTexture!==!0&&(this.textures[l].isArrayTexture=this.textures[l].image.depth>1);this.dispose()}this.viewport.set(0,0,e,i),this.scissor.set(0,0,e,i)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let i=0,s=e.textures.length;i<s;i++){this.textures[i]=e.textures[i].clone(),this.textures[i].isRenderTargetTexture=!0,this.textures[i].renderTarget=this;const l=Object.assign({},e.textures[i].image);this.textures[i].source=new Up(l)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class na extends Pb{constructor(e=1,i=1,s={}){super(e,i,s),this.isWebGLRenderTarget=!0}}class Tx extends kn{constructor(e=null,i=1,s=1,l=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:i,height:s,depth:l},this.magFilter=Pn,this.minFilter=Pn,this.wrapR=Na,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class Ib extends kn{constructor(e=null,i=1,s=1,l=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:i,height:s,depth:l},this.magFilter=Pn,this.minFilter=Pn,this.wrapR=Na,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const _u=class _u{constructor(e,i,s,l,c,f,p,m,h,_,g,v,M,b,C,y){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,i,s,l,c,f,p,m,h,_,g,v,M,b,C,y)}set(e,i,s,l,c,f,p,m,h,_,g,v,M,b,C,y){const x=this.elements;return x[0]=e,x[4]=i,x[8]=s,x[12]=l,x[1]=c,x[5]=f,x[9]=p,x[13]=m,x[2]=h,x[6]=_,x[10]=g,x[14]=v,x[3]=M,x[7]=b,x[11]=C,x[15]=y,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new _u().fromArray(this.elements)}copy(e){const i=this.elements,s=e.elements;return i[0]=s[0],i[1]=s[1],i[2]=s[2],i[3]=s[3],i[4]=s[4],i[5]=s[5],i[6]=s[6],i[7]=s[7],i[8]=s[8],i[9]=s[9],i[10]=s[10],i[11]=s[11],i[12]=s[12],i[13]=s[13],i[14]=s[14],i[15]=s[15],this}copyPosition(e){const i=this.elements,s=e.elements;return i[12]=s[12],i[13]=s[13],i[14]=s[14],this}setFromMatrix3(e){const i=e.elements;return this.set(i[0],i[3],i[6],0,i[1],i[4],i[7],0,i[2],i[5],i[8],0,0,0,0,1),this}extractBasis(e,i,s){return this.determinantAffine()===0?(e.set(1,0,0),i.set(0,1,0),s.set(0,0,1),this):(e.setFromMatrixColumn(this,0),i.setFromMatrixColumn(this,1),s.setFromMatrixColumn(this,2),this)}makeBasis(e,i,s){return this.set(e.x,i.x,s.x,0,e.y,i.y,s.y,0,e.z,i.z,s.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();const i=this.elements,s=e.elements,l=1/Bs.setFromMatrixColumn(e,0).length(),c=1/Bs.setFromMatrixColumn(e,1).length(),f=1/Bs.setFromMatrixColumn(e,2).length();return i[0]=s[0]*l,i[1]=s[1]*l,i[2]=s[2]*l,i[3]=0,i[4]=s[4]*c,i[5]=s[5]*c,i[6]=s[6]*c,i[7]=0,i[8]=s[8]*f,i[9]=s[9]*f,i[10]=s[10]*f,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,this}makeRotationFromEuler(e){const i=this.elements,s=e.x,l=e.y,c=e.z,f=Math.cos(s),p=Math.sin(s),m=Math.cos(l),h=Math.sin(l),_=Math.cos(c),g=Math.sin(c);if(e.order==="XYZ"){const v=f*_,M=f*g,b=p*_,C=p*g;i[0]=m*_,i[4]=-m*g,i[8]=h,i[1]=M+b*h,i[5]=v-C*h,i[9]=-p*m,i[2]=C-v*h,i[6]=b+M*h,i[10]=f*m}else if(e.order==="YXZ"){const v=m*_,M=m*g,b=h*_,C=h*g;i[0]=v+C*p,i[4]=b*p-M,i[8]=f*h,i[1]=f*g,i[5]=f*_,i[9]=-p,i[2]=M*p-b,i[6]=C+v*p,i[10]=f*m}else if(e.order==="ZXY"){const v=m*_,M=m*g,b=h*_,C=h*g;i[0]=v-C*p,i[4]=-f*g,i[8]=b+M*p,i[1]=M+b*p,i[5]=f*_,i[9]=C-v*p,i[2]=-f*h,i[6]=p,i[10]=f*m}else if(e.order==="ZYX"){const v=f*_,M=f*g,b=p*_,C=p*g;i[0]=m*_,i[4]=b*h-M,i[8]=v*h+C,i[1]=m*g,i[5]=C*h+v,i[9]=M*h-b,i[2]=-h,i[6]=p*m,i[10]=f*m}else if(e.order==="YZX"){const v=f*m,M=f*h,b=p*m,C=p*h;i[0]=m*_,i[4]=C-v*g,i[8]=b*g+M,i[1]=g,i[5]=f*_,i[9]=-p*_,i[2]=-h*_,i[6]=M*g+b,i[10]=v-C*g}else if(e.order==="XZY"){const v=f*m,M=f*h,b=p*m,C=p*h;i[0]=m*_,i[4]=-g,i[8]=h*_,i[1]=v*g+C,i[5]=f*_,i[9]=M*g-b,i[2]=b*g-M,i[6]=p*_,i[10]=C*g+v}return i[3]=0,i[7]=0,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Bb,e,Fb)}lookAt(e,i,s){const l=this.elements;return ui.subVectors(e,i),ui.lengthSq()===0&&(ui.z=1),ui.normalize(),pr.crossVectors(s,ui),pr.lengthSq()===0&&(Math.abs(s.z)===1?ui.x+=1e-4:ui.z+=1e-4,ui.normalize(),pr.crossVectors(s,ui)),pr.normalize(),Uc.crossVectors(ui,pr),l[0]=pr.x,l[4]=Uc.x,l[8]=ui.x,l[1]=pr.y,l[5]=Uc.y,l[9]=ui.y,l[2]=pr.z,l[6]=Uc.z,l[10]=ui.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,i){const s=e.elements,l=i.elements,c=this.elements,f=s[0],p=s[4],m=s[8],h=s[12],_=s[1],g=s[5],v=s[9],M=s[13],b=s[2],C=s[6],y=s[10],x=s[14],O=s[3],I=s[7],w=s[11],B=s[15],U=l[0],F=l[4],T=l[8],P=l[12],q=l[1],V=l[5],Q=l[9],fe=l[13],me=l[2],j=l[6],L=l[10],H=l[14],$=l[3],_e=l[7],be=l[11],N=l[15];return c[0]=f*U+p*q+m*me+h*$,c[4]=f*F+p*V+m*j+h*_e,c[8]=f*T+p*Q+m*L+h*be,c[12]=f*P+p*fe+m*H+h*N,c[1]=_*U+g*q+v*me+M*$,c[5]=_*F+g*V+v*j+M*_e,c[9]=_*T+g*Q+v*L+M*be,c[13]=_*P+g*fe+v*H+M*N,c[2]=b*U+C*q+y*me+x*$,c[6]=b*F+C*V+y*j+x*_e,c[10]=b*T+C*Q+y*L+x*be,c[14]=b*P+C*fe+y*H+x*N,c[3]=O*U+I*q+w*me+B*$,c[7]=O*F+I*V+w*j+B*_e,c[11]=O*T+I*Q+w*L+B*be,c[15]=O*P+I*fe+w*H+B*N,this}multiplyScalar(e){const i=this.elements;return i[0]*=e,i[4]*=e,i[8]*=e,i[12]*=e,i[1]*=e,i[5]*=e,i[9]*=e,i[13]*=e,i[2]*=e,i[6]*=e,i[10]*=e,i[14]*=e,i[3]*=e,i[7]*=e,i[11]*=e,i[15]*=e,this}determinant(){const e=this.elements,i=e[0],s=e[4],l=e[8],c=e[12],f=e[1],p=e[5],m=e[9],h=e[13],_=e[2],g=e[6],v=e[10],M=e[14],b=e[3],C=e[7],y=e[11],x=e[15],O=m*M-h*v,I=p*M-h*g,w=p*v-m*g,B=f*M-h*_,U=f*v-m*_,F=f*g-p*_;return i*(C*O-y*I+x*w)-s*(b*O-y*B+x*U)+l*(b*I-C*B+x*F)-c*(b*w-C*U+y*F)}determinantAffine(){const e=this.elements,i=e[0],s=e[4],l=e[8],c=e[1],f=e[5],p=e[9],m=e[2],h=e[6],_=e[10];return i*(f*_-p*h)-s*(c*_-p*m)+l*(c*h-f*m)}transpose(){const e=this.elements;let i;return i=e[1],e[1]=e[4],e[4]=i,i=e[2],e[2]=e[8],e[8]=i,i=e[6],e[6]=e[9],e[9]=i,i=e[3],e[3]=e[12],e[12]=i,i=e[7],e[7]=e[13],e[13]=i,i=e[11],e[11]=e[14],e[14]=i,this}setPosition(e,i,s){const l=this.elements;return e.isVector3?(l[12]=e.x,l[13]=e.y,l[14]=e.z):(l[12]=e,l[13]=i,l[14]=s),this}invert(){const e=this.elements,i=e[0],s=e[1],l=e[2],c=e[3],f=e[4],p=e[5],m=e[6],h=e[7],_=e[8],g=e[9],v=e[10],M=e[11],b=e[12],C=e[13],y=e[14],x=e[15],O=i*p-s*f,I=i*m-l*f,w=i*h-c*f,B=s*m-l*p,U=s*h-c*p,F=l*h-c*m,T=_*C-g*b,P=_*y-v*b,q=_*x-M*b,V=g*y-v*C,Q=g*x-M*C,fe=v*x-M*y,me=O*fe-I*Q+w*V+B*q-U*P+F*T;if(me===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const j=1/me;return e[0]=(p*fe-m*Q+h*V)*j,e[1]=(l*Q-s*fe-c*V)*j,e[2]=(C*F-y*U+x*B)*j,e[3]=(v*U-g*F-M*B)*j,e[4]=(m*q-f*fe-h*P)*j,e[5]=(i*fe-l*q+c*P)*j,e[6]=(y*w-b*F-x*I)*j,e[7]=(_*F-v*w+M*I)*j,e[8]=(f*Q-p*q+h*T)*j,e[9]=(s*q-i*Q-c*T)*j,e[10]=(b*U-C*w+x*O)*j,e[11]=(g*w-_*U-M*O)*j,e[12]=(p*P-f*V-m*T)*j,e[13]=(i*V-s*P+l*T)*j,e[14]=(C*I-b*B-y*O)*j,e[15]=(_*B-g*I+v*O)*j,this}scale(e){const i=this.elements,s=e.x,l=e.y,c=e.z;return i[0]*=s,i[4]*=l,i[8]*=c,i[1]*=s,i[5]*=l,i[9]*=c,i[2]*=s,i[6]*=l,i[10]*=c,i[3]*=s,i[7]*=l,i[11]*=c,this}getMaxScaleOnAxis(){const e=this.elements,i=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],s=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],l=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(i,s,l))}makeTranslation(e,i,s){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,i,0,0,1,s,0,0,0,1),this}makeRotationX(e){const i=Math.cos(e),s=Math.sin(e);return this.set(1,0,0,0,0,i,-s,0,0,s,i,0,0,0,0,1),this}makeRotationY(e){const i=Math.cos(e),s=Math.sin(e);return this.set(i,0,s,0,0,1,0,0,-s,0,i,0,0,0,0,1),this}makeRotationZ(e){const i=Math.cos(e),s=Math.sin(e);return this.set(i,-s,0,0,s,i,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,i){const s=Math.cos(i),l=Math.sin(i),c=1-s,f=e.x,p=e.y,m=e.z,h=c*f,_=c*p;return this.set(h*f+s,h*p-l*m,h*m+l*p,0,h*p+l*m,_*p+s,_*m-l*f,0,h*m-l*p,_*m+l*f,c*m*m+s,0,0,0,0,1),this}makeScale(e,i,s){return this.set(e,0,0,0,0,i,0,0,0,0,s,0,0,0,0,1),this}makeShear(e,i,s,l,c,f){return this.set(1,s,c,0,e,1,f,0,i,l,1,0,0,0,0,1),this}compose(e,i,s){const l=this.elements,c=i._x,f=i._y,p=i._z,m=i._w,h=c+c,_=f+f,g=p+p,v=c*h,M=c*_,b=c*g,C=f*_,y=f*g,x=p*g,O=m*h,I=m*_,w=m*g,B=s.x,U=s.y,F=s.z;return l[0]=(1-(C+x))*B,l[1]=(M+w)*B,l[2]=(b-I)*B,l[3]=0,l[4]=(M-w)*U,l[5]=(1-(v+x))*U,l[6]=(y+O)*U,l[7]=0,l[8]=(b+I)*F,l[9]=(y-O)*F,l[10]=(1-(v+C))*F,l[11]=0,l[12]=e.x,l[13]=e.y,l[14]=e.z,l[15]=1,this}decompose(e,i,s){const l=this.elements;e.x=l[12],e.y=l[13],e.z=l[14];const c=this.determinantAffine();if(c===0)return s.set(1,1,1),i.identity(),this;let f=Bs.set(l[0],l[1],l[2]).length();const p=Bs.set(l[4],l[5],l[6]).length(),m=Bs.set(l[8],l[9],l[10]).length();c<0&&(f=-f),Oi.copy(this);const h=1/f,_=1/p,g=1/m;return Oi.elements[0]*=h,Oi.elements[1]*=h,Oi.elements[2]*=h,Oi.elements[4]*=_,Oi.elements[5]*=_,Oi.elements[6]*=_,Oi.elements[8]*=g,Oi.elements[9]*=g,Oi.elements[10]*=g,i.setFromRotationMatrix(Oi),s.x=f,s.y=p,s.z=m,this}makePerspective(e,i,s,l,c,f,p=ea,m=!1){const h=this.elements,_=2*c/(i-e),g=2*c/(s-l),v=(i+e)/(i-e),M=(s+l)/(s-l);let b,C;if(m)b=c/(f-c),C=f*c/(f-c);else if(p===ea)b=-(f+c)/(f-c),C=-2*f*c/(f-c);else if(p===gu)b=-f/(f-c),C=-f*c/(f-c);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+p);return h[0]=_,h[4]=0,h[8]=v,h[12]=0,h[1]=0,h[5]=g,h[9]=M,h[13]=0,h[2]=0,h[6]=0,h[10]=b,h[14]=C,h[3]=0,h[7]=0,h[11]=-1,h[15]=0,this}makeOrthographic(e,i,s,l,c,f,p=ea,m=!1){const h=this.elements,_=2/(i-e),g=2/(s-l),v=-(i+e)/(i-e),M=-(s+l)/(s-l);let b,C;if(m)b=1/(f-c),C=f/(f-c);else if(p===ea)b=-2/(f-c),C=-(f+c)/(f-c);else if(p===gu)b=-1/(f-c),C=-c/(f-c);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+p);return h[0]=_,h[4]=0,h[8]=0,h[12]=v,h[1]=0,h[5]=g,h[9]=0,h[13]=M,h[2]=0,h[6]=0,h[10]=b,h[14]=C,h[3]=0,h[7]=0,h[11]=0,h[15]=1,this}equals(e){const i=this.elements,s=e.elements;for(let l=0;l<16;l++)if(i[l]!==s[l])return!1;return!0}fromArray(e,i=0){for(let s=0;s<16;s++)this.elements[s]=e[s+i];return this}toArray(e=[],i=0){const s=this.elements;return e[i]=s[0],e[i+1]=s[1],e[i+2]=s[2],e[i+3]=s[3],e[i+4]=s[4],e[i+5]=s[5],e[i+6]=s[6],e[i+7]=s[7],e[i+8]=s[8],e[i+9]=s[9],e[i+10]=s[10],e[i+11]=s[11],e[i+12]=s[12],e[i+13]=s[13],e[i+14]=s[14],e[i+15]=s[15],e}};_u.prototype.isMatrix4=!0;let Mn=_u;const Bs=new ce,Oi=new Mn,Bb=new ce(0,0,0),Fb=new ce(1,1,1),pr=new ce,Uc=new ce,ui=new ce,jv=new Mn,Jv=new ro;class es{constructor(e=0,i=0,s=0,l=es.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=i,this._z=s,this._order=l}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,i,s,l=this._order){return this._x=e,this._y=i,this._z=s,this._order=l,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,i=this._order,s=!0){const l=e.elements,c=l[0],f=l[4],p=l[8],m=l[1],h=l[5],_=l[9],g=l[2],v=l[6],M=l[10];switch(i){case"XYZ":this._y=Math.asin(At(p,-1,1)),Math.abs(p)<.9999999?(this._x=Math.atan2(-_,M),this._z=Math.atan2(-f,c)):(this._x=Math.atan2(v,h),this._z=0);break;case"YXZ":this._x=Math.asin(-At(_,-1,1)),Math.abs(_)<.9999999?(this._y=Math.atan2(p,M),this._z=Math.atan2(m,h)):(this._y=Math.atan2(-g,c),this._z=0);break;case"ZXY":this._x=Math.asin(At(v,-1,1)),Math.abs(v)<.9999999?(this._y=Math.atan2(-g,M),this._z=Math.atan2(-f,h)):(this._y=0,this._z=Math.atan2(m,c));break;case"ZYX":this._y=Math.asin(-At(g,-1,1)),Math.abs(g)<.9999999?(this._x=Math.atan2(v,M),this._z=Math.atan2(m,c)):(this._x=0,this._z=Math.atan2(-f,h));break;case"YZX":this._z=Math.asin(At(m,-1,1)),Math.abs(m)<.9999999?(this._x=Math.atan2(-_,h),this._y=Math.atan2(-g,c)):(this._x=0,this._y=Math.atan2(p,M));break;case"XZY":this._z=Math.asin(-At(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(v,h),this._y=Math.atan2(p,c)):(this._x=Math.atan2(-_,M),this._y=0);break;default:rt("Euler: .setFromRotationMatrix() encountered an unknown order: "+i)}return this._order=i,s===!0&&this._onChangeCallback(),this}setFromQuaternion(e,i,s){return jv.makeRotationFromQuaternion(e),this.setFromRotationMatrix(jv,i,s)}setFromVector3(e,i=this._order){return this.set(e.x,e.y,e.z,i)}reorder(e){return Jv.setFromEuler(this),this.setFromQuaternion(Jv,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],i=0){return e[i]=this._x,e[i+1]=this._y,e[i+2]=this._z,e[i+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}es.DEFAULT_ORDER="XYZ";class Ax{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let zb=0;const $v=new ce,Fs=new ro,Aa=new Mn,Nc=new ce,$o=new ce,Hb=new ce,Gb=new ro,e_=new ce(1,0,0),t_=new ce(0,1,0),n_=new ce(0,0,1),i_={type:"added"},Vb={type:"removed"},zs={type:"childadded",child:null},Kd={type:"childremoved",child:null};class hi extends ts{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:zb++}),this.uuid=pl(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=hi.DEFAULT_UP.clone();const e=new ce,i=new es,s=new ro,l=new ce(1,1,1);function c(){s.setFromEuler(i,!1)}function f(){i.setFromQuaternion(s,void 0,!1)}i._onChange(c),s._onChange(f),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:i},quaternion:{configurable:!0,enumerable:!0,value:s},scale:{configurable:!0,enumerable:!0,value:l},modelViewMatrix:{value:new Mn},normalMatrix:{value:new ot}}),this.matrix=new Mn,this.matrixWorld=new Mn,this.matrixAutoUpdate=hi.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=hi.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Ax,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,i){this.quaternion.setFromAxisAngle(e,i)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,i){return Fs.setFromAxisAngle(e,i),this.quaternion.multiply(Fs),this}rotateOnWorldAxis(e,i){return Fs.setFromAxisAngle(e,i),this.quaternion.premultiply(Fs),this}rotateX(e){return this.rotateOnAxis(e_,e)}rotateY(e){return this.rotateOnAxis(t_,e)}rotateZ(e){return this.rotateOnAxis(n_,e)}translateOnAxis(e,i){return $v.copy(e).applyQuaternion(this.quaternion),this.position.add($v.multiplyScalar(i)),this}translateX(e){return this.translateOnAxis(e_,e)}translateY(e){return this.translateOnAxis(t_,e)}translateZ(e){return this.translateOnAxis(n_,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Aa.copy(this.matrixWorld).invert())}lookAt(e,i,s){e.isVector3?Nc.copy(e):Nc.set(e,i,s);const l=this.parent;this.updateWorldMatrix(!0,!1),$o.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Aa.lookAt($o,Nc,this.up):Aa.lookAt(Nc,$o,this.up),this.quaternion.setFromRotationMatrix(Aa),l&&(Aa.extractRotation(l.matrixWorld),Fs.setFromRotationMatrix(Aa),this.quaternion.premultiply(Fs.invert()))}add(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.add(arguments[i]);return this}return e===this?(wt("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(i_),zs.child=e,this.dispatchEvent(zs),zs.child=null):wt("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let s=0;s<arguments.length;s++)this.remove(arguments[s]);return this}const i=this.children.indexOf(e);return i!==-1&&(e.parent=null,this.children.splice(i,1),e.dispatchEvent(Vb),Kd.child=e,this.dispatchEvent(Kd),Kd.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Aa.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Aa.multiply(e.parent.matrixWorld)),e.applyMatrix4(Aa),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(i_),zs.child=e,this.dispatchEvent(zs),zs.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,i){if(this[e]===i)return this;for(let s=0,l=this.children.length;s<l;s++){const f=this.children[s].getObjectByProperty(e,i);if(f!==void 0)return f}}getObjectsByProperty(e,i,s=[]){this[e]===i&&s.push(this);const l=this.children;for(let c=0,f=l.length;c<f;c++)l[c].getObjectsByProperty(e,i,s);return s}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose($o,e,Hb),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose($o,Gb,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const i=this.matrixWorld.elements;return e.set(i[8],i[9],i[10]).normalize()}raycast(){}traverse(e){e(this);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].traverseVisible(e)}traverseAncestors(e){const i=this.parent;i!==null&&(e(i),i.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const i=e.x,s=e.y,l=e.z,c=this.matrix.elements;c[12]+=i-c[0]*i-c[4]*s-c[8]*l,c[13]+=s-c[1]*i-c[5]*s-c[9]*l,c[14]+=l-c[2]*i-c[6]*s-c[10]*l}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].updateMatrixWorld(e)}updateWorldMatrix(e,i,s=!1){const l=this.parent;if(e===!0&&l!==null&&l.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||s)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,s=!0),i===!0){const c=this.children;for(let f=0,p=c.length;f<p;f++)c[f].updateWorldMatrix(!1,!0,s)}}toJSON(e){const i=e===void 0||typeof e=="string",s={};i&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},s.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const l={};l.uuid=this.uuid,l.type=this.type,this.name!==""&&(l.name=this.name),this.castShadow===!0&&(l.castShadow=!0),this.receiveShadow===!0&&(l.receiveShadow=!0),this.visible===!1&&(l.visible=!1),this.frustumCulled===!1&&(l.frustumCulled=!1),this.renderOrder!==0&&(l.renderOrder=this.renderOrder),this.static!==!1&&(l.static=this.static),Object.keys(this.userData).length>0&&(l.userData=this.userData),l.layers=this.layers.mask,l.matrix=this.matrix.toArray(),l.up=this.up.toArray(),this.pivot!==null&&(l.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(l.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(l.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(l.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(l.type="InstancedMesh",l.count=this.count,l.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(l.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(l.type="BatchedMesh",l.perObjectFrustumCulled=this.perObjectFrustumCulled,l.sortObjects=this.sortObjects,l.drawRanges=this._drawRanges,l.reservedRanges=this._reservedRanges,l.geometryInfo=this._geometryInfo.map(p=>({...p,boundingBox:p.boundingBox?p.boundingBox.toJSON():void 0,boundingSphere:p.boundingSphere?p.boundingSphere.toJSON():void 0})),l.instanceInfo=this._instanceInfo.map(p=>({...p})),l.availableInstanceIds=this._availableInstanceIds.slice(),l.availableGeometryIds=this._availableGeometryIds.slice(),l.nextIndexStart=this._nextIndexStart,l.nextVertexStart=this._nextVertexStart,l.geometryCount=this._geometryCount,l.maxInstanceCount=this._maxInstanceCount,l.maxVertexCount=this._maxVertexCount,l.maxIndexCount=this._maxIndexCount,l.geometryInitialized=this._geometryInitialized,l.matricesTexture=this._matricesTexture.toJSON(e),l.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(l.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(l.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(l.boundingBox=this.boundingBox.toJSON()));function c(p,m){return p[m.uuid]===void 0&&(p[m.uuid]=m.toJSON(e)),m.uuid}if(this.isScene)this.background&&(this.background.isColor?l.background=this.background.toJSON():this.background.isTexture&&(l.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(l.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){l.geometry=c(e.geometries,this.geometry);const p=this.geometry.parameters;if(p!==void 0&&p.shapes!==void 0){const m=p.shapes;if(Array.isArray(m))for(let h=0,_=m.length;h<_;h++){const g=m[h];c(e.shapes,g)}else c(e.shapes,m)}}if(this.isSkinnedMesh&&(l.bindMode=this.bindMode,l.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(c(e.skeletons,this.skeleton),l.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const p=[];for(let m=0,h=this.material.length;m<h;m++)p.push(c(e.materials,this.material[m]));l.material=p}else l.material=c(e.materials,this.material);if(this.children.length>0){l.children=[];for(let p=0;p<this.children.length;p++)l.children.push(this.children[p].toJSON(e).object)}if(this.animations.length>0){l.animations=[];for(let p=0;p<this.animations.length;p++){const m=this.animations[p];l.animations.push(c(e.animations,m))}}if(i){const p=f(e.geometries),m=f(e.materials),h=f(e.textures),_=f(e.images),g=f(e.shapes),v=f(e.skeletons),M=f(e.animations),b=f(e.nodes);p.length>0&&(s.geometries=p),m.length>0&&(s.materials=m),h.length>0&&(s.textures=h),_.length>0&&(s.images=_),g.length>0&&(s.shapes=g),v.length>0&&(s.skeletons=v),M.length>0&&(s.animations=M),b.length>0&&(s.nodes=b)}return s.object=l,s;function f(p){const m=[];for(const h in p){const _=p[h];delete _.metadata,m.push(_)}return m}}clone(e){return new this.constructor().copy(this,e)}copy(e,i=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),i===!0)for(let s=0;s<e.children.length;s++){const l=e.children[s];this.add(l.clone())}return this}}hi.DEFAULT_UP=new ce(0,1,0);hi.DEFAULT_MATRIX_AUTO_UPDATE=!0;hi.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class Lc extends hi{constructor(){super(),this.isGroup=!0,this.type="Group"}}const kb={type:"move"};class Qd{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Lc,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Lc,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new ce,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new ce),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Lc,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new ce,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new ce,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const i=this._hand;if(i)for(const s of e.hand.values())this._getHandJoint(i,s)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,i,s){let l=null,c=null,f=null;const p=this._targetRay,m=this._grip,h=this._hand;if(e&&i.session.visibilityState!=="visible-blurred"){if(h&&e.hand){f=!0;for(const C of e.hand.values()){const y=i.getJointPose(C,s),x=this._getHandJoint(h,C);y!==null&&(x.matrix.fromArray(y.transform.matrix),x.matrix.decompose(x.position,x.rotation,x.scale),x.matrixWorldNeedsUpdate=!0,x.jointRadius=y.radius),x.visible=y!==null}const _=h.joints["index-finger-tip"],g=h.joints["thumb-tip"],v=_.position.distanceTo(g.position),M=.02,b=.005;h.inputState.pinching&&v>M+b?(h.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!h.inputState.pinching&&v<=M-b&&(h.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else m!==null&&e.gripSpace&&(c=i.getPose(e.gripSpace,s),c!==null&&(m.matrix.fromArray(c.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,c.linearVelocity?(m.hasLinearVelocity=!0,m.linearVelocity.copy(c.linearVelocity)):m.hasLinearVelocity=!1,c.angularVelocity?(m.hasAngularVelocity=!0,m.angularVelocity.copy(c.angularVelocity)):m.hasAngularVelocity=!1,m.eventsEnabled&&m.dispatchEvent({type:"gripUpdated",data:e,target:this})));p!==null&&(l=i.getPose(e.targetRaySpace,s),l===null&&c!==null&&(l=c),l!==null&&(p.matrix.fromArray(l.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,l.linearVelocity?(p.hasLinearVelocity=!0,p.linearVelocity.copy(l.linearVelocity)):p.hasLinearVelocity=!1,l.angularVelocity?(p.hasAngularVelocity=!0,p.angularVelocity.copy(l.angularVelocity)):p.hasAngularVelocity=!1,this.dispatchEvent(kb)))}return p!==null&&(p.visible=l!==null),m!==null&&(m.visible=c!==null),h!==null&&(h.visible=f!==null),this}_getHandJoint(e,i){if(e.joints[i.jointName]===void 0){const s=new Lc;s.matrixAutoUpdate=!1,s.visible=!1,e.joints[i.jointName]=s,e.add(s)}return e.joints[i.jointName]}}const Rx={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},mr={h:0,s:0,l:0},Oc={h:0,s:0,l:0};function jd(a,e,i){return i<0&&(i+=1),i>1&&(i-=1),i<1/6?a+(e-a)*6*i:i<1/2?e:i<2/3?a+(e-a)*6*(2/3-i):a}class zt{constructor(e,i,s){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,i,s)}set(e,i,s){if(i===void 0&&s===void 0){const l=e;l&&l.isColor?this.copy(l):typeof l=="number"?this.setHex(l):typeof l=="string"&&this.setStyle(l)}else this.setRGB(e,i,s);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,i=Ti){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Tt.colorSpaceToWorking(this,i),this}setRGB(e,i,s,l=Tt.workingColorSpace){return this.r=e,this.g=i,this.b=s,Tt.colorSpaceToWorking(this,l),this}setHSL(e,i,s,l=Tt.workingColorSpace){if(e=Db(e,1),i=At(i,0,1),s=At(s,0,1),i===0)this.r=this.g=this.b=s;else{const c=s<=.5?s*(1+i):s+i-s*i,f=2*s-c;this.r=jd(f,c,e+1/3),this.g=jd(f,c,e),this.b=jd(f,c,e-1/3)}return Tt.colorSpaceToWorking(this,l),this}setStyle(e,i=Ti){function s(c){c!==void 0&&parseFloat(c)<1&&rt("Color: Alpha component of "+e+" will be ignored.")}let l;if(l=/^(\w+)\(([^\)]*)\)/.exec(e)){let c;const f=l[1],p=l[2];switch(f){case"rgb":case"rgba":if(c=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(p))return s(c[4]),this.setRGB(Math.min(255,parseInt(c[1],10))/255,Math.min(255,parseInt(c[2],10))/255,Math.min(255,parseInt(c[3],10))/255,i);if(c=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(p))return s(c[4]),this.setRGB(Math.min(100,parseInt(c[1],10))/100,Math.min(100,parseInt(c[2],10))/100,Math.min(100,parseInt(c[3],10))/100,i);break;case"hsl":case"hsla":if(c=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(p))return s(c[4]),this.setHSL(parseFloat(c[1])/360,parseFloat(c[2])/100,parseFloat(c[3])/100,i);break;default:rt("Color: Unknown color model "+e)}}else if(l=/^\#([A-Fa-f\d]+)$/.exec(e)){const c=l[1],f=c.length;if(f===3)return this.setRGB(parseInt(c.charAt(0),16)/15,parseInt(c.charAt(1),16)/15,parseInt(c.charAt(2),16)/15,i);if(f===6)return this.setHex(parseInt(c,16),i);rt("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,i);return this}setColorName(e,i=Ti){const s=Rx[e.toLowerCase()];return s!==void 0?this.setHex(s,i):rt("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Oa(e.r),this.g=Oa(e.g),this.b=Oa(e.b),this}copyLinearToSRGB(e){return this.r=js(e.r),this.g=js(e.g),this.b=js(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Ti){return Tt.workingToColorSpace(zn.copy(this),e),Math.round(At(zn.r*255,0,255))*65536+Math.round(At(zn.g*255,0,255))*256+Math.round(At(zn.b*255,0,255))}getHexString(e=Ti){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,i=Tt.workingColorSpace){Tt.workingToColorSpace(zn.copy(this),i);const s=zn.r,l=zn.g,c=zn.b,f=Math.max(s,l,c),p=Math.min(s,l,c);let m,h;const _=(p+f)/2;if(p===f)m=0,h=0;else{const g=f-p;switch(h=_<=.5?g/(f+p):g/(2-f-p),f){case s:m=(l-c)/g+(l<c?6:0);break;case l:m=(c-s)/g+2;break;case c:m=(s-l)/g+4;break}m/=6}return e.h=m,e.s=h,e.l=_,e}getRGB(e,i=Tt.workingColorSpace){return Tt.workingToColorSpace(zn.copy(this),i),e.r=zn.r,e.g=zn.g,e.b=zn.b,e}getStyle(e=Ti){Tt.workingToColorSpace(zn.copy(this),e);const i=zn.r,s=zn.g,l=zn.b;return e!==Ti?`color(${e} ${i.toFixed(3)} ${s.toFixed(3)} ${l.toFixed(3)})`:`rgb(${Math.round(i*255)},${Math.round(s*255)},${Math.round(l*255)})`}offsetHSL(e,i,s){return this.getHSL(mr),this.setHSL(mr.h+e,mr.s+i,mr.l+s)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,i){return this.r=e.r+i.r,this.g=e.g+i.g,this.b=e.b+i.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,i){return this.r+=(e.r-this.r)*i,this.g+=(e.g-this.g)*i,this.b+=(e.b-this.b)*i,this}lerpColors(e,i,s){return this.r=e.r+(i.r-e.r)*s,this.g=e.g+(i.g-e.g)*s,this.b=e.b+(i.b-e.b)*s,this}lerpHSL(e,i){this.getHSL(mr),e.getHSL(Oc);const s=Xd(mr.h,Oc.h,i),l=Xd(mr.s,Oc.s,i),c=Xd(mr.l,Oc.l,i);return this.setHSL(s,l,c),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const i=this.r,s=this.g,l=this.b,c=e.elements;return this.r=c[0]*i+c[3]*s+c[6]*l,this.g=c[1]*i+c[4]*s+c[7]*l,this.b=c[2]*i+c[5]*s+c[8]*l,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,i=0){return this.r=e[i],this.g=e[i+1],this.b=e[i+2],this}toArray(e=[],i=0){return e[i]=this.r,e[i+1]=this.g,e[i+2]=this.b,e}fromBufferAttribute(e,i){return this.r=e.getX(i),this.g=e.getY(i),this.b=e.getZ(i),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const zn=new zt;zt.NAMES=Rx;class Xb extends hi{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new es,this.environmentIntensity=1,this.environmentRotation=new es,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,i){return super.copy(e,i),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const i=super.toJSON(e);return this.fog!==null&&(i.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(i.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(i.object.backgroundIntensity=this.backgroundIntensity),i.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(i.object.environmentIntensity=this.environmentIntensity),i.object.environmentRotation=this.environmentRotation.toArray(),i}}const Pi=new ce,Ra=new ce,Jd=new ce,Ca=new ce,Hs=new ce,Gs=new ce,a_=new ce,$d=new ce,eh=new ce,th=new ce,nh=new dn,ih=new dn,ah=new dn;class Fi{constructor(e=new ce,i=new ce,s=new ce){this.a=e,this.b=i,this.c=s}static getNormal(e,i,s,l){l.subVectors(s,i),Pi.subVectors(e,i),l.cross(Pi);const c=l.lengthSq();return c>0?l.multiplyScalar(1/Math.sqrt(c)):l.set(0,0,0)}static getBarycoord(e,i,s,l,c){Pi.subVectors(l,i),Ra.subVectors(s,i),Jd.subVectors(e,i);const f=Pi.dot(Pi),p=Pi.dot(Ra),m=Pi.dot(Jd),h=Ra.dot(Ra),_=Ra.dot(Jd),g=f*h-p*p;if(g===0)return c.set(0,0,0),null;const v=1/g,M=(h*m-p*_)*v,b=(f*_-p*m)*v;return c.set(1-M-b,b,M)}static containsPoint(e,i,s,l){return this.getBarycoord(e,i,s,l,Ca)===null?!1:Ca.x>=0&&Ca.y>=0&&Ca.x+Ca.y<=1}static getInterpolation(e,i,s,l,c,f,p,m){return this.getBarycoord(e,i,s,l,Ca)===null?(m.x=0,m.y=0,"z"in m&&(m.z=0),"w"in m&&(m.w=0),null):(m.setScalar(0),m.addScaledVector(c,Ca.x),m.addScaledVector(f,Ca.y),m.addScaledVector(p,Ca.z),m)}static getInterpolatedAttribute(e,i,s,l,c,f){return nh.setScalar(0),ih.setScalar(0),ah.setScalar(0),nh.fromBufferAttribute(e,i),ih.fromBufferAttribute(e,s),ah.fromBufferAttribute(e,l),f.setScalar(0),f.addScaledVector(nh,c.x),f.addScaledVector(ih,c.y),f.addScaledVector(ah,c.z),f}static isFrontFacing(e,i,s,l){return Pi.subVectors(s,i),Ra.subVectors(e,i),Pi.cross(Ra).dot(l)<0}set(e,i,s){return this.a.copy(e),this.b.copy(i),this.c.copy(s),this}setFromPointsAndIndices(e,i,s,l){return this.a.copy(e[i]),this.b.copy(e[s]),this.c.copy(e[l]),this}setFromAttributeAndIndices(e,i,s,l){return this.a.fromBufferAttribute(e,i),this.b.fromBufferAttribute(e,s),this.c.fromBufferAttribute(e,l),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Pi.subVectors(this.c,this.b),Ra.subVectors(this.a,this.b),Pi.cross(Ra).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Fi.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,i){return Fi.getBarycoord(e,this.a,this.b,this.c,i)}getInterpolation(e,i,s,l,c){return Fi.getInterpolation(e,this.a,this.b,this.c,i,s,l,c)}containsPoint(e){return Fi.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Fi.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,i){const s=this.a,l=this.b,c=this.c;let f,p;Hs.subVectors(l,s),Gs.subVectors(c,s),$d.subVectors(e,s);const m=Hs.dot($d),h=Gs.dot($d);if(m<=0&&h<=0)return i.copy(s);eh.subVectors(e,l);const _=Hs.dot(eh),g=Gs.dot(eh);if(_>=0&&g<=_)return i.copy(l);const v=m*g-_*h;if(v<=0&&m>=0&&_<=0)return f=m/(m-_),i.copy(s).addScaledVector(Hs,f);th.subVectors(e,c);const M=Hs.dot(th),b=Gs.dot(th);if(b>=0&&M<=b)return i.copy(c);const C=M*h-m*b;if(C<=0&&h>=0&&b<=0)return p=h/(h-b),i.copy(s).addScaledVector(Gs,p);const y=_*b-M*g;if(y<=0&&g-_>=0&&M-b>=0)return a_.subVectors(c,l),p=(g-_)/(g-_+(M-b)),i.copy(l).addScaledVector(a_,p);const x=1/(y+C+v);return f=C*x,p=v*x,i.copy(s).addScaledVector(Hs,f).addScaledVector(Gs,p)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class ml{constructor(e=new ce(1/0,1/0,1/0),i=new ce(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=i}set(e,i){return this.min.copy(e),this.max.copy(i),this}setFromArray(e){this.makeEmpty();for(let i=0,s=e.length;i<s;i+=3)this.expandByPoint(Ii.fromArray(e,i));return this}setFromBufferAttribute(e){this.makeEmpty();for(let i=0,s=e.count;i<s;i++)this.expandByPoint(Ii.fromBufferAttribute(e,i));return this}setFromPoints(e){this.makeEmpty();for(let i=0,s=e.length;i<s;i++)this.expandByPoint(e[i]);return this}setFromCenterAndSize(e,i){const s=Ii.copy(i).multiplyScalar(.5);return this.min.copy(e).sub(s),this.max.copy(e).add(s),this}setFromObject(e,i=!1){return this.makeEmpty(),this.expandByObject(e,i)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,i=!1){e.updateWorldMatrix(!1,!1);const s=e.geometry;if(s!==void 0){const c=s.getAttribute("position");if(i===!0&&c!==void 0&&e.isInstancedMesh!==!0)for(let f=0,p=c.count;f<p;f++)e.isMesh===!0?e.getVertexPosition(f,Ii):Ii.fromBufferAttribute(c,f),Ii.applyMatrix4(e.matrixWorld),this.expandByPoint(Ii);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Pc.copy(e.boundingBox)):(s.boundingBox===null&&s.computeBoundingBox(),Pc.copy(s.boundingBox)),Pc.applyMatrix4(e.matrixWorld),this.union(Pc)}const l=e.children;for(let c=0,f=l.length;c<f;c++)this.expandByObject(l[c],i);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,i){return i.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Ii),Ii.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let i,s;return e.normal.x>0?(i=e.normal.x*this.min.x,s=e.normal.x*this.max.x):(i=e.normal.x*this.max.x,s=e.normal.x*this.min.x),e.normal.y>0?(i+=e.normal.y*this.min.y,s+=e.normal.y*this.max.y):(i+=e.normal.y*this.max.y,s+=e.normal.y*this.min.y),e.normal.z>0?(i+=e.normal.z*this.min.z,s+=e.normal.z*this.max.z):(i+=e.normal.z*this.max.z,s+=e.normal.z*this.min.z),i<=-e.constant&&s>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(el),Ic.subVectors(this.max,el),Vs.subVectors(e.a,el),ks.subVectors(e.b,el),Xs.subVectors(e.c,el),gr.subVectors(ks,Vs),vr.subVectors(Xs,ks),kr.subVectors(Vs,Xs);let i=[0,-gr.z,gr.y,0,-vr.z,vr.y,0,-kr.z,kr.y,gr.z,0,-gr.x,vr.z,0,-vr.x,kr.z,0,-kr.x,-gr.y,gr.x,0,-vr.y,vr.x,0,-kr.y,kr.x,0];return!rh(i,Vs,ks,Xs,Ic)||(i=[1,0,0,0,1,0,0,0,1],!rh(i,Vs,ks,Xs,Ic))?!1:(Bc.crossVectors(gr,vr),i=[Bc.x,Bc.y,Bc.z],rh(i,Vs,ks,Xs,Ic))}clampPoint(e,i){return i.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Ii).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Ii).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(wa[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),wa[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),wa[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),wa[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),wa[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),wa[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),wa[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),wa[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(wa),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const wa=[new ce,new ce,new ce,new ce,new ce,new ce,new ce,new ce],Ii=new ce,Pc=new ml,Vs=new ce,ks=new ce,Xs=new ce,gr=new ce,vr=new ce,kr=new ce,el=new ce,Ic=new ce,Bc=new ce,Xr=new ce;function rh(a,e,i,s,l){for(let c=0,f=a.length-3;c<=f;c+=3){Xr.fromArray(a,c);const p=l.x*Math.abs(Xr.x)+l.y*Math.abs(Xr.y)+l.z*Math.abs(Xr.z),m=e.dot(Xr),h=i.dot(Xr),_=s.dot(Xr);if(Math.max(-Math.max(m,h,_),Math.min(m,h,_))>p)return!1}return!0}const yn=new ce,Fc=new Pt;let Wb=0;class ia extends ts{constructor(e,i,s=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Wb++}),this.name="",this.array=e,this.itemSize=i,this.count=e!==void 0?e.length/i:0,this.normalized=s,this.usage=Xv,this.updateRanges=[],this.gpuType=$i,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,i){this.updateRanges.push({start:e,count:i})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,i,s){e*=this.itemSize,s*=i.itemSize;for(let l=0,c=this.itemSize;l<c;l++)this.array[e+l]=i.array[s+l];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let i=0,s=this.count;i<s;i++)Fc.fromBufferAttribute(this,i),Fc.applyMatrix3(e),this.setXY(i,Fc.x,Fc.y);else if(this.itemSize===3)for(let i=0,s=this.count;i<s;i++)yn.fromBufferAttribute(this,i),yn.applyMatrix3(e),this.setXYZ(i,yn.x,yn.y,yn.z);return this}applyMatrix4(e){for(let i=0,s=this.count;i<s;i++)yn.fromBufferAttribute(this,i),yn.applyMatrix4(e),this.setXYZ(i,yn.x,yn.y,yn.z);return this}applyNormalMatrix(e){for(let i=0,s=this.count;i<s;i++)yn.fromBufferAttribute(this,i),yn.applyNormalMatrix(e),this.setXYZ(i,yn.x,yn.y,yn.z);return this}transformDirection(e){for(let i=0,s=this.count;i<s;i++)yn.fromBufferAttribute(this,i),yn.transformDirection(e),this.setXYZ(i,yn.x,yn.y,yn.z);return this}set(e,i=0){return this.array.set(e,i),this}getComponent(e,i){let s=this.array[e*this.itemSize+i];return this.normalized&&(s=Jo(s,this.array)),s}setComponent(e,i,s){return this.normalized&&(s=jn(s,this.array)),this.array[e*this.itemSize+i]=s,this}getX(e){let i=this.array[e*this.itemSize];return this.normalized&&(i=Jo(i,this.array)),i}setX(e,i){return this.normalized&&(i=jn(i,this.array)),this.array[e*this.itemSize]=i,this}getY(e){let i=this.array[e*this.itemSize+1];return this.normalized&&(i=Jo(i,this.array)),i}setY(e,i){return this.normalized&&(i=jn(i,this.array)),this.array[e*this.itemSize+1]=i,this}getZ(e){let i=this.array[e*this.itemSize+2];return this.normalized&&(i=Jo(i,this.array)),i}setZ(e,i){return this.normalized&&(i=jn(i,this.array)),this.array[e*this.itemSize+2]=i,this}getW(e){let i=this.array[e*this.itemSize+3];return this.normalized&&(i=Jo(i,this.array)),i}setW(e,i){return this.normalized&&(i=jn(i,this.array)),this.array[e*this.itemSize+3]=i,this}setXY(e,i,s){return e*=this.itemSize,this.normalized&&(i=jn(i,this.array),s=jn(s,this.array)),this.array[e+0]=i,this.array[e+1]=s,this}setXYZ(e,i,s,l){return e*=this.itemSize,this.normalized&&(i=jn(i,this.array),s=jn(s,this.array),l=jn(l,this.array)),this.array[e+0]=i,this.array[e+1]=s,this.array[e+2]=l,this}setXYZW(e,i,s,l,c){return e*=this.itemSize,this.normalized&&(i=jn(i,this.array),s=jn(s,this.array),l=jn(l,this.array),c=jn(c,this.array)),this.array[e+0]=i,this.array[e+1]=s,this.array[e+2]=l,this.array[e+3]=c,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Xv&&(e.usage=this.usage),e}dispose(){this.dispatchEvent({type:"dispose"})}}class Cx extends ia{constructor(e,i,s){super(new Uint16Array(e),i,s)}}class wx extends ia{constructor(e,i,s){super(new Uint32Array(e),i,s)}}class Pa extends ia{constructor(e,i,s){super(new Float32Array(e),i,s)}}const qb=new ml,tl=new ce,sh=new ce;class Np{constructor(e=new ce,i=-1){this.isSphere=!0,this.center=e,this.radius=i}set(e,i){return this.center.copy(e),this.radius=i,this}setFromPoints(e,i){const s=this.center;i!==void 0?s.copy(i):qb.setFromPoints(e).getCenter(s);let l=0;for(let c=0,f=e.length;c<f;c++)l=Math.max(l,s.distanceToSquared(e[c]));return this.radius=Math.sqrt(l),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const i=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=i*i}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,i){const s=this.center.distanceToSquared(e);return i.copy(e),s>this.radius*this.radius&&(i.sub(this.center).normalize(),i.multiplyScalar(this.radius).add(this.center)),i}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;tl.subVectors(e,this.center);const i=tl.lengthSq();if(i>this.radius*this.radius){const s=Math.sqrt(i),l=(s-this.radius)*.5;this.center.addScaledVector(tl,l/s),this.radius+=l}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(sh.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(tl.copy(e.center).add(sh)),this.expandByPoint(tl.copy(e.center).sub(sh))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let Yb=0;const bi=new Mn,oh=new hi,Ws=new ce,fi=new ml,nl=new ml,wn=new ce;class za extends ts{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Yb++}),this.uuid=pl(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Ab(e)?wx:Cx)(e,1):this.index=e,this}setIndirect(e,i=0){return this.indirect=e,this.indirectOffset=i,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,i){return this.attributes[e]=i,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,i,s=0){this.groups.push({start:e,count:i,materialIndex:s})}clearGroups(){this.groups=[]}setDrawRange(e,i){this.drawRange.start=e,this.drawRange.count=i}applyMatrix4(e){const i=this.attributes.position;i!==void 0&&(i.applyMatrix4(e),i.needsUpdate=!0);const s=this.attributes.normal;if(s!==void 0){const c=new ot().getNormalMatrix(e);s.applyNormalMatrix(c),s.needsUpdate=!0}const l=this.attributes.tangent;return l!==void 0&&(l.transformDirection(e),l.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return bi.makeRotationFromQuaternion(e),this.applyMatrix4(bi),this}rotateX(e){return bi.makeRotationX(e),this.applyMatrix4(bi),this}rotateY(e){return bi.makeRotationY(e),this.applyMatrix4(bi),this}rotateZ(e){return bi.makeRotationZ(e),this.applyMatrix4(bi),this}translate(e,i,s){return bi.makeTranslation(e,i,s),this.applyMatrix4(bi),this}scale(e,i,s){return bi.makeScale(e,i,s),this.applyMatrix4(bi),this}lookAt(e){return oh.lookAt(e),oh.updateMatrix(),this.applyMatrix4(oh.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Ws).negate(),this.translate(Ws.x,Ws.y,Ws.z),this}setFromPoints(e){const i=this.getAttribute("position");if(i===void 0){const s=[];for(let l=0,c=e.length;l<c;l++){const f=e[l];s.push(f.x,f.y,f.z||0)}this.setAttribute("position",new Pa(s,3))}else{const s=Math.min(e.length,i.count);for(let l=0;l<s;l++){const c=e[l];i.setXYZ(l,c.x,c.y,c.z||0)}e.length>i.count&&rt("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),i.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ml);const e=this.attributes.position,i=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){wt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new ce(-1/0,-1/0,-1/0),new ce(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),i)for(let s=0,l=i.length;s<l;s++){const c=i[s];fi.setFromBufferAttribute(c),this.morphTargetsRelative?(wn.addVectors(this.boundingBox.min,fi.min),this.boundingBox.expandByPoint(wn),wn.addVectors(this.boundingBox.max,fi.max),this.boundingBox.expandByPoint(wn)):(this.boundingBox.expandByPoint(fi.min),this.boundingBox.expandByPoint(fi.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&wt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Np);const e=this.attributes.position,i=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){wt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new ce,1/0);return}if(e){const s=this.boundingSphere.center;if(fi.setFromBufferAttribute(e),i)for(let c=0,f=i.length;c<f;c++){const p=i[c];nl.setFromBufferAttribute(p),this.morphTargetsRelative?(wn.addVectors(fi.min,nl.min),fi.expandByPoint(wn),wn.addVectors(fi.max,nl.max),fi.expandByPoint(wn)):(fi.expandByPoint(nl.min),fi.expandByPoint(nl.max))}fi.getCenter(s);let l=0;for(let c=0,f=e.count;c<f;c++)wn.fromBufferAttribute(e,c),l=Math.max(l,s.distanceToSquared(wn));if(i)for(let c=0,f=i.length;c<f;c++){const p=i[c],m=this.morphTargetsRelative;for(let h=0,_=p.count;h<_;h++)wn.fromBufferAttribute(p,h),m&&(Ws.fromBufferAttribute(e,h),wn.add(Ws)),l=Math.max(l,s.distanceToSquared(wn))}this.boundingSphere.radius=Math.sqrt(l),isNaN(this.boundingSphere.radius)&&wt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,i=this.attributes;if(e===null||i.position===void 0||i.normal===void 0||i.uv===void 0){wt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const s=i.position,l=i.normal,c=i.uv;let f=this.getAttribute("tangent");(f===void 0||f.count!==s.count)&&(f=new ia(new Float32Array(4*s.count),4),this.setAttribute("tangent",f));const p=[],m=[];for(let T=0;T<s.count;T++)p[T]=new ce,m[T]=new ce;const h=new ce,_=new ce,g=new ce,v=new Pt,M=new Pt,b=new Pt,C=new ce,y=new ce;function x(T,P,q){h.fromBufferAttribute(s,T),_.fromBufferAttribute(s,P),g.fromBufferAttribute(s,q),v.fromBufferAttribute(c,T),M.fromBufferAttribute(c,P),b.fromBufferAttribute(c,q),_.sub(h),g.sub(h),M.sub(v),b.sub(v);const V=1/(M.x*b.y-b.x*M.y);isFinite(V)&&(C.copy(_).multiplyScalar(b.y).addScaledVector(g,-M.y).multiplyScalar(V),y.copy(g).multiplyScalar(M.x).addScaledVector(_,-b.x).multiplyScalar(V),p[T].add(C),p[P].add(C),p[q].add(C),m[T].add(y),m[P].add(y),m[q].add(y))}let O=this.groups;O.length===0&&(O=[{start:0,count:e.count}]);for(let T=0,P=O.length;T<P;++T){const q=O[T],V=q.start,Q=q.count;for(let fe=V,me=V+Q;fe<me;fe+=3)x(e.getX(fe+0),e.getX(fe+1),e.getX(fe+2))}const I=new ce,w=new ce,B=new ce,U=new ce;function F(T){B.fromBufferAttribute(l,T),U.copy(B);const P=p[T];I.copy(P),I.sub(B.multiplyScalar(B.dot(P))).normalize(),w.crossVectors(U,P);const V=w.dot(m[T])<0?-1:1;f.setXYZW(T,I.x,I.y,I.z,V)}for(let T=0,P=O.length;T<P;++T){const q=O[T],V=q.start,Q=q.count;for(let fe=V,me=V+Q;fe<me;fe+=3)F(e.getX(fe+0)),F(e.getX(fe+1)),F(e.getX(fe+2))}this._transformed=!0}computeVertexNormals(){const e=this.index,i=this.getAttribute("position");if(i!==void 0){let s=this.getAttribute("normal");if(s===void 0||s.count!==i.count)s=new ia(new Float32Array(i.count*3),3),this.setAttribute("normal",s);else for(let v=0,M=s.count;v<M;v++)s.setXYZ(v,0,0,0);const l=new ce,c=new ce,f=new ce,p=new ce,m=new ce,h=new ce,_=new ce,g=new ce;if(e)for(let v=0,M=e.count;v<M;v+=3){const b=e.getX(v+0),C=e.getX(v+1),y=e.getX(v+2);l.fromBufferAttribute(i,b),c.fromBufferAttribute(i,C),f.fromBufferAttribute(i,y),_.subVectors(f,c),g.subVectors(l,c),_.cross(g),p.fromBufferAttribute(s,b),m.fromBufferAttribute(s,C),h.fromBufferAttribute(s,y),p.add(_),m.add(_),h.add(_),s.setXYZ(b,p.x,p.y,p.z),s.setXYZ(C,m.x,m.y,m.z),s.setXYZ(y,h.x,h.y,h.z)}else for(let v=0,M=i.count;v<M;v+=3)l.fromBufferAttribute(i,v+0),c.fromBufferAttribute(i,v+1),f.fromBufferAttribute(i,v+2),_.subVectors(f,c),g.subVectors(l,c),_.cross(g),s.setXYZ(v+0,_.x,_.y,_.z),s.setXYZ(v+1,_.x,_.y,_.z),s.setXYZ(v+2,_.x,_.y,_.z);this.normalizeNormals(),s.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let i=0,s=e.count;i<s;i++)wn.fromBufferAttribute(e,i),wn.normalize(),e.setXYZ(i,wn.x,wn.y,wn.z)}toNonIndexed(){function e(p,m){const h=p.array,_=p.itemSize,g=p.normalized,v=new h.constructor(m.length*_);let M=0,b=0;for(let C=0,y=m.length;C<y;C++){p.isInterleavedBufferAttribute?M=m[C]*p.data.stride+p.offset:M=m[C]*_;for(let x=0;x<_;x++)v[b++]=h[M++]}return new ia(v,_,g)}if(this.index===null)return rt("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const i=new za,s=this.index.array,l=this.attributes;for(const p in l){const m=l[p],h=e(m,s);i.setAttribute(p,h)}const c=this.morphAttributes;for(const p in c){const m=[],h=c[p];for(let _=0,g=h.length;_<g;_++){const v=h[_],M=e(v,s);m.push(M)}i.morphAttributes[p]=m}i.morphTargetsRelative=this.morphTargetsRelative;const f=this.groups;for(let p=0,m=f.length;p<m;p++){const h=f[p];i.addGroup(h.start,h.count,h.materialIndex)}return i}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const m=this.parameters;for(const h in m)m[h]!==void 0&&(e[h]=m[h]);return e}e.data={attributes:{}};const i=this.index;i!==null&&(e.data.index={type:i.array.constructor.name,array:Array.prototype.slice.call(i.array)});const s=this.attributes;for(const m in s){const h=s[m];e.data.attributes[m]=h.toJSON(e.data)}const l={};let c=!1;for(const m in this.morphAttributes){const h=this.morphAttributes[m],_=[];for(let g=0,v=h.length;g<v;g++){const M=h[g];_.push(M.toJSON(e.data))}_.length>0&&(l[m]=_,c=!0)}c&&(e.data.morphAttributes=l,e.data.morphTargetsRelative=this.morphTargetsRelative);const f=this.groups;f.length>0&&(e.data.groups=JSON.parse(JSON.stringify(f)));const p=this.boundingSphere;return p!==null&&(e.data.boundingSphere=p.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const i={};this.name=e.name;const s=e.index;s!==null&&this.setIndex(s.clone());const l=e.attributes;for(const h in l){const _=l[h];this.setAttribute(h,_.clone(i))}const c=e.morphAttributes;for(const h in c){const _=[],g=c[h];for(let v=0,M=g.length;v<M;v++)_.push(g[v].clone(i));this.morphAttributes[h]=_}this.morphTargetsRelative=e.morphTargetsRelative;const f=e.groups;for(let h=0,_=f.length;h<_;h++){const g=f[h];this.addGroup(g.start,g.count,g.materialIndex)}const p=e.boundingBox;p!==null&&(this.boundingBox=p.clone());const m=e.boundingSphere;return m!==null&&(this.boundingSphere=m.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}let Zb=0;class bu extends ts{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Zb++}),this.uuid=pl(),this.name="",this.type="Material",this.blending=Ks,this.side=Mr,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Mh,this.blendDst=Eh,this.blendEquation=Zr,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new zt(0,0,0),this.blendAlpha=0,this.depthFunc=Js,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=kv,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ps,this.stencilZFail=Ps,this.stencilZPass=Ps,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const i in e){const s=e[i];if(s===void 0){rt(`Material: parameter '${i}' has value of undefined.`);continue}const l=this[i];if(l===void 0){rt(`Material: '${i}' is not a property of THREE.${this.type}.`);continue}l&&l.isColor?l.set(s):l&&l.isVector2&&s&&s.isVector2||l&&l.isEuler&&s&&s.isEuler||l&&l.isVector3&&s&&s.isVector3?l.copy(s):this[i]=s}}toJSON(e){const i=e===void 0||typeof e=="string";i&&(e={textures:{},images:{}});const s={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.color&&this.color.isColor&&(s.color=this.color.getHex()),this.roughness!==void 0&&(s.roughness=this.roughness),this.metalness!==void 0&&(s.metalness=this.metalness),this.sheen!==void 0&&(s.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(s.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(s.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(s.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(s.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(s.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(s.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(s.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(s.shininess=this.shininess),this.clearcoat!==void 0&&(s.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(s.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(s.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(s.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(s.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,s.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(s.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(s.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(s.dispersion=this.dispersion),this.iridescence!==void 0&&(s.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(s.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(s.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(s.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(s.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(s.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(s.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(s.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(s.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(s.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(s.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(s.lightMap=this.lightMap.toJSON(e).uuid,s.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(s.aoMap=this.aoMap.toJSON(e).uuid,s.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(s.bumpMap=this.bumpMap.toJSON(e).uuid,s.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(s.normalMap=this.normalMap.toJSON(e).uuid,s.normalMapType=this.normalMapType,s.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(s.displacementMap=this.displacementMap.toJSON(e).uuid,s.displacementScale=this.displacementScale,s.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(s.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(s.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(s.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(s.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(s.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(s.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(s.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(s.combine=this.combine)),this.envMapRotation!==void 0&&(s.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(s.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(s.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(s.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(s.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(s.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(s.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(s.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(s.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(s.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(s.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(s.size=this.size),this.shadowSide!==null&&(s.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(s.sizeAttenuation=this.sizeAttenuation),this.blending!==Ks&&(s.blending=this.blending),this.side!==Mr&&(s.side=this.side),this.vertexColors===!0&&(s.vertexColors=!0),this.opacity<1&&(s.opacity=this.opacity),this.transparent===!0&&(s.transparent=!0),this.blendSrc!==Mh&&(s.blendSrc=this.blendSrc),this.blendDst!==Eh&&(s.blendDst=this.blendDst),this.blendEquation!==Zr&&(s.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(s.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(s.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(s.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(s.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(s.blendAlpha=this.blendAlpha),this.depthFunc!==Js&&(s.depthFunc=this.depthFunc),this.depthTest===!1&&(s.depthTest=this.depthTest),this.depthWrite===!1&&(s.depthWrite=this.depthWrite),this.colorWrite===!1&&(s.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(s.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==kv&&(s.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(s.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(s.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ps&&(s.stencilFail=this.stencilFail),this.stencilZFail!==Ps&&(s.stencilZFail=this.stencilZFail),this.stencilZPass!==Ps&&(s.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(s.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(s.rotation=this.rotation),this.polygonOffset===!0&&(s.polygonOffset=!0),this.polygonOffsetFactor!==0&&(s.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(s.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(s.linewidth=this.linewidth),this.dashSize!==void 0&&(s.dashSize=this.dashSize),this.gapSize!==void 0&&(s.gapSize=this.gapSize),this.scale!==void 0&&(s.scale=this.scale),this.dithering===!0&&(s.dithering=!0),this.alphaTest>0&&(s.alphaTest=this.alphaTest),this.alphaHash===!0&&(s.alphaHash=!0),this.alphaToCoverage===!0&&(s.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(s.premultipliedAlpha=!0),this.forceSinglePass===!0&&(s.forceSinglePass=!0),this.allowOverride===!1&&(s.allowOverride=!1),this.wireframe===!0&&(s.wireframe=!0),this.wireframeLinewidth>1&&(s.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(s.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(s.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(s.flatShading=!0),this.visible===!1&&(s.visible=!1),this.toneMapped===!1&&(s.toneMapped=!1),this.fog===!1&&(s.fog=!1),Object.keys(this.userData).length>0&&(s.userData=this.userData);function l(c){const f=[];for(const p in c){const m=c[p];delete m.metadata,f.push(m)}return f}if(i){const c=l(e.textures),f=l(e.images);c.length>0&&(s.textures=c),f.length>0&&(s.images=f)}return s}fromJSON(e,i){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new zt().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=i[e.map]||null),e.matcap!==void 0&&(this.matcap=i[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=i[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=i[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=i[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let s=e.normalScale;Array.isArray(s)===!1&&(s=[s,s]),this.normalScale=new Pt().fromArray(s)}return e.displacementMap!==void 0&&(this.displacementMap=i[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=i[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=i[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=i[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=i[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=i[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=i[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=i[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=i[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=i[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=i[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=i[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=i[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=i[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new Pt().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=i[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=i[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=i[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=i[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=i[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=i[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=i[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const i=e.clippingPlanes;let s=null;if(i!==null){const l=i.length;s=new Array(l);for(let c=0;c!==l;++c)s[c]=i[c].clone()}return this.clippingPlanes=s,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}const Da=new ce,lh=new ce,zc=new ce,_r=new ce,ch=new ce,Hc=new ce,uh=new ce;class Kb{constructor(e=new ce,i=new ce(0,0,-1)){this.origin=e,this.direction=i}set(e,i){return this.origin.copy(e),this.direction.copy(i),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,i){return i.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Da)),this}closestPointToPoint(e,i){i.subVectors(e,this.origin);const s=i.dot(this.direction);return s<0?i.copy(this.origin):i.copy(this.origin).addScaledVector(this.direction,s)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const i=Da.subVectors(e,this.origin).dot(this.direction);return i<0?this.origin.distanceToSquared(e):(Da.copy(this.origin).addScaledVector(this.direction,i),Da.distanceToSquared(e))}distanceSqToSegment(e,i,s,l){lh.copy(e).add(i).multiplyScalar(.5),zc.copy(i).sub(e).normalize(),_r.copy(this.origin).sub(lh);const c=e.distanceTo(i)*.5,f=-this.direction.dot(zc),p=_r.dot(this.direction),m=-_r.dot(zc),h=_r.lengthSq(),_=Math.abs(1-f*f);let g,v,M,b;if(_>0)if(g=f*m-p,v=f*p-m,b=c*_,g>=0)if(v>=-b)if(v<=b){const C=1/_;g*=C,v*=C,M=g*(g+f*v+2*p)+v*(f*g+v+2*m)+h}else v=c,g=Math.max(0,-(f*v+p)),M=-g*g+v*(v+2*m)+h;else v=-c,g=Math.max(0,-(f*v+p)),M=-g*g+v*(v+2*m)+h;else v<=-b?(g=Math.max(0,-(-f*c+p)),v=g>0?-c:Math.min(Math.max(-c,-m),c),M=-g*g+v*(v+2*m)+h):v<=b?(g=0,v=Math.min(Math.max(-c,-m),c),M=v*(v+2*m)+h):(g=Math.max(0,-(f*c+p)),v=g>0?c:Math.min(Math.max(-c,-m),c),M=-g*g+v*(v+2*m)+h);else v=f>0?-c:c,g=Math.max(0,-(f*v+p)),M=-g*g+v*(v+2*m)+h;return s&&s.copy(this.origin).addScaledVector(this.direction,g),l&&l.copy(lh).addScaledVector(zc,v),M}intersectSphere(e,i){Da.subVectors(e.center,this.origin);const s=Da.dot(this.direction),l=Da.dot(Da)-s*s,c=e.radius*e.radius;if(l>c)return null;const f=Math.sqrt(c-l),p=s-f,m=s+f;return m<0?null:p<0?this.at(m,i):this.at(p,i)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const i=e.normal.dot(this.direction);if(i===0)return e.distanceToPoint(this.origin)===0?0:null;const s=-(this.origin.dot(e.normal)+e.constant)/i;return s>=0?s:null}intersectPlane(e,i){const s=this.distanceToPlane(e);return s===null?null:this.at(s,i)}intersectsPlane(e){const i=e.distanceToPoint(this.origin);return i===0||e.normal.dot(this.direction)*i<0}intersectBox(e,i){let s,l,c,f,p,m;const h=1/this.direction.x,_=1/this.direction.y,g=1/this.direction.z,v=this.origin;return h>=0?(s=(e.min.x-v.x)*h,l=(e.max.x-v.x)*h):(s=(e.max.x-v.x)*h,l=(e.min.x-v.x)*h),_>=0?(c=(e.min.y-v.y)*_,f=(e.max.y-v.y)*_):(c=(e.max.y-v.y)*_,f=(e.min.y-v.y)*_),s>f||c>l||((c>s||isNaN(s))&&(s=c),(f<l||isNaN(l))&&(l=f),g>=0?(p=(e.min.z-v.z)*g,m=(e.max.z-v.z)*g):(p=(e.max.z-v.z)*g,m=(e.min.z-v.z)*g),s>m||p>l)||((p>s||s!==s)&&(s=p),(m<l||l!==l)&&(l=m),l<0)?null:this.at(s>=0?s:l,i)}intersectsBox(e){return this.intersectBox(e,Da)!==null}intersectTriangle(e,i,s,l,c){ch.subVectors(i,e),Hc.subVectors(s,e),uh.crossVectors(ch,Hc);let f=this.direction.dot(uh),p;if(f>0){if(l)return null;p=1}else if(f<0)p=-1,f=-f;else return null;_r.subVectors(this.origin,e);const m=p*this.direction.dot(Hc.crossVectors(_r,Hc));if(m<0)return null;const h=p*this.direction.dot(ch.cross(_r));if(h<0||m+h>f)return null;const _=-p*_r.dot(uh);return _<0?null:this.at(_/f,c)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Dx extends bu{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new zt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new es,this.combine=lx,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const r_=new Mn,Wr=new Kb,Gc=new Np,s_=new ce,Vc=new ce,kc=new ce,Xc=new ce,fh=new ce,Wc=new ce,o_=new ce,qc=new ce;class ra extends hi{constructor(e=new za,i=new Dx){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=i,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,i){return super.copy(e,i),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const i=this.geometry.morphAttributes,s=Object.keys(i);if(s.length>0){const l=i[s[0]];if(l!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,f=l.length;c<f;c++){const p=l[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[p]=c}}}}getVertexPosition(e,i){const s=this.geometry,l=s.attributes.position,c=s.morphAttributes.position,f=s.morphTargetsRelative;i.fromBufferAttribute(l,e);const p=this.morphTargetInfluences;if(c&&p){Wc.set(0,0,0);for(let m=0,h=c.length;m<h;m++){const _=p[m],g=c[m];_!==0&&(fh.fromBufferAttribute(g,e),f?Wc.addScaledVector(fh,_):Wc.addScaledVector(fh.sub(i),_))}i.add(Wc)}return i}raycast(e,i){const s=this.geometry,l=this.material,c=this.matrixWorld;l!==void 0&&(s.boundingSphere===null&&s.computeBoundingSphere(),Gc.copy(s.boundingSphere),Gc.applyMatrix4(c),Wr.copy(e.ray).recast(e.near),!(Gc.containsPoint(Wr.origin)===!1&&(Wr.intersectSphere(Gc,s_)===null||Wr.origin.distanceToSquared(s_)>(e.far-e.near)**2))&&(r_.copy(c).invert(),Wr.copy(e.ray).applyMatrix4(r_),!(s.boundingBox!==null&&Wr.intersectsBox(s.boundingBox)===!1)&&this._computeIntersections(e,i,Wr)))}_computeIntersections(e,i,s){let l;const c=this.geometry,f=this.material,p=c.index,m=c.attributes.position,h=c.attributes.uv,_=c.attributes.uv1,g=c.attributes.normal,v=c.groups,M=c.drawRange;if(p!==null)if(Array.isArray(f))for(let b=0,C=v.length;b<C;b++){const y=v[b],x=f[y.materialIndex],O=Math.max(y.start,M.start),I=Math.min(p.count,Math.min(y.start+y.count,M.start+M.count));for(let w=O,B=I;w<B;w+=3){const U=p.getX(w),F=p.getX(w+1),T=p.getX(w+2);l=Yc(this,x,e,s,h,_,g,U,F,T),l&&(l.faceIndex=Math.floor(w/3),l.face.materialIndex=y.materialIndex,i.push(l))}}else{const b=Math.max(0,M.start),C=Math.min(p.count,M.start+M.count);for(let y=b,x=C;y<x;y+=3){const O=p.getX(y),I=p.getX(y+1),w=p.getX(y+2);l=Yc(this,f,e,s,h,_,g,O,I,w),l&&(l.faceIndex=Math.floor(y/3),i.push(l))}}else if(m!==void 0)if(Array.isArray(f))for(let b=0,C=v.length;b<C;b++){const y=v[b],x=f[y.materialIndex],O=Math.max(y.start,M.start),I=Math.min(m.count,Math.min(y.start+y.count,M.start+M.count));for(let w=O,B=I;w<B;w+=3){const U=w,F=w+1,T=w+2;l=Yc(this,x,e,s,h,_,g,U,F,T),l&&(l.faceIndex=Math.floor(w/3),l.face.materialIndex=y.materialIndex,i.push(l))}}else{const b=Math.max(0,M.start),C=Math.min(m.count,M.start+M.count);for(let y=b,x=C;y<x;y+=3){const O=y,I=y+1,w=y+2;l=Yc(this,f,e,s,h,_,g,O,I,w),l&&(l.faceIndex=Math.floor(y/3),i.push(l))}}}}function Qb(a,e,i,s,l,c,f,p){let m;if(e.side===$n?m=s.intersectTriangle(f,c,l,!0,p):m=s.intersectTriangle(l,c,f,e.side===Mr,p),m===null)return null;qc.copy(p),qc.applyMatrix4(a.matrixWorld);const h=i.ray.origin.distanceTo(qc);return h<i.near||h>i.far?null:{distance:h,point:qc.clone(),object:a}}function Yc(a,e,i,s,l,c,f,p,m,h){a.getVertexPosition(p,Vc),a.getVertexPosition(m,kc),a.getVertexPosition(h,Xc);const _=Qb(a,e,i,s,Vc,kc,Xc,o_);if(_){const g=new ce;Fi.getBarycoord(o_,Vc,kc,Xc,g),l&&(_.uv=Fi.getInterpolatedAttribute(l,p,m,h,g,new Pt)),c&&(_.uv1=Fi.getInterpolatedAttribute(c,p,m,h,g,new Pt)),f&&(_.normal=Fi.getInterpolatedAttribute(f,p,m,h,g,new ce),_.normal.dot(s.direction)>0&&_.normal.multiplyScalar(-1));const v={a:p,b:m,c:h,normal:new ce,materialIndex:0};Fi.getNormal(Vc,kc,Xc,v.normal),_.face=v,_.barycoord=g}return _}class jb extends kn{constructor(e=null,i=1,s=1,l,c,f,p,m,h=Pn,_=Pn,g,v){super(null,f,p,m,h,_,l,c,g,v),this.isDataTexture=!0,this.image={data:e,width:i,height:s},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const dh=new ce,Jb=new ce,$b=new ot;class Yr{constructor(e=new ce(1,0,0),i=0){this.isPlane=!0,this.normal=e,this.constant=i}set(e,i){return this.normal.copy(e),this.constant=i,this}setComponents(e,i,s,l){return this.normal.set(e,i,s),this.constant=l,this}setFromNormalAndCoplanarPoint(e,i){return this.normal.copy(e),this.constant=-i.dot(this.normal),this}setFromCoplanarPoints(e,i,s){const l=dh.subVectors(s,i).cross(Jb.subVectors(e,i)).normalize();return this.setFromNormalAndCoplanarPoint(l,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,i){return i.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,i,s=!0){const l=e.delta(dh),c=this.normal.dot(l);if(c===0)return this.distanceToPoint(e.start)===0?i.copy(e.start):null;const f=-(e.start.dot(this.normal)+this.constant)/c;return s===!0&&(f<0||f>1)?null:i.copy(e.start).addScaledVector(l,f)}intersectsLine(e){const i=this.distanceToPoint(e.start),s=this.distanceToPoint(e.end);return i<0&&s>0||s<0&&i>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,i){const s=i||$b.getNormalMatrix(e),l=this.coplanarPoint(dh).applyMatrix4(e),c=this.normal.applyMatrix3(s).normalize();return this.constant=-l.dot(c),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const qr=new Np,e1=new Pt(.5,.5),Zc=new ce;class Ux{constructor(e=new Yr,i=new Yr,s=new Yr,l=new Yr,c=new Yr,f=new Yr){this.planes=[e,i,s,l,c,f]}set(e,i,s,l,c,f){const p=this.planes;return p[0].copy(e),p[1].copy(i),p[2].copy(s),p[3].copy(l),p[4].copy(c),p[5].copy(f),this}copy(e){const i=this.planes;for(let s=0;s<6;s++)i[s].copy(e.planes[s]);return this}setFromProjectionMatrix(e,i=ea,s=!1){const l=this.planes,c=e.elements,f=c[0],p=c[1],m=c[2],h=c[3],_=c[4],g=c[5],v=c[6],M=c[7],b=c[8],C=c[9],y=c[10],x=c[11],O=c[12],I=c[13],w=c[14],B=c[15];if(l[0].setComponents(h-f,M-_,x-b,B-O).normalize(),l[1].setComponents(h+f,M+_,x+b,B+O).normalize(),l[2].setComponents(h+p,M+g,x+C,B+I).normalize(),l[3].setComponents(h-p,M-g,x-C,B-I).normalize(),s)l[4].setComponents(m,v,y,w).normalize(),l[5].setComponents(h-m,M-v,x-y,B-w).normalize();else if(l[4].setComponents(h-m,M-v,x-y,B-w).normalize(),i===ea)l[5].setComponents(h+m,M+v,x+y,B+w).normalize();else if(i===gu)l[5].setComponents(m,v,y,w).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+i);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),qr.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const i=e.geometry;i.boundingSphere===null&&i.computeBoundingSphere(),qr.copy(i.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(qr)}intersectsSprite(e){qr.center.set(0,0,0);const i=e1.distanceTo(e.center);return qr.radius=.7071067811865476+i,qr.applyMatrix4(e.matrixWorld),this.intersectsSphere(qr)}intersectsSphere(e){const i=this.planes,s=e.center,l=-e.radius;for(let c=0;c<6;c++)if(i[c].distanceToPoint(s)<l)return!1;return!0}intersectsBox(e){const i=this.planes;for(let s=0;s<6;s++){const l=i[s];if(Zc.x=l.normal.x>0?e.max.x:e.min.x,Zc.y=l.normal.y>0?e.max.y:e.min.y,Zc.z=l.normal.z>0?e.max.z:e.min.z,l.distanceToPoint(Zc)<0)return!1}return!0}containsPoint(e){const i=this.planes;for(let s=0;s<6;s++)if(i[s].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Nx extends kn{constructor(e=[],i=Jr,s,l,c,f,p,m,h,_){super(e,i,s,l,c,f,p,m,h,_),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class eo extends kn{constructor(e,i,s=aa,l,c,f,p=Pn,m=Pn,h,_=Fa,g=1){if(_!==Fa&&_!==jr)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const v={width:e,height:i,depth:g};super(v,l,c,f,p,m,_,s,h),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Up(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const i=super.toJSON(e);return this.compareFunction!==null&&(i.compareFunction=this.compareFunction),i}}class t1 extends eo{constructor(e,i=aa,s=Jr,l,c,f=Pn,p=Pn,m,h=Fa){const _={width:e,height:e,depth:1},g=[_,_,_,_,_,_];super(e,e,i,s,l,c,f,p,m,h),this.image=g,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class Lx extends kn{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class gl extends za{constructor(e=1,i=1,s=1,l=1,c=1,f=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:i,depth:s,widthSegments:l,heightSegments:c,depthSegments:f};const p=this;l=Math.floor(l),c=Math.floor(c),f=Math.floor(f);const m=[],h=[],_=[],g=[];let v=0,M=0;b("z","y","x",-1,-1,s,i,e,f,c,0),b("z","y","x",1,-1,s,i,-e,f,c,1),b("x","z","y",1,1,e,s,i,l,f,2),b("x","z","y",1,-1,e,s,-i,l,f,3),b("x","y","z",1,-1,e,i,s,l,c,4),b("x","y","z",-1,-1,e,i,-s,l,c,5),this.setIndex(m),this.setAttribute("position",new Pa(h,3)),this.setAttribute("normal",new Pa(_,3)),this.setAttribute("uv",new Pa(g,2));function b(C,y,x,O,I,w,B,U,F,T,P){const q=w/F,V=B/T,Q=w/2,fe=B/2,me=U/2,j=F+1,L=T+1;let H=0,$=0;const _e=new ce;for(let be=0;be<L;be++){const N=be*V-fe;for(let Y=0;Y<j;Y++){const de=Y*q-Q;_e[C]=de*O,_e[y]=N*I,_e[x]=me,h.push(_e.x,_e.y,_e.z),_e[C]=0,_e[y]=0,_e[x]=U>0?1:-1,_.push(_e.x,_e.y,_e.z),g.push(Y/F),g.push(1-be/T),H+=1}}for(let be=0;be<T;be++)for(let N=0;N<F;N++){const Y=v+N+j*be,de=v+N+j*(be+1),Te=v+(N+1)+j*(be+1),Ce=v+(N+1)+j*be;m.push(Y,de,Ce),m.push(de,Te,Ce),$+=6}p.addGroup(M,$,P),M+=$,v+=H}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new gl(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class vl extends za{constructor(e=1,i=1,s=1,l=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:i,widthSegments:s,heightSegments:l};const c=e/2,f=i/2,p=Math.floor(s),m=Math.floor(l),h=p+1,_=m+1,g=e/p,v=i/m,M=[],b=[],C=[],y=[];for(let x=0;x<_;x++){const O=x*v-f;for(let I=0;I<h;I++){const w=I*g-c;b.push(w,-O,0),C.push(0,0,1),y.push(I/p),y.push(1-x/m)}}for(let x=0;x<m;x++)for(let O=0;O<p;O++){const I=O+h*x,w=O+h*(x+1),B=O+1+h*(x+1),U=O+1+h*x;M.push(I,w,U),M.push(w,B,U)}this.setIndex(M),this.setAttribute("position",new Pa(b,3)),this.setAttribute("normal",new Pa(C,3)),this.setAttribute("uv",new Pa(y,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new vl(e.width,e.height,e.widthSegments,e.heightSegments)}}function to(a){const e={};for(const i in a){e[i]={};for(const s in a[i]){const l=a[i][s];if(l_(l))l.isRenderTargetTexture?(rt("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[i][s]=null):e[i][s]=l.clone();else if(Array.isArray(l))if(l_(l[0])){const c=[];for(let f=0,p=l.length;f<p;f++)c[f]=l[f].clone();e[i][s]=c}else e[i][s]=l.slice();else e[i][s]=l}}return e}function Vn(a){const e={};for(let i=0;i<a.length;i++){const s=to(a[i]);for(const l in s)e[l]=s[l]}return e}function l_(a){return a&&(a.isColor||a.isMatrix3||a.isMatrix4||a.isVector2||a.isVector3||a.isVector4||a.isTexture||a.isQuaternion)}function n1(a){const e=[];for(let i=0;i<a.length;i++)e.push(a[i].clone());return e}function Ox(a){const e=a.getRenderTarget();return e===null?a.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:Tt.workingColorSpace}const i1={clone:to,merge:Vn};var a1=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,r1=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Gi extends bu{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=a1,this.fragmentShader=r1,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=to(e.uniforms),this.uniformsGroups=n1(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const i=super.toJSON(e);i.glslVersion=this.glslVersion,i.uniforms={};for(const l in this.uniforms){const f=this.uniforms[l].value;f&&f.isTexture?i.uniforms[l]={type:"t",value:f.toJSON(e).uuid}:f&&f.isColor?i.uniforms[l]={type:"c",value:f.getHex()}:f&&f.isVector2?i.uniforms[l]={type:"v2",value:f.toArray()}:f&&f.isVector3?i.uniforms[l]={type:"v3",value:f.toArray()}:f&&f.isVector4?i.uniforms[l]={type:"v4",value:f.toArray()}:f&&f.isMatrix3?i.uniforms[l]={type:"m3",value:f.toArray()}:f&&f.isMatrix4?i.uniforms[l]={type:"m4",value:f.toArray()}:i.uniforms[l]={value:f}}Object.keys(this.defines).length>0&&(i.defines=this.defines),i.vertexShader=this.vertexShader,i.fragmentShader=this.fragmentShader,i.lights=this.lights,i.clipping=this.clipping;const s={};for(const l in this.extensions)this.extensions[l]===!0&&(s[l]=!0);return Object.keys(s).length>0&&(i.extensions=s),i}fromJSON(e,i){if(super.fromJSON(e,i),e.uniforms!==void 0)for(const s in e.uniforms){const l=e.uniforms[s];switch(this.uniforms[s]={},l.type){case"t":this.uniforms[s].value=i[l.value]||null;break;case"c":this.uniforms[s].value=new zt().setHex(l.value);break;case"v2":this.uniforms[s].value=new Pt().fromArray(l.value);break;case"v3":this.uniforms[s].value=new ce().fromArray(l.value);break;case"v4":this.uniforms[s].value=new dn().fromArray(l.value);break;case"m3":this.uniforms[s].value=new ot().fromArray(l.value);break;case"m4":this.uniforms[s].value=new Mn().fromArray(l.value);break;default:this.uniforms[s].value=l.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(const s in e.extensions)this.extensions[s]=e.extensions[s];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}}class s1 extends Gi{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class o1 extends bu{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=_b,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class l1 extends bu{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const Kc=new ce,Qc=new ro,Ki=new ce;class Px extends hi{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Mn,this.projectionMatrix=new Mn,this.projectionMatrixInverse=new Mn,this.coordinateSystem=ea,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,i){return super.copy(e,i),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Kc,Qc,Ki),Ki.x===1&&Ki.y===1&&Ki.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Kc,Qc,Ki.set(1,1,1)).invert()}updateWorldMatrix(e,i,s=!1){super.updateWorldMatrix(e,i,s),this.matrixWorld.decompose(Kc,Qc,Ki),Ki.x===1&&Ki.y===1&&Ki.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Kc,Qc,Ki.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const xr=new ce,c_=new Pt,u_=new Pt;class Bi extends Px{constructor(e=50,i=1,s=.1,l=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=s,this.far=l,this.focus=10,this.aspect=i,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,i){return super.copy(e,i),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const i=.5*this.getFilmHeight()/e;this.fov=cp*2*Math.atan(i),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(kd*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return cp*2*Math.atan(Math.tan(kd*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,i,s){xr.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(xr.x,xr.y).multiplyScalar(-e/xr.z),xr.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),s.set(xr.x,xr.y).multiplyScalar(-e/xr.z)}getViewSize(e,i){return this.getViewBounds(e,c_,u_),i.subVectors(u_,c_)}setViewOffset(e,i,s,l,c,f){this.aspect=e/i,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=i,this.view.offsetX=s,this.view.offsetY=l,this.view.width=c,this.view.height=f,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let i=e*Math.tan(kd*.5*this.fov)/this.zoom,s=2*i,l=this.aspect*s,c=-.5*l;const f=this.view;if(this.view!==null&&this.view.enabled){const m=f.fullWidth,h=f.fullHeight;c+=f.offsetX*l/m,i-=f.offsetY*s/h,l*=f.width/m,s*=f.height/h}const p=this.filmOffset;p!==0&&(c+=e*p/this.getFilmWidth()),this.projectionMatrix.makePerspective(c,c+l,i,i-s,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const i=super.toJSON(e);return i.object.fov=this.fov,i.object.zoom=this.zoom,i.object.near=this.near,i.object.far=this.far,i.object.focus=this.focus,i.object.aspect=this.aspect,this.view!==null&&(i.object.view=Object.assign({},this.view)),i.object.filmGauge=this.filmGauge,i.object.filmOffset=this.filmOffset,i}}class Lp extends Px{constructor(e=-1,i=1,s=1,l=-1,c=.1,f=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=i,this.top=s,this.bottom=l,this.near=c,this.far=f,this.updateProjectionMatrix()}copy(e,i){return super.copy(e,i),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,i,s,l,c,f){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=i,this.view.offsetX=s,this.view.offsetY=l,this.view.width=c,this.view.height=f,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),i=(this.top-this.bottom)/(2*this.zoom),s=(this.right+this.left)/2,l=(this.top+this.bottom)/2;let c=s-e,f=s+e,p=l+i,m=l-i;if(this.view!==null&&this.view.enabled){const h=(this.right-this.left)/this.view.fullWidth/this.zoom,_=(this.top-this.bottom)/this.view.fullHeight/this.zoom;c+=h*this.view.offsetX,f=c+h*this.view.width,p-=_*this.view.offsetY,m=p-_*this.view.height}this.projectionMatrix.makeOrthographic(c,f,p,m,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const i=super.toJSON(e);return i.object.zoom=this.zoom,i.object.left=this.left,i.object.right=this.right,i.object.top=this.top,i.object.bottom=this.bottom,i.object.near=this.near,i.object.far=this.far,this.view!==null&&(i.object.view=Object.assign({},this.view)),i}}const qs=-90,Ys=1;class c1 extends hi{constructor(e,i,s){super(),this.type="CubeCamera",this.renderTarget=s,this.coordinateSystem=null,this.activeMipmapLevel=0;const l=new Bi(qs,Ys,e,i);l.layers=this.layers,this.add(l);const c=new Bi(qs,Ys,e,i);c.layers=this.layers,this.add(c);const f=new Bi(qs,Ys,e,i);f.layers=this.layers,this.add(f);const p=new Bi(qs,Ys,e,i);p.layers=this.layers,this.add(p);const m=new Bi(qs,Ys,e,i);m.layers=this.layers,this.add(m);const h=new Bi(qs,Ys,e,i);h.layers=this.layers,this.add(h)}updateCoordinateSystem(){const e=this.coordinateSystem,i=this.children.concat(),[s,l,c,f,p,m]=i;for(const h of i)this.remove(h);if(e===ea)s.up.set(0,1,0),s.lookAt(1,0,0),l.up.set(0,1,0),l.lookAt(-1,0,0),c.up.set(0,0,-1),c.lookAt(0,1,0),f.up.set(0,0,1),f.lookAt(0,-1,0),p.up.set(0,1,0),p.lookAt(0,0,1),m.up.set(0,1,0),m.lookAt(0,0,-1);else if(e===gu)s.up.set(0,-1,0),s.lookAt(-1,0,0),l.up.set(0,-1,0),l.lookAt(1,0,0),c.up.set(0,0,1),c.lookAt(0,1,0),f.up.set(0,0,-1),f.lookAt(0,-1,0),p.up.set(0,-1,0),p.lookAt(0,0,1),m.up.set(0,-1,0),m.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const h of i)this.add(h),h.updateMatrixWorld()}update(e,i){this.parent===null&&this.updateMatrixWorld();const{renderTarget:s,activeMipmapLevel:l}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[c,f,p,m,h,_]=this.children,g=e.getRenderTarget(),v=e.getActiveCubeFace(),M=e.getActiveMipmapLevel(),b=e.xr.enabled;e.xr.enabled=!1;const C=s.texture.generateMipmaps;s.texture.generateMipmaps=!1;let y=!1;e.isWebGLRenderer===!0?y=e.state.buffers.depth.getReversed():y=e.reversedDepthBuffer,e.setRenderTarget(s,0,l),y&&e.autoClear===!1&&e.clearDepth(),e.render(i,c),e.setRenderTarget(s,1,l),y&&e.autoClear===!1&&e.clearDepth(),e.render(i,f),e.setRenderTarget(s,2,l),y&&e.autoClear===!1&&e.clearDepth(),e.render(i,p),e.setRenderTarget(s,3,l),y&&e.autoClear===!1&&e.clearDepth(),e.render(i,m),e.setRenderTarget(s,4,l),y&&e.autoClear===!1&&e.clearDepth(),e.render(i,h),s.texture.generateMipmaps=C,e.setRenderTarget(s,5,l),y&&e.autoClear===!1&&e.clearDepth(),e.render(i,_),e.setRenderTarget(g,v,M),e.xr.enabled=b,s.texture.needsPMREMUpdate=!0}}class u1 extends Bi{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}class f1{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1,rt("Clock: This module has been deprecated. Please use THREE.Timer instead.")}start(){this.startTime=performance.now(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const i=performance.now();e=(i-this.oldTime)/1e3,this.oldTime=i,this.elapsedTime+=e}return e}}const Fp=class Fp{constructor(e,i,s,l){this.elements=[1,0,0,1],e!==void 0&&this.set(e,i,s,l)}identity(){return this.set(1,0,0,1),this}fromArray(e,i=0){for(let s=0;s<4;s++)this.elements[s]=e[s+i];return this}set(e,i,s,l){const c=this.elements;return c[0]=e,c[2]=i,c[1]=s,c[3]=l,this}};Fp.prototype.isMatrix2=!0;let f_=Fp;function d_(a,e,i,s){const l=d1(s);switch(i){case yx:return a*e;case Ex:return a*e/l.components*l.byteLength;case Ap:return a*e/l.components*l.byteLength;case $r:return a*e*2/l.components*l.byteLength;case Rp:return a*e*2/l.components*l.byteLength;case Mx:return a*e*3/l.components*l.byteLength;case zi:return a*e*4/l.components*l.byteLength;case Cp:return a*e*4/l.components*l.byteLength;case ru:case su:return Math.floor((a+3)/4)*Math.floor((e+3)/4)*8;case ou:case lu:return Math.floor((a+3)/4)*Math.floor((e+3)/4)*16;case Oh:case Ih:return Math.max(a,16)*Math.max(e,8)/4;case Lh:case Ph:return Math.max(a,8)*Math.max(e,8)/2;case Bh:case Fh:case Hh:case Gh:return Math.floor((a+3)/4)*Math.floor((e+3)/4)*8;case zh:case du:case Vh:return Math.floor((a+3)/4)*Math.floor((e+3)/4)*16;case kh:return Math.floor((a+3)/4)*Math.floor((e+3)/4)*16;case Xh:return Math.floor((a+4)/5)*Math.floor((e+3)/4)*16;case Wh:return Math.floor((a+4)/5)*Math.floor((e+4)/5)*16;case qh:return Math.floor((a+5)/6)*Math.floor((e+4)/5)*16;case Yh:return Math.floor((a+5)/6)*Math.floor((e+5)/6)*16;case Zh:return Math.floor((a+7)/8)*Math.floor((e+4)/5)*16;case Kh:return Math.floor((a+7)/8)*Math.floor((e+5)/6)*16;case Qh:return Math.floor((a+7)/8)*Math.floor((e+7)/8)*16;case jh:return Math.floor((a+9)/10)*Math.floor((e+4)/5)*16;case Jh:return Math.floor((a+9)/10)*Math.floor((e+5)/6)*16;case $h:return Math.floor((a+9)/10)*Math.floor((e+7)/8)*16;case ep:return Math.floor((a+9)/10)*Math.floor((e+9)/10)*16;case tp:return Math.floor((a+11)/12)*Math.floor((e+9)/10)*16;case np:return Math.floor((a+11)/12)*Math.floor((e+11)/12)*16;case ip:case ap:case rp:return Math.ceil(a/4)*Math.ceil(e/4)*16;case sp:case op:return Math.ceil(a/4)*Math.ceil(e/4)*8;case hu:case lp:return Math.ceil(a/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${i} format.`)}function d1(a){switch(a){case Ai:case vx:return{byteLength:1,components:1};case cl:case _x:case Ba:return{byteLength:2,components:1};case bp:case Tp:return{byteLength:2,components:4};case aa:case Ep:case $i:return{byteLength:4,components:1};case xx:case Sx:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${a}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Mp}}));typeof window<"u"&&(window.__THREE__?rt("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Mp);function Ix(){let a=null,e=!1,i=null,s=null;function l(c,f){i(c,f),s=a.requestAnimationFrame(l)}return{start:function(){e!==!0&&i!==null&&a!==null&&(s=a.requestAnimationFrame(l),e=!0)},stop:function(){a!==null&&a.cancelAnimationFrame(s),e=!1},setAnimationLoop:function(c){i=c},setContext:function(c){a=c}}}function h1(a){const e=new WeakMap;function i(p,m){const h=p.array,_=p.usage,g=h.byteLength,v=a.createBuffer();a.bindBuffer(m,v),a.bufferData(m,h,_),p.onUploadCallback();let M;if(h instanceof Float32Array)M=a.FLOAT;else if(typeof Float16Array<"u"&&h instanceof Float16Array)M=a.HALF_FLOAT;else if(h instanceof Uint16Array)p.isFloat16BufferAttribute?M=a.HALF_FLOAT:M=a.UNSIGNED_SHORT;else if(h instanceof Int16Array)M=a.SHORT;else if(h instanceof Uint32Array)M=a.UNSIGNED_INT;else if(h instanceof Int32Array)M=a.INT;else if(h instanceof Int8Array)M=a.BYTE;else if(h instanceof Uint8Array)M=a.UNSIGNED_BYTE;else if(h instanceof Uint8ClampedArray)M=a.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+h);return{buffer:v,type:M,bytesPerElement:h.BYTES_PER_ELEMENT,version:p.version,size:g}}function s(p,m,h){const _=m.array,g=m.updateRanges;if(a.bindBuffer(h,p),g.length===0)a.bufferSubData(h,0,_);else{g.sort((M,b)=>M.start-b.start);let v=0;for(let M=1;M<g.length;M++){const b=g[v],C=g[M];C.start<=b.start+b.count+1?b.count=Math.max(b.count,C.start+C.count-b.start):(++v,g[v]=C)}g.length=v+1;for(let M=0,b=g.length;M<b;M++){const C=g[M];a.bufferSubData(h,C.start*_.BYTES_PER_ELEMENT,_,C.start,C.count)}m.clearUpdateRanges()}m.onUploadCallback()}function l(p){return p.isInterleavedBufferAttribute&&(p=p.data),e.get(p)}function c(p){p.isInterleavedBufferAttribute&&(p=p.data);const m=e.get(p);m&&(a.deleteBuffer(m.buffer),e.delete(p))}function f(p,m){if(p.isInterleavedBufferAttribute&&(p=p.data),p.isGLBufferAttribute){const _=e.get(p);(!_||_.version<p.version)&&e.set(p,{buffer:p.buffer,type:p.type,bytesPerElement:p.elementSize,version:p.version});return}const h=e.get(p);if(h===void 0)e.set(p,i(p,m));else if(h.version<p.version){if(h.size!==p.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");s(h.buffer,p,m),h.version=p.version}}return{get:l,remove:c,update:f}}var p1=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,m1=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,g1=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,v1=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,_1=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,x1=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,S1=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,y1=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,M1=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,E1=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,b1=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,T1=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,A1=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,R1=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,C1=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,w1=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,D1=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,U1=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,N1=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,L1=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,O1=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,P1=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,I1=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,B1=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,F1=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,z1=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,H1=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,G1=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,V1=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,k1=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,X1="gl_FragColor = linearToOutputTexel( gl_FragColor );",W1=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,q1=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,Y1=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,Z1=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,K1=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Q1=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,j1=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,J1=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,$1=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,eT=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,tT=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,nT=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,iT=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,aT=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,rT=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,sT=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,oT=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lT=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,cT=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,uT=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,fT=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,dT=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,hT=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,pT=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,mT=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,gT=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,vT=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,_T=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,xT=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,ST=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,yT=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,MT=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,ET=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,bT=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,TT=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,AT=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,RT=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,CT=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,wT=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,DT=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,UT=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,NT=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,LT=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,OT=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,PT=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,IT=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,BT=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,FT=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,zT=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,HT=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,GT=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,VT=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,kT=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,XT=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,WT=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,qT=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,YT=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,ZT=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,KT=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,QT=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,jT=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,JT=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,$T=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,eA=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,tA=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,nA=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,iA=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,aA=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,rA=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,sA=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,oA=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,lA=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,cA=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,uA=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,fA=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,dA=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,hA=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const pA=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,mA=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,gA=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,vA=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,_A=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,xA=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,SA=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,yA=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,MA=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,EA=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,bA=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,TA=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,AA=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,RA=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,CA=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,wA=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,DA=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,UA=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,NA=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,LA=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,OA=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,PA=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,IA=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,BA=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,FA=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,zA=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,HA=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,GA=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,VA=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,kA=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,XA=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,WA=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,qA=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,YA=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ht={alphahash_fragment:p1,alphahash_pars_fragment:m1,alphamap_fragment:g1,alphamap_pars_fragment:v1,alphatest_fragment:_1,alphatest_pars_fragment:x1,aomap_fragment:S1,aomap_pars_fragment:y1,batching_pars_vertex:M1,batching_vertex:E1,begin_vertex:b1,beginnormal_vertex:T1,bsdfs:A1,iridescence_fragment:R1,bumpmap_pars_fragment:C1,clipping_planes_fragment:w1,clipping_planes_pars_fragment:D1,clipping_planes_pars_vertex:U1,clipping_planes_vertex:N1,color_fragment:L1,color_pars_fragment:O1,color_pars_vertex:P1,color_vertex:I1,common:B1,cube_uv_reflection_fragment:F1,defaultnormal_vertex:z1,displacementmap_pars_vertex:H1,displacementmap_vertex:G1,emissivemap_fragment:V1,emissivemap_pars_fragment:k1,colorspace_fragment:X1,colorspace_pars_fragment:W1,envmap_fragment:q1,envmap_common_pars_fragment:Y1,envmap_pars_fragment:Z1,envmap_pars_vertex:K1,envmap_physical_pars_fragment:sT,envmap_vertex:Q1,fog_vertex:j1,fog_pars_vertex:J1,fog_fragment:$1,fog_pars_fragment:eT,gradientmap_pars_fragment:tT,lightmap_pars_fragment:nT,lights_lambert_fragment:iT,lights_lambert_pars_fragment:aT,lights_pars_begin:rT,lights_toon_fragment:oT,lights_toon_pars_fragment:lT,lights_phong_fragment:cT,lights_phong_pars_fragment:uT,lights_physical_fragment:fT,lights_physical_pars_fragment:dT,lights_fragment_begin:hT,lights_fragment_maps:pT,lights_fragment_end:mT,lightprobes_pars_fragment:gT,logdepthbuf_fragment:vT,logdepthbuf_pars_fragment:_T,logdepthbuf_pars_vertex:xT,logdepthbuf_vertex:ST,map_fragment:yT,map_pars_fragment:MT,map_particle_fragment:ET,map_particle_pars_fragment:bT,metalnessmap_fragment:TT,metalnessmap_pars_fragment:AT,morphinstance_vertex:RT,morphcolor_vertex:CT,morphnormal_vertex:wT,morphtarget_pars_vertex:DT,morphtarget_vertex:UT,normal_fragment_begin:NT,normal_fragment_maps:LT,normal_pars_fragment:OT,normal_pars_vertex:PT,normal_vertex:IT,normalmap_pars_fragment:BT,clearcoat_normal_fragment_begin:FT,clearcoat_normal_fragment_maps:zT,clearcoat_pars_fragment:HT,iridescence_pars_fragment:GT,opaque_fragment:VT,packing:kT,premultiplied_alpha_fragment:XT,project_vertex:WT,dithering_fragment:qT,dithering_pars_fragment:YT,roughnessmap_fragment:ZT,roughnessmap_pars_fragment:KT,shadowmap_pars_fragment:QT,shadowmap_pars_vertex:jT,shadowmap_vertex:JT,shadowmask_pars_fragment:$T,skinbase_vertex:eA,skinning_pars_vertex:tA,skinning_vertex:nA,skinnormal_vertex:iA,specularmap_fragment:aA,specularmap_pars_fragment:rA,tonemapping_fragment:sA,tonemapping_pars_fragment:oA,transmission_fragment:lA,transmission_pars_fragment:cA,uv_pars_fragment:uA,uv_pars_vertex:fA,uv_vertex:dA,worldpos_vertex:hA,background_vert:pA,background_frag:mA,backgroundCube_vert:gA,backgroundCube_frag:vA,cube_vert:_A,cube_frag:xA,depth_vert:SA,depth_frag:yA,distance_vert:MA,distance_frag:EA,equirect_vert:bA,equirect_frag:TA,linedashed_vert:AA,linedashed_frag:RA,meshbasic_vert:CA,meshbasic_frag:wA,meshlambert_vert:DA,meshlambert_frag:UA,meshmatcap_vert:NA,meshmatcap_frag:LA,meshnormal_vert:OA,meshnormal_frag:PA,meshphong_vert:IA,meshphong_frag:BA,meshphysical_vert:FA,meshphysical_frag:zA,meshtoon_vert:HA,meshtoon_frag:GA,points_vert:VA,points_frag:kA,shadow_vert:XA,shadow_frag:WA,sprite_vert:qA,sprite_frag:YA},Ge={common:{diffuse:{value:new zt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new ot},alphaMap:{value:null},alphaMapTransform:{value:new ot},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new ot}},envmap:{envMap:{value:null},envMapRotation:{value:new ot},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new ot}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new ot}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new ot},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new ot},normalScale:{value:new Pt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new ot},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new ot}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new ot}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new ot}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new zt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new ce},probesMax:{value:new ce},probesResolution:{value:new ce}},points:{diffuse:{value:new zt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new ot},alphaTest:{value:0},uvTransform:{value:new ot}},sprite:{diffuse:{value:new zt(16777215)},opacity:{value:1},center:{value:new Pt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new ot},alphaMap:{value:null},alphaMapTransform:{value:new ot},alphaTest:{value:0}}},Ji={basic:{uniforms:Vn([Ge.common,Ge.specularmap,Ge.envmap,Ge.aomap,Ge.lightmap,Ge.fog]),vertexShader:ht.meshbasic_vert,fragmentShader:ht.meshbasic_frag},lambert:{uniforms:Vn([Ge.common,Ge.specularmap,Ge.envmap,Ge.aomap,Ge.lightmap,Ge.emissivemap,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.fog,Ge.lights,{emissive:{value:new zt(0)},envMapIntensity:{value:1}}]),vertexShader:ht.meshlambert_vert,fragmentShader:ht.meshlambert_frag},phong:{uniforms:Vn([Ge.common,Ge.specularmap,Ge.envmap,Ge.aomap,Ge.lightmap,Ge.emissivemap,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.fog,Ge.lights,{emissive:{value:new zt(0)},specular:{value:new zt(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:ht.meshphong_vert,fragmentShader:ht.meshphong_frag},standard:{uniforms:Vn([Ge.common,Ge.envmap,Ge.aomap,Ge.lightmap,Ge.emissivemap,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.roughnessmap,Ge.metalnessmap,Ge.fog,Ge.lights,{emissive:{value:new zt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ht.meshphysical_vert,fragmentShader:ht.meshphysical_frag},toon:{uniforms:Vn([Ge.common,Ge.aomap,Ge.lightmap,Ge.emissivemap,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.gradientmap,Ge.fog,Ge.lights,{emissive:{value:new zt(0)}}]),vertexShader:ht.meshtoon_vert,fragmentShader:ht.meshtoon_frag},matcap:{uniforms:Vn([Ge.common,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,Ge.fog,{matcap:{value:null}}]),vertexShader:ht.meshmatcap_vert,fragmentShader:ht.meshmatcap_frag},points:{uniforms:Vn([Ge.points,Ge.fog]),vertexShader:ht.points_vert,fragmentShader:ht.points_frag},dashed:{uniforms:Vn([Ge.common,Ge.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ht.linedashed_vert,fragmentShader:ht.linedashed_frag},depth:{uniforms:Vn([Ge.common,Ge.displacementmap]),vertexShader:ht.depth_vert,fragmentShader:ht.depth_frag},normal:{uniforms:Vn([Ge.common,Ge.bumpmap,Ge.normalmap,Ge.displacementmap,{opacity:{value:1}}]),vertexShader:ht.meshnormal_vert,fragmentShader:ht.meshnormal_frag},sprite:{uniforms:Vn([Ge.sprite,Ge.fog]),vertexShader:ht.sprite_vert,fragmentShader:ht.sprite_frag},background:{uniforms:{uvTransform:{value:new ot},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ht.background_vert,fragmentShader:ht.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new ot}},vertexShader:ht.backgroundCube_vert,fragmentShader:ht.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ht.cube_vert,fragmentShader:ht.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ht.equirect_vert,fragmentShader:ht.equirect_frag},distance:{uniforms:Vn([Ge.common,Ge.displacementmap,{referencePosition:{value:new ce},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:ht.distance_vert,fragmentShader:ht.distance_frag},shadow:{uniforms:Vn([Ge.lights,Ge.fog,{color:{value:new zt(0)},opacity:{value:1}}]),vertexShader:ht.shadow_vert,fragmentShader:ht.shadow_frag}};Ji.physical={uniforms:Vn([Ji.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new ot},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new ot},clearcoatNormalScale:{value:new Pt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new ot},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new ot},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new ot},sheen:{value:0},sheenColor:{value:new zt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new ot},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new ot},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new ot},transmissionSamplerSize:{value:new Pt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new ot},attenuationDistance:{value:0},attenuationColor:{value:new zt(0)},specularColor:{value:new zt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new ot},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new ot},anisotropyVector:{value:new Pt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new ot}}]),vertexShader:ht.meshphysical_vert,fragmentShader:ht.meshphysical_frag};const jc={r:0,b:0,g:0},ZA=new Mn,Bx=new ot;Bx.set(-1,0,0,0,1,0,0,0,1);function KA(a,e,i,s,l,c){const f=new zt(0);let p=l===!0?0:1,m,h,_=null,g=0,v=null;function M(O){let I=O.isScene===!0?O.background:null;if(I&&I.isTexture){const w=O.backgroundBlurriness>0;I=e.get(I,w)}return I}function b(O){let I=!1;const w=M(O);w===null?y(f,p):w&&w.isColor&&(y(w,1),I=!0);const B=a.xr.getEnvironmentBlendMode();B==="additive"?i.buffers.color.setClear(0,0,0,1,c):B==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,c),(a.autoClear||I)&&(i.buffers.depth.setTest(!0),i.buffers.depth.setMask(!0),i.buffers.color.setMask(!0),a.clear(a.autoClearColor,a.autoClearDepth,a.autoClearStencil))}function C(O,I){const w=M(I);w&&(w.isCubeTexture||w.mapping===Eu)?(h===void 0&&(h=new ra(new gl(1,1,1),new Gi({name:"BackgroundCubeMaterial",uniforms:to(Ji.backgroundCube.uniforms),vertexShader:Ji.backgroundCube.vertexShader,fragmentShader:Ji.backgroundCube.fragmentShader,side:$n,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(B,U,F){this.matrixWorld.copyPosition(F.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),h.material.uniforms.envMap.value=w,h.material.uniforms.backgroundBlurriness.value=I.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=I.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(ZA.makeRotationFromEuler(I.backgroundRotation)).transpose(),w.isCubeTexture&&w.isRenderTargetTexture===!1&&h.material.uniforms.backgroundRotation.value.premultiply(Bx),h.material.toneMapped=Tt.getTransfer(w.colorSpace)!==Wt,(_!==w||g!==w.version||v!==a.toneMapping)&&(h.material.needsUpdate=!0,_=w,g=w.version,v=a.toneMapping),h.layers.enableAll(),O.unshift(h,h.geometry,h.material,0,0,null)):w&&w.isTexture&&(m===void 0&&(m=new ra(new vl(2,2),new Gi({name:"BackgroundMaterial",uniforms:to(Ji.background.uniforms),vertexShader:Ji.background.vertexShader,fragmentShader:Ji.background.fragmentShader,side:Mr,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),m.geometry.deleteAttribute("normal"),Object.defineProperty(m.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(m)),m.material.uniforms.t2D.value=w,m.material.uniforms.backgroundIntensity.value=I.backgroundIntensity,m.material.toneMapped=Tt.getTransfer(w.colorSpace)!==Wt,w.matrixAutoUpdate===!0&&w.updateMatrix(),m.material.uniforms.uvTransform.value.copy(w.matrix),(_!==w||g!==w.version||v!==a.toneMapping)&&(m.material.needsUpdate=!0,_=w,g=w.version,v=a.toneMapping),m.layers.enableAll(),O.unshift(m,m.geometry,m.material,0,0,null))}function y(O,I){O.getRGB(jc,Ox(a)),i.buffers.color.setClear(jc.r,jc.g,jc.b,I,c)}function x(){h!==void 0&&(h.geometry.dispose(),h.material.dispose(),h=void 0),m!==void 0&&(m.geometry.dispose(),m.material.dispose(),m=void 0)}return{getClearColor:function(){return f},setClearColor:function(O,I=1){f.set(O),p=I,y(f,p)},getClearAlpha:function(){return p},setClearAlpha:function(O){p=O,y(f,p)},render:b,addToRenderList:C,dispose:x}}function QA(a,e){const i=a.getParameter(a.MAX_VERTEX_ATTRIBS),s={},l=v(null);let c=l,f=!1;function p(V,Q,fe,me,j){let L=!1;const H=g(V,me,fe,Q);c!==H&&(c=H,h(c.object)),L=M(V,me,fe,j),L&&b(V,me,fe,j),j!==null&&e.update(j,a.ELEMENT_ARRAY_BUFFER),(L||f)&&(f=!1,w(V,Q,fe,me),j!==null&&a.bindBuffer(a.ELEMENT_ARRAY_BUFFER,e.get(j).buffer))}function m(){return a.createVertexArray()}function h(V){return a.bindVertexArray(V)}function _(V){return a.deleteVertexArray(V)}function g(V,Q,fe,me){const j=me.wireframe===!0;let L=s[Q.id];L===void 0&&(L={},s[Q.id]=L);const H=V.isInstancedMesh===!0?V.id:0;let $=L[H];$===void 0&&($={},L[H]=$);let _e=$[fe.id];_e===void 0&&(_e={},$[fe.id]=_e);let be=_e[j];return be===void 0&&(be=v(m()),_e[j]=be),be}function v(V){const Q=[],fe=[],me=[];for(let j=0;j<i;j++)Q[j]=0,fe[j]=0,me[j]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:Q,enabledAttributes:fe,attributeDivisors:me,object:V,attributes:{},index:null}}function M(V,Q,fe,me){const j=c.attributes,L=Q.attributes;let H=0;const $=fe.getAttributes();for(const _e in $)if($[_e].location>=0){const N=j[_e];let Y=L[_e];if(Y===void 0&&(_e==="instanceMatrix"&&V.instanceMatrix&&(Y=V.instanceMatrix),_e==="instanceColor"&&V.instanceColor&&(Y=V.instanceColor)),N===void 0||N.attribute!==Y||Y&&N.data!==Y.data)return!0;H++}return c.attributesNum!==H||c.index!==me}function b(V,Q,fe,me){const j={},L=Q.attributes;let H=0;const $=fe.getAttributes();for(const _e in $)if($[_e].location>=0){let N=L[_e];N===void 0&&(_e==="instanceMatrix"&&V.instanceMatrix&&(N=V.instanceMatrix),_e==="instanceColor"&&V.instanceColor&&(N=V.instanceColor));const Y={};Y.attribute=N,N&&N.data&&(Y.data=N.data),j[_e]=Y,H++}c.attributes=j,c.attributesNum=H,c.index=me}function C(){const V=c.newAttributes;for(let Q=0,fe=V.length;Q<fe;Q++)V[Q]=0}function y(V){x(V,0)}function x(V,Q){const fe=c.newAttributes,me=c.enabledAttributes,j=c.attributeDivisors;fe[V]=1,me[V]===0&&(a.enableVertexAttribArray(V),me[V]=1),j[V]!==Q&&(a.vertexAttribDivisor(V,Q),j[V]=Q)}function O(){const V=c.newAttributes,Q=c.enabledAttributes;for(let fe=0,me=Q.length;fe<me;fe++)Q[fe]!==V[fe]&&(a.disableVertexAttribArray(fe),Q[fe]=0)}function I(V,Q,fe,me,j,L,H){H===!0?a.vertexAttribIPointer(V,Q,fe,j,L):a.vertexAttribPointer(V,Q,fe,me,j,L)}function w(V,Q,fe,me){C();const j=me.attributes,L=fe.getAttributes(),H=Q.defaultAttributeValues;for(const $ in L){const _e=L[$];if(_e.location>=0){let be=j[$];if(be===void 0&&($==="instanceMatrix"&&V.instanceMatrix&&(be=V.instanceMatrix),$==="instanceColor"&&V.instanceColor&&(be=V.instanceColor)),be!==void 0){const N=be.normalized,Y=be.itemSize,de=e.get(be);if(de===void 0)continue;const Te=de.buffer,Ce=de.type,ee=de.bytesPerElement,Me=Ce===a.INT||Ce===a.UNSIGNED_INT||be.gpuType===Ep;if(be.isInterleavedBufferAttribute){const ve=be.data,He=ve.stride,nt=be.offset;if(ve.isInstancedInterleavedBuffer){for(let je=0;je<_e.locationSize;je++)x(_e.location+je,ve.meshPerAttribute);V.isInstancedMesh!==!0&&me._maxInstanceCount===void 0&&(me._maxInstanceCount=ve.meshPerAttribute*ve.count)}else for(let je=0;je<_e.locationSize;je++)y(_e.location+je);a.bindBuffer(a.ARRAY_BUFFER,Te);for(let je=0;je<_e.locationSize;je++)I(_e.location+je,Y/_e.locationSize,Ce,N,He*ee,(nt+Y/_e.locationSize*je)*ee,Me)}else{if(be.isInstancedBufferAttribute){for(let ve=0;ve<_e.locationSize;ve++)x(_e.location+ve,be.meshPerAttribute);V.isInstancedMesh!==!0&&me._maxInstanceCount===void 0&&(me._maxInstanceCount=be.meshPerAttribute*be.count)}else for(let ve=0;ve<_e.locationSize;ve++)y(_e.location+ve);a.bindBuffer(a.ARRAY_BUFFER,Te);for(let ve=0;ve<_e.locationSize;ve++)I(_e.location+ve,Y/_e.locationSize,Ce,N,Y*ee,Y/_e.locationSize*ve*ee,Me)}}else if(H!==void 0){const N=H[$];if(N!==void 0)switch(N.length){case 2:a.vertexAttrib2fv(_e.location,N);break;case 3:a.vertexAttrib3fv(_e.location,N);break;case 4:a.vertexAttrib4fv(_e.location,N);break;default:a.vertexAttrib1fv(_e.location,N)}}}}O()}function B(){P();for(const V in s){const Q=s[V];for(const fe in Q){const me=Q[fe];for(const j in me){const L=me[j];for(const H in L)_(L[H].object),delete L[H];delete me[j]}}delete s[V]}}function U(V){if(s[V.id]===void 0)return;const Q=s[V.id];for(const fe in Q){const me=Q[fe];for(const j in me){const L=me[j];for(const H in L)_(L[H].object),delete L[H];delete me[j]}}delete s[V.id]}function F(V){for(const Q in s){const fe=s[Q];for(const me in fe){const j=fe[me];if(j[V.id]===void 0)continue;const L=j[V.id];for(const H in L)_(L[H].object),delete L[H];delete j[V.id]}}}function T(V){for(const Q in s){const fe=s[Q],me=V.isInstancedMesh===!0?V.id:0,j=fe[me];if(j!==void 0){for(const L in j){const H=j[L];for(const $ in H)_(H[$].object),delete H[$];delete j[L]}delete fe[me],Object.keys(fe).length===0&&delete s[Q]}}}function P(){q(),f=!0,c!==l&&(c=l,h(c.object))}function q(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:p,reset:P,resetDefaultState:q,dispose:B,releaseStatesOfGeometry:U,releaseStatesOfObject:T,releaseStatesOfProgram:F,initAttributes:C,enableAttribute:y,disableUnusedAttributes:O}}function jA(a,e,i){let s;function l(m){s=m}function c(m,h){a.drawArrays(s,m,h),i.update(h,s,1)}function f(m,h,_){_!==0&&(a.drawArraysInstanced(s,m,h,_),i.update(h,s,_))}function p(m,h,_){if(_===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(s,m,0,h,0,_);let v=0;for(let M=0;M<_;M++)v+=h[M];i.update(v,s,1)}this.setMode=l,this.render=c,this.renderInstances=f,this.renderMultiDraw=p}function JA(a,e,i,s){let l;function c(){if(l!==void 0)return l;if(e.has("EXT_texture_filter_anisotropic")===!0){const F=e.get("EXT_texture_filter_anisotropic");l=a.getParameter(F.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else l=0;return l}function f(F){return!(F!==zi&&s.convert(F)!==a.getParameter(a.IMPLEMENTATION_COLOR_READ_FORMAT))}function p(F){const T=F===Ba&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(F!==Ai&&s.convert(F)!==a.getParameter(a.IMPLEMENTATION_COLOR_READ_TYPE)&&F!==$i&&!T)}function m(F){if(F==="highp"){if(a.getShaderPrecisionFormat(a.VERTEX_SHADER,a.HIGH_FLOAT).precision>0&&a.getShaderPrecisionFormat(a.FRAGMENT_SHADER,a.HIGH_FLOAT).precision>0)return"highp";F="mediump"}return F==="mediump"&&a.getShaderPrecisionFormat(a.VERTEX_SHADER,a.MEDIUM_FLOAT).precision>0&&a.getShaderPrecisionFormat(a.FRAGMENT_SHADER,a.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let h=i.precision!==void 0?i.precision:"highp";const _=m(h);_!==h&&(rt("WebGLRenderer:",h,"not supported, using",_,"instead."),h=_);const g=i.logarithmicDepthBuffer===!0,v=i.reversedDepthBuffer===!0&&e.has("EXT_clip_control");i.reversedDepthBuffer===!0&&v===!1&&rt("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const M=a.getParameter(a.MAX_TEXTURE_IMAGE_UNITS),b=a.getParameter(a.MAX_VERTEX_TEXTURE_IMAGE_UNITS),C=a.getParameter(a.MAX_TEXTURE_SIZE),y=a.getParameter(a.MAX_CUBE_MAP_TEXTURE_SIZE),x=a.getParameter(a.MAX_VERTEX_ATTRIBS),O=a.getParameter(a.MAX_VERTEX_UNIFORM_VECTORS),I=a.getParameter(a.MAX_VARYING_VECTORS),w=a.getParameter(a.MAX_FRAGMENT_UNIFORM_VECTORS),B=a.getParameter(a.MAX_SAMPLES),U=a.getParameter(a.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:c,getMaxPrecision:m,textureFormatReadable:f,textureTypeReadable:p,precision:h,logarithmicDepthBuffer:g,reversedDepthBuffer:v,maxTextures:M,maxVertexTextures:b,maxTextureSize:C,maxCubemapSize:y,maxAttributes:x,maxVertexUniforms:O,maxVaryings:I,maxFragmentUniforms:w,maxSamples:B,samples:U}}function $A(a){const e=this;let i=null,s=0,l=!1,c=!1;const f=new Yr,p=new ot,m={value:null,needsUpdate:!1};this.uniform=m,this.numPlanes=0,this.numIntersection=0,this.init=function(g,v){const M=g.length!==0||v||s!==0||l;return l=v,s=g.length,M},this.beginShadows=function(){c=!0,_(null)},this.endShadows=function(){c=!1},this.setGlobalState=function(g,v){i=_(g,v,0)},this.setState=function(g,v,M){const b=g.clippingPlanes,C=g.clipIntersection,y=g.clipShadows,x=a.get(g);if(!l||b===null||b.length===0||c&&!y)c?_(null):h();else{const O=c?0:s,I=O*4;let w=x.clippingState||null;m.value=w,w=_(b,v,I,M);for(let B=0;B!==I;++B)w[B]=i[B];x.clippingState=w,this.numIntersection=C?this.numPlanes:0,this.numPlanes+=O}};function h(){m.value!==i&&(m.value=i,m.needsUpdate=s>0),e.numPlanes=s,e.numIntersection=0}function _(g,v,M,b){const C=g!==null?g.length:0;let y=null;if(C!==0){if(y=m.value,b!==!0||y===null){const x=M+C*4,O=v.matrixWorldInverse;p.getNormalMatrix(O),(y===null||y.length<x)&&(y=new Float32Array(x));for(let I=0,w=M;I!==C;++I,w+=4)f.copy(g[I]).applyMatrix4(O,p),f.normal.toArray(y,w),y[w+3]=f.constant}m.value=y,m.needsUpdate=!0}return e.numPlanes=C,e.numIntersection=0,y}}const yr=4,h_=[.125,.215,.35,.446,.526,.582],Kr=20,eR=256,il=new Lp,p_=new zt;let hh=null,ph=0,mh=0,gh=!1;const tR=new ce;class m_{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,i=0,s=.1,l=100,c={}){const{size:f=256,position:p=tR}=c;hh=this._renderer.getRenderTarget(),ph=this._renderer.getActiveCubeFace(),mh=this._renderer.getActiveMipmapLevel(),gh=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(f);const m=this._allocateTargets();return m.depthBuffer=!0,this._sceneToCubeUV(e,s,l,m,p),i>0&&this._blur(m,0,0,i),this._applyPMREM(m),this._cleanup(m),m}fromEquirectangular(e,i=null){return this._fromTexture(e,i)}fromCubemap(e,i=null){return this._fromTexture(e,i)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=__(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=v_(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(hh,ph,mh),this._renderer.xr.enabled=gh,e.scissorTest=!1,Zs(e,0,0,e.width,e.height)}_fromTexture(e,i){e.mapping===Jr||e.mapping===$s?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),hh=this._renderer.getRenderTarget(),ph=this._renderer.getActiveCubeFace(),mh=this._renderer.getActiveMipmapLevel(),gh=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const s=i||this._allocateTargets();return this._textureToCubeUV(e,s),this._applyPMREM(s),this._cleanup(s),s}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),i=4*this._cubeSize,s={magFilter:Hn,minFilter:Hn,generateMipmaps:!1,type:Ba,format:zi,colorSpace:pu,depthBuffer:!1},l=g_(e,i,s);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==i){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=g_(e,i,s);const{_lodMax:c}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=nR(c)),this._blurMaterial=aR(c,e,i),this._ggxMaterial=iR(c,e,i)}return l}_compileMaterial(e){const i=new ra(new za,e);this._renderer.compile(i,il)}_sceneToCubeUV(e,i,s,l,c){const m=new Bi(90,1,i,s),h=[1,-1,1,1,1,1],_=[1,1,1,-1,-1,-1],g=this._renderer,v=g.autoClear,M=g.toneMapping;g.getClearColor(p_),g.toneMapping=ta,g.autoClear=!1,g.state.buffers.depth.getReversed()&&(g.setRenderTarget(l),g.clearDepth(),g.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new ra(new gl,new Dx({name:"PMREM.Background",side:$n,depthWrite:!1,depthTest:!1})));const C=this._backgroundBox,y=C.material;let x=!1;const O=e.background;O?O.isColor&&(y.color.copy(O),e.background=null,x=!0):(y.color.copy(p_),x=!0);for(let I=0;I<6;I++){const w=I%3;w===0?(m.up.set(0,h[I],0),m.position.set(c.x,c.y,c.z),m.lookAt(c.x+_[I],c.y,c.z)):w===1?(m.up.set(0,0,h[I]),m.position.set(c.x,c.y,c.z),m.lookAt(c.x,c.y+_[I],c.z)):(m.up.set(0,h[I],0),m.position.set(c.x,c.y,c.z),m.lookAt(c.x,c.y,c.z+_[I]));const B=this._cubeSize;Zs(l,w*B,I>2?B:0,B,B),g.setRenderTarget(l),x&&g.render(C,m),g.render(e,m)}g.toneMapping=M,g.autoClear=v,e.background=O}_textureToCubeUV(e,i){const s=this._renderer,l=e.mapping===Jr||e.mapping===$s;l?(this._cubemapMaterial===null&&(this._cubemapMaterial=__()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=v_());const c=l?this._cubemapMaterial:this._equirectMaterial,f=this._lodMeshes[0];f.material=c;const p=c.uniforms;p.envMap.value=e;const m=this._cubeSize;Zs(i,0,0,3*m,2*m),s.setRenderTarget(i),s.render(f,il)}_applyPMREM(e){const i=this._renderer,s=i.autoClear;i.autoClear=!1;const l=this._lodMeshes.length;for(let c=1;c<l;c++)this._applyGGXFilter(e,c-1,c);i.autoClear=s}_applyGGXFilter(e,i,s){const l=this._renderer,c=this._pingPongRenderTarget,f=this._ggxMaterial,p=this._lodMeshes[s];p.material=f;const m=f.uniforms,h=s/(this._lodMeshes.length-1),_=i/(this._lodMeshes.length-1),g=Math.sqrt(h*h-_*_),v=0+h*1.25,M=g*v,{_lodMax:b}=this,C=this._sizeLods[s],y=3*C*(s>b-yr?s-b+yr:0),x=4*(this._cubeSize-C);m.envMap.value=e.texture,m.roughness.value=M,m.mipInt.value=b-i,Zs(c,y,x,3*C,2*C),l.setRenderTarget(c),l.render(p,il),m.envMap.value=c.texture,m.roughness.value=0,m.mipInt.value=b-s,Zs(e,y,x,3*C,2*C),l.setRenderTarget(e),l.render(p,il)}_blur(e,i,s,l,c){const f=this._pingPongRenderTarget;this._halfBlur(e,f,i,s,l,"latitudinal",c),this._halfBlur(f,e,s,s,l,"longitudinal",c)}_halfBlur(e,i,s,l,c,f,p){const m=this._renderer,h=this._blurMaterial;f!=="latitudinal"&&f!=="longitudinal"&&wt("blur direction must be either latitudinal or longitudinal!");const _=3,g=this._lodMeshes[l];g.material=h;const v=h.uniforms,M=this._sizeLods[s]-1,b=isFinite(c)?Math.PI/(2*M):2*Math.PI/(2*Kr-1),C=c/b,y=isFinite(c)?1+Math.floor(_*C):Kr;y>Kr&&rt(`sigmaRadians, ${c}, is too large and will clip, as it requested ${y} samples when the maximum is set to ${Kr}`);const x=[];let O=0;for(let F=0;F<Kr;++F){const T=F/C,P=Math.exp(-T*T/2);x.push(P),F===0?O+=P:F<y&&(O+=2*P)}for(let F=0;F<x.length;F++)x[F]=x[F]/O;v.envMap.value=e.texture,v.samples.value=y,v.weights.value=x,v.latitudinal.value=f==="latitudinal",p&&(v.poleAxis.value=p);const{_lodMax:I}=this;v.dTheta.value=b,v.mipInt.value=I-s;const w=this._sizeLods[l],B=3*w*(l>I-yr?l-I+yr:0),U=4*(this._cubeSize-w);Zs(i,B,U,3*w,2*w),m.setRenderTarget(i),m.render(g,il)}}function nR(a){const e=[],i=[],s=[];let l=a;const c=a-yr+1+h_.length;for(let f=0;f<c;f++){const p=Math.pow(2,l);e.push(p);let m=1/p;f>a-yr?m=h_[f-a+yr-1]:f===0&&(m=0),i.push(m);const h=1/(p-2),_=-h,g=1+h,v=[_,_,g,_,g,g,_,_,g,g,_,g],M=6,b=6,C=3,y=2,x=1,O=new Float32Array(C*b*M),I=new Float32Array(y*b*M),w=new Float32Array(x*b*M);for(let U=0;U<M;U++){const F=U%3*2/3-1,T=U>2?0:-1,P=[F,T,0,F+2/3,T,0,F+2/3,T+1,0,F,T,0,F+2/3,T+1,0,F,T+1,0];O.set(P,C*b*U),I.set(v,y*b*U);const q=[U,U,U,U,U,U];w.set(q,x*b*U)}const B=new za;B.setAttribute("position",new ia(O,C)),B.setAttribute("uv",new ia(I,y)),B.setAttribute("faceIndex",new ia(w,x)),s.push(new ra(B,null)),l>yr&&l--}return{lodMeshes:s,sizeLods:e,sigmas:i}}function g_(a,e,i){const s=new na(a,e,i);return s.texture.mapping=Eu,s.texture.name="PMREM.cubeUv",s.scissorTest=!0,s}function Zs(a,e,i,s,l){a.viewport.set(e,i,s,l),a.scissor.set(e,i,s,l)}function iR(a,e,i){return new Gi({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:eR,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/i,CUBEUV_MAX_MIP:`${a}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Tu(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:La,depthTest:!1,depthWrite:!1})}function aR(a,e,i){const s=new Float32Array(Kr),l=new ce(0,1,0);return new Gi({name:"SphericalGaussianBlur",defines:{n:Kr,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/i,CUBEUV_MAX_MIP:`${a}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:s},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:l}},vertexShader:Tu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:La,depthTest:!1,depthWrite:!1})}function v_(){return new Gi({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Tu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:La,depthTest:!1,depthWrite:!1})}function __(){return new Gi({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Tu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:La,depthTest:!1,depthWrite:!1})}function Tu(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class Fx extends na{constructor(e=1,i={}){super(e,e,i),this.isWebGLCubeRenderTarget=!0;const s={width:e,height:e,depth:1},l=[s,s,s,s,s,s];this.texture=new Nx(l),this._setTextureOptions(i),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,i){this.texture.type=i.type,this.texture.colorSpace=i.colorSpace,this.texture.generateMipmaps=i.generateMipmaps,this.texture.minFilter=i.minFilter,this.texture.magFilter=i.magFilter;const s={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},l=new gl(5,5,5),c=new Gi({name:"CubemapFromEquirect",uniforms:to(s.uniforms),vertexShader:s.vertexShader,fragmentShader:s.fragmentShader,side:$n,blending:La});c.uniforms.tEquirect.value=i;const f=new ra(l,c),p=i.minFilter;return i.minFilter===Qr&&(i.minFilter=Hn),new c1(1,10,this).update(e,f),i.minFilter=p,f.geometry.dispose(),f.material.dispose(),this}clear(e,i=!0,s=!0,l=!0){const c=e.getRenderTarget();for(let f=0;f<6;f++)e.setRenderTarget(this,f),e.clear(i,s,l);e.setRenderTarget(c)}}function rR(a){let e=new WeakMap,i=new WeakMap,s=null;function l(v,M=!1){return v==null?null:M?f(v):c(v)}function c(v){if(v&&v.isTexture){const M=v.mapping;if(M===Hd||M===Gd)if(e.has(v)){const b=e.get(v).texture;return p(b,v.mapping)}else{const b=v.image;if(b&&b.height>0){const C=new Fx(b.height);return C.fromEquirectangularTexture(a,v),e.set(v,C),v.addEventListener("dispose",h),p(C.texture,v.mapping)}else return null}}return v}function f(v){if(v&&v.isTexture){const M=v.mapping,b=M===Hd||M===Gd,C=M===Jr||M===$s;if(b||C){let y=i.get(v);const x=y!==void 0?y.texture.pmremVersion:0;if(v.isRenderTargetTexture&&v.pmremVersion!==x)return s===null&&(s=new m_(a)),y=b?s.fromEquirectangular(v,y):s.fromCubemap(v,y),y.texture.pmremVersion=v.pmremVersion,i.set(v,y),y.texture;if(y!==void 0)return y.texture;{const O=v.image;return b&&O&&O.height>0||C&&O&&m(O)?(s===null&&(s=new m_(a)),y=b?s.fromEquirectangular(v):s.fromCubemap(v),y.texture.pmremVersion=v.pmremVersion,i.set(v,y),v.addEventListener("dispose",_),y.texture):null}}}return v}function p(v,M){return M===Hd?v.mapping=Jr:M===Gd&&(v.mapping=$s),v}function m(v){let M=0;const b=6;for(let C=0;C<b;C++)v[C]!==void 0&&M++;return M===b}function h(v){const M=v.target;M.removeEventListener("dispose",h);const b=e.get(M);b!==void 0&&(e.delete(M),b.dispose())}function _(v){const M=v.target;M.removeEventListener("dispose",_);const b=i.get(M);b!==void 0&&(i.delete(M),b.dispose())}function g(){e=new WeakMap,i=new WeakMap,s!==null&&(s.dispose(),s=null)}return{get:l,dispose:g}}function sR(a){const e={};function i(s){if(e[s]!==void 0)return e[s];const l=a.getExtension(s);return e[s]=l,l}return{has:function(s){return i(s)!==null},init:function(){i("EXT_color_buffer_float"),i("WEBGL_clip_cull_distance"),i("OES_texture_float_linear"),i("EXT_color_buffer_half_float"),i("WEBGL_multisampled_render_to_texture"),i("WEBGL_render_shared_exponent")},get:function(s){const l=i(s);return l===null&&Qs("WebGLRenderer: "+s+" extension not supported."),l}}}function oR(a,e,i,s){const l={},c=new WeakMap;function f(g){const v=g.target;v.index!==null&&e.remove(v.index);for(const b in v.attributes)e.remove(v.attributes[b]);v.removeEventListener("dispose",f),delete l[v.id];const M=c.get(v);M&&(e.remove(M),c.delete(v)),s.releaseStatesOfGeometry(v),v.isInstancedBufferGeometry===!0&&delete v._maxInstanceCount,i.memory.geometries--}function p(g,v){return l[v.id]===!0||(v.addEventListener("dispose",f),l[v.id]=!0,i.memory.geometries++),v}function m(g){const v=g.attributes;for(const M in v)e.update(v[M],a.ARRAY_BUFFER)}function h(g){const v=[],M=g.index,b=g.attributes.position;let C=0;if(b===void 0)return;if(M!==null){const O=M.array;C=M.version;for(let I=0,w=O.length;I<w;I+=3){const B=O[I+0],U=O[I+1],F=O[I+2];v.push(B,U,U,F,F,B)}}else{const O=b.array;C=b.version;for(let I=0,w=O.length/3-1;I<w;I+=3){const B=I+0,U=I+1,F=I+2;v.push(B,U,U,F,F,B)}}const y=new(b.count>=65535?wx:Cx)(v,1);y.version=C;const x=c.get(g);x&&e.remove(x),c.set(g,y)}function _(g){const v=c.get(g);if(v){const M=g.index;M!==null&&v.version<M.version&&h(g)}else h(g);return c.get(g)}return{get:p,update:m,getWireframeAttribute:_}}function lR(a,e,i){let s;function l(g){s=g}let c,f;function p(g){c=g.type,f=g.bytesPerElement}function m(g,v){a.drawElements(s,v,c,g*f),i.update(v,s,1)}function h(g,v,M){M!==0&&(a.drawElementsInstanced(s,v,c,g*f,M),i.update(v,s,M))}function _(g,v,M){if(M===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(s,v,0,c,g,0,M);let C=0;for(let y=0;y<M;y++)C+=v[y];i.update(C,s,1)}this.setMode=l,this.setIndex=p,this.render=m,this.renderInstances=h,this.renderMultiDraw=_}function cR(a){const e={geometries:0,textures:0},i={frame:0,calls:0,triangles:0,points:0,lines:0};function s(c,f,p){switch(i.calls++,f){case a.TRIANGLES:i.triangles+=p*(c/3);break;case a.LINES:i.lines+=p*(c/2);break;case a.LINE_STRIP:i.lines+=p*(c-1);break;case a.LINE_LOOP:i.lines+=p*c;break;case a.POINTS:i.points+=p*c;break;default:wt("WebGLInfo: Unknown draw mode:",f);break}}function l(){i.calls=0,i.triangles=0,i.points=0,i.lines=0}return{memory:e,render:i,programs:null,autoReset:!0,reset:l,update:s}}function uR(a,e,i){const s=new WeakMap,l=new dn;function c(f,p,m){const h=f.morphTargetInfluences,_=p.morphAttributes.position||p.morphAttributes.normal||p.morphAttributes.color,g=_!==void 0?_.length:0;let v=s.get(p);if(v===void 0||v.count!==g){let P=function(){F.dispose(),s.delete(p),p.removeEventListener("dispose",P)};v!==void 0&&v.texture.dispose();const M=p.morphAttributes.position!==void 0,b=p.morphAttributes.normal!==void 0,C=p.morphAttributes.color!==void 0,y=p.morphAttributes.position||[],x=p.morphAttributes.normal||[],O=p.morphAttributes.color||[];let I=0;M===!0&&(I=1),b===!0&&(I=2),C===!0&&(I=3);let w=p.attributes.position.count*I,B=1;w>e.maxTextureSize&&(B=Math.ceil(w/e.maxTextureSize),w=e.maxTextureSize);const U=new Float32Array(w*B*4*g),F=new Tx(U,w,B,g);F.type=$i,F.needsUpdate=!0;const T=I*4;for(let q=0;q<g;q++){const V=y[q],Q=x[q],fe=O[q],me=w*B*4*q;for(let j=0;j<V.count;j++){const L=j*T;M===!0&&(l.fromBufferAttribute(V,j),U[me+L+0]=l.x,U[me+L+1]=l.y,U[me+L+2]=l.z,U[me+L+3]=0),b===!0&&(l.fromBufferAttribute(Q,j),U[me+L+4]=l.x,U[me+L+5]=l.y,U[me+L+6]=l.z,U[me+L+7]=0),C===!0&&(l.fromBufferAttribute(fe,j),U[me+L+8]=l.x,U[me+L+9]=l.y,U[me+L+10]=l.z,U[me+L+11]=fe.itemSize===4?l.w:1)}}v={count:g,texture:F,size:new Pt(w,B)},s.set(p,v),p.addEventListener("dispose",P)}if(f.isInstancedMesh===!0&&f.morphTexture!==null)m.getUniforms().setValue(a,"morphTexture",f.morphTexture,i);else{let M=0;for(let C=0;C<h.length;C++)M+=h[C];const b=p.morphTargetsRelative?1:1-M;m.getUniforms().setValue(a,"morphTargetBaseInfluence",b),m.getUniforms().setValue(a,"morphTargetInfluences",h)}m.getUniforms().setValue(a,"morphTargetsTexture",v.texture,i),m.getUniforms().setValue(a,"morphTargetsTextureSize",v.size)}return{update:c}}function fR(a,e,i,s,l){let c=new WeakMap;function f(h){const _=l.render.frame,g=h.geometry,v=e.get(h,g);if(c.get(v)!==_&&(e.update(v),c.set(v,_)),h.isInstancedMesh&&(h.hasEventListener("dispose",m)===!1&&h.addEventListener("dispose",m),c.get(h)!==_&&(i.update(h.instanceMatrix,a.ARRAY_BUFFER),h.instanceColor!==null&&i.update(h.instanceColor,a.ARRAY_BUFFER),c.set(h,_))),h.isSkinnedMesh){const M=h.skeleton;c.get(M)!==_&&(M.update(),c.set(M,_))}return v}function p(){c=new WeakMap}function m(h){const _=h.target;_.removeEventListener("dispose",m),s.releaseStatesOfObject(_),i.remove(_.instanceMatrix),_.instanceColor!==null&&i.remove(_.instanceColor)}return{update:f,dispose:p}}const dR={[cx]:"LINEAR_TONE_MAPPING",[ux]:"REINHARD_TONE_MAPPING",[fx]:"CINEON_TONE_MAPPING",[dx]:"ACES_FILMIC_TONE_MAPPING",[px]:"AGX_TONE_MAPPING",[mx]:"NEUTRAL_TONE_MAPPING",[hx]:"CUSTOM_TONE_MAPPING"};function hR(a,e,i,s,l,c){const f=new na(e,i,{type:a,depthBuffer:l,stencilBuffer:c,samples:s?4:0,depthTexture:l?new eo(e,i):void 0}),p=new na(e,i,{type:Ba,depthBuffer:!1,stencilBuffer:!1}),m=new za;m.setAttribute("position",new Pa([-1,3,0,-1,-1,0,3,-1,0],3)),m.setAttribute("uv",new Pa([0,2,0,0,2,0],2));const h=new s1({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),_=new ra(m,h),g=new Lp(-1,1,1,-1,0,1);let v=null,M=null,b=!1,C,y=null,x=[],O=!1;this.setSize=function(I,w){f.setSize(I,w),p.setSize(I,w);for(let B=0;B<x.length;B++){const U=x[B];U.setSize&&U.setSize(I,w)}},this.setEffects=function(I){x=I,O=x.length>0&&x[0].isRenderPass===!0;const w=f.width,B=f.height;for(let U=0;U<x.length;U++){const F=x[U];F.setSize&&F.setSize(w,B)}},this.begin=function(I,w){if(b||I.toneMapping===ta&&x.length===0)return!1;if(y=w,w!==null){const B=w.width,U=w.height;(f.width!==B||f.height!==U)&&this.setSize(B,U)}return O===!1&&I.setRenderTarget(f),C=I.toneMapping,I.toneMapping=ta,!0},this.hasRenderPass=function(){return O},this.end=function(I,w){I.toneMapping=C,b=!0;let B=f,U=p;for(let F=0;F<x.length;F++){const T=x[F];if(T.enabled!==!1&&(T.render(I,U,B,w),T.needsSwap!==!1)){const P=B;B=U,U=P}}if(v!==I.outputColorSpace||M!==I.toneMapping){v=I.outputColorSpace,M=I.toneMapping,h.defines={},Tt.getTransfer(v)===Wt&&(h.defines.SRGB_TRANSFER="");const F=dR[M];F&&(h.defines[F]=""),h.needsUpdate=!0}h.uniforms.tDiffuse.value=B.texture,I.setRenderTarget(y),I.render(_,g),y=null,b=!1},this.isCompositing=function(){return b},this.dispose=function(){f.depthTexture&&f.depthTexture.dispose(),f.dispose(),p.dispose(),m.dispose(),h.dispose()}}const zx=new kn,up=new eo(1,1),Hx=new Tx,Gx=new Ib,Vx=new Nx,x_=[],S_=[],y_=new Float32Array(16),M_=new Float32Array(9),E_=new Float32Array(4);function so(a,e,i){const s=a[0];if(s<=0||s>0)return a;const l=e*i;let c=x_[l];if(c===void 0&&(c=new Float32Array(l),x_[l]=c),e!==0){s.toArray(c,0);for(let f=1,p=0;f!==e;++f)p+=i,a[f].toArray(c,p)}return c}function Tn(a,e){if(a.length!==e.length)return!1;for(let i=0,s=a.length;i<s;i++)if(a[i]!==e[i])return!1;return!0}function An(a,e){for(let i=0,s=e.length;i<s;i++)a[i]=e[i]}function Au(a,e){let i=S_[e];i===void 0&&(i=new Int32Array(e),S_[e]=i);for(let s=0;s!==e;++s)i[s]=a.allocateTextureUnit();return i}function pR(a,e){const i=this.cache;i[0]!==e&&(a.uniform1f(this.addr,e),i[0]=e)}function mR(a,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y)&&(a.uniform2f(this.addr,e.x,e.y),i[0]=e.x,i[1]=e.y);else{if(Tn(i,e))return;a.uniform2fv(this.addr,e),An(i,e)}}function gR(a,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z)&&(a.uniform3f(this.addr,e.x,e.y,e.z),i[0]=e.x,i[1]=e.y,i[2]=e.z);else if(e.r!==void 0)(i[0]!==e.r||i[1]!==e.g||i[2]!==e.b)&&(a.uniform3f(this.addr,e.r,e.g,e.b),i[0]=e.r,i[1]=e.g,i[2]=e.b);else{if(Tn(i,e))return;a.uniform3fv(this.addr,e),An(i,e)}}function vR(a,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z||i[3]!==e.w)&&(a.uniform4f(this.addr,e.x,e.y,e.z,e.w),i[0]=e.x,i[1]=e.y,i[2]=e.z,i[3]=e.w);else{if(Tn(i,e))return;a.uniform4fv(this.addr,e),An(i,e)}}function _R(a,e){const i=this.cache,s=e.elements;if(s===void 0){if(Tn(i,e))return;a.uniformMatrix2fv(this.addr,!1,e),An(i,e)}else{if(Tn(i,s))return;E_.set(s),a.uniformMatrix2fv(this.addr,!1,E_),An(i,s)}}function xR(a,e){const i=this.cache,s=e.elements;if(s===void 0){if(Tn(i,e))return;a.uniformMatrix3fv(this.addr,!1,e),An(i,e)}else{if(Tn(i,s))return;M_.set(s),a.uniformMatrix3fv(this.addr,!1,M_),An(i,s)}}function SR(a,e){const i=this.cache,s=e.elements;if(s===void 0){if(Tn(i,e))return;a.uniformMatrix4fv(this.addr,!1,e),An(i,e)}else{if(Tn(i,s))return;y_.set(s),a.uniformMatrix4fv(this.addr,!1,y_),An(i,s)}}function yR(a,e){const i=this.cache;i[0]!==e&&(a.uniform1i(this.addr,e),i[0]=e)}function MR(a,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y)&&(a.uniform2i(this.addr,e.x,e.y),i[0]=e.x,i[1]=e.y);else{if(Tn(i,e))return;a.uniform2iv(this.addr,e),An(i,e)}}function ER(a,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z)&&(a.uniform3i(this.addr,e.x,e.y,e.z),i[0]=e.x,i[1]=e.y,i[2]=e.z);else{if(Tn(i,e))return;a.uniform3iv(this.addr,e),An(i,e)}}function bR(a,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z||i[3]!==e.w)&&(a.uniform4i(this.addr,e.x,e.y,e.z,e.w),i[0]=e.x,i[1]=e.y,i[2]=e.z,i[3]=e.w);else{if(Tn(i,e))return;a.uniform4iv(this.addr,e),An(i,e)}}function TR(a,e){const i=this.cache;i[0]!==e&&(a.uniform1ui(this.addr,e),i[0]=e)}function AR(a,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y)&&(a.uniform2ui(this.addr,e.x,e.y),i[0]=e.x,i[1]=e.y);else{if(Tn(i,e))return;a.uniform2uiv(this.addr,e),An(i,e)}}function RR(a,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z)&&(a.uniform3ui(this.addr,e.x,e.y,e.z),i[0]=e.x,i[1]=e.y,i[2]=e.z);else{if(Tn(i,e))return;a.uniform3uiv(this.addr,e),An(i,e)}}function CR(a,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z||i[3]!==e.w)&&(a.uniform4ui(this.addr,e.x,e.y,e.z,e.w),i[0]=e.x,i[1]=e.y,i[2]=e.z,i[3]=e.w);else{if(Tn(i,e))return;a.uniform4uiv(this.addr,e),An(i,e)}}function wR(a,e,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(a.uniform1i(this.addr,l),s[0]=l);let c;this.type===a.SAMPLER_2D_SHADOW?(up.compareFunction=i.isReversedDepthBuffer()?Dp:wp,c=up):c=zx,i.setTexture2D(e||c,l)}function DR(a,e,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(a.uniform1i(this.addr,l),s[0]=l),i.setTexture3D(e||Gx,l)}function UR(a,e,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(a.uniform1i(this.addr,l),s[0]=l),i.setTextureCube(e||Vx,l)}function NR(a,e,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(a.uniform1i(this.addr,l),s[0]=l),i.setTexture2DArray(e||Hx,l)}function LR(a){switch(a){case 5126:return pR;case 35664:return mR;case 35665:return gR;case 35666:return vR;case 35674:return _R;case 35675:return xR;case 35676:return SR;case 5124:case 35670:return yR;case 35667:case 35671:return MR;case 35668:case 35672:return ER;case 35669:case 35673:return bR;case 5125:return TR;case 36294:return AR;case 36295:return RR;case 36296:return CR;case 35678:case 36198:case 36298:case 36306:case 35682:return wR;case 35679:case 36299:case 36307:return DR;case 35680:case 36300:case 36308:case 36293:return UR;case 36289:case 36303:case 36311:case 36292:return NR}}function OR(a,e){a.uniform1fv(this.addr,e)}function PR(a,e){const i=so(e,this.size,2);a.uniform2fv(this.addr,i)}function IR(a,e){const i=so(e,this.size,3);a.uniform3fv(this.addr,i)}function BR(a,e){const i=so(e,this.size,4);a.uniform4fv(this.addr,i)}function FR(a,e){const i=so(e,this.size,4);a.uniformMatrix2fv(this.addr,!1,i)}function zR(a,e){const i=so(e,this.size,9);a.uniformMatrix3fv(this.addr,!1,i)}function HR(a,e){const i=so(e,this.size,16);a.uniformMatrix4fv(this.addr,!1,i)}function GR(a,e){a.uniform1iv(this.addr,e)}function VR(a,e){a.uniform2iv(this.addr,e)}function kR(a,e){a.uniform3iv(this.addr,e)}function XR(a,e){a.uniform4iv(this.addr,e)}function WR(a,e){a.uniform1uiv(this.addr,e)}function qR(a,e){a.uniform2uiv(this.addr,e)}function YR(a,e){a.uniform3uiv(this.addr,e)}function ZR(a,e){a.uniform4uiv(this.addr,e)}function KR(a,e,i){const s=this.cache,l=e.length,c=Au(i,l);Tn(s,c)||(a.uniform1iv(this.addr,c),An(s,c));let f;this.type===a.SAMPLER_2D_SHADOW?f=up:f=zx;for(let p=0;p!==l;++p)i.setTexture2D(e[p]||f,c[p])}function QR(a,e,i){const s=this.cache,l=e.length,c=Au(i,l);Tn(s,c)||(a.uniform1iv(this.addr,c),An(s,c));for(let f=0;f!==l;++f)i.setTexture3D(e[f]||Gx,c[f])}function jR(a,e,i){const s=this.cache,l=e.length,c=Au(i,l);Tn(s,c)||(a.uniform1iv(this.addr,c),An(s,c));for(let f=0;f!==l;++f)i.setTextureCube(e[f]||Vx,c[f])}function JR(a,e,i){const s=this.cache,l=e.length,c=Au(i,l);Tn(s,c)||(a.uniform1iv(this.addr,c),An(s,c));for(let f=0;f!==l;++f)i.setTexture2DArray(e[f]||Hx,c[f])}function $R(a){switch(a){case 5126:return OR;case 35664:return PR;case 35665:return IR;case 35666:return BR;case 35674:return FR;case 35675:return zR;case 35676:return HR;case 5124:case 35670:return GR;case 35667:case 35671:return VR;case 35668:case 35672:return kR;case 35669:case 35673:return XR;case 5125:return WR;case 36294:return qR;case 36295:return YR;case 36296:return ZR;case 35678:case 36198:case 36298:case 36306:case 35682:return KR;case 35679:case 36299:case 36307:return QR;case 35680:case 36300:case 36308:case 36293:return jR;case 36289:case 36303:case 36311:case 36292:return JR}}class e2{constructor(e,i,s){this.id=e,this.addr=s,this.cache=[],this.type=i.type,this.setValue=LR(i.type)}}class t2{constructor(e,i,s){this.id=e,this.addr=s,this.cache=[],this.type=i.type,this.size=i.size,this.setValue=$R(i.type)}}class n2{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,i,s){const l=this.seq;for(let c=0,f=l.length;c!==f;++c){const p=l[c];p.setValue(e,i[p.id],s)}}}const vh=/(\w+)(\])?(\[|\.)?/g;function b_(a,e){a.seq.push(e),a.map[e.id]=e}function i2(a,e,i){const s=a.name,l=s.length;for(vh.lastIndex=0;;){const c=vh.exec(s),f=vh.lastIndex;let p=c[1];const m=c[2]==="]",h=c[3];if(m&&(p=p|0),h===void 0||h==="["&&f+2===l){b_(i,h===void 0?new e2(p,a,e):new t2(p,a,e));break}else{let g=i.map[p];g===void 0&&(g=new n2(p),b_(i,g)),i=g}}}class cu{constructor(e,i){this.seq=[],this.map={};const s=e.getProgramParameter(i,e.ACTIVE_UNIFORMS);for(let f=0;f<s;++f){const p=e.getActiveUniform(i,f),m=e.getUniformLocation(i,p.name);i2(p,m,this)}const l=[],c=[];for(const f of this.seq)f.type===e.SAMPLER_2D_SHADOW||f.type===e.SAMPLER_CUBE_SHADOW||f.type===e.SAMPLER_2D_ARRAY_SHADOW?l.push(f):c.push(f);l.length>0&&(this.seq=l.concat(c))}setValue(e,i,s,l){const c=this.map[i];c!==void 0&&c.setValue(e,s,l)}setOptional(e,i,s){const l=i[s];l!==void 0&&this.setValue(e,s,l)}static upload(e,i,s,l){for(let c=0,f=i.length;c!==f;++c){const p=i[c],m=s[p.id];m.needsUpdate!==!1&&p.setValue(e,m.value,l)}}static seqWithValue(e,i){const s=[];for(let l=0,c=e.length;l!==c;++l){const f=e[l];f.id in i&&s.push(f)}return s}}function T_(a,e,i){const s=a.createShader(e);return a.shaderSource(s,i),a.compileShader(s),s}const a2=37297;let r2=0;function s2(a,e){const i=a.split(`
`),s=[],l=Math.max(e-6,0),c=Math.min(e+6,i.length);for(let f=l;f<c;f++){const p=f+1;s.push(`${p===e?">":" "} ${p}: ${i[f]}`)}return s.join(`
`)}const A_=new ot;function o2(a){Tt._getMatrix(A_,Tt.workingColorSpace,a);const e=`mat3( ${A_.elements.map(i=>i.toFixed(4))} )`;switch(Tt.getTransfer(a)){case mu:return[e,"LinearTransferOETF"];case Wt:return[e,"sRGBTransferOETF"];default:return rt("WebGLProgram: Unsupported color space: ",a),[e,"LinearTransferOETF"]}}function R_(a,e,i){const s=a.getShaderParameter(e,a.COMPILE_STATUS),c=(a.getShaderInfoLog(e)||"").trim();if(s&&c==="")return"";const f=/ERROR: 0:(\d+)/.exec(c);if(f){const p=parseInt(f[1]);return i.toUpperCase()+`

`+c+`

`+s2(a.getShaderSource(e),p)}else return c}function l2(a,e){const i=o2(e);return[`vec4 ${a}( vec4 value ) {`,`	return ${i[1]}( vec4( value.rgb * ${i[0]}, value.a ) );`,"}"].join(`
`)}const c2={[cx]:"Linear",[ux]:"Reinhard",[fx]:"Cineon",[dx]:"ACESFilmic",[px]:"AgX",[mx]:"Neutral",[hx]:"Custom"};function u2(a,e){const i=c2[e];return i===void 0?(rt("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+a+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+a+"( vec3 color ) { return "+i+"ToneMapping( color ); }"}const Jc=new ce;function f2(){Tt.getLuminanceCoefficients(Jc);const a=Jc.x.toFixed(4),e=Jc.y.toFixed(4),i=Jc.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${a}, ${e}, ${i} );`,"	return dot( weights, rgb );","}"].join(`
`)}function d2(a){return[a.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",a.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(sl).join(`
`)}function h2(a){const e=[];for(const i in a){const s=a[i];s!==!1&&e.push("#define "+i+" "+s)}return e.join(`
`)}function p2(a,e){const i={},s=a.getProgramParameter(e,a.ACTIVE_ATTRIBUTES);for(let l=0;l<s;l++){const c=a.getActiveAttrib(e,l),f=c.name;let p=1;c.type===a.FLOAT_MAT2&&(p=2),c.type===a.FLOAT_MAT3&&(p=3),c.type===a.FLOAT_MAT4&&(p=4),i[f]={type:c.type,location:a.getAttribLocation(e,f),locationSize:p}}return i}function sl(a){return a!==""}function C_(a,e){const i=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return a.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,i).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function w_(a,e){return a.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const m2=/^[ \t]*#include +<([\w\d./]+)>/gm;function fp(a){return a.replace(m2,v2)}const g2=new Map;function v2(a,e){let i=ht[e];if(i===void 0){const s=g2.get(e);if(s!==void 0)i=ht[s],rt('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,s);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">")}return fp(i)}const _2=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function D_(a){return a.replace(_2,x2)}function x2(a,e,i,s){let l="";for(let c=parseInt(e);c<parseInt(i);c++)l+=s.replace(/\[\s*i\s*\]/g,"[ "+c+" ]").replace(/UNROLLED_LOOP_INDEX/g,c);return l}function U_(a){let e=`precision ${a.precision} float;
	precision ${a.precision} int;
	precision ${a.precision} sampler2D;
	precision ${a.precision} samplerCube;
	precision ${a.precision} sampler3D;
	precision ${a.precision} sampler2DArray;
	precision ${a.precision} sampler2DShadow;
	precision ${a.precision} samplerCubeShadow;
	precision ${a.precision} sampler2DArrayShadow;
	precision ${a.precision} isampler2D;
	precision ${a.precision} isampler3D;
	precision ${a.precision} isamplerCube;
	precision ${a.precision} isampler2DArray;
	precision ${a.precision} usampler2D;
	precision ${a.precision} usampler3D;
	precision ${a.precision} usamplerCube;
	precision ${a.precision} usampler2DArray;
	`;return a.precision==="highp"?e+=`
#define HIGH_PRECISION`:a.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:a.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const S2={[au]:"SHADOWMAP_TYPE_PCF",[rl]:"SHADOWMAP_TYPE_VSM"};function y2(a){return S2[a.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const M2={[Jr]:"ENVMAP_TYPE_CUBE",[$s]:"ENVMAP_TYPE_CUBE",[Eu]:"ENVMAP_TYPE_CUBE_UV"};function E2(a){return a.envMap===!1?"ENVMAP_TYPE_CUBE":M2[a.envMapMode]||"ENVMAP_TYPE_CUBE"}const b2={[$s]:"ENVMAP_MODE_REFRACTION"};function T2(a){return a.envMap===!1?"ENVMAP_MODE_REFLECTION":b2[a.envMapMode]||"ENVMAP_MODE_REFLECTION"}const A2={[lx]:"ENVMAP_BLENDING_MULTIPLY",[mb]:"ENVMAP_BLENDING_MIX",[gb]:"ENVMAP_BLENDING_ADD"};function R2(a){return a.envMap===!1?"ENVMAP_BLENDING_NONE":A2[a.combine]||"ENVMAP_BLENDING_NONE"}function C2(a){const e=a.envMapCubeUVHeight;if(e===null)return null;const i=Math.log2(e)-2,s=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,i),112)),texelHeight:s,maxMip:i}}function w2(a,e,i,s){const l=a.getContext(),c=i.defines;let f=i.vertexShader,p=i.fragmentShader;const m=y2(i),h=E2(i),_=T2(i),g=R2(i),v=C2(i),M=d2(i),b=h2(c),C=l.createProgram();let y,x,O=i.glslVersion?"#version "+i.glslVersion+`
`:"";i.isRawShaderMaterial?(y=["#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,b].filter(sl).join(`
`),y.length>0&&(y+=`
`),x=["#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,b].filter(sl).join(`
`),x.length>0&&(x+=`
`)):(y=[U_(i),"#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,b,i.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",i.batching?"#define USE_BATCHING":"",i.batchingColor?"#define USE_BATCHING_COLOR":"",i.instancing?"#define USE_INSTANCING":"",i.instancingColor?"#define USE_INSTANCING_COLOR":"",i.instancingMorph?"#define USE_INSTANCING_MORPH":"",i.useFog&&i.fog?"#define USE_FOG":"",i.useFog&&i.fogExp2?"#define FOG_EXP2":"",i.map?"#define USE_MAP":"",i.envMap?"#define USE_ENVMAP":"",i.envMap?"#define "+_:"",i.lightMap?"#define USE_LIGHTMAP":"",i.aoMap?"#define USE_AOMAP":"",i.bumpMap?"#define USE_BUMPMAP":"",i.normalMap?"#define USE_NORMALMAP":"",i.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",i.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",i.displacementMap?"#define USE_DISPLACEMENTMAP":"",i.emissiveMap?"#define USE_EMISSIVEMAP":"",i.anisotropy?"#define USE_ANISOTROPY":"",i.anisotropyMap?"#define USE_ANISOTROPYMAP":"",i.clearcoatMap?"#define USE_CLEARCOATMAP":"",i.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",i.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",i.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",i.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",i.specularMap?"#define USE_SPECULARMAP":"",i.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",i.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",i.roughnessMap?"#define USE_ROUGHNESSMAP":"",i.metalnessMap?"#define USE_METALNESSMAP":"",i.alphaMap?"#define USE_ALPHAMAP":"",i.alphaHash?"#define USE_ALPHAHASH":"",i.transmission?"#define USE_TRANSMISSION":"",i.transmissionMap?"#define USE_TRANSMISSIONMAP":"",i.thicknessMap?"#define USE_THICKNESSMAP":"",i.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",i.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",i.mapUv?"#define MAP_UV "+i.mapUv:"",i.alphaMapUv?"#define ALPHAMAP_UV "+i.alphaMapUv:"",i.lightMapUv?"#define LIGHTMAP_UV "+i.lightMapUv:"",i.aoMapUv?"#define AOMAP_UV "+i.aoMapUv:"",i.emissiveMapUv?"#define EMISSIVEMAP_UV "+i.emissiveMapUv:"",i.bumpMapUv?"#define BUMPMAP_UV "+i.bumpMapUv:"",i.normalMapUv?"#define NORMALMAP_UV "+i.normalMapUv:"",i.displacementMapUv?"#define DISPLACEMENTMAP_UV "+i.displacementMapUv:"",i.metalnessMapUv?"#define METALNESSMAP_UV "+i.metalnessMapUv:"",i.roughnessMapUv?"#define ROUGHNESSMAP_UV "+i.roughnessMapUv:"",i.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+i.anisotropyMapUv:"",i.clearcoatMapUv?"#define CLEARCOATMAP_UV "+i.clearcoatMapUv:"",i.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+i.clearcoatNormalMapUv:"",i.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+i.clearcoatRoughnessMapUv:"",i.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+i.iridescenceMapUv:"",i.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+i.iridescenceThicknessMapUv:"",i.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+i.sheenColorMapUv:"",i.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+i.sheenRoughnessMapUv:"",i.specularMapUv?"#define SPECULARMAP_UV "+i.specularMapUv:"",i.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+i.specularColorMapUv:"",i.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+i.specularIntensityMapUv:"",i.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+i.transmissionMapUv:"",i.thicknessMapUv?"#define THICKNESSMAP_UV "+i.thicknessMapUv:"",i.vertexTangents&&i.flatShading===!1?"#define USE_TANGENT":"",i.vertexNormals?"#define HAS_NORMAL":"",i.vertexColors?"#define USE_COLOR":"",i.vertexAlphas?"#define USE_COLOR_ALPHA":"",i.vertexUv1s?"#define USE_UV1":"",i.vertexUv2s?"#define USE_UV2":"",i.vertexUv3s?"#define USE_UV3":"",i.pointsUvs?"#define USE_POINTS_UV":"",i.flatShading?"#define FLAT_SHADED":"",i.skinning?"#define USE_SKINNING":"",i.morphTargets?"#define USE_MORPHTARGETS":"",i.morphNormals&&i.flatShading===!1?"#define USE_MORPHNORMALS":"",i.morphColors?"#define USE_MORPHCOLORS":"",i.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+i.morphTextureStride:"",i.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+i.morphTargetsCount:"",i.doubleSided?"#define DOUBLE_SIDED":"",i.flipSided?"#define FLIP_SIDED":"",i.shadowMapEnabled?"#define USE_SHADOWMAP":"",i.shadowMapEnabled?"#define "+m:"",i.sizeAttenuation?"#define USE_SIZEATTENUATION":"",i.numLightProbes>0?"#define USE_LIGHT_PROBES":"",i.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",i.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(sl).join(`
`),x=[U_(i),"#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,b,i.useFog&&i.fog?"#define USE_FOG":"",i.useFog&&i.fogExp2?"#define FOG_EXP2":"",i.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",i.map?"#define USE_MAP":"",i.matcap?"#define USE_MATCAP":"",i.envMap?"#define USE_ENVMAP":"",i.envMap?"#define "+h:"",i.envMap?"#define "+_:"",i.envMap?"#define "+g:"",v?"#define CUBEUV_TEXEL_WIDTH "+v.texelWidth:"",v?"#define CUBEUV_TEXEL_HEIGHT "+v.texelHeight:"",v?"#define CUBEUV_MAX_MIP "+v.maxMip+".0":"",i.lightMap?"#define USE_LIGHTMAP":"",i.aoMap?"#define USE_AOMAP":"",i.bumpMap?"#define USE_BUMPMAP":"",i.normalMap?"#define USE_NORMALMAP":"",i.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",i.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",i.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",i.emissiveMap?"#define USE_EMISSIVEMAP":"",i.anisotropy?"#define USE_ANISOTROPY":"",i.anisotropyMap?"#define USE_ANISOTROPYMAP":"",i.clearcoat?"#define USE_CLEARCOAT":"",i.clearcoatMap?"#define USE_CLEARCOATMAP":"",i.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",i.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",i.dispersion?"#define USE_DISPERSION":"",i.iridescence?"#define USE_IRIDESCENCE":"",i.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",i.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",i.specularMap?"#define USE_SPECULARMAP":"",i.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",i.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",i.roughnessMap?"#define USE_ROUGHNESSMAP":"",i.metalnessMap?"#define USE_METALNESSMAP":"",i.alphaMap?"#define USE_ALPHAMAP":"",i.alphaTest?"#define USE_ALPHATEST":"",i.alphaHash?"#define USE_ALPHAHASH":"",i.sheen?"#define USE_SHEEN":"",i.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",i.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",i.transmission?"#define USE_TRANSMISSION":"",i.transmissionMap?"#define USE_TRANSMISSIONMAP":"",i.thicknessMap?"#define USE_THICKNESSMAP":"",i.vertexTangents&&i.flatShading===!1?"#define USE_TANGENT":"",i.vertexColors||i.instancingColor?"#define USE_COLOR":"",i.vertexAlphas||i.batchingColor?"#define USE_COLOR_ALPHA":"",i.vertexUv1s?"#define USE_UV1":"",i.vertexUv2s?"#define USE_UV2":"",i.vertexUv3s?"#define USE_UV3":"",i.pointsUvs?"#define USE_POINTS_UV":"",i.gradientMap?"#define USE_GRADIENTMAP":"",i.flatShading?"#define FLAT_SHADED":"",i.doubleSided?"#define DOUBLE_SIDED":"",i.flipSided?"#define FLIP_SIDED":"",i.shadowMapEnabled?"#define USE_SHADOWMAP":"",i.shadowMapEnabled?"#define "+m:"",i.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",i.numLightProbes>0?"#define USE_LIGHT_PROBES":"",i.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",i.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",i.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",i.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",i.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",i.toneMapping!==ta?"#define TONE_MAPPING":"",i.toneMapping!==ta?ht.tonemapping_pars_fragment:"",i.toneMapping!==ta?u2("toneMapping",i.toneMapping):"",i.dithering?"#define DITHERING":"",i.opaque?"#define OPAQUE":"",ht.colorspace_pars_fragment,l2("linearToOutputTexel",i.outputColorSpace),f2(),i.useDepthPacking?"#define DEPTH_PACKING "+i.depthPacking:"",`
`].filter(sl).join(`
`)),f=fp(f),f=C_(f,i),f=w_(f,i),p=fp(p),p=C_(p,i),p=w_(p,i),f=D_(f),p=D_(p),i.isRawShaderMaterial!==!0&&(O=`#version 300 es
`,y=[M,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+y,x=["#define varying in",i.glslVersion===Wv?"":"layout(location = 0) out highp vec4 pc_fragColor;",i.glslVersion===Wv?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+x);const I=O+y+f,w=O+x+p,B=T_(l,l.VERTEX_SHADER,I),U=T_(l,l.FRAGMENT_SHADER,w);l.attachShader(C,B),l.attachShader(C,U),i.index0AttributeName!==void 0?l.bindAttribLocation(C,0,i.index0AttributeName):i.hasPositionAttribute===!0&&l.bindAttribLocation(C,0,"position"),l.linkProgram(C);function F(V){if(a.debug.checkShaderErrors){const Q=l.getProgramInfoLog(C)||"",fe=l.getShaderInfoLog(B)||"",me=l.getShaderInfoLog(U)||"",j=Q.trim(),L=fe.trim(),H=me.trim();let $=!0,_e=!0;if(l.getProgramParameter(C,l.LINK_STATUS)===!1)if($=!1,typeof a.debug.onShaderError=="function")a.debug.onShaderError(l,C,B,U);else{const be=R_(l,B,"vertex"),N=R_(l,U,"fragment");wt("WebGLProgram: Shader Error "+l.getError()+" - VALIDATE_STATUS "+l.getProgramParameter(C,l.VALIDATE_STATUS)+`

Material Name: `+V.name+`
Material Type: `+V.type+`

Program Info Log: `+j+`
`+be+`
`+N)}else j!==""?rt("WebGLProgram: Program Info Log:",j):(L===""||H==="")&&(_e=!1);_e&&(V.diagnostics={runnable:$,programLog:j,vertexShader:{log:L,prefix:y},fragmentShader:{log:H,prefix:x}})}l.deleteShader(B),l.deleteShader(U),T=new cu(l,C),P=p2(l,C)}let T;this.getUniforms=function(){return T===void 0&&F(this),T};let P;this.getAttributes=function(){return P===void 0&&F(this),P};let q=i.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return q===!1&&(q=l.getProgramParameter(C,a2)),q},this.destroy=function(){s.releaseStatesOfProgram(this),l.deleteProgram(C),this.program=void 0},this.type=i.shaderType,this.name=i.shaderName,this.id=r2++,this.cacheKey=e,this.usedTimes=1,this.program=C,this.vertexShader=B,this.fragmentShader=U,this}let D2=0;class U2{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,i,s){const l=this._getShaderCacheForMaterial(e);return l.has(i)===!1&&(l.add(i),i.usedTimes++),l.has(s)===!1&&(l.add(s),s.usedTimes++),this}remove(e){const i=this.materialCache.get(e);for(const s of i)s.usedTimes--,s.usedTimes===0&&this.shaderCache.delete(s.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const i=this.materialCache;let s=i.get(e);return s===void 0&&(s=new Set,i.set(e,s)),s}_getShaderStage(e){const i=this.shaderCache;let s=i.get(e);return s===void 0&&(s=new N2(e),i.set(e,s)),s}}class N2{constructor(e){this.id=D2++,this.code=e,this.usedTimes=0}}function L2(a){return a===$r||a===du||a===hu}function O2(a,e,i,s,l,c){const f=new Ax,p=new U2,m=new Set,h=[],_=new Map,g=s.logarithmicDepthBuffer;let v=s.precision;const M={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function b(T){return m.add(T),T===0?"uv":`uv${T}`}function C(T,P,q,V,Q,fe){const me=V.fog,j=Q.geometry,L=T.isMeshStandardMaterial||T.isMeshLambertMaterial||T.isMeshPhongMaterial?V.environment:null,H=T.isMeshStandardMaterial||T.isMeshLambertMaterial&&!T.envMap||T.isMeshPhongMaterial&&!T.envMap,$=e.get(T.envMap||L,H),_e=$&&$.mapping===Eu?$.image.height:null,be=M[T.type];T.precision!==null&&(v=s.getMaxPrecision(T.precision),v!==T.precision&&rt("WebGLProgram.getParameters:",T.precision,"not supported, using",v,"instead."));const N=j.morphAttributes.position||j.morphAttributes.normal||j.morphAttributes.color,Y=N!==void 0?N.length:0;let de=0;j.morphAttributes.position!==void 0&&(de=1),j.morphAttributes.normal!==void 0&&(de=2),j.morphAttributes.color!==void 0&&(de=3);let Te,Ce,ee,Me;if(be){const Oe=Ji[be];Te=Oe.vertexShader,Ce=Oe.fragmentShader}else{Te=T.vertexShader,Ce=T.fragmentShader;const Oe=p.getVertexShaderStage(T),gt=p.getFragmentShaderStage(T);p.update(T,Oe,gt),ee=Oe.id,Me=gt.id}const ve=a.getRenderTarget(),He=a.state.buffers.depth.getReversed(),nt=Q.isInstancedMesh===!0,je=Q.isBatchedMesh===!0,Dt=!!T.map,ut=!!T.matcap,pt=!!$,mt=!!T.aoMap,dt=!!T.lightMap,qt=!!T.bumpMap&&T.wireframe===!1,$t=!!T.normalMap,Ut=!!T.displacementMap,cn=!!T.emissiveMap,Yt=!!T.metalnessMap,St=!!T.roughnessMap,X=T.anisotropy>0,Bt=T.clearcoat>0,Ct=T.dispersion>0,D=T.iridescence>0,E=T.sheen>0,K=T.transmission>0,se=X&&!!T.anisotropyMap,he=Bt&&!!T.clearcoatMap,De=Bt&&!!T.clearcoatNormalMap,Le=Bt&&!!T.clearcoatRoughnessMap,pe=D&&!!T.iridescenceMap,ge=D&&!!T.iridescenceThicknessMap,Ne=E&&!!T.sheenColorMap,Ve=E&&!!T.sheenRoughnessMap,Be=!!T.specularMap,Ie=!!T.specularColorMap,Ye=!!T.specularIntensityMap,$e=K&&!!T.transmissionMap,at=K&&!!T.thicknessMap,k=!!T.gradientMap,Ue=!!T.alphaMap,te=T.alphaTest>0,Ae=!!T.alphaHash,we=!!T.extensions;let Se=ta;T.toneMapped&&(ve===null||ve.isXRRenderTarget===!0)&&(Se=a.toneMapping);const We={shaderID:be,shaderType:T.type,shaderName:T.name,vertexShader:Te,fragmentShader:Ce,defines:T.defines,customVertexShaderID:ee,customFragmentShaderID:Me,isRawShaderMaterial:T.isRawShaderMaterial===!0,glslVersion:T.glslVersion,precision:v,batching:je,batchingColor:je&&Q._colorsTexture!==null,instancing:nt,instancingColor:nt&&Q.instanceColor!==null,instancingMorph:nt&&Q.morphTexture!==null,outputColorSpace:ve===null?a.outputColorSpace:ve.isXRRenderTarget===!0?ve.texture.colorSpace:Tt.workingColorSpace,alphaToCoverage:!!T.alphaToCoverage,map:Dt,matcap:ut,envMap:pt,envMapMode:pt&&$.mapping,envMapCubeUVHeight:_e,aoMap:mt,lightMap:dt,bumpMap:qt,normalMap:$t,displacementMap:Ut,emissiveMap:cn,normalMapObjectSpace:$t&&T.normalMapType===xb,normalMapTangentSpace:$t&&T.normalMapType===Vv,packedNormalMap:$t&&T.normalMapType===Vv&&L2(T.normalMap.format),metalnessMap:Yt,roughnessMap:St,anisotropy:X,anisotropyMap:se,clearcoat:Bt,clearcoatMap:he,clearcoatNormalMap:De,clearcoatRoughnessMap:Le,dispersion:Ct,iridescence:D,iridescenceMap:pe,iridescenceThicknessMap:ge,sheen:E,sheenColorMap:Ne,sheenRoughnessMap:Ve,specularMap:Be,specularColorMap:Ie,specularIntensityMap:Ye,transmission:K,transmissionMap:$e,thicknessMap:at,gradientMap:k,opaque:T.transparent===!1&&T.blending===Ks&&T.alphaToCoverage===!1,alphaMap:Ue,alphaTest:te,alphaHash:Ae,combine:T.combine,mapUv:Dt&&b(T.map.channel),aoMapUv:mt&&b(T.aoMap.channel),lightMapUv:dt&&b(T.lightMap.channel),bumpMapUv:qt&&b(T.bumpMap.channel),normalMapUv:$t&&b(T.normalMap.channel),displacementMapUv:Ut&&b(T.displacementMap.channel),emissiveMapUv:cn&&b(T.emissiveMap.channel),metalnessMapUv:Yt&&b(T.metalnessMap.channel),roughnessMapUv:St&&b(T.roughnessMap.channel),anisotropyMapUv:se&&b(T.anisotropyMap.channel),clearcoatMapUv:he&&b(T.clearcoatMap.channel),clearcoatNormalMapUv:De&&b(T.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Le&&b(T.clearcoatRoughnessMap.channel),iridescenceMapUv:pe&&b(T.iridescenceMap.channel),iridescenceThicknessMapUv:ge&&b(T.iridescenceThicknessMap.channel),sheenColorMapUv:Ne&&b(T.sheenColorMap.channel),sheenRoughnessMapUv:Ve&&b(T.sheenRoughnessMap.channel),specularMapUv:Be&&b(T.specularMap.channel),specularColorMapUv:Ie&&b(T.specularColorMap.channel),specularIntensityMapUv:Ye&&b(T.specularIntensityMap.channel),transmissionMapUv:$e&&b(T.transmissionMap.channel),thicknessMapUv:at&&b(T.thicknessMap.channel),alphaMapUv:Ue&&b(T.alphaMap.channel),vertexTangents:!!j.attributes.tangent&&($t||X),vertexNormals:!!j.attributes.normal,vertexColors:T.vertexColors,vertexAlphas:T.vertexColors===!0&&!!j.attributes.color&&j.attributes.color.itemSize===4,pointsUvs:Q.isPoints===!0&&!!j.attributes.uv&&(Dt||Ue),fog:!!me,useFog:T.fog===!0,fogExp2:!!me&&me.isFogExp2,flatShading:T.wireframe===!1&&(T.flatShading===!0||j.attributes.normal===void 0&&$t===!1&&(T.isMeshLambertMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isMeshPhysicalMaterial)),sizeAttenuation:T.sizeAttenuation===!0,logarithmicDepthBuffer:g,reversedDepthBuffer:He,skinning:Q.isSkinnedMesh===!0,hasPositionAttribute:j.attributes.position!==void 0,morphTargets:j.morphAttributes.position!==void 0,morphNormals:j.morphAttributes.normal!==void 0,morphColors:j.morphAttributes.color!==void 0,morphTargetsCount:Y,morphTextureStride:de,numDirLights:P.directional.length,numPointLights:P.point.length,numSpotLights:P.spot.length,numSpotLightMaps:P.spotLightMap.length,numRectAreaLights:P.rectArea.length,numHemiLights:P.hemi.length,numDirLightShadows:P.directionalShadowMap.length,numPointLightShadows:P.pointShadowMap.length,numSpotLightShadows:P.spotShadowMap.length,numSpotLightShadowsWithMaps:P.numSpotLightShadowsWithMaps,numLightProbes:P.numLightProbes,numLightProbeGrids:fe.length,numClippingPlanes:c.numPlanes,numClipIntersection:c.numIntersection,dithering:T.dithering,shadowMapEnabled:a.shadowMap.enabled&&q.length>0,shadowMapType:a.shadowMap.type,toneMapping:Se,decodeVideoTexture:Dt&&T.map.isVideoTexture===!0&&Tt.getTransfer(T.map.colorSpace)===Wt,decodeVideoTextureEmissive:cn&&T.emissiveMap.isVideoTexture===!0&&Tt.getTransfer(T.emissiveMap.colorSpace)===Wt,premultipliedAlpha:T.premultipliedAlpha,doubleSided:T.side===Ua,flipSided:T.side===$n,useDepthPacking:T.depthPacking>=0,depthPacking:T.depthPacking||0,index0AttributeName:T.index0AttributeName,extensionClipCullDistance:we&&T.extensions.clipCullDistance===!0&&i.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(we&&T.extensions.multiDraw===!0||je)&&i.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:T.customProgramCacheKey()};return We.vertexUv1s=m.has(1),We.vertexUv2s=m.has(2),We.vertexUv3s=m.has(3),m.clear(),We}function y(T){const P=[];if(T.shaderID?P.push(T.shaderID):(P.push(T.customVertexShaderID),P.push(T.customFragmentShaderID)),T.defines!==void 0)for(const q in T.defines)P.push(q),P.push(T.defines[q]);return T.isRawShaderMaterial===!1&&(x(P,T),O(P,T),P.push(a.outputColorSpace)),P.push(T.customProgramCacheKey),P.join()}function x(T,P){T.push(P.precision),T.push(P.outputColorSpace),T.push(P.envMapMode),T.push(P.envMapCubeUVHeight),T.push(P.mapUv),T.push(P.alphaMapUv),T.push(P.lightMapUv),T.push(P.aoMapUv),T.push(P.bumpMapUv),T.push(P.normalMapUv),T.push(P.displacementMapUv),T.push(P.emissiveMapUv),T.push(P.metalnessMapUv),T.push(P.roughnessMapUv),T.push(P.anisotropyMapUv),T.push(P.clearcoatMapUv),T.push(P.clearcoatNormalMapUv),T.push(P.clearcoatRoughnessMapUv),T.push(P.iridescenceMapUv),T.push(P.iridescenceThicknessMapUv),T.push(P.sheenColorMapUv),T.push(P.sheenRoughnessMapUv),T.push(P.specularMapUv),T.push(P.specularColorMapUv),T.push(P.specularIntensityMapUv),T.push(P.transmissionMapUv),T.push(P.thicknessMapUv),T.push(P.combine),T.push(P.fogExp2),T.push(P.sizeAttenuation),T.push(P.morphTargetsCount),T.push(P.morphAttributeCount),T.push(P.numDirLights),T.push(P.numPointLights),T.push(P.numSpotLights),T.push(P.numSpotLightMaps),T.push(P.numHemiLights),T.push(P.numRectAreaLights),T.push(P.numDirLightShadows),T.push(P.numPointLightShadows),T.push(P.numSpotLightShadows),T.push(P.numSpotLightShadowsWithMaps),T.push(P.numLightProbes),T.push(P.shadowMapType),T.push(P.toneMapping),T.push(P.numClippingPlanes),T.push(P.numClipIntersection),T.push(P.depthPacking)}function O(T,P){f.disableAll(),P.instancing&&f.enable(0),P.instancingColor&&f.enable(1),P.instancingMorph&&f.enable(2),P.matcap&&f.enable(3),P.envMap&&f.enable(4),P.normalMapObjectSpace&&f.enable(5),P.normalMapTangentSpace&&f.enable(6),P.clearcoat&&f.enable(7),P.iridescence&&f.enable(8),P.alphaTest&&f.enable(9),P.vertexColors&&f.enable(10),P.vertexAlphas&&f.enable(11),P.vertexUv1s&&f.enable(12),P.vertexUv2s&&f.enable(13),P.vertexUv3s&&f.enable(14),P.vertexTangents&&f.enable(15),P.anisotropy&&f.enable(16),P.alphaHash&&f.enable(17),P.batching&&f.enable(18),P.dispersion&&f.enable(19),P.batchingColor&&f.enable(20),P.gradientMap&&f.enable(21),P.packedNormalMap&&f.enable(22),P.vertexNormals&&f.enable(23),T.push(f.mask),f.disableAll(),P.fog&&f.enable(0),P.useFog&&f.enable(1),P.flatShading&&f.enable(2),P.logarithmicDepthBuffer&&f.enable(3),P.reversedDepthBuffer&&f.enable(4),P.skinning&&f.enable(5),P.morphTargets&&f.enable(6),P.morphNormals&&f.enable(7),P.morphColors&&f.enable(8),P.premultipliedAlpha&&f.enable(9),P.shadowMapEnabled&&f.enable(10),P.doubleSided&&f.enable(11),P.flipSided&&f.enable(12),P.useDepthPacking&&f.enable(13),P.dithering&&f.enable(14),P.transmission&&f.enable(15),P.sheen&&f.enable(16),P.opaque&&f.enable(17),P.pointsUvs&&f.enable(18),P.decodeVideoTexture&&f.enable(19),P.decodeVideoTextureEmissive&&f.enable(20),P.alphaToCoverage&&f.enable(21),P.numLightProbeGrids>0&&f.enable(22),P.hasPositionAttribute&&f.enable(23),T.push(f.mask)}function I(T){const P=M[T.type];let q;if(P){const V=Ji[P];q=i1.clone(V.uniforms)}else q=T.uniforms;return q}function w(T,P){let q=_.get(P);return q!==void 0?++q.usedTimes:(q=new w2(a,P,T,l),h.push(q),_.set(P,q)),q}function B(T){if(--T.usedTimes===0){const P=h.indexOf(T);h[P]=h[h.length-1],h.pop(),_.delete(T.cacheKey),T.destroy()}}function U(T){p.remove(T)}function F(){p.dispose()}return{getParameters:C,getProgramCacheKey:y,getUniforms:I,acquireProgram:w,releaseProgram:B,releaseShaderCache:U,programs:h,dispose:F}}function P2(){let a=new WeakMap;function e(f){return a.has(f)}function i(f){let p=a.get(f);return p===void 0&&(p={},a.set(f,p)),p}function s(f){a.delete(f)}function l(f,p,m){a.get(f)[p]=m}function c(){a=new WeakMap}return{has:e,get:i,remove:s,update:l,dispose:c}}function I2(a,e){return a.groupOrder!==e.groupOrder?a.groupOrder-e.groupOrder:a.renderOrder!==e.renderOrder?a.renderOrder-e.renderOrder:a.material.id!==e.material.id?a.material.id-e.material.id:a.materialVariant!==e.materialVariant?a.materialVariant-e.materialVariant:a.z!==e.z?a.z-e.z:a.id-e.id}function N_(a,e){return a.groupOrder!==e.groupOrder?a.groupOrder-e.groupOrder:a.renderOrder!==e.renderOrder?a.renderOrder-e.renderOrder:a.z!==e.z?e.z-a.z:a.id-e.id}function L_(){const a=[];let e=0;const i=[],s=[],l=[];function c(){e=0,i.length=0,s.length=0,l.length=0}function f(v){let M=0;return v.isInstancedMesh&&(M+=2),v.isSkinnedMesh&&(M+=1),M}function p(v,M,b,C,y,x){let O=a[e];return O===void 0?(O={id:v.id,object:v,geometry:M,material:b,materialVariant:f(v),groupOrder:C,renderOrder:v.renderOrder,z:y,group:x},a[e]=O):(O.id=v.id,O.object=v,O.geometry=M,O.material=b,O.materialVariant=f(v),O.groupOrder=C,O.renderOrder=v.renderOrder,O.z=y,O.group=x),e++,O}function m(v,M,b,C,y,x){const O=p(v,M,b,C,y,x);b.transmission>0?s.push(O):b.transparent===!0?l.push(O):i.push(O)}function h(v,M,b,C,y,x){const O=p(v,M,b,C,y,x);b.transmission>0?s.unshift(O):b.transparent===!0?l.unshift(O):i.unshift(O)}function _(v,M,b){i.length>1&&i.sort(v||I2),s.length>1&&s.sort(M||N_),l.length>1&&l.sort(M||N_),b&&(i.reverse(),s.reverse(),l.reverse())}function g(){for(let v=e,M=a.length;v<M;v++){const b=a[v];if(b.id===null)break;b.id=null,b.object=null,b.geometry=null,b.material=null,b.group=null}}return{opaque:i,transmissive:s,transparent:l,init:c,push:m,unshift:h,finish:g,sort:_}}function B2(){let a=new WeakMap;function e(s,l){const c=a.get(s);let f;return c===void 0?(f=new L_,a.set(s,[f])):l>=c.length?(f=new L_,c.push(f)):f=c[l],f}function i(){a=new WeakMap}return{get:e,dispose:i}}function F2(){const a={};return{get:function(e){if(a[e.id]!==void 0)return a[e.id];let i;switch(e.type){case"DirectionalLight":i={direction:new ce,color:new zt};break;case"SpotLight":i={position:new ce,direction:new ce,color:new zt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":i={position:new ce,color:new zt,distance:0,decay:0};break;case"HemisphereLight":i={direction:new ce,skyColor:new zt,groundColor:new zt};break;case"RectAreaLight":i={color:new zt,position:new ce,halfWidth:new ce,halfHeight:new ce};break}return a[e.id]=i,i}}}function z2(){const a={};return{get:function(e){if(a[e.id]!==void 0)return a[e.id];let i;switch(e.type){case"DirectionalLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Pt};break;case"SpotLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Pt};break;case"PointLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Pt,shadowCameraNear:1,shadowCameraFar:1e3};break}return a[e.id]=i,i}}}let H2=0;function G2(a,e){return(e.castShadow?2:0)-(a.castShadow?2:0)+(e.map?1:0)-(a.map?1:0)}function V2(a){const e=new F2,i=z2(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)s.probe.push(new ce);const l=new ce,c=new Mn,f=new Mn;function p(h){let _=0,g=0,v=0;for(let P=0;P<9;P++)s.probe[P].set(0,0,0);let M=0,b=0,C=0,y=0,x=0,O=0,I=0,w=0,B=0,U=0,F=0;h.sort(G2);for(let P=0,q=h.length;P<q;P++){const V=h[P],Q=V.color,fe=V.intensity,me=V.distance;let j=null;if(V.shadow&&V.shadow.map&&(V.shadow.map.texture.format===$r?j=V.shadow.map.texture:j=V.shadow.map.depthTexture||V.shadow.map.texture),V.isAmbientLight)_+=Q.r*fe,g+=Q.g*fe,v+=Q.b*fe;else if(V.isLightProbe){for(let L=0;L<9;L++)s.probe[L].addScaledVector(V.sh.coefficients[L],fe);F++}else if(V.isDirectionalLight){const L=e.get(V);if(L.color.copy(V.color).multiplyScalar(V.intensity),V.castShadow){const H=V.shadow,$=i.get(V);$.shadowIntensity=H.intensity,$.shadowBias=H.bias,$.shadowNormalBias=H.normalBias,$.shadowRadius=H.radius,$.shadowMapSize=H.mapSize,s.directionalShadow[M]=$,s.directionalShadowMap[M]=j,s.directionalShadowMatrix[M]=V.shadow.matrix,O++}s.directional[M]=L,M++}else if(V.isSpotLight){const L=e.get(V);L.position.setFromMatrixPosition(V.matrixWorld),L.color.copy(Q).multiplyScalar(fe),L.distance=me,L.coneCos=Math.cos(V.angle),L.penumbraCos=Math.cos(V.angle*(1-V.penumbra)),L.decay=V.decay,s.spot[C]=L;const H=V.shadow;if(V.map&&(s.spotLightMap[B]=V.map,B++,H.updateMatrices(V),V.castShadow&&U++),s.spotLightMatrix[C]=H.matrix,V.castShadow){const $=i.get(V);$.shadowIntensity=H.intensity,$.shadowBias=H.bias,$.shadowNormalBias=H.normalBias,$.shadowRadius=H.radius,$.shadowMapSize=H.mapSize,s.spotShadow[C]=$,s.spotShadowMap[C]=j,w++}C++}else if(V.isRectAreaLight){const L=e.get(V);L.color.copy(Q).multiplyScalar(fe),L.halfWidth.set(V.width*.5,0,0),L.halfHeight.set(0,V.height*.5,0),s.rectArea[y]=L,y++}else if(V.isPointLight){const L=e.get(V);if(L.color.copy(V.color).multiplyScalar(V.intensity),L.distance=V.distance,L.decay=V.decay,V.castShadow){const H=V.shadow,$=i.get(V);$.shadowIntensity=H.intensity,$.shadowBias=H.bias,$.shadowNormalBias=H.normalBias,$.shadowRadius=H.radius,$.shadowMapSize=H.mapSize,$.shadowCameraNear=H.camera.near,$.shadowCameraFar=H.camera.far,s.pointShadow[b]=$,s.pointShadowMap[b]=j,s.pointShadowMatrix[b]=V.shadow.matrix,I++}s.point[b]=L,b++}else if(V.isHemisphereLight){const L=e.get(V);L.skyColor.copy(V.color).multiplyScalar(fe),L.groundColor.copy(V.groundColor).multiplyScalar(fe),s.hemi[x]=L,x++}}y>0&&(a.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=Ge.LTC_FLOAT_1,s.rectAreaLTC2=Ge.LTC_FLOAT_2):(s.rectAreaLTC1=Ge.LTC_HALF_1,s.rectAreaLTC2=Ge.LTC_HALF_2)),s.ambient[0]=_,s.ambient[1]=g,s.ambient[2]=v;const T=s.hash;(T.directionalLength!==M||T.pointLength!==b||T.spotLength!==C||T.rectAreaLength!==y||T.hemiLength!==x||T.numDirectionalShadows!==O||T.numPointShadows!==I||T.numSpotShadows!==w||T.numSpotMaps!==B||T.numLightProbes!==F)&&(s.directional.length=M,s.spot.length=C,s.rectArea.length=y,s.point.length=b,s.hemi.length=x,s.directionalShadow.length=O,s.directionalShadowMap.length=O,s.pointShadow.length=I,s.pointShadowMap.length=I,s.spotShadow.length=w,s.spotShadowMap.length=w,s.directionalShadowMatrix.length=O,s.pointShadowMatrix.length=I,s.spotLightMatrix.length=w+B-U,s.spotLightMap.length=B,s.numSpotLightShadowsWithMaps=U,s.numLightProbes=F,T.directionalLength=M,T.pointLength=b,T.spotLength=C,T.rectAreaLength=y,T.hemiLength=x,T.numDirectionalShadows=O,T.numPointShadows=I,T.numSpotShadows=w,T.numSpotMaps=B,T.numLightProbes=F,s.version=H2++)}function m(h,_){let g=0,v=0,M=0,b=0,C=0;const y=_.matrixWorldInverse;for(let x=0,O=h.length;x<O;x++){const I=h[x];if(I.isDirectionalLight){const w=s.directional[g];w.direction.setFromMatrixPosition(I.matrixWorld),l.setFromMatrixPosition(I.target.matrixWorld),w.direction.sub(l),w.direction.transformDirection(y),g++}else if(I.isSpotLight){const w=s.spot[M];w.position.setFromMatrixPosition(I.matrixWorld),w.position.applyMatrix4(y),w.direction.setFromMatrixPosition(I.matrixWorld),l.setFromMatrixPosition(I.target.matrixWorld),w.direction.sub(l),w.direction.transformDirection(y),M++}else if(I.isRectAreaLight){const w=s.rectArea[b];w.position.setFromMatrixPosition(I.matrixWorld),w.position.applyMatrix4(y),f.identity(),c.copy(I.matrixWorld),c.premultiply(y),f.extractRotation(c),w.halfWidth.set(I.width*.5,0,0),w.halfHeight.set(0,I.height*.5,0),w.halfWidth.applyMatrix4(f),w.halfHeight.applyMatrix4(f),b++}else if(I.isPointLight){const w=s.point[v];w.position.setFromMatrixPosition(I.matrixWorld),w.position.applyMatrix4(y),v++}else if(I.isHemisphereLight){const w=s.hemi[C];w.direction.setFromMatrixPosition(I.matrixWorld),w.direction.transformDirection(y),C++}}}return{setup:p,setupView:m,state:s}}function O_(a){const e=new V2(a),i=[],s=[],l=[];function c(v){g.camera=v,i.length=0,s.length=0,l.length=0}function f(v){i.push(v)}function p(v){s.push(v)}function m(v){l.push(v)}function h(){e.setup(i)}function _(v){e.setupView(i,v)}const g={lightsArray:i,shadowsArray:s,lightProbeGridArray:l,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:c,state:g,setupLights:h,setupLightsView:_,pushLight:f,pushShadow:p,pushLightProbeGrid:m}}function k2(a){let e=new WeakMap;function i(l,c=0){const f=e.get(l);let p;return f===void 0?(p=new O_(a),e.set(l,[p])):c>=f.length?(p=new O_(a),f.push(p)):p=f[c],p}function s(){e=new WeakMap}return{get:i,dispose:s}}const X2=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,W2=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,q2=[new ce(1,0,0),new ce(-1,0,0),new ce(0,1,0),new ce(0,-1,0),new ce(0,0,1),new ce(0,0,-1)],Y2=[new ce(0,-1,0),new ce(0,-1,0),new ce(0,0,1),new ce(0,0,-1),new ce(0,-1,0),new ce(0,-1,0)],P_=new Mn,al=new ce,_h=new ce;function Z2(a,e,i){let s=new Ux;const l=new Pt,c=new Pt,f=new dn,p=new o1,m=new l1,h={},_=i.maxTextureSize,g={[Mr]:$n,[$n]:Mr,[Ua]:Ua},v=new Gi({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Pt},radius:{value:4}},vertexShader:X2,fragmentShader:W2}),M=v.clone();M.defines.HORIZONTAL_PASS=1;const b=new za;b.setAttribute("position",new ia(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const C=new ra(b,v),y=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=au;let x=this.type;this.render=function(U,F,T){if(y.enabled===!1||y.autoUpdate===!1&&y.needsUpdate===!1||U.length===0)return;this.type===QE&&(rt("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=au);const P=a.getRenderTarget(),q=a.getActiveCubeFace(),V=a.getActiveMipmapLevel(),Q=a.state;Q.setBlending(La),Q.buffers.depth.getReversed()===!0?Q.buffers.color.setClear(0,0,0,0):Q.buffers.color.setClear(1,1,1,1),Q.buffers.depth.setTest(!0),Q.setScissorTest(!1);const fe=x!==this.type;fe&&F.traverse(function(me){me.material&&(Array.isArray(me.material)?me.material.forEach(j=>j.needsUpdate=!0):me.material.needsUpdate=!0)});for(let me=0,j=U.length;me<j;me++){const L=U[me],H=L.shadow;if(H===void 0){rt("WebGLShadowMap:",L,"has no shadow.");continue}if(H.autoUpdate===!1&&H.needsUpdate===!1)continue;l.copy(H.mapSize);const $=H.getFrameExtents();l.multiply($),c.copy(H.mapSize),(l.x>_||l.y>_)&&(l.x>_&&(c.x=Math.floor(_/$.x),l.x=c.x*$.x,H.mapSize.x=c.x),l.y>_&&(c.y=Math.floor(_/$.y),l.y=c.y*$.y,H.mapSize.y=c.y));const _e=a.state.buffers.depth.getReversed();if(H.camera._reversedDepth=_e,H.map===null||fe===!0){if(H.map!==null&&(H.map.depthTexture!==null&&(H.map.depthTexture.dispose(),H.map.depthTexture=null),H.map.dispose()),this.type===rl){if(L.isPointLight){rt("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}H.map=new na(l.x,l.y,{format:$r,type:Ba,minFilter:Hn,magFilter:Hn,generateMipmaps:!1}),H.map.texture.name=L.name+".shadowMap",H.map.depthTexture=new eo(l.x,l.y,$i),H.map.depthTexture.name=L.name+".shadowMapDepth",H.map.depthTexture.format=Fa,H.map.depthTexture.compareFunction=null,H.map.depthTexture.minFilter=Pn,H.map.depthTexture.magFilter=Pn}else L.isPointLight?(H.map=new Fx(l.x),H.map.depthTexture=new t1(l.x,aa)):(H.map=new na(l.x,l.y),H.map.depthTexture=new eo(l.x,l.y,aa)),H.map.depthTexture.name=L.name+".shadowMap",H.map.depthTexture.format=Fa,this.type===au?(H.map.depthTexture.compareFunction=_e?Dp:wp,H.map.depthTexture.minFilter=Hn,H.map.depthTexture.magFilter=Hn):(H.map.depthTexture.compareFunction=null,H.map.depthTexture.minFilter=Pn,H.map.depthTexture.magFilter=Pn);H.camera.updateProjectionMatrix()}const be=H.map.isWebGLCubeRenderTarget?6:1;for(let N=0;N<be;N++){if(H.map.isWebGLCubeRenderTarget)a.setRenderTarget(H.map,N),a.clear();else{N===0&&(a.setRenderTarget(H.map),a.clear());const Y=H.getViewport(N);f.set(c.x*Y.x,c.y*Y.y,c.x*Y.z,c.y*Y.w),Q.viewport(f)}if(L.isPointLight){const Y=H.camera,de=H.matrix,Te=L.distance||Y.far;Te!==Y.far&&(Y.far=Te,Y.updateProjectionMatrix()),al.setFromMatrixPosition(L.matrixWorld),Y.position.copy(al),_h.copy(Y.position),_h.add(q2[N]),Y.up.copy(Y2[N]),Y.lookAt(_h),Y.updateMatrixWorld(),de.makeTranslation(-al.x,-al.y,-al.z),P_.multiplyMatrices(Y.projectionMatrix,Y.matrixWorldInverse),H._frustum.setFromProjectionMatrix(P_,Y.coordinateSystem,Y.reversedDepth)}else H.updateMatrices(L);s=H.getFrustum(),w(F,T,H.camera,L,this.type)}H.isPointLightShadow!==!0&&this.type===rl&&O(H,T),H.needsUpdate=!1}x=this.type,y.needsUpdate=!1,a.setRenderTarget(P,q,V)};function O(U,F){const T=e.update(C);v.defines.VSM_SAMPLES!==U.blurSamples&&(v.defines.VSM_SAMPLES=U.blurSamples,M.defines.VSM_SAMPLES=U.blurSamples,v.needsUpdate=!0,M.needsUpdate=!0),U.mapPass===null&&(U.mapPass=new na(l.x,l.y,{format:$r,type:Ba})),v.uniforms.shadow_pass.value=U.map.depthTexture,v.uniforms.resolution.value=U.mapSize,v.uniforms.radius.value=U.radius,a.setRenderTarget(U.mapPass),a.clear(),a.renderBufferDirect(F,null,T,v,C,null),M.uniforms.shadow_pass.value=U.mapPass.texture,M.uniforms.resolution.value=U.mapSize,M.uniforms.radius.value=U.radius,a.setRenderTarget(U.map),a.clear(),a.renderBufferDirect(F,null,T,M,C,null)}function I(U,F,T,P){let q=null;const V=T.isPointLight===!0?U.customDistanceMaterial:U.customDepthMaterial;if(V!==void 0)q=V;else if(q=T.isPointLight===!0?m:p,a.localClippingEnabled&&F.clipShadows===!0&&Array.isArray(F.clippingPlanes)&&F.clippingPlanes.length!==0||F.displacementMap&&F.displacementScale!==0||F.alphaMap&&F.alphaTest>0||F.map&&F.alphaTest>0||F.alphaToCoverage===!0){const Q=q.uuid,fe=F.uuid;let me=h[Q];me===void 0&&(me={},h[Q]=me);let j=me[fe];j===void 0&&(j=q.clone(),me[fe]=j,F.addEventListener("dispose",B)),q=j}if(q.visible=F.visible,q.wireframe=F.wireframe,P===rl?q.side=F.shadowSide!==null?F.shadowSide:F.side:q.side=F.shadowSide!==null?F.shadowSide:g[F.side],q.alphaMap=F.alphaMap,q.alphaTest=F.alphaToCoverage===!0?.5:F.alphaTest,q.map=F.map,q.clipShadows=F.clipShadows,q.clippingPlanes=F.clippingPlanes,q.clipIntersection=F.clipIntersection,q.displacementMap=F.displacementMap,q.displacementScale=F.displacementScale,q.displacementBias=F.displacementBias,q.wireframeLinewidth=F.wireframeLinewidth,q.linewidth=F.linewidth,T.isPointLight===!0&&q.isMeshDistanceMaterial===!0){const Q=a.properties.get(q);Q.light=T}return q}function w(U,F,T,P,q){if(U.visible===!1)return;if(U.layers.test(F.layers)&&(U.isMesh||U.isLine||U.isPoints)&&(U.castShadow||U.receiveShadow&&q===rl)&&(!U.frustumCulled||s.intersectsObject(U))){U.modelViewMatrix.multiplyMatrices(T.matrixWorldInverse,U.matrixWorld);const fe=e.update(U),me=U.material;if(Array.isArray(me)){const j=fe.groups;for(let L=0,H=j.length;L<H;L++){const $=j[L],_e=me[$.materialIndex];if(_e&&_e.visible){const be=I(U,_e,P,q);U.onBeforeShadow(a,U,F,T,fe,be,$),a.renderBufferDirect(T,null,fe,be,U,$),U.onAfterShadow(a,U,F,T,fe,be,$)}}}else if(me.visible){const j=I(U,me,P,q);U.onBeforeShadow(a,U,F,T,fe,j,null),a.renderBufferDirect(T,null,fe,j,U,null),U.onAfterShadow(a,U,F,T,fe,j,null)}}const Q=U.children;for(let fe=0,me=Q.length;fe<me;fe++)w(Q[fe],F,T,P,q)}function B(U){U.target.removeEventListener("dispose",B);for(const T in h){const P=h[T],q=U.target.uuid;q in P&&(P[q].dispose(),delete P[q])}}}function K2(a,e){function i(){let k=!1;const Ue=new dn;let te=null;const Ae=new dn(0,0,0,0);return{setMask:function(we){te!==we&&!k&&(a.colorMask(we,we,we,we),te=we)},setLocked:function(we){k=we},setClear:function(we,Se,We,Oe,gt){gt===!0&&(we*=Oe,Se*=Oe,We*=Oe),Ue.set(we,Se,We,Oe),Ae.equals(Ue)===!1&&(a.clearColor(we,Se,We,Oe),Ae.copy(Ue))},reset:function(){k=!1,te=null,Ae.set(-1,0,0,0)}}}function s(){let k=!1,Ue=!1,te=null,Ae=null,we=null;return{setReversed:function(Se){if(Ue!==Se){const We=e.get("EXT_clip_control");Se?We.clipControlEXT(We.LOWER_LEFT_EXT,We.ZERO_TO_ONE_EXT):We.clipControlEXT(We.LOWER_LEFT_EXT,We.NEGATIVE_ONE_TO_ONE_EXT),Ue=Se;const Oe=we;we=null,this.setClear(Oe)}},getReversed:function(){return Ue},setTest:function(Se){Se?ve(a.DEPTH_TEST):He(a.DEPTH_TEST)},setMask:function(Se){te!==Se&&!k&&(a.depthMask(Se),te=Se)},setFunc:function(Se){if(Ue&&(Se=wb[Se]),Ae!==Se){switch(Se){case bh:a.depthFunc(a.NEVER);break;case Th:a.depthFunc(a.ALWAYS);break;case Ah:a.depthFunc(a.LESS);break;case Js:a.depthFunc(a.LEQUAL);break;case Rh:a.depthFunc(a.EQUAL);break;case Ch:a.depthFunc(a.GEQUAL);break;case wh:a.depthFunc(a.GREATER);break;case Dh:a.depthFunc(a.NOTEQUAL);break;default:a.depthFunc(a.LEQUAL)}Ae=Se}},setLocked:function(Se){k=Se},setClear:function(Se){we!==Se&&(we=Se,Ue&&(Se=1-Se),a.clearDepth(Se))},reset:function(){k=!1,te=null,Ae=null,we=null,Ue=!1}}}function l(){let k=!1,Ue=null,te=null,Ae=null,we=null,Se=null,We=null,Oe=null,gt=null;return{setTest:function(Rt){k||(Rt?ve(a.STENCIL_TEST):He(a.STENCIL_TEST))},setMask:function(Rt){Ue!==Rt&&!k&&(a.stencilMask(Rt),Ue=Rt)},setFunc:function(Rt,en,tn){(te!==Rt||Ae!==en||we!==tn)&&(a.stencilFunc(Rt,en,tn),te=Rt,Ae=en,we=tn)},setOp:function(Rt,en,tn){(Se!==Rt||We!==en||Oe!==tn)&&(a.stencilOp(Rt,en,tn),Se=Rt,We=en,Oe=tn)},setLocked:function(Rt){k=Rt},setClear:function(Rt){gt!==Rt&&(a.clearStencil(Rt),gt=Rt)},reset:function(){k=!1,Ue=null,te=null,Ae=null,we=null,Se=null,We=null,Oe=null,gt=null}}}const c=new i,f=new s,p=new l,m=new WeakMap,h=new WeakMap;let _={},g={},v={},M=new WeakMap,b=[],C=null,y=!1,x=null,O=null,I=null,w=null,B=null,U=null,F=null,T=new zt(0,0,0),P=0,q=!1,V=null,Q=null,fe=null,me=null,j=null;const L=a.getParameter(a.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let H=!1,$=0;const _e=a.getParameter(a.VERSION);_e.indexOf("WebGL")!==-1?($=parseFloat(/^WebGL (\d)/.exec(_e)[1]),H=$>=1):_e.indexOf("OpenGL ES")!==-1&&($=parseFloat(/^OpenGL ES (\d)/.exec(_e)[1]),H=$>=2);let be=null,N={};const Y=a.getParameter(a.SCISSOR_BOX),de=a.getParameter(a.VIEWPORT),Te=new dn().fromArray(Y),Ce=new dn().fromArray(de);function ee(k,Ue,te,Ae){const we=new Uint8Array(4),Se=a.createTexture();a.bindTexture(k,Se),a.texParameteri(k,a.TEXTURE_MIN_FILTER,a.NEAREST),a.texParameteri(k,a.TEXTURE_MAG_FILTER,a.NEAREST);for(let We=0;We<te;We++)k===a.TEXTURE_3D||k===a.TEXTURE_2D_ARRAY?a.texImage3D(Ue,0,a.RGBA,1,1,Ae,0,a.RGBA,a.UNSIGNED_BYTE,we):a.texImage2D(Ue+We,0,a.RGBA,1,1,0,a.RGBA,a.UNSIGNED_BYTE,we);return Se}const Me={};Me[a.TEXTURE_2D]=ee(a.TEXTURE_2D,a.TEXTURE_2D,1),Me[a.TEXTURE_CUBE_MAP]=ee(a.TEXTURE_CUBE_MAP,a.TEXTURE_CUBE_MAP_POSITIVE_X,6),Me[a.TEXTURE_2D_ARRAY]=ee(a.TEXTURE_2D_ARRAY,a.TEXTURE_2D_ARRAY,1,1),Me[a.TEXTURE_3D]=ee(a.TEXTURE_3D,a.TEXTURE_3D,1,1),c.setClear(0,0,0,1),f.setClear(1),p.setClear(0),ve(a.DEPTH_TEST),f.setFunc(Js),qt(!1),$t(Fv),ve(a.CULL_FACE),mt(La);function ve(k){_[k]!==!0&&(a.enable(k),_[k]=!0)}function He(k){_[k]!==!1&&(a.disable(k),_[k]=!1)}function nt(k,Ue){return v[k]!==Ue?(a.bindFramebuffer(k,Ue),v[k]=Ue,k===a.DRAW_FRAMEBUFFER&&(v[a.FRAMEBUFFER]=Ue),k===a.FRAMEBUFFER&&(v[a.DRAW_FRAMEBUFFER]=Ue),!0):!1}function je(k,Ue){let te=b,Ae=!1;if(k){te=M.get(Ue),te===void 0&&(te=[],M.set(Ue,te));const we=k.textures;if(te.length!==we.length||te[0]!==a.COLOR_ATTACHMENT0){for(let Se=0,We=we.length;Se<We;Se++)te[Se]=a.COLOR_ATTACHMENT0+Se;te.length=we.length,Ae=!0}}else te[0]!==a.BACK&&(te[0]=a.BACK,Ae=!0);Ae&&a.drawBuffers(te)}function Dt(k){return C!==k?(a.useProgram(k),C=k,!0):!1}const ut={[Zr]:a.FUNC_ADD,[JE]:a.FUNC_SUBTRACT,[$E]:a.FUNC_REVERSE_SUBTRACT};ut[eb]=a.MIN,ut[tb]=a.MAX;const pt={[nb]:a.ZERO,[ib]:a.ONE,[ab]:a.SRC_COLOR,[Mh]:a.SRC_ALPHA,[ub]:a.SRC_ALPHA_SATURATE,[lb]:a.DST_COLOR,[sb]:a.DST_ALPHA,[rb]:a.ONE_MINUS_SRC_COLOR,[Eh]:a.ONE_MINUS_SRC_ALPHA,[cb]:a.ONE_MINUS_DST_COLOR,[ob]:a.ONE_MINUS_DST_ALPHA,[fb]:a.CONSTANT_COLOR,[db]:a.ONE_MINUS_CONSTANT_COLOR,[hb]:a.CONSTANT_ALPHA,[pb]:a.ONE_MINUS_CONSTANT_ALPHA};function mt(k,Ue,te,Ae,we,Se,We,Oe,gt,Rt){if(k===La){y===!0&&(He(a.BLEND),y=!1);return}if(y===!1&&(ve(a.BLEND),y=!0),k!==jE){if(k!==x||Rt!==q){if((O!==Zr||B!==Zr)&&(a.blendEquation(a.FUNC_ADD),O=Zr,B=Zr),Rt)switch(k){case Ks:a.blendFuncSeparate(a.ONE,a.ONE_MINUS_SRC_ALPHA,a.ONE,a.ONE_MINUS_SRC_ALPHA);break;case zv:a.blendFunc(a.ONE,a.ONE);break;case Hv:a.blendFuncSeparate(a.ZERO,a.ONE_MINUS_SRC_COLOR,a.ZERO,a.ONE);break;case Gv:a.blendFuncSeparate(a.DST_COLOR,a.ONE_MINUS_SRC_ALPHA,a.ZERO,a.ONE);break;default:wt("WebGLState: Invalid blending: ",k);break}else switch(k){case Ks:a.blendFuncSeparate(a.SRC_ALPHA,a.ONE_MINUS_SRC_ALPHA,a.ONE,a.ONE_MINUS_SRC_ALPHA);break;case zv:a.blendFuncSeparate(a.SRC_ALPHA,a.ONE,a.ONE,a.ONE);break;case Hv:wt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Gv:wt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:wt("WebGLState: Invalid blending: ",k);break}I=null,w=null,U=null,F=null,T.set(0,0,0),P=0,x=k,q=Rt}return}we=we||Ue,Se=Se||te,We=We||Ae,(Ue!==O||we!==B)&&(a.blendEquationSeparate(ut[Ue],ut[we]),O=Ue,B=we),(te!==I||Ae!==w||Se!==U||We!==F)&&(a.blendFuncSeparate(pt[te],pt[Ae],pt[Se],pt[We]),I=te,w=Ae,U=Se,F=We),(Oe.equals(T)===!1||gt!==P)&&(a.blendColor(Oe.r,Oe.g,Oe.b,gt),T.copy(Oe),P=gt),x=k,q=!1}function dt(k,Ue){k.side===Ua?He(a.CULL_FACE):ve(a.CULL_FACE);let te=k.side===$n;Ue&&(te=!te),qt(te),k.blending===Ks&&k.transparent===!1?mt(La):mt(k.blending,k.blendEquation,k.blendSrc,k.blendDst,k.blendEquationAlpha,k.blendSrcAlpha,k.blendDstAlpha,k.blendColor,k.blendAlpha,k.premultipliedAlpha),f.setFunc(k.depthFunc),f.setTest(k.depthTest),f.setMask(k.depthWrite),c.setMask(k.colorWrite);const Ae=k.stencilWrite;p.setTest(Ae),Ae&&(p.setMask(k.stencilWriteMask),p.setFunc(k.stencilFunc,k.stencilRef,k.stencilFuncMask),p.setOp(k.stencilFail,k.stencilZFail,k.stencilZPass)),cn(k.polygonOffset,k.polygonOffsetFactor,k.polygonOffsetUnits),k.alphaToCoverage===!0?ve(a.SAMPLE_ALPHA_TO_COVERAGE):He(a.SAMPLE_ALPHA_TO_COVERAGE)}function qt(k){V!==k&&(k?a.frontFace(a.CW):a.frontFace(a.CCW),V=k)}function $t(k){k!==ZE?(ve(a.CULL_FACE),k!==Q&&(k===Fv?a.cullFace(a.BACK):k===KE?a.cullFace(a.FRONT):a.cullFace(a.FRONT_AND_BACK))):He(a.CULL_FACE),Q=k}function Ut(k){k!==fe&&(H&&a.lineWidth(k),fe=k)}function cn(k,Ue,te){k?(ve(a.POLYGON_OFFSET_FILL),(me!==Ue||j!==te)&&(me=Ue,j=te,f.getReversed()&&(Ue=-Ue),a.polygonOffset(Ue,te))):He(a.POLYGON_OFFSET_FILL)}function Yt(k){k?ve(a.SCISSOR_TEST):He(a.SCISSOR_TEST)}function St(k){k===void 0&&(k=a.TEXTURE0+L-1),be!==k&&(a.activeTexture(k),be=k)}function X(k,Ue,te){te===void 0&&(be===null?te=a.TEXTURE0+L-1:te=be);let Ae=N[te];Ae===void 0&&(Ae={type:void 0,texture:void 0},N[te]=Ae),(Ae.type!==k||Ae.texture!==Ue)&&(be!==te&&(a.activeTexture(te),be=te),a.bindTexture(k,Ue||Me[k]),Ae.type=k,Ae.texture=Ue)}function Bt(){const k=N[be];k!==void 0&&k.type!==void 0&&(a.bindTexture(k.type,null),k.type=void 0,k.texture=void 0)}function Ct(){try{a.compressedTexImage2D(...arguments)}catch(k){wt("WebGLState:",k)}}function D(){try{a.compressedTexImage3D(...arguments)}catch(k){wt("WebGLState:",k)}}function E(){try{a.texSubImage2D(...arguments)}catch(k){wt("WebGLState:",k)}}function K(){try{a.texSubImage3D(...arguments)}catch(k){wt("WebGLState:",k)}}function se(){try{a.compressedTexSubImage2D(...arguments)}catch(k){wt("WebGLState:",k)}}function he(){try{a.compressedTexSubImage3D(...arguments)}catch(k){wt("WebGLState:",k)}}function De(){try{a.texStorage2D(...arguments)}catch(k){wt("WebGLState:",k)}}function Le(){try{a.texStorage3D(...arguments)}catch(k){wt("WebGLState:",k)}}function pe(){try{a.texImage2D(...arguments)}catch(k){wt("WebGLState:",k)}}function ge(){try{a.texImage3D(...arguments)}catch(k){wt("WebGLState:",k)}}function Ne(k){return g[k]!==void 0?g[k]:a.getParameter(k)}function Ve(k,Ue){g[k]!==Ue&&(a.pixelStorei(k,Ue),g[k]=Ue)}function Be(k){Te.equals(k)===!1&&(a.scissor(k.x,k.y,k.z,k.w),Te.copy(k))}function Ie(k){Ce.equals(k)===!1&&(a.viewport(k.x,k.y,k.z,k.w),Ce.copy(k))}function Ye(k,Ue){let te=h.get(Ue);te===void 0&&(te=new WeakMap,h.set(Ue,te));let Ae=te.get(k);Ae===void 0&&(Ae=a.getUniformBlockIndex(Ue,k.name),te.set(k,Ae))}function $e(k,Ue){const Ae=h.get(Ue).get(k);m.get(Ue)!==Ae&&(a.uniformBlockBinding(Ue,Ae,k.__bindingPointIndex),m.set(Ue,Ae))}function at(){a.disable(a.BLEND),a.disable(a.CULL_FACE),a.disable(a.DEPTH_TEST),a.disable(a.POLYGON_OFFSET_FILL),a.disable(a.SCISSOR_TEST),a.disable(a.STENCIL_TEST),a.disable(a.SAMPLE_ALPHA_TO_COVERAGE),a.blendEquation(a.FUNC_ADD),a.blendFunc(a.ONE,a.ZERO),a.blendFuncSeparate(a.ONE,a.ZERO,a.ONE,a.ZERO),a.blendColor(0,0,0,0),a.colorMask(!0,!0,!0,!0),a.clearColor(0,0,0,0),a.depthMask(!0),a.depthFunc(a.LESS),f.setReversed(!1),a.clearDepth(1),a.stencilMask(4294967295),a.stencilFunc(a.ALWAYS,0,4294967295),a.stencilOp(a.KEEP,a.KEEP,a.KEEP),a.clearStencil(0),a.cullFace(a.BACK),a.frontFace(a.CCW),a.polygonOffset(0,0),a.activeTexture(a.TEXTURE0),a.bindFramebuffer(a.FRAMEBUFFER,null),a.bindFramebuffer(a.DRAW_FRAMEBUFFER,null),a.bindFramebuffer(a.READ_FRAMEBUFFER,null),a.useProgram(null),a.lineWidth(1),a.scissor(0,0,a.canvas.width,a.canvas.height),a.viewport(0,0,a.canvas.width,a.canvas.height),a.pixelStorei(a.PACK_ALIGNMENT,4),a.pixelStorei(a.UNPACK_ALIGNMENT,4),a.pixelStorei(a.UNPACK_FLIP_Y_WEBGL,!1),a.pixelStorei(a.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),a.pixelStorei(a.UNPACK_COLORSPACE_CONVERSION_WEBGL,a.BROWSER_DEFAULT_WEBGL),a.pixelStorei(a.PACK_ROW_LENGTH,0),a.pixelStorei(a.PACK_SKIP_PIXELS,0),a.pixelStorei(a.PACK_SKIP_ROWS,0),a.pixelStorei(a.UNPACK_ROW_LENGTH,0),a.pixelStorei(a.UNPACK_IMAGE_HEIGHT,0),a.pixelStorei(a.UNPACK_SKIP_PIXELS,0),a.pixelStorei(a.UNPACK_SKIP_ROWS,0),a.pixelStorei(a.UNPACK_SKIP_IMAGES,0),_={},g={},be=null,N={},v={},M=new WeakMap,b=[],C=null,y=!1,x=null,O=null,I=null,w=null,B=null,U=null,F=null,T=new zt(0,0,0),P=0,q=!1,V=null,Q=null,fe=null,me=null,j=null,Te.set(0,0,a.canvas.width,a.canvas.height),Ce.set(0,0,a.canvas.width,a.canvas.height),c.reset(),f.reset(),p.reset()}return{buffers:{color:c,depth:f,stencil:p},enable:ve,disable:He,bindFramebuffer:nt,drawBuffers:je,useProgram:Dt,setBlending:mt,setMaterial:dt,setFlipSided:qt,setCullFace:$t,setLineWidth:Ut,setPolygonOffset:cn,setScissorTest:Yt,activeTexture:St,bindTexture:X,unbindTexture:Bt,compressedTexImage2D:Ct,compressedTexImage3D:D,texImage2D:pe,texImage3D:ge,pixelStorei:Ve,getParameter:Ne,updateUBOMapping:Ye,uniformBlockBinding:$e,texStorage2D:De,texStorage3D:Le,texSubImage2D:E,texSubImage3D:K,compressedTexSubImage2D:se,compressedTexSubImage3D:he,scissor:Be,viewport:Ie,reset:at}}function Q2(a,e,i,s,l,c,f){const p=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,m=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new Pt,_=new WeakMap,g=new Set;let v;const M=new WeakMap;let b=!1;try{b=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function C(D,E){return b?new OffscreenCanvas(D,E):vu("canvas")}function y(D,E,K){let se=1;const he=Ct(D);if((he.width>K||he.height>K)&&(se=K/Math.max(he.width,he.height)),se<1)if(typeof HTMLImageElement<"u"&&D instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&D instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&D instanceof ImageBitmap||typeof VideoFrame<"u"&&D instanceof VideoFrame){const De=Math.floor(se*he.width),Le=Math.floor(se*he.height);v===void 0&&(v=C(De,Le));const pe=E?C(De,Le):v;return pe.width=De,pe.height=Le,pe.getContext("2d").drawImage(D,0,0,De,Le),rt("WebGLRenderer: Texture has been resized from ("+he.width+"x"+he.height+") to ("+De+"x"+Le+")."),pe}else return"data"in D&&rt("WebGLRenderer: Image in DataTexture is too big ("+he.width+"x"+he.height+")."),D;return D}function x(D){return D.generateMipmaps}function O(D){a.generateMipmap(D)}function I(D){return D.isWebGLCubeRenderTarget?a.TEXTURE_CUBE_MAP:D.isWebGL3DRenderTarget?a.TEXTURE_3D:D.isWebGLArrayRenderTarget||D.isCompressedArrayTexture?a.TEXTURE_2D_ARRAY:a.TEXTURE_2D}function w(D,E,K,se,he,De=!1){if(D!==null){if(a[D]!==void 0)return a[D];rt("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+D+"'")}let Le;se&&(Le=e.get("EXT_texture_norm16"),Le||rt("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let pe=E;if(E===a.RED&&(K===a.FLOAT&&(pe=a.R32F),K===a.HALF_FLOAT&&(pe=a.R16F),K===a.UNSIGNED_BYTE&&(pe=a.R8),K===a.UNSIGNED_SHORT&&Le&&(pe=Le.R16_EXT),K===a.SHORT&&Le&&(pe=Le.R16_SNORM_EXT)),E===a.RED_INTEGER&&(K===a.UNSIGNED_BYTE&&(pe=a.R8UI),K===a.UNSIGNED_SHORT&&(pe=a.R16UI),K===a.UNSIGNED_INT&&(pe=a.R32UI),K===a.BYTE&&(pe=a.R8I),K===a.SHORT&&(pe=a.R16I),K===a.INT&&(pe=a.R32I)),E===a.RG&&(K===a.FLOAT&&(pe=a.RG32F),K===a.HALF_FLOAT&&(pe=a.RG16F),K===a.UNSIGNED_BYTE&&(pe=a.RG8),K===a.UNSIGNED_SHORT&&Le&&(pe=Le.RG16_EXT),K===a.SHORT&&Le&&(pe=Le.RG16_SNORM_EXT)),E===a.RG_INTEGER&&(K===a.UNSIGNED_BYTE&&(pe=a.RG8UI),K===a.UNSIGNED_SHORT&&(pe=a.RG16UI),K===a.UNSIGNED_INT&&(pe=a.RG32UI),K===a.BYTE&&(pe=a.RG8I),K===a.SHORT&&(pe=a.RG16I),K===a.INT&&(pe=a.RG32I)),E===a.RGB_INTEGER&&(K===a.UNSIGNED_BYTE&&(pe=a.RGB8UI),K===a.UNSIGNED_SHORT&&(pe=a.RGB16UI),K===a.UNSIGNED_INT&&(pe=a.RGB32UI),K===a.BYTE&&(pe=a.RGB8I),K===a.SHORT&&(pe=a.RGB16I),K===a.INT&&(pe=a.RGB32I)),E===a.RGBA_INTEGER&&(K===a.UNSIGNED_BYTE&&(pe=a.RGBA8UI),K===a.UNSIGNED_SHORT&&(pe=a.RGBA16UI),K===a.UNSIGNED_INT&&(pe=a.RGBA32UI),K===a.BYTE&&(pe=a.RGBA8I),K===a.SHORT&&(pe=a.RGBA16I),K===a.INT&&(pe=a.RGBA32I)),E===a.RGB&&(K===a.UNSIGNED_SHORT&&Le&&(pe=Le.RGB16_EXT),K===a.SHORT&&Le&&(pe=Le.RGB16_SNORM_EXT),K===a.UNSIGNED_INT_5_9_9_9_REV&&(pe=a.RGB9_E5),K===a.UNSIGNED_INT_10F_11F_11F_REV&&(pe=a.R11F_G11F_B10F)),E===a.RGBA){const ge=De?mu:Tt.getTransfer(he);K===a.FLOAT&&(pe=a.RGBA32F),K===a.HALF_FLOAT&&(pe=a.RGBA16F),K===a.UNSIGNED_BYTE&&(pe=ge===Wt?a.SRGB8_ALPHA8:a.RGBA8),K===a.UNSIGNED_SHORT&&Le&&(pe=Le.RGBA16_EXT),K===a.SHORT&&Le&&(pe=Le.RGBA16_SNORM_EXT),K===a.UNSIGNED_SHORT_4_4_4_4&&(pe=a.RGBA4),K===a.UNSIGNED_SHORT_5_5_5_1&&(pe=a.RGB5_A1)}return(pe===a.R16F||pe===a.R32F||pe===a.RG16F||pe===a.RG32F||pe===a.RGBA16F||pe===a.RGBA32F)&&e.get("EXT_color_buffer_float"),pe}function B(D,E){let K;return D?E===null||E===aa||E===ul?K=a.DEPTH24_STENCIL8:E===$i?K=a.DEPTH32F_STENCIL8:E===cl&&(K=a.DEPTH24_STENCIL8,rt("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):E===null||E===aa||E===ul?K=a.DEPTH_COMPONENT24:E===$i?K=a.DEPTH_COMPONENT32F:E===cl&&(K=a.DEPTH_COMPONENT16),K}function U(D,E){return x(D)===!0||D.isFramebufferTexture&&D.minFilter!==Pn&&D.minFilter!==Hn?Math.log2(Math.max(E.width,E.height))+1:D.mipmaps!==void 0&&D.mipmaps.length>0?D.mipmaps.length:D.isCompressedTexture&&Array.isArray(D.image)?E.mipmaps.length:1}function F(D){const E=D.target;E.removeEventListener("dispose",F),P(E),E.isVideoTexture&&_.delete(E),E.isHTMLTexture&&g.delete(E)}function T(D){const E=D.target;E.removeEventListener("dispose",T),V(E)}function P(D){const E=s.get(D);if(E.__webglInit===void 0)return;const K=D.source,se=M.get(K);if(se){const he=se[E.__cacheKey];he.usedTimes--,he.usedTimes===0&&q(D),Object.keys(se).length===0&&M.delete(K)}s.remove(D)}function q(D){const E=s.get(D);a.deleteTexture(E.__webglTexture);const K=D.source,se=M.get(K);delete se[E.__cacheKey],f.memory.textures--}function V(D){const E=s.get(D);if(D.depthTexture&&(D.depthTexture.dispose(),s.remove(D.depthTexture)),D.isWebGLCubeRenderTarget)for(let se=0;se<6;se++){if(Array.isArray(E.__webglFramebuffer[se]))for(let he=0;he<E.__webglFramebuffer[se].length;he++)a.deleteFramebuffer(E.__webglFramebuffer[se][he]);else a.deleteFramebuffer(E.__webglFramebuffer[se]);E.__webglDepthbuffer&&a.deleteRenderbuffer(E.__webglDepthbuffer[se])}else{if(Array.isArray(E.__webglFramebuffer))for(let se=0;se<E.__webglFramebuffer.length;se++)a.deleteFramebuffer(E.__webglFramebuffer[se]);else a.deleteFramebuffer(E.__webglFramebuffer);if(E.__webglDepthbuffer&&a.deleteRenderbuffer(E.__webglDepthbuffer),E.__webglMultisampledFramebuffer&&a.deleteFramebuffer(E.__webglMultisampledFramebuffer),E.__webglColorRenderbuffer)for(let se=0;se<E.__webglColorRenderbuffer.length;se++)E.__webglColorRenderbuffer[se]&&a.deleteRenderbuffer(E.__webglColorRenderbuffer[se]);E.__webglDepthRenderbuffer&&a.deleteRenderbuffer(E.__webglDepthRenderbuffer)}const K=D.textures;for(let se=0,he=K.length;se<he;se++){const De=s.get(K[se]);De.__webglTexture&&(a.deleteTexture(De.__webglTexture),f.memory.textures--),s.remove(K[se])}s.remove(D)}let Q=0;function fe(){Q=0}function me(){return Q}function j(D){Q=D}function L(){const D=Q;return D>=l.maxTextures&&rt("WebGLTextures: Trying to use "+D+" texture units while this GPU supports only "+l.maxTextures),Q+=1,D}function H(D){const E=[];return E.push(D.wrapS),E.push(D.wrapT),E.push(D.wrapR||0),E.push(D.magFilter),E.push(D.minFilter),E.push(D.anisotropy),E.push(D.internalFormat),E.push(D.format),E.push(D.type),E.push(D.generateMipmaps),E.push(D.premultiplyAlpha),E.push(D.flipY),E.push(D.unpackAlignment),E.push(D.colorSpace),E.join()}function $(D,E){const K=s.get(D);if(D.isVideoTexture&&X(D),D.isRenderTargetTexture===!1&&D.isExternalTexture!==!0&&D.version>0&&K.__version!==D.version){const se=D.image;if(se===null)rt("WebGLRenderer: Texture marked for update but no image data found.");else if(se.complete===!1)rt("WebGLRenderer: Texture marked for update but image is incomplete");else{He(K,D,E);return}}else D.isExternalTexture&&(K.__webglTexture=D.sourceTexture?D.sourceTexture:null);i.bindTexture(a.TEXTURE_2D,K.__webglTexture,a.TEXTURE0+E)}function _e(D,E){const K=s.get(D);if(D.isRenderTargetTexture===!1&&D.version>0&&K.__version!==D.version){He(K,D,E);return}else D.isExternalTexture&&(K.__webglTexture=D.sourceTexture?D.sourceTexture:null);i.bindTexture(a.TEXTURE_2D_ARRAY,K.__webglTexture,a.TEXTURE0+E)}function be(D,E){const K=s.get(D);if(D.isRenderTargetTexture===!1&&D.version>0&&K.__version!==D.version){He(K,D,E);return}i.bindTexture(a.TEXTURE_3D,K.__webglTexture,a.TEXTURE0+E)}function N(D,E){const K=s.get(D);if(D.isCubeDepthTexture!==!0&&D.version>0&&K.__version!==D.version){nt(K,D,E);return}i.bindTexture(a.TEXTURE_CUBE_MAP,K.__webglTexture,a.TEXTURE0+E)}const Y={[Uh]:a.REPEAT,[Na]:a.CLAMP_TO_EDGE,[Nh]:a.MIRRORED_REPEAT},de={[Pn]:a.NEAREST,[vb]:a.NEAREST_MIPMAP_NEAREST,[Dc]:a.NEAREST_MIPMAP_LINEAR,[Hn]:a.LINEAR,[Vd]:a.LINEAR_MIPMAP_NEAREST,[Qr]:a.LINEAR_MIPMAP_LINEAR},Te={[Sb]:a.NEVER,[Tb]:a.ALWAYS,[yb]:a.LESS,[wp]:a.LEQUAL,[Mb]:a.EQUAL,[Dp]:a.GEQUAL,[Eb]:a.GREATER,[bb]:a.NOTEQUAL};function Ce(D,E){if(E.type===$i&&e.has("OES_texture_float_linear")===!1&&(E.magFilter===Hn||E.magFilter===Vd||E.magFilter===Dc||E.magFilter===Qr||E.minFilter===Hn||E.minFilter===Vd||E.minFilter===Dc||E.minFilter===Qr)&&rt("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),a.texParameteri(D,a.TEXTURE_WRAP_S,Y[E.wrapS]),a.texParameteri(D,a.TEXTURE_WRAP_T,Y[E.wrapT]),(D===a.TEXTURE_3D||D===a.TEXTURE_2D_ARRAY)&&a.texParameteri(D,a.TEXTURE_WRAP_R,Y[E.wrapR]),a.texParameteri(D,a.TEXTURE_MAG_FILTER,de[E.magFilter]),a.texParameteri(D,a.TEXTURE_MIN_FILTER,de[E.minFilter]),E.compareFunction&&(a.texParameteri(D,a.TEXTURE_COMPARE_MODE,a.COMPARE_REF_TO_TEXTURE),a.texParameteri(D,a.TEXTURE_COMPARE_FUNC,Te[E.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(E.magFilter===Pn||E.minFilter!==Dc&&E.minFilter!==Qr||E.type===$i&&e.has("OES_texture_float_linear")===!1)return;if(E.anisotropy>1||s.get(E).__currentAnisotropy){const K=e.get("EXT_texture_filter_anisotropic");a.texParameterf(D,K.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(E.anisotropy,l.getMaxAnisotropy())),s.get(E).__currentAnisotropy=E.anisotropy}}}function ee(D,E){let K=!1;D.__webglInit===void 0&&(D.__webglInit=!0,E.addEventListener("dispose",F));const se=E.source;let he=M.get(se);he===void 0&&(he={},M.set(se,he));const De=H(E);if(De!==D.__cacheKey){he[De]===void 0&&(he[De]={texture:a.createTexture(),usedTimes:0},f.memory.textures++,K=!0),he[De].usedTimes++;const Le=he[D.__cacheKey];Le!==void 0&&(he[D.__cacheKey].usedTimes--,Le.usedTimes===0&&q(E)),D.__cacheKey=De,D.__webglTexture=he[De].texture}return K}function Me(D,E,K){return Math.floor(Math.floor(D/K)/E)}function ve(D,E,K,se){const De=D.updateRanges;if(De.length===0)i.texSubImage2D(a.TEXTURE_2D,0,0,0,E.width,E.height,K,se,E.data);else{De.sort((Ve,Be)=>Ve.start-Be.start);let Le=0;for(let Ve=1;Ve<De.length;Ve++){const Be=De[Le],Ie=De[Ve],Ye=Be.start+Be.count,$e=Me(Ie.start,E.width,4),at=Me(Be.start,E.width,4);Ie.start<=Ye+1&&$e===at&&Me(Ie.start+Ie.count-1,E.width,4)===$e?Be.count=Math.max(Be.count,Ie.start+Ie.count-Be.start):(++Le,De[Le]=Ie)}De.length=Le+1;const pe=i.getParameter(a.UNPACK_ROW_LENGTH),ge=i.getParameter(a.UNPACK_SKIP_PIXELS),Ne=i.getParameter(a.UNPACK_SKIP_ROWS);i.pixelStorei(a.UNPACK_ROW_LENGTH,E.width);for(let Ve=0,Be=De.length;Ve<Be;Ve++){const Ie=De[Ve],Ye=Math.floor(Ie.start/4),$e=Math.ceil(Ie.count/4),at=Ye%E.width,k=Math.floor(Ye/E.width),Ue=$e,te=1;i.pixelStorei(a.UNPACK_SKIP_PIXELS,at),i.pixelStorei(a.UNPACK_SKIP_ROWS,k),i.texSubImage2D(a.TEXTURE_2D,0,at,k,Ue,te,K,se,E.data)}D.clearUpdateRanges(),i.pixelStorei(a.UNPACK_ROW_LENGTH,pe),i.pixelStorei(a.UNPACK_SKIP_PIXELS,ge),i.pixelStorei(a.UNPACK_SKIP_ROWS,Ne)}}function He(D,E,K){let se=a.TEXTURE_2D;(E.isDataArrayTexture||E.isCompressedArrayTexture)&&(se=a.TEXTURE_2D_ARRAY),E.isData3DTexture&&(se=a.TEXTURE_3D);const he=ee(D,E),De=E.source;i.bindTexture(se,D.__webglTexture,a.TEXTURE0+K);const Le=s.get(De);if(De.version!==Le.__version||he===!0){if(i.activeTexture(a.TEXTURE0+K),(typeof ImageBitmap<"u"&&E.image instanceof ImageBitmap)===!1){const te=Tt.getPrimaries(Tt.workingColorSpace),Ae=E.colorSpace===Sr?null:Tt.getPrimaries(E.colorSpace),we=E.colorSpace===Sr||te===Ae?a.NONE:a.BROWSER_DEFAULT_WEBGL;i.pixelStorei(a.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(a.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(a.UNPACK_COLORSPACE_CONVERSION_WEBGL,we)}i.pixelStorei(a.UNPACK_ALIGNMENT,E.unpackAlignment);let ge=y(E.image,!1,l.maxTextureSize);ge=Bt(E,ge);const Ne=c.convert(E.format,E.colorSpace),Ve=c.convert(E.type);let Be=w(E.internalFormat,Ne,Ve,E.normalized,E.colorSpace,E.isVideoTexture);Ce(se,E);let Ie;const Ye=E.mipmaps,$e=E.isVideoTexture!==!0,at=Le.__version===void 0||he===!0,k=De.dataReady,Ue=U(E,ge);if(E.isDepthTexture)Be=B(E.format===jr,E.type),at&&($e?i.texStorage2D(a.TEXTURE_2D,1,Be,ge.width,ge.height):i.texImage2D(a.TEXTURE_2D,0,Be,ge.width,ge.height,0,Ne,Ve,null));else if(E.isDataTexture)if(Ye.length>0){$e&&at&&i.texStorage2D(a.TEXTURE_2D,Ue,Be,Ye[0].width,Ye[0].height);for(let te=0,Ae=Ye.length;te<Ae;te++)Ie=Ye[te],$e?k&&i.texSubImage2D(a.TEXTURE_2D,te,0,0,Ie.width,Ie.height,Ne,Ve,Ie.data):i.texImage2D(a.TEXTURE_2D,te,Be,Ie.width,Ie.height,0,Ne,Ve,Ie.data);E.generateMipmaps=!1}else $e?(at&&i.texStorage2D(a.TEXTURE_2D,Ue,Be,ge.width,ge.height),k&&ve(E,ge,Ne,Ve)):i.texImage2D(a.TEXTURE_2D,0,Be,ge.width,ge.height,0,Ne,Ve,ge.data);else if(E.isCompressedTexture)if(E.isCompressedArrayTexture){$e&&at&&i.texStorage3D(a.TEXTURE_2D_ARRAY,Ue,Be,Ye[0].width,Ye[0].height,ge.depth);for(let te=0,Ae=Ye.length;te<Ae;te++)if(Ie=Ye[te],E.format!==zi)if(Ne!==null)if($e){if(k)if(E.layerUpdates.size>0){const we=d_(Ie.width,Ie.height,E.format,E.type);for(const Se of E.layerUpdates){const We=Ie.data.subarray(Se*we/Ie.data.BYTES_PER_ELEMENT,(Se+1)*we/Ie.data.BYTES_PER_ELEMENT);i.compressedTexSubImage3D(a.TEXTURE_2D_ARRAY,te,0,0,Se,Ie.width,Ie.height,1,Ne,We)}E.clearLayerUpdates()}else i.compressedTexSubImage3D(a.TEXTURE_2D_ARRAY,te,0,0,0,Ie.width,Ie.height,ge.depth,Ne,Ie.data)}else i.compressedTexImage3D(a.TEXTURE_2D_ARRAY,te,Be,Ie.width,Ie.height,ge.depth,0,Ie.data,0,0);else rt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else $e?k&&i.texSubImage3D(a.TEXTURE_2D_ARRAY,te,0,0,0,Ie.width,Ie.height,ge.depth,Ne,Ve,Ie.data):i.texImage3D(a.TEXTURE_2D_ARRAY,te,Be,Ie.width,Ie.height,ge.depth,0,Ne,Ve,Ie.data)}else{$e&&at&&i.texStorage2D(a.TEXTURE_2D,Ue,Be,Ye[0].width,Ye[0].height);for(let te=0,Ae=Ye.length;te<Ae;te++)Ie=Ye[te],E.format!==zi?Ne!==null?$e?k&&i.compressedTexSubImage2D(a.TEXTURE_2D,te,0,0,Ie.width,Ie.height,Ne,Ie.data):i.compressedTexImage2D(a.TEXTURE_2D,te,Be,Ie.width,Ie.height,0,Ie.data):rt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):$e?k&&i.texSubImage2D(a.TEXTURE_2D,te,0,0,Ie.width,Ie.height,Ne,Ve,Ie.data):i.texImage2D(a.TEXTURE_2D,te,Be,Ie.width,Ie.height,0,Ne,Ve,Ie.data)}else if(E.isDataArrayTexture)if($e){if(at&&i.texStorage3D(a.TEXTURE_2D_ARRAY,Ue,Be,ge.width,ge.height,ge.depth),k)if(E.layerUpdates.size>0){const te=d_(ge.width,ge.height,E.format,E.type);for(const Ae of E.layerUpdates){const we=ge.data.subarray(Ae*te/ge.data.BYTES_PER_ELEMENT,(Ae+1)*te/ge.data.BYTES_PER_ELEMENT);i.texSubImage3D(a.TEXTURE_2D_ARRAY,0,0,0,Ae,ge.width,ge.height,1,Ne,Ve,we)}E.clearLayerUpdates()}else i.texSubImage3D(a.TEXTURE_2D_ARRAY,0,0,0,0,ge.width,ge.height,ge.depth,Ne,Ve,ge.data)}else i.texImage3D(a.TEXTURE_2D_ARRAY,0,Be,ge.width,ge.height,ge.depth,0,Ne,Ve,ge.data);else if(E.isData3DTexture)$e?(at&&i.texStorage3D(a.TEXTURE_3D,Ue,Be,ge.width,ge.height,ge.depth),k&&i.texSubImage3D(a.TEXTURE_3D,0,0,0,0,ge.width,ge.height,ge.depth,Ne,Ve,ge.data)):i.texImage3D(a.TEXTURE_3D,0,Be,ge.width,ge.height,ge.depth,0,Ne,Ve,ge.data);else if(E.isFramebufferTexture){if(at)if($e)i.texStorage2D(a.TEXTURE_2D,Ue,Be,ge.width,ge.height);else{let te=ge.width,Ae=ge.height;for(let we=0;we<Ue;we++)i.texImage2D(a.TEXTURE_2D,we,Be,te,Ae,0,Ne,Ve,null),te>>=1,Ae>>=1}}else if(E.isHTMLTexture){if("texElementImage2D"in a){const te=a.canvas;if(te.hasAttribute("layoutsubtree")||te.setAttribute("layoutsubtree","true"),ge.parentNode!==te){te.appendChild(ge),g.add(E),te.onpaint=Ae=>{const we=Ae.changedElements;for(const Se of g)we.includes(Se.image)&&(Se.needsUpdate=!0)},te.requestPaint();return}if(a.texElementImage2D.length===3)a.texElementImage2D(a.TEXTURE_2D,a.RGBA8,ge);else{const we=a.RGBA,Se=a.RGBA,We=a.UNSIGNED_BYTE;a.texElementImage2D(a.TEXTURE_2D,0,we,Se,We,ge)}a.texParameteri(a.TEXTURE_2D,a.TEXTURE_MIN_FILTER,a.LINEAR),a.texParameteri(a.TEXTURE_2D,a.TEXTURE_WRAP_S,a.CLAMP_TO_EDGE),a.texParameteri(a.TEXTURE_2D,a.TEXTURE_WRAP_T,a.CLAMP_TO_EDGE)}}else if(Ye.length>0){if($e&&at){const te=Ct(Ye[0]);i.texStorage2D(a.TEXTURE_2D,Ue,Be,te.width,te.height)}for(let te=0,Ae=Ye.length;te<Ae;te++)Ie=Ye[te],$e?k&&i.texSubImage2D(a.TEXTURE_2D,te,0,0,Ne,Ve,Ie):i.texImage2D(a.TEXTURE_2D,te,Be,Ne,Ve,Ie);E.generateMipmaps=!1}else if($e){if(at){const te=Ct(ge);i.texStorage2D(a.TEXTURE_2D,Ue,Be,te.width,te.height)}k&&i.texSubImage2D(a.TEXTURE_2D,0,0,0,Ne,Ve,ge)}else i.texImage2D(a.TEXTURE_2D,0,Be,Ne,Ve,ge);x(E)&&O(se),Le.__version=De.version,E.onUpdate&&E.onUpdate(E)}D.__version=E.version}function nt(D,E,K){if(E.image.length!==6)return;const se=ee(D,E),he=E.source;i.bindTexture(a.TEXTURE_CUBE_MAP,D.__webglTexture,a.TEXTURE0+K);const De=s.get(he);if(he.version!==De.__version||se===!0){i.activeTexture(a.TEXTURE0+K);const Le=Tt.getPrimaries(Tt.workingColorSpace),pe=E.colorSpace===Sr?null:Tt.getPrimaries(E.colorSpace),ge=E.colorSpace===Sr||Le===pe?a.NONE:a.BROWSER_DEFAULT_WEBGL;i.pixelStorei(a.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(a.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(a.UNPACK_ALIGNMENT,E.unpackAlignment),i.pixelStorei(a.UNPACK_COLORSPACE_CONVERSION_WEBGL,ge);const Ne=E.isCompressedTexture||E.image[0].isCompressedTexture,Ve=E.image[0]&&E.image[0].isDataTexture,Be=[];for(let Se=0;Se<6;Se++)!Ne&&!Ve?Be[Se]=y(E.image[Se],!0,l.maxCubemapSize):Be[Se]=Ve?E.image[Se].image:E.image[Se],Be[Se]=Bt(E,Be[Se]);const Ie=Be[0],Ye=c.convert(E.format,E.colorSpace),$e=c.convert(E.type),at=w(E.internalFormat,Ye,$e,E.normalized,E.colorSpace),k=E.isVideoTexture!==!0,Ue=De.__version===void 0||se===!0,te=he.dataReady;let Ae=U(E,Ie);Ce(a.TEXTURE_CUBE_MAP,E);let we;if(Ne){k&&Ue&&i.texStorage2D(a.TEXTURE_CUBE_MAP,Ae,at,Ie.width,Ie.height);for(let Se=0;Se<6;Se++){we=Be[Se].mipmaps;for(let We=0;We<we.length;We++){const Oe=we[We];E.format!==zi?Ye!==null?k?te&&i.compressedTexSubImage2D(a.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We,0,0,Oe.width,Oe.height,Ye,Oe.data):i.compressedTexImage2D(a.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We,at,Oe.width,Oe.height,0,Oe.data):rt("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):k?te&&i.texSubImage2D(a.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We,0,0,Oe.width,Oe.height,Ye,$e,Oe.data):i.texImage2D(a.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We,at,Oe.width,Oe.height,0,Ye,$e,Oe.data)}}}else{if(we=E.mipmaps,k&&Ue){we.length>0&&Ae++;const Se=Ct(Be[0]);i.texStorage2D(a.TEXTURE_CUBE_MAP,Ae,at,Se.width,Se.height)}for(let Se=0;Se<6;Se++)if(Ve){k?te&&i.texSubImage2D(a.TEXTURE_CUBE_MAP_POSITIVE_X+Se,0,0,0,Be[Se].width,Be[Se].height,Ye,$e,Be[Se].data):i.texImage2D(a.TEXTURE_CUBE_MAP_POSITIVE_X+Se,0,at,Be[Se].width,Be[Se].height,0,Ye,$e,Be[Se].data);for(let We=0;We<we.length;We++){const gt=we[We].image[Se].image;k?te&&i.texSubImage2D(a.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We+1,0,0,gt.width,gt.height,Ye,$e,gt.data):i.texImage2D(a.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We+1,at,gt.width,gt.height,0,Ye,$e,gt.data)}}else{k?te&&i.texSubImage2D(a.TEXTURE_CUBE_MAP_POSITIVE_X+Se,0,0,0,Ye,$e,Be[Se]):i.texImage2D(a.TEXTURE_CUBE_MAP_POSITIVE_X+Se,0,at,Ye,$e,Be[Se]);for(let We=0;We<we.length;We++){const Oe=we[We];k?te&&i.texSubImage2D(a.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We+1,0,0,Ye,$e,Oe.image[Se]):i.texImage2D(a.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We+1,at,Ye,$e,Oe.image[Se])}}}x(E)&&O(a.TEXTURE_CUBE_MAP),De.__version=he.version,E.onUpdate&&E.onUpdate(E)}D.__version=E.version}function je(D,E,K,se,he,De){const Le=c.convert(K.format,K.colorSpace),pe=c.convert(K.type),ge=w(K.internalFormat,Le,pe,K.normalized,K.colorSpace),Ne=s.get(E),Ve=s.get(K);if(Ve.__renderTarget=E,!Ne.__hasExternalTextures){const Be=Math.max(1,E.width>>De),Ie=Math.max(1,E.height>>De);he===a.TEXTURE_3D||he===a.TEXTURE_2D_ARRAY?i.texImage3D(he,De,ge,Be,Ie,E.depth,0,Le,pe,null):i.texImage2D(he,De,ge,Be,Ie,0,Le,pe,null)}i.bindFramebuffer(a.FRAMEBUFFER,D),St(E)?p.framebufferTexture2DMultisampleEXT(a.FRAMEBUFFER,se,he,Ve.__webglTexture,0,Yt(E)):(he===a.TEXTURE_2D||he>=a.TEXTURE_CUBE_MAP_POSITIVE_X&&he<=a.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&a.framebufferTexture2D(a.FRAMEBUFFER,se,he,Ve.__webglTexture,De),i.bindFramebuffer(a.FRAMEBUFFER,null)}function Dt(D,E,K){if(a.bindRenderbuffer(a.RENDERBUFFER,D),E.depthBuffer){const se=E.depthTexture,he=se&&se.isDepthTexture?se.type:null,De=B(E.stencilBuffer,he),Le=E.stencilBuffer?a.DEPTH_STENCIL_ATTACHMENT:a.DEPTH_ATTACHMENT;St(E)?p.renderbufferStorageMultisampleEXT(a.RENDERBUFFER,Yt(E),De,E.width,E.height):K?a.renderbufferStorageMultisample(a.RENDERBUFFER,Yt(E),De,E.width,E.height):a.renderbufferStorage(a.RENDERBUFFER,De,E.width,E.height),a.framebufferRenderbuffer(a.FRAMEBUFFER,Le,a.RENDERBUFFER,D)}else{const se=E.textures;for(let he=0;he<se.length;he++){const De=se[he],Le=c.convert(De.format,De.colorSpace),pe=c.convert(De.type),ge=w(De.internalFormat,Le,pe,De.normalized,De.colorSpace);St(E)?p.renderbufferStorageMultisampleEXT(a.RENDERBUFFER,Yt(E),ge,E.width,E.height):K?a.renderbufferStorageMultisample(a.RENDERBUFFER,Yt(E),ge,E.width,E.height):a.renderbufferStorage(a.RENDERBUFFER,ge,E.width,E.height)}}a.bindRenderbuffer(a.RENDERBUFFER,null)}function ut(D,E,K){const se=E.isWebGLCubeRenderTarget===!0;if(i.bindFramebuffer(a.FRAMEBUFFER,D),!(E.depthTexture&&E.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const he=s.get(E.depthTexture);if(he.__renderTarget=E,(!he.__webglTexture||E.depthTexture.image.width!==E.width||E.depthTexture.image.height!==E.height)&&(E.depthTexture.image.width=E.width,E.depthTexture.image.height=E.height,E.depthTexture.needsUpdate=!0),se){if(he.__webglInit===void 0&&(he.__webglInit=!0,E.depthTexture.addEventListener("dispose",F)),he.__webglTexture===void 0){he.__webglTexture=a.createTexture(),i.bindTexture(a.TEXTURE_CUBE_MAP,he.__webglTexture),Ce(a.TEXTURE_CUBE_MAP,E.depthTexture);const Ne=c.convert(E.depthTexture.format),Ve=c.convert(E.depthTexture.type);let Be;E.depthTexture.format===Fa?Be=a.DEPTH_COMPONENT24:E.depthTexture.format===jr&&(Be=a.DEPTH24_STENCIL8);for(let Ie=0;Ie<6;Ie++)a.texImage2D(a.TEXTURE_CUBE_MAP_POSITIVE_X+Ie,0,Be,E.width,E.height,0,Ne,Ve,null)}}else $(E.depthTexture,0);const De=he.__webglTexture,Le=Yt(E),pe=se?a.TEXTURE_CUBE_MAP_POSITIVE_X+K:a.TEXTURE_2D,ge=E.depthTexture.format===jr?a.DEPTH_STENCIL_ATTACHMENT:a.DEPTH_ATTACHMENT;if(E.depthTexture.format===Fa)St(E)?p.framebufferTexture2DMultisampleEXT(a.FRAMEBUFFER,ge,pe,De,0,Le):a.framebufferTexture2D(a.FRAMEBUFFER,ge,pe,De,0);else if(E.depthTexture.format===jr)St(E)?p.framebufferTexture2DMultisampleEXT(a.FRAMEBUFFER,ge,pe,De,0,Le):a.framebufferTexture2D(a.FRAMEBUFFER,ge,pe,De,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function pt(D){const E=s.get(D),K=D.isWebGLCubeRenderTarget===!0;if(E.__boundDepthTexture!==D.depthTexture){const se=D.depthTexture;if(E.__depthDisposeCallback&&E.__depthDisposeCallback(),se){const he=()=>{delete E.__boundDepthTexture,delete E.__depthDisposeCallback,se.removeEventListener("dispose",he)};se.addEventListener("dispose",he),E.__depthDisposeCallback=he}E.__boundDepthTexture=se}if(D.depthTexture&&!E.__autoAllocateDepthBuffer)if(K)for(let se=0;se<6;se++)ut(E.__webglFramebuffer[se],D,se);else{const se=D.texture.mipmaps;se&&se.length>0?ut(E.__webglFramebuffer[0],D,0):ut(E.__webglFramebuffer,D,0)}else if(K){E.__webglDepthbuffer=[];for(let se=0;se<6;se++)if(i.bindFramebuffer(a.FRAMEBUFFER,E.__webglFramebuffer[se]),E.__webglDepthbuffer[se]===void 0)E.__webglDepthbuffer[se]=a.createRenderbuffer(),Dt(E.__webglDepthbuffer[se],D,!1);else{const he=D.stencilBuffer?a.DEPTH_STENCIL_ATTACHMENT:a.DEPTH_ATTACHMENT,De=E.__webglDepthbuffer[se];a.bindRenderbuffer(a.RENDERBUFFER,De),a.framebufferRenderbuffer(a.FRAMEBUFFER,he,a.RENDERBUFFER,De)}}else{const se=D.texture.mipmaps;if(se&&se.length>0?i.bindFramebuffer(a.FRAMEBUFFER,E.__webglFramebuffer[0]):i.bindFramebuffer(a.FRAMEBUFFER,E.__webglFramebuffer),E.__webglDepthbuffer===void 0)E.__webglDepthbuffer=a.createRenderbuffer(),Dt(E.__webglDepthbuffer,D,!1);else{const he=D.stencilBuffer?a.DEPTH_STENCIL_ATTACHMENT:a.DEPTH_ATTACHMENT,De=E.__webglDepthbuffer;a.bindRenderbuffer(a.RENDERBUFFER,De),a.framebufferRenderbuffer(a.FRAMEBUFFER,he,a.RENDERBUFFER,De)}}i.bindFramebuffer(a.FRAMEBUFFER,null)}function mt(D,E,K){const se=s.get(D);E!==void 0&&je(se.__webglFramebuffer,D,D.texture,a.COLOR_ATTACHMENT0,a.TEXTURE_2D,0),K!==void 0&&pt(D)}function dt(D){const E=D.texture,K=s.get(D),se=s.get(E);D.addEventListener("dispose",T);const he=D.textures,De=D.isWebGLCubeRenderTarget===!0,Le=he.length>1;if(Le||(se.__webglTexture===void 0&&(se.__webglTexture=a.createTexture()),se.__version=E.version,f.memory.textures++),De){K.__webglFramebuffer=[];for(let pe=0;pe<6;pe++)if(E.mipmaps&&E.mipmaps.length>0){K.__webglFramebuffer[pe]=[];for(let ge=0;ge<E.mipmaps.length;ge++)K.__webglFramebuffer[pe][ge]=a.createFramebuffer()}else K.__webglFramebuffer[pe]=a.createFramebuffer()}else{if(E.mipmaps&&E.mipmaps.length>0){K.__webglFramebuffer=[];for(let pe=0;pe<E.mipmaps.length;pe++)K.__webglFramebuffer[pe]=a.createFramebuffer()}else K.__webglFramebuffer=a.createFramebuffer();if(Le)for(let pe=0,ge=he.length;pe<ge;pe++){const Ne=s.get(he[pe]);Ne.__webglTexture===void 0&&(Ne.__webglTexture=a.createTexture(),f.memory.textures++)}if(D.samples>0&&St(D)===!1){K.__webglMultisampledFramebuffer=a.createFramebuffer(),K.__webglColorRenderbuffer=[],i.bindFramebuffer(a.FRAMEBUFFER,K.__webglMultisampledFramebuffer);for(let pe=0;pe<he.length;pe++){const ge=he[pe];K.__webglColorRenderbuffer[pe]=a.createRenderbuffer(),a.bindRenderbuffer(a.RENDERBUFFER,K.__webglColorRenderbuffer[pe]);const Ne=c.convert(ge.format,ge.colorSpace),Ve=c.convert(ge.type),Be=w(ge.internalFormat,Ne,Ve,ge.normalized,ge.colorSpace,D.isXRRenderTarget===!0),Ie=Yt(D);a.renderbufferStorageMultisample(a.RENDERBUFFER,Ie,Be,D.width,D.height),a.framebufferRenderbuffer(a.FRAMEBUFFER,a.COLOR_ATTACHMENT0+pe,a.RENDERBUFFER,K.__webglColorRenderbuffer[pe])}a.bindRenderbuffer(a.RENDERBUFFER,null),D.depthBuffer&&(K.__webglDepthRenderbuffer=a.createRenderbuffer(),Dt(K.__webglDepthRenderbuffer,D,!0)),i.bindFramebuffer(a.FRAMEBUFFER,null)}}if(De){i.bindTexture(a.TEXTURE_CUBE_MAP,se.__webglTexture),Ce(a.TEXTURE_CUBE_MAP,E);for(let pe=0;pe<6;pe++)if(E.mipmaps&&E.mipmaps.length>0)for(let ge=0;ge<E.mipmaps.length;ge++)je(K.__webglFramebuffer[pe][ge],D,E,a.COLOR_ATTACHMENT0,a.TEXTURE_CUBE_MAP_POSITIVE_X+pe,ge);else je(K.__webglFramebuffer[pe],D,E,a.COLOR_ATTACHMENT0,a.TEXTURE_CUBE_MAP_POSITIVE_X+pe,0);x(E)&&O(a.TEXTURE_CUBE_MAP),i.unbindTexture()}else if(Le){for(let pe=0,ge=he.length;pe<ge;pe++){const Ne=he[pe],Ve=s.get(Ne);let Be=a.TEXTURE_2D;(D.isWebGL3DRenderTarget||D.isWebGLArrayRenderTarget)&&(Be=D.isWebGL3DRenderTarget?a.TEXTURE_3D:a.TEXTURE_2D_ARRAY),i.bindTexture(Be,Ve.__webglTexture),Ce(Be,Ne),je(K.__webglFramebuffer,D,Ne,a.COLOR_ATTACHMENT0+pe,Be,0),x(Ne)&&O(Be)}i.unbindTexture()}else{let pe=a.TEXTURE_2D;if((D.isWebGL3DRenderTarget||D.isWebGLArrayRenderTarget)&&(pe=D.isWebGL3DRenderTarget?a.TEXTURE_3D:a.TEXTURE_2D_ARRAY),i.bindTexture(pe,se.__webglTexture),Ce(pe,E),E.mipmaps&&E.mipmaps.length>0)for(let ge=0;ge<E.mipmaps.length;ge++)je(K.__webglFramebuffer[ge],D,E,a.COLOR_ATTACHMENT0,pe,ge);else je(K.__webglFramebuffer,D,E,a.COLOR_ATTACHMENT0,pe,0);x(E)&&O(pe),i.unbindTexture()}D.depthBuffer&&pt(D)}function qt(D){const E=D.textures;for(let K=0,se=E.length;K<se;K++){const he=E[K];if(x(he)){const De=I(D),Le=s.get(he).__webglTexture;i.bindTexture(De,Le),O(De),i.unbindTexture()}}}const $t=[],Ut=[];function cn(D){if(D.samples>0){if(St(D)===!1){const E=D.textures,K=D.width,se=D.height;let he=a.COLOR_BUFFER_BIT;const De=D.stencilBuffer?a.DEPTH_STENCIL_ATTACHMENT:a.DEPTH_ATTACHMENT,Le=s.get(D),pe=E.length>1;if(pe)for(let Ne=0;Ne<E.length;Ne++)i.bindFramebuffer(a.FRAMEBUFFER,Le.__webglMultisampledFramebuffer),a.framebufferRenderbuffer(a.FRAMEBUFFER,a.COLOR_ATTACHMENT0+Ne,a.RENDERBUFFER,null),i.bindFramebuffer(a.FRAMEBUFFER,Le.__webglFramebuffer),a.framebufferTexture2D(a.DRAW_FRAMEBUFFER,a.COLOR_ATTACHMENT0+Ne,a.TEXTURE_2D,null,0);i.bindFramebuffer(a.READ_FRAMEBUFFER,Le.__webglMultisampledFramebuffer);const ge=D.texture.mipmaps;ge&&ge.length>0?i.bindFramebuffer(a.DRAW_FRAMEBUFFER,Le.__webglFramebuffer[0]):i.bindFramebuffer(a.DRAW_FRAMEBUFFER,Le.__webglFramebuffer);for(let Ne=0;Ne<E.length;Ne++){if(D.resolveDepthBuffer&&(D.depthBuffer&&(he|=a.DEPTH_BUFFER_BIT),D.stencilBuffer&&D.resolveStencilBuffer&&(he|=a.STENCIL_BUFFER_BIT)),pe){a.framebufferRenderbuffer(a.READ_FRAMEBUFFER,a.COLOR_ATTACHMENT0,a.RENDERBUFFER,Le.__webglColorRenderbuffer[Ne]);const Ve=s.get(E[Ne]).__webglTexture;a.framebufferTexture2D(a.DRAW_FRAMEBUFFER,a.COLOR_ATTACHMENT0,a.TEXTURE_2D,Ve,0)}a.blitFramebuffer(0,0,K,se,0,0,K,se,he,a.NEAREST),m===!0&&($t.length=0,Ut.length=0,$t.push(a.COLOR_ATTACHMENT0+Ne),D.depthBuffer&&D.resolveDepthBuffer===!1&&($t.push(De),Ut.push(De),a.invalidateFramebuffer(a.DRAW_FRAMEBUFFER,Ut)),a.invalidateFramebuffer(a.READ_FRAMEBUFFER,$t))}if(i.bindFramebuffer(a.READ_FRAMEBUFFER,null),i.bindFramebuffer(a.DRAW_FRAMEBUFFER,null),pe)for(let Ne=0;Ne<E.length;Ne++){i.bindFramebuffer(a.FRAMEBUFFER,Le.__webglMultisampledFramebuffer),a.framebufferRenderbuffer(a.FRAMEBUFFER,a.COLOR_ATTACHMENT0+Ne,a.RENDERBUFFER,Le.__webglColorRenderbuffer[Ne]);const Ve=s.get(E[Ne]).__webglTexture;i.bindFramebuffer(a.FRAMEBUFFER,Le.__webglFramebuffer),a.framebufferTexture2D(a.DRAW_FRAMEBUFFER,a.COLOR_ATTACHMENT0+Ne,a.TEXTURE_2D,Ve,0)}i.bindFramebuffer(a.DRAW_FRAMEBUFFER,Le.__webglMultisampledFramebuffer)}else if(D.depthBuffer&&D.resolveDepthBuffer===!1&&m){const E=D.stencilBuffer?a.DEPTH_STENCIL_ATTACHMENT:a.DEPTH_ATTACHMENT;a.invalidateFramebuffer(a.DRAW_FRAMEBUFFER,[E])}}}function Yt(D){return Math.min(l.maxSamples,D.samples)}function St(D){const E=s.get(D);return D.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&E.__useRenderToTexture!==!1}function X(D){const E=f.render.frame;_.get(D)!==E&&(_.set(D,E),D.update())}function Bt(D,E){const K=D.colorSpace,se=D.format,he=D.type;return D.isCompressedTexture===!0||D.isVideoTexture===!0||K!==pu&&K!==Sr&&(Tt.getTransfer(K)===Wt?(se!==zi||he!==Ai)&&rt("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):wt("WebGLTextures: Unsupported texture color space:",K)),E}function Ct(D){return typeof HTMLImageElement<"u"&&D instanceof HTMLImageElement?(h.width=D.naturalWidth||D.width,h.height=D.naturalHeight||D.height):typeof VideoFrame<"u"&&D instanceof VideoFrame?(h.width=D.displayWidth,h.height=D.displayHeight):(h.width=D.width,h.height=D.height),h}this.allocateTextureUnit=L,this.resetTextureUnits=fe,this.getTextureUnits=me,this.setTextureUnits=j,this.setTexture2D=$,this.setTexture2DArray=_e,this.setTexture3D=be,this.setTextureCube=N,this.rebindTextures=mt,this.setupRenderTarget=dt,this.updateRenderTargetMipmap=qt,this.updateMultisampleRenderTarget=cn,this.setupDepthRenderbuffer=pt,this.setupFrameBufferTexture=je,this.useMultisampledRTT=St,this.isReversedDepthBuffer=function(){return i.buffers.depth.getReversed()}}function j2(a,e){function i(s,l=Sr){let c;const f=Tt.getTransfer(l);if(s===Ai)return a.UNSIGNED_BYTE;if(s===bp)return a.UNSIGNED_SHORT_4_4_4_4;if(s===Tp)return a.UNSIGNED_SHORT_5_5_5_1;if(s===xx)return a.UNSIGNED_INT_5_9_9_9_REV;if(s===Sx)return a.UNSIGNED_INT_10F_11F_11F_REV;if(s===vx)return a.BYTE;if(s===_x)return a.SHORT;if(s===cl)return a.UNSIGNED_SHORT;if(s===Ep)return a.INT;if(s===aa)return a.UNSIGNED_INT;if(s===$i)return a.FLOAT;if(s===Ba)return a.HALF_FLOAT;if(s===yx)return a.ALPHA;if(s===Mx)return a.RGB;if(s===zi)return a.RGBA;if(s===Fa)return a.DEPTH_COMPONENT;if(s===jr)return a.DEPTH_STENCIL;if(s===Ex)return a.RED;if(s===Ap)return a.RED_INTEGER;if(s===$r)return a.RG;if(s===Rp)return a.RG_INTEGER;if(s===Cp)return a.RGBA_INTEGER;if(s===ru||s===su||s===ou||s===lu)if(f===Wt)if(c=e.get("WEBGL_compressed_texture_s3tc_srgb"),c!==null){if(s===ru)return c.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(s===su)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(s===ou)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(s===lu)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(c=e.get("WEBGL_compressed_texture_s3tc"),c!==null){if(s===ru)return c.COMPRESSED_RGB_S3TC_DXT1_EXT;if(s===su)return c.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(s===ou)return c.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(s===lu)return c.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(s===Lh||s===Oh||s===Ph||s===Ih)if(c=e.get("WEBGL_compressed_texture_pvrtc"),c!==null){if(s===Lh)return c.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(s===Oh)return c.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(s===Ph)return c.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(s===Ih)return c.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(s===Bh||s===Fh||s===zh||s===Hh||s===Gh||s===du||s===Vh)if(c=e.get("WEBGL_compressed_texture_etc"),c!==null){if(s===Bh||s===Fh)return f===Wt?c.COMPRESSED_SRGB8_ETC2:c.COMPRESSED_RGB8_ETC2;if(s===zh)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:c.COMPRESSED_RGBA8_ETC2_EAC;if(s===Hh)return c.COMPRESSED_R11_EAC;if(s===Gh)return c.COMPRESSED_SIGNED_R11_EAC;if(s===du)return c.COMPRESSED_RG11_EAC;if(s===Vh)return c.COMPRESSED_SIGNED_RG11_EAC}else return null;if(s===kh||s===Xh||s===Wh||s===qh||s===Yh||s===Zh||s===Kh||s===Qh||s===jh||s===Jh||s===$h||s===ep||s===tp||s===np)if(c=e.get("WEBGL_compressed_texture_astc"),c!==null){if(s===kh)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:c.COMPRESSED_RGBA_ASTC_4x4_KHR;if(s===Xh)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:c.COMPRESSED_RGBA_ASTC_5x4_KHR;if(s===Wh)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:c.COMPRESSED_RGBA_ASTC_5x5_KHR;if(s===qh)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:c.COMPRESSED_RGBA_ASTC_6x5_KHR;if(s===Yh)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:c.COMPRESSED_RGBA_ASTC_6x6_KHR;if(s===Zh)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:c.COMPRESSED_RGBA_ASTC_8x5_KHR;if(s===Kh)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:c.COMPRESSED_RGBA_ASTC_8x6_KHR;if(s===Qh)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:c.COMPRESSED_RGBA_ASTC_8x8_KHR;if(s===jh)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:c.COMPRESSED_RGBA_ASTC_10x5_KHR;if(s===Jh)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:c.COMPRESSED_RGBA_ASTC_10x6_KHR;if(s===$h)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:c.COMPRESSED_RGBA_ASTC_10x8_KHR;if(s===ep)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:c.COMPRESSED_RGBA_ASTC_10x10_KHR;if(s===tp)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:c.COMPRESSED_RGBA_ASTC_12x10_KHR;if(s===np)return f===Wt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:c.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(s===ip||s===ap||s===rp)if(c=e.get("EXT_texture_compression_bptc"),c!==null){if(s===ip)return f===Wt?c.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:c.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(s===ap)return c.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(s===rp)return c.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(s===sp||s===op||s===hu||s===lp)if(c=e.get("EXT_texture_compression_rgtc"),c!==null){if(s===sp)return c.COMPRESSED_RED_RGTC1_EXT;if(s===op)return c.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(s===hu)return c.COMPRESSED_RED_GREEN_RGTC2_EXT;if(s===lp)return c.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return s===ul?a.UNSIGNED_INT_24_8:a[s]!==void 0?a[s]:null}return{convert:i}}const J2=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,$2=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class e3{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,i){if(this.texture===null){const s=new Lx(e.texture);(e.depthNear!==i.depthNear||e.depthFar!==i.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=s}}getMesh(e){if(this.texture!==null&&this.mesh===null){const i=e.cameras[0].viewport,s=new Gi({vertexShader:J2,fragmentShader:$2,uniforms:{depthColor:{value:this.texture},depthWidth:{value:i.z},depthHeight:{value:i.w}}});this.mesh=new ra(new vl(20,20),s)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class t3 extends ts{constructor(e,i){super();const s=this;let l=null,c=1,f=null,p="local-floor",m=1,h=null,_=null,g=null,v=null,M=null,b=null;const C=typeof XRWebGLBinding<"u",y=new e3,x={},O=i.getContextAttributes();let I=null,w=null;const B=[],U=[],F=new Pt;let T=null;const P=new Bi;P.viewport=new dn;const q=new Bi;q.viewport=new dn;const V=[P,q],Q=new u1;let fe=null,me=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(ee){let Me=B[ee];return Me===void 0&&(Me=new Qd,B[ee]=Me),Me.getTargetRaySpace()},this.getControllerGrip=function(ee){let Me=B[ee];return Me===void 0&&(Me=new Qd,B[ee]=Me),Me.getGripSpace()},this.getHand=function(ee){let Me=B[ee];return Me===void 0&&(Me=new Qd,B[ee]=Me),Me.getHandSpace()};function j(ee){const Me=U.indexOf(ee.inputSource);if(Me===-1)return;const ve=B[Me];ve!==void 0&&(ve.update(ee.inputSource,ee.frame,h||f),ve.dispatchEvent({type:ee.type,data:ee.inputSource}))}function L(){l.removeEventListener("select",j),l.removeEventListener("selectstart",j),l.removeEventListener("selectend",j),l.removeEventListener("squeeze",j),l.removeEventListener("squeezestart",j),l.removeEventListener("squeezeend",j),l.removeEventListener("end",L),l.removeEventListener("inputsourceschange",H);for(let ee=0;ee<B.length;ee++){const Me=U[ee];Me!==null&&(U[ee]=null,B[ee].disconnect(Me))}fe=null,me=null,y.reset();for(const ee in x)delete x[ee];e.setRenderTarget(I),M=null,v=null,g=null,l=null,w=null,Ce.stop(),s.isPresenting=!1,e.setPixelRatio(T),e.setSize(F.width,F.height,!1),s.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(ee){c=ee,s.isPresenting===!0&&rt("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(ee){p=ee,s.isPresenting===!0&&rt("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return h||f},this.setReferenceSpace=function(ee){h=ee},this.getBaseLayer=function(){return v!==null?v:M},this.getBinding=function(){return g===null&&C&&(g=new XRWebGLBinding(l,i)),g},this.getFrame=function(){return b},this.getSession=function(){return l},this.setSession=async function(ee){if(l=ee,l!==null){if(I=e.getRenderTarget(),l.addEventListener("select",j),l.addEventListener("selectstart",j),l.addEventListener("selectend",j),l.addEventListener("squeeze",j),l.addEventListener("squeezestart",j),l.addEventListener("squeezeend",j),l.addEventListener("end",L),l.addEventListener("inputsourceschange",H),O.xrCompatible!==!0&&await i.makeXRCompatible(),T=e.getPixelRatio(),e.getSize(F),C&&"createProjectionLayer"in XRWebGLBinding.prototype){let ve=null,He=null,nt=null;O.depth&&(nt=O.stencil?i.DEPTH24_STENCIL8:i.DEPTH_COMPONENT24,ve=O.stencil?jr:Fa,He=O.stencil?ul:aa);const je={colorFormat:i.RGBA8,depthFormat:nt,scaleFactor:c};g=this.getBinding(),v=g.createProjectionLayer(je),l.updateRenderState({layers:[v]}),e.setPixelRatio(1),e.setSize(v.textureWidth,v.textureHeight,!1),w=new na(v.textureWidth,v.textureHeight,{format:zi,type:Ai,depthTexture:new eo(v.textureWidth,v.textureHeight,He,void 0,void 0,void 0,void 0,void 0,void 0,ve),stencilBuffer:O.stencil,colorSpace:e.outputColorSpace,samples:O.antialias?4:0,resolveDepthBuffer:v.ignoreDepthValues===!1,resolveStencilBuffer:v.ignoreDepthValues===!1})}else{const ve={antialias:O.antialias,alpha:!0,depth:O.depth,stencil:O.stencil,framebufferScaleFactor:c};M=new XRWebGLLayer(l,i,ve),l.updateRenderState({baseLayer:M}),e.setPixelRatio(1),e.setSize(M.framebufferWidth,M.framebufferHeight,!1),w=new na(M.framebufferWidth,M.framebufferHeight,{format:zi,type:Ai,colorSpace:e.outputColorSpace,stencilBuffer:O.stencil,resolveDepthBuffer:M.ignoreDepthValues===!1,resolveStencilBuffer:M.ignoreDepthValues===!1})}w.isXRRenderTarget=!0,this.setFoveation(m),h=null,f=await l.requestReferenceSpace(p),Ce.setContext(l),Ce.start(),s.isPresenting=!0,s.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(l!==null)return l.environmentBlendMode},this.getDepthTexture=function(){return y.getDepthTexture()};function H(ee){for(let Me=0;Me<ee.removed.length;Me++){const ve=ee.removed[Me],He=U.indexOf(ve);He>=0&&(U[He]=null,B[He].disconnect(ve))}for(let Me=0;Me<ee.added.length;Me++){const ve=ee.added[Me];let He=U.indexOf(ve);if(He===-1){for(let je=0;je<B.length;je++)if(je>=U.length){U.push(ve),He=je;break}else if(U[je]===null){U[je]=ve,He=je;break}if(He===-1)break}const nt=B[He];nt&&nt.connect(ve)}}const $=new ce,_e=new ce;function be(ee,Me,ve){$.setFromMatrixPosition(Me.matrixWorld),_e.setFromMatrixPosition(ve.matrixWorld);const He=$.distanceTo(_e),nt=Me.projectionMatrix.elements,je=ve.projectionMatrix.elements,Dt=nt[14]/(nt[10]-1),ut=nt[14]/(nt[10]+1),pt=(nt[9]+1)/nt[5],mt=(nt[9]-1)/nt[5],dt=(nt[8]-1)/nt[0],qt=(je[8]+1)/je[0],$t=Dt*dt,Ut=Dt*qt,cn=He/(-dt+qt),Yt=cn*-dt;if(Me.matrixWorld.decompose(ee.position,ee.quaternion,ee.scale),ee.translateX(Yt),ee.translateZ(cn),ee.matrixWorld.compose(ee.position,ee.quaternion,ee.scale),ee.matrixWorldInverse.copy(ee.matrixWorld).invert(),nt[10]===-1)ee.projectionMatrix.copy(Me.projectionMatrix),ee.projectionMatrixInverse.copy(Me.projectionMatrixInverse);else{const St=Dt+cn,X=ut+cn,Bt=$t-Yt,Ct=Ut+(He-Yt),D=pt*ut/X*St,E=mt*ut/X*St;ee.projectionMatrix.makePerspective(Bt,Ct,D,E,St,X),ee.projectionMatrixInverse.copy(ee.projectionMatrix).invert()}}function N(ee,Me){Me===null?ee.matrixWorld.copy(ee.matrix):ee.matrixWorld.multiplyMatrices(Me.matrixWorld,ee.matrix),ee.matrixWorldInverse.copy(ee.matrixWorld).invert()}this.updateCamera=function(ee){if(l===null)return;let Me=ee.near,ve=ee.far;y.texture!==null&&(y.depthNear>0&&(Me=y.depthNear),y.depthFar>0&&(ve=y.depthFar)),Q.near=q.near=P.near=Me,Q.far=q.far=P.far=ve,(fe!==Q.near||me!==Q.far)&&(l.updateRenderState({depthNear:Q.near,depthFar:Q.far}),fe=Q.near,me=Q.far),Q.layers.mask=ee.layers.mask|6,P.layers.mask=Q.layers.mask&-5,q.layers.mask=Q.layers.mask&-3;const He=ee.parent,nt=Q.cameras;N(Q,He);for(let je=0;je<nt.length;je++)N(nt[je],He);nt.length===2?be(Q,P,q):Q.projectionMatrix.copy(P.projectionMatrix),Y(ee,Q,He)};function Y(ee,Me,ve){ve===null?ee.matrix.copy(Me.matrixWorld):(ee.matrix.copy(ve.matrixWorld),ee.matrix.invert(),ee.matrix.multiply(Me.matrixWorld)),ee.matrix.decompose(ee.position,ee.quaternion,ee.scale),ee.updateMatrixWorld(!0),ee.projectionMatrix.copy(Me.projectionMatrix),ee.projectionMatrixInverse.copy(Me.projectionMatrixInverse),ee.isPerspectiveCamera&&(ee.fov=cp*2*Math.atan(1/ee.projectionMatrix.elements[5]),ee.zoom=1)}this.getCamera=function(){return Q},this.getFoveation=function(){if(!(v===null&&M===null))return m},this.setFoveation=function(ee){m=ee,v!==null&&(v.fixedFoveation=ee),M!==null&&M.fixedFoveation!==void 0&&(M.fixedFoveation=ee)},this.hasDepthSensing=function(){return y.texture!==null},this.getDepthSensingMesh=function(){return y.getMesh(Q)},this.getCameraTexture=function(ee){return x[ee]};let de=null;function Te(ee,Me){if(_=Me.getViewerPose(h||f),b=Me,_!==null){const ve=_.views;M!==null&&(e.setRenderTargetFramebuffer(w,M.framebuffer),e.setRenderTarget(w));let He=!1;ve.length!==Q.cameras.length&&(Q.cameras.length=0,He=!0);for(let ut=0;ut<ve.length;ut++){const pt=ve[ut];let mt=null;if(M!==null)mt=M.getViewport(pt);else{const qt=g.getViewSubImage(v,pt);mt=qt.viewport,ut===0&&(e.setRenderTargetTextures(w,qt.colorTexture,qt.depthStencilTexture),e.setRenderTarget(w))}let dt=V[ut];dt===void 0&&(dt=new Bi,dt.layers.enable(ut),dt.viewport=new dn,V[ut]=dt),dt.matrix.fromArray(pt.transform.matrix),dt.matrix.decompose(dt.position,dt.quaternion,dt.scale),dt.projectionMatrix.fromArray(pt.projectionMatrix),dt.projectionMatrixInverse.copy(dt.projectionMatrix).invert(),dt.viewport.set(mt.x,mt.y,mt.width,mt.height),ut===0&&(Q.matrix.copy(dt.matrix),Q.matrix.decompose(Q.position,Q.quaternion,Q.scale)),He===!0&&Q.cameras.push(dt)}const nt=l.enabledFeatures;if(nt&&nt.includes("depth-sensing")&&l.depthUsage=="gpu-optimized"&&C){g=s.getBinding();const ut=g.getDepthInformation(ve[0]);ut&&ut.isValid&&ut.texture&&y.init(ut,l.renderState)}if(nt&&nt.includes("camera-access")&&C){e.state.unbindTexture(),g=s.getBinding();for(let ut=0;ut<ve.length;ut++){const pt=ve[ut].camera;if(pt){let mt=x[pt];mt||(mt=new Lx,x[pt]=mt);const dt=g.getCameraImage(pt);mt.sourceTexture=dt}}}}for(let ve=0;ve<B.length;ve++){const He=U[ve],nt=B[ve];He!==null&&nt!==void 0&&nt.update(He,Me,h||f)}de&&de(ee,Me),Me.detectedPlanes&&s.dispatchEvent({type:"planesdetected",data:Me}),b=null}const Ce=new Ix;Ce.setAnimationLoop(Te),this.setAnimationLoop=function(ee){de=ee},this.dispose=function(){}}}const n3=new Mn,kx=new ot;kx.set(-1,0,0,0,1,0,0,0,1);function i3(a,e){function i(y,x){y.matrixAutoUpdate===!0&&y.updateMatrix(),x.value.copy(y.matrix)}function s(y,x){x.color.getRGB(y.fogColor.value,Ox(a)),x.isFog?(y.fogNear.value=x.near,y.fogFar.value=x.far):x.isFogExp2&&(y.fogDensity.value=x.density)}function l(y,x,O,I,w){x.isNodeMaterial?x.uniformsNeedUpdate=!1:x.isMeshBasicMaterial?c(y,x):x.isMeshLambertMaterial?(c(y,x),x.envMap&&(y.envMapIntensity.value=x.envMapIntensity)):x.isMeshToonMaterial?(c(y,x),g(y,x)):x.isMeshPhongMaterial?(c(y,x),_(y,x),x.envMap&&(y.envMapIntensity.value=x.envMapIntensity)):x.isMeshStandardMaterial?(c(y,x),v(y,x),x.isMeshPhysicalMaterial&&M(y,x,w)):x.isMeshMatcapMaterial?(c(y,x),b(y,x)):x.isMeshDepthMaterial?c(y,x):x.isMeshDistanceMaterial?(c(y,x),C(y,x)):x.isMeshNormalMaterial?c(y,x):x.isLineBasicMaterial?(f(y,x),x.isLineDashedMaterial&&p(y,x)):x.isPointsMaterial?m(y,x,O,I):x.isSpriteMaterial?h(y,x):x.isShadowMaterial?(y.color.value.copy(x.color),y.opacity.value=x.opacity):x.isShaderMaterial&&(x.uniformsNeedUpdate=!1)}function c(y,x){y.opacity.value=x.opacity,x.color&&y.diffuse.value.copy(x.color),x.emissive&&y.emissive.value.copy(x.emissive).multiplyScalar(x.emissiveIntensity),x.map&&(y.map.value=x.map,i(x.map,y.mapTransform)),x.alphaMap&&(y.alphaMap.value=x.alphaMap,i(x.alphaMap,y.alphaMapTransform)),x.bumpMap&&(y.bumpMap.value=x.bumpMap,i(x.bumpMap,y.bumpMapTransform),y.bumpScale.value=x.bumpScale,x.side===$n&&(y.bumpScale.value*=-1)),x.normalMap&&(y.normalMap.value=x.normalMap,i(x.normalMap,y.normalMapTransform),y.normalScale.value.copy(x.normalScale),x.side===$n&&y.normalScale.value.negate()),x.displacementMap&&(y.displacementMap.value=x.displacementMap,i(x.displacementMap,y.displacementMapTransform),y.displacementScale.value=x.displacementScale,y.displacementBias.value=x.displacementBias),x.emissiveMap&&(y.emissiveMap.value=x.emissiveMap,i(x.emissiveMap,y.emissiveMapTransform)),x.specularMap&&(y.specularMap.value=x.specularMap,i(x.specularMap,y.specularMapTransform)),x.alphaTest>0&&(y.alphaTest.value=x.alphaTest);const O=e.get(x),I=O.envMap,w=O.envMapRotation;I&&(y.envMap.value=I,y.envMapRotation.value.setFromMatrix4(n3.makeRotationFromEuler(w)).transpose(),I.isCubeTexture&&I.isRenderTargetTexture===!1&&y.envMapRotation.value.premultiply(kx),y.reflectivity.value=x.reflectivity,y.ior.value=x.ior,y.refractionRatio.value=x.refractionRatio),x.lightMap&&(y.lightMap.value=x.lightMap,y.lightMapIntensity.value=x.lightMapIntensity,i(x.lightMap,y.lightMapTransform)),x.aoMap&&(y.aoMap.value=x.aoMap,y.aoMapIntensity.value=x.aoMapIntensity,i(x.aoMap,y.aoMapTransform))}function f(y,x){y.diffuse.value.copy(x.color),y.opacity.value=x.opacity,x.map&&(y.map.value=x.map,i(x.map,y.mapTransform))}function p(y,x){y.dashSize.value=x.dashSize,y.totalSize.value=x.dashSize+x.gapSize,y.scale.value=x.scale}function m(y,x,O,I){y.diffuse.value.copy(x.color),y.opacity.value=x.opacity,y.size.value=x.size*O,y.scale.value=I*.5,x.map&&(y.map.value=x.map,i(x.map,y.uvTransform)),x.alphaMap&&(y.alphaMap.value=x.alphaMap,i(x.alphaMap,y.alphaMapTransform)),x.alphaTest>0&&(y.alphaTest.value=x.alphaTest)}function h(y,x){y.diffuse.value.copy(x.color),y.opacity.value=x.opacity,y.rotation.value=x.rotation,x.map&&(y.map.value=x.map,i(x.map,y.mapTransform)),x.alphaMap&&(y.alphaMap.value=x.alphaMap,i(x.alphaMap,y.alphaMapTransform)),x.alphaTest>0&&(y.alphaTest.value=x.alphaTest)}function _(y,x){y.specular.value.copy(x.specular),y.shininess.value=Math.max(x.shininess,1e-4)}function g(y,x){x.gradientMap&&(y.gradientMap.value=x.gradientMap)}function v(y,x){y.metalness.value=x.metalness,x.metalnessMap&&(y.metalnessMap.value=x.metalnessMap,i(x.metalnessMap,y.metalnessMapTransform)),y.roughness.value=x.roughness,x.roughnessMap&&(y.roughnessMap.value=x.roughnessMap,i(x.roughnessMap,y.roughnessMapTransform)),x.envMap&&(y.envMapIntensity.value=x.envMapIntensity)}function M(y,x,O){y.ior.value=x.ior,x.sheen>0&&(y.sheenColor.value.copy(x.sheenColor).multiplyScalar(x.sheen),y.sheenRoughness.value=x.sheenRoughness,x.sheenColorMap&&(y.sheenColorMap.value=x.sheenColorMap,i(x.sheenColorMap,y.sheenColorMapTransform)),x.sheenRoughnessMap&&(y.sheenRoughnessMap.value=x.sheenRoughnessMap,i(x.sheenRoughnessMap,y.sheenRoughnessMapTransform))),x.clearcoat>0&&(y.clearcoat.value=x.clearcoat,y.clearcoatRoughness.value=x.clearcoatRoughness,x.clearcoatMap&&(y.clearcoatMap.value=x.clearcoatMap,i(x.clearcoatMap,y.clearcoatMapTransform)),x.clearcoatRoughnessMap&&(y.clearcoatRoughnessMap.value=x.clearcoatRoughnessMap,i(x.clearcoatRoughnessMap,y.clearcoatRoughnessMapTransform)),x.clearcoatNormalMap&&(y.clearcoatNormalMap.value=x.clearcoatNormalMap,i(x.clearcoatNormalMap,y.clearcoatNormalMapTransform),y.clearcoatNormalScale.value.copy(x.clearcoatNormalScale),x.side===$n&&y.clearcoatNormalScale.value.negate())),x.dispersion>0&&(y.dispersion.value=x.dispersion),x.iridescence>0&&(y.iridescence.value=x.iridescence,y.iridescenceIOR.value=x.iridescenceIOR,y.iridescenceThicknessMinimum.value=x.iridescenceThicknessRange[0],y.iridescenceThicknessMaximum.value=x.iridescenceThicknessRange[1],x.iridescenceMap&&(y.iridescenceMap.value=x.iridescenceMap,i(x.iridescenceMap,y.iridescenceMapTransform)),x.iridescenceThicknessMap&&(y.iridescenceThicknessMap.value=x.iridescenceThicknessMap,i(x.iridescenceThicknessMap,y.iridescenceThicknessMapTransform))),x.transmission>0&&(y.transmission.value=x.transmission,y.transmissionSamplerMap.value=O.texture,y.transmissionSamplerSize.value.set(O.width,O.height),x.transmissionMap&&(y.transmissionMap.value=x.transmissionMap,i(x.transmissionMap,y.transmissionMapTransform)),y.thickness.value=x.thickness,x.thicknessMap&&(y.thicknessMap.value=x.thicknessMap,i(x.thicknessMap,y.thicknessMapTransform)),y.attenuationDistance.value=x.attenuationDistance,y.attenuationColor.value.copy(x.attenuationColor)),x.anisotropy>0&&(y.anisotropyVector.value.set(x.anisotropy*Math.cos(x.anisotropyRotation),x.anisotropy*Math.sin(x.anisotropyRotation)),x.anisotropyMap&&(y.anisotropyMap.value=x.anisotropyMap,i(x.anisotropyMap,y.anisotropyMapTransform))),y.specularIntensity.value=x.specularIntensity,y.specularColor.value.copy(x.specularColor),x.specularColorMap&&(y.specularColorMap.value=x.specularColorMap,i(x.specularColorMap,y.specularColorMapTransform)),x.specularIntensityMap&&(y.specularIntensityMap.value=x.specularIntensityMap,i(x.specularIntensityMap,y.specularIntensityMapTransform))}function b(y,x){x.matcap&&(y.matcap.value=x.matcap)}function C(y,x){const O=e.get(x).light;y.referencePosition.value.setFromMatrixPosition(O.matrixWorld),y.nearDistance.value=O.shadow.camera.near,y.farDistance.value=O.shadow.camera.far}return{refreshFogUniforms:s,refreshMaterialUniforms:l}}function a3(a,e,i,s){let l={},c={},f=[];const p=a.getParameter(a.MAX_UNIFORM_BUFFER_BINDINGS);function m(w,B){const U=B.program;s.uniformBlockBinding(w,U)}function h(w,B){let U=l[w.id];U===void 0&&(y(w),U=_(w),l[w.id]=U,w.addEventListener("dispose",O));const F=B.program;s.updateUBOMapping(w,F);const T=e.render.frame;c[w.id]!==T&&(v(w),c[w.id]=T)}function _(w){const B=g();w.__bindingPointIndex=B;const U=a.createBuffer(),F=w.__size,T=w.usage;return a.bindBuffer(a.UNIFORM_BUFFER,U),a.bufferData(a.UNIFORM_BUFFER,F,T),a.bindBuffer(a.UNIFORM_BUFFER,null),a.bindBufferBase(a.UNIFORM_BUFFER,B,U),U}function g(){for(let w=0;w<p;w++)if(f.indexOf(w)===-1)return f.push(w),w;return wt("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function v(w){const B=l[w.id],U=w.uniforms,F=w.__cache;a.bindBuffer(a.UNIFORM_BUFFER,B);for(let T=0,P=U.length;T<P;T++){const q=U[T];if(Array.isArray(q))for(let V=0,Q=q.length;V<Q;V++)M(q[V],T,V,F);else M(q,T,0,F)}a.bindBuffer(a.UNIFORM_BUFFER,null)}function M(w,B,U,F){if(C(w,B,U,F)===!0){const T=w.__offset,P=w.value;if(Array.isArray(P)){let q=0;for(let V=0;V<P.length;V++){const Q=P[V],fe=x(Q);b(Q,w.__data,q),typeof Q!="number"&&typeof Q!="boolean"&&!Q.isMatrix3&&!ArrayBuffer.isView(Q)&&(q+=fe.storage/Float32Array.BYTES_PER_ELEMENT)}}else b(P,w.__data,0);a.bufferSubData(a.UNIFORM_BUFFER,T,w.__data)}}function b(w,B,U){typeof w=="number"||typeof w=="boolean"?B[0]=w:w.isMatrix3?(B[0]=w.elements[0],B[1]=w.elements[1],B[2]=w.elements[2],B[3]=0,B[4]=w.elements[3],B[5]=w.elements[4],B[6]=w.elements[5],B[7]=0,B[8]=w.elements[6],B[9]=w.elements[7],B[10]=w.elements[8],B[11]=0):ArrayBuffer.isView(w)?B.set(new w.constructor(w.buffer,w.byteOffset,B.length)):w.toArray(B,U)}function C(w,B,U,F){const T=w.value,P=B+"_"+U;if(F[P]===void 0)return typeof T=="number"||typeof T=="boolean"?F[P]=T:ArrayBuffer.isView(T)?F[P]=T.slice():F[P]=T.clone(),!0;{const q=F[P];if(typeof T=="number"||typeof T=="boolean"){if(q!==T)return F[P]=T,!0}else{if(ArrayBuffer.isView(T))return!0;if(q.equals(T)===!1)return q.copy(T),!0}}return!1}function y(w){const B=w.uniforms;let U=0;const F=16;for(let P=0,q=B.length;P<q;P++){const V=Array.isArray(B[P])?B[P]:[B[P]];for(let Q=0,fe=V.length;Q<fe;Q++){const me=V[Q],j=Array.isArray(me.value)?me.value:[me.value];for(let L=0,H=j.length;L<H;L++){const $=j[L],_e=x($),be=U%F,N=be%_e.boundary,Y=be+N;U+=N,Y!==0&&F-Y<_e.storage&&(U+=F-Y),me.__data=new Float32Array(_e.storage/Float32Array.BYTES_PER_ELEMENT),me.__offset=U,U+=_e.storage}}}const T=U%F;return T>0&&(U+=F-T),w.__size=U,w.__cache={},this}function x(w){const B={boundary:0,storage:0};return typeof w=="number"||typeof w=="boolean"?(B.boundary=4,B.storage=4):w.isVector2?(B.boundary=8,B.storage=8):w.isVector3||w.isColor?(B.boundary=16,B.storage=12):w.isVector4?(B.boundary=16,B.storage=16):w.isMatrix3?(B.boundary=48,B.storage=48):w.isMatrix4?(B.boundary=64,B.storage=64):w.isTexture?rt("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(w)?(B.boundary=16,B.storage=w.byteLength):rt("WebGLRenderer: Unsupported uniform value type.",w),B}function O(w){const B=w.target;B.removeEventListener("dispose",O);const U=f.indexOf(B.__bindingPointIndex);f.splice(U,1),a.deleteBuffer(l[B.id]),delete l[B.id],delete c[B.id]}function I(){for(const w in l)a.deleteBuffer(l[w]);f=[],l={},c={}}return{bind:m,update:h,dispose:I}}const r3=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let Qi=null;function s3(){return Qi===null&&(Qi=new jb(r3,16,16,$r,Ba),Qi.name="DFG_LUT",Qi.minFilter=Hn,Qi.magFilter=Hn,Qi.wrapS=Na,Qi.wrapT=Na,Qi.generateMipmaps=!1,Qi.needsUpdate=!0),Qi}class o3{constructor(e={}){const{canvas:i=Rb(),context:s=null,depth:l=!0,stencil:c=!1,alpha:f=!1,antialias:p=!1,premultipliedAlpha:m=!0,preserveDrawingBuffer:h=!1,powerPreference:_="default",failIfMajorPerformanceCaveat:g=!1,reversedDepthBuffer:v=!1,outputBufferType:M=Ai}=e;this.isWebGLRenderer=!0;let b;if(s!==null){if(typeof WebGLRenderingContext<"u"&&s instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");b=s.getContextAttributes().alpha}else b=f;const C=M,y=new Set([Cp,Rp,Ap]),x=new Set([Ai,aa,cl,ul,bp,Tp]),O=new Uint32Array(4),I=new Int32Array(4),w=new ce;let B=null,U=null;const F=[],T=[];let P=null;this.domElement=i,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=ta,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const q=this;let V=!1,Q=null,fe=null,me=null,j=null;this._outputColorSpace=Ti;let L=0,H=0,$=null,_e=-1,be=null;const N=new dn,Y=new dn;let de=null;const Te=new zt(0);let Ce=0,ee=i.width,Me=i.height,ve=1,He=null,nt=null;const je=new dn(0,0,ee,Me),Dt=new dn(0,0,ee,Me);let ut=!1;const pt=new Ux;let mt=!1,dt=!1;const qt=new Mn,$t=new ce,Ut=new dn,cn={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Yt=!1;function St(){return $===null?ve:1}let X=s;function Bt(A,W){return i.getContext(A,W)}try{const A={alpha:!0,depth:l,stencil:c,antialias:p,premultipliedAlpha:m,preserveDrawingBuffer:h,powerPreference:_,failIfMajorPerformanceCaveat:g};if("setAttribute"in i&&i.setAttribute("data-engine",`three.js r${Mp}`),i.addEventListener("webglcontextlost",gt,!1),i.addEventListener("webglcontextrestored",Rt,!1),i.addEventListener("webglcontextcreationerror",en,!1),X===null){const W="webgl2";if(X=Bt(W,A),X===null)throw Bt(W)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}}catch(A){throw wt("WebGLRenderer: "+A.message),A}let Ct,D,E,K,se,he,De,Le,pe,ge,Ne,Ve,Be,Ie,Ye,$e,at,k,Ue,te,Ae,we,Se;function We(){Ct=new sR(X),Ct.init(),Ae=new j2(X,Ct),D=new JA(X,Ct,e,Ae),E=new K2(X,Ct),D.reversedDepthBuffer&&v&&E.buffers.depth.setReversed(!0),fe=X.createFramebuffer(),me=X.createFramebuffer(),j=X.createFramebuffer(),K=new cR(X),se=new P2,he=new Q2(X,Ct,E,se,D,Ae,K),De=new rR(q),Le=new h1(X),we=new QA(X,Le),pe=new oR(X,Le,K,we),ge=new fR(X,pe,Le,we,K),k=new uR(X,D,he),Ye=new $A(se),Ne=new O2(q,De,Ct,D,we,Ye),Ve=new i3(q,se),Be=new B2,Ie=new k2(Ct),at=new KA(q,De,E,ge,b,m),$e=new Z2(q,ge,D),Se=new a3(X,K,D,E),Ue=new jA(X,Ct,K),te=new lR(X,Ct,K),K.programs=Ne.programs,q.capabilities=D,q.extensions=Ct,q.properties=se,q.renderLists=Be,q.shadowMap=$e,q.state=E,q.info=K}We(),C!==Ai&&(P=new hR(C,i.width,i.height,p,l,c));const Oe=new t3(q,X);this.xr=Oe,this.getContext=function(){return X},this.getContextAttributes=function(){return X.getContextAttributes()},this.forceContextLoss=function(){const A=Ct.get("WEBGL_lose_context");A&&A.loseContext()},this.forceContextRestore=function(){const A=Ct.get("WEBGL_lose_context");A&&A.restoreContext()},this.getPixelRatio=function(){return ve},this.setPixelRatio=function(A){A!==void 0&&(ve=A,this.setSize(ee,Me,!1))},this.getSize=function(A){return A.set(ee,Me)},this.setSize=function(A,W,oe=!0){if(Oe.isPresenting){rt("WebGLRenderer: Can't change size while VR device is presenting.");return}ee=A,Me=W,i.width=Math.floor(A*ve),i.height=Math.floor(W*ve),oe===!0&&(i.style.width=A+"px",i.style.height=W+"px"),P!==null&&P.setSize(i.width,i.height),this.setViewport(0,0,A,W)},this.getDrawingBufferSize=function(A){return A.set(ee*ve,Me*ve).floor()},this.setDrawingBufferSize=function(A,W,oe){ee=A,Me=W,ve=oe,i.width=Math.floor(A*oe),i.height=Math.floor(W*oe),this.setViewport(0,0,A,W)},this.setEffects=function(A){if(C===Ai){wt("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(A){for(let W=0;W<A.length;W++)if(A[W].isOutputPass===!0){rt("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}P.setEffects(A||[])},this.getCurrentViewport=function(A){return A.copy(N)},this.getViewport=function(A){return A.copy(je)},this.setViewport=function(A,W,oe,ae){A.isVector4?je.set(A.x,A.y,A.z,A.w):je.set(A,W,oe,ae),E.viewport(N.copy(je).multiplyScalar(ve).round())},this.getScissor=function(A){return A.copy(Dt)},this.setScissor=function(A,W,oe,ae){A.isVector4?Dt.set(A.x,A.y,A.z,A.w):Dt.set(A,W,oe,ae),E.scissor(Y.copy(Dt).multiplyScalar(ve).round())},this.getScissorTest=function(){return ut},this.setScissorTest=function(A){E.setScissorTest(ut=A)},this.setOpaqueSort=function(A){He=A},this.setTransparentSort=function(A){nt=A},this.getClearColor=function(A){return A.copy(at.getClearColor())},this.setClearColor=function(){at.setClearColor(...arguments)},this.getClearAlpha=function(){return at.getClearAlpha()},this.setClearAlpha=function(){at.setClearAlpha(...arguments)},this.clear=function(A=!0,W=!0,oe=!0){let ae=0;if(A){let re=!1;if($!==null){const ze=$.texture.format;re=y.has(ze)}if(re){const ze=$.texture.type,Xe=x.has(ze),Fe=at.getClearColor(),Ze=at.getClearAlpha(),qe=Fe.r,et=Fe.g,lt=Fe.b;Xe?(O[0]=qe,O[1]=et,O[2]=lt,O[3]=Ze,X.clearBufferuiv(X.COLOR,0,O)):(I[0]=qe,I[1]=et,I[2]=lt,I[3]=Ze,X.clearBufferiv(X.COLOR,0,I))}else ae|=X.COLOR_BUFFER_BIT}W&&(ae|=X.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),oe&&(ae|=X.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),ae!==0&&X.clear(ae)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(A){A.setRenderer(this),Q=A},this.dispose=function(){i.removeEventListener("webglcontextlost",gt,!1),i.removeEventListener("webglcontextrestored",Rt,!1),i.removeEventListener("webglcontextcreationerror",en,!1),at.dispose(),Be.dispose(),Ie.dispose(),se.dispose(),De.dispose(),ge.dispose(),we.dispose(),Se.dispose(),Ne.dispose(),Oe.dispose(),Oe.removeEventListener("sessionstart",mn),Oe.removeEventListener("sessionend",Dn),Xn.stop()};function gt(A){A.preventDefault(),Yv("WebGLRenderer: Context Lost."),V=!0}function Rt(){Yv("WebGLRenderer: Context Restored."),V=!1;const A=K.autoReset,W=$e.enabled,oe=$e.autoUpdate,ae=$e.needsUpdate,re=$e.type;We(),K.autoReset=A,$e.enabled=W,$e.autoUpdate=oe,$e.needsUpdate=ae,$e.type=re}function en(A){wt("WebGLRenderer: A WebGL context could not be created. Reason: ",A.statusMessage)}function tn(A){const W=A.target;W.removeEventListener("dispose",tn),Ha(W)}function Ha(A){ei(A),se.remove(A)}function ei(A){const W=se.get(A).programs;W!==void 0&&(W.forEach(function(oe){Ne.releaseProgram(oe)}),A.isShaderMaterial&&Ne.releaseShaderCache(A))}this.renderBufferDirect=function(A,W,oe,ae,re,ze){W===null&&(W=cn);const Xe=re.isMesh&&re.matrixWorld.determinantAffine()<0,Fe=ka(A,W,oe,ae,re);E.setMaterial(ae,Xe);let Ze=oe.index,qe=1;if(ae.wireframe===!0){if(Ze=pe.getWireframeAttribute(oe),Ze===void 0)return;qe=2}const et=oe.drawRange,lt=oe.attributes.position;let Je=et.start*qe,Nt=(et.start+et.count)*qe;ze!==null&&(Je=Math.max(Je,ze.start*qe),Nt=Math.min(Nt,(ze.start+ze.count)*qe)),Ze!==null?(Je=Math.max(Je,0),Nt=Math.min(Nt,Ze.count)):lt!=null&&(Je=Math.max(Je,0),Nt=Math.min(Nt,lt.count));const rn=Nt-Je;if(rn<0||rn===1/0)return;we.setup(re,ae,Fe,oe,Ze);let jt,Ht=Ue;if(Ze!==null&&(jt=Le.get(Ze),Ht=te,Ht.setIndex(jt)),re.isMesh)ae.wireframe===!0?(E.setLineWidth(ae.wireframeLinewidth*St()),Ht.setMode(X.LINES)):Ht.setMode(X.TRIANGLES);else if(re.isLine){let Gt=ae.linewidth;Gt===void 0&&(Gt=1),E.setLineWidth(Gt*St()),re.isLineSegments?Ht.setMode(X.LINES):re.isLineLoop?Ht.setMode(X.LINE_LOOP):Ht.setMode(X.LINE_STRIP)}else re.isPoints?Ht.setMode(X.POINTS):re.isSprite&&Ht.setMode(X.TRIANGLES);if(re.isBatchedMesh)if(Ct.get("WEBGL_multi_draw"))Ht.renderMultiDraw(re._multiDrawStarts,re._multiDrawCounts,re._multiDrawCount);else{const Gt=re._multiDrawStarts,ke=re._multiDrawCounts,In=re._multiDrawCount,vt=Ze?Le.get(Ze).bytesPerElement:1,En=se.get(ae).currentProgram.getUniforms();for(let ti=0;ti<In;ti++)En.setValue(X,"_gl_DrawID",ti),Ht.render(Gt[ti]/vt,ke[ti])}else if(re.isInstancedMesh)Ht.renderInstances(Je,rn,re.count);else if(oe.isInstancedBufferGeometry){const Gt=oe._maxInstanceCount!==void 0?oe._maxInstanceCount:1/0,ke=Math.min(oe.instanceCount,Gt);Ht.renderInstances(Je,rn,ke)}else Ht.render(Je,rn)};function ns(A,W,oe){A.transparent===!0&&A.side===Ua&&A.forceSinglePass===!1?(A.side=$n,A.needsUpdate=!0,Va(A,W,oe),A.side=Mr,A.needsUpdate=!0,Va(A,W,oe),A.side=Ua):Va(A,W,oe)}this.compile=function(A,W,oe=null){oe===null&&(oe=A),U=Ie.get(oe),U.init(W),T.push(U),oe.traverseVisible(function(re){re.isLight&&re.layers.test(W.layers)&&(U.pushLight(re),re.castShadow&&U.pushShadow(re))}),A!==oe&&A.traverseVisible(function(re){re.isLight&&re.layers.test(W.layers)&&(U.pushLight(re),re.castShadow&&U.pushShadow(re))}),U.setupLights();const ae=new Set;return A.traverse(function(re){if(!(re.isMesh||re.isPoints||re.isLine||re.isSprite))return;const ze=re.material;if(ze)if(Array.isArray(ze))for(let Xe=0;Xe<ze.length;Xe++){const Fe=ze[Xe];ns(Fe,oe,re),ae.add(Fe)}else ns(ze,oe,re),ae.add(ze)}),U=T.pop(),ae},this.compileAsync=function(A,W,oe=null){const ae=this.compile(A,W,oe);return new Promise(re=>{function ze(){if(ae.forEach(function(Xe){se.get(Xe).currentProgram.isReady()&&ae.delete(Xe)}),ae.size===0){re(A);return}setTimeout(ze,10)}Ct.get("KHR_parallel_shader_compile")!==null?ze():setTimeout(ze,10)})};let is=null;function ki(A){is&&is(A)}function mn(){Xn.stop()}function Dn(){Xn.start()}const Xn=new Ix;Xn.setAnimationLoop(ki),typeof self<"u"&&Xn.setContext(self),this.setAnimationLoop=function(A){is=A,Oe.setAnimationLoop(A),A===null?Xn.stop():Xn.start()},Oe.addEventListener("sessionstart",mn),Oe.addEventListener("sessionend",Dn),this.render=function(A,W){if(W!==void 0&&W.isCamera!==!0){wt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(V===!0)return;Q!==null&&Q.renderStart(A,W);const oe=Oe.enabled===!0&&Oe.isPresenting===!0,ae=P!==null&&($===null||oe)&&P.begin(q,$);if(A.matrixWorldAutoUpdate===!0&&A.updateMatrixWorld(),W.parent===null&&W.matrixWorldAutoUpdate===!0&&W.updateMatrixWorld(),Oe.enabled===!0&&Oe.isPresenting===!0&&(P===null||P.isCompositing()===!1)&&(Oe.cameraAutoUpdate===!0&&Oe.updateCamera(W),W=Oe.getCamera()),A.isScene===!0&&A.onBeforeRender(q,A,W,$),U=Ie.get(A,T.length),U.init(W),U.state.textureUnits=he.getTextureUnits(),T.push(U),qt.multiplyMatrices(W.projectionMatrix,W.matrixWorldInverse),pt.setFromProjectionMatrix(qt,ea,W.reversedDepth),dt=this.localClippingEnabled,mt=Ye.init(this.clippingPlanes,dt),B=Be.get(A,F.length),B.init(),F.push(B),Oe.enabled===!0&&Oe.isPresenting===!0){const Xe=q.xr.getDepthSensingMesh();Xe!==null&&Er(Xe,W,-1/0,q.sortObjects)}Er(A,W,0,q.sortObjects),B.finish(),q.sortObjects===!0&&B.sort(He,nt,W.reversedDepth),Yt=Oe.enabled===!1||Oe.isPresenting===!1||Oe.hasDepthSensing()===!1,Yt&&at.addToRenderList(B,A),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),mt===!0&&Ye.beginShadows();const re=U.state.shadowsArray;if($e.render(re,A,W),mt===!0&&Ye.endShadows(),(ae&&P.hasRenderPass())===!1){const Xe=B.opaque,Fe=B.transmissive;if(U.setupLights(),W.isArrayCamera){const Ze=W.cameras;if(Fe.length>0)for(let qe=0,et=Ze.length;qe<et;qe++){const lt=Ze[qe];xl(Xe,Fe,A,lt)}Yt&&at.render(A);for(let qe=0,et=Ze.length;qe<et;qe++){const lt=Ze[qe];_l(B,A,lt,lt.viewport)}}else Fe.length>0&&xl(Xe,Fe,A,W),Yt&&at.render(A),_l(B,A,W)}$!==null&&H===0&&(he.updateMultisampleRenderTarget($),he.updateRenderTargetMipmap($)),ae&&P.end(q),A.isScene===!0&&A.onAfterRender(q,A,W),we.resetDefaultState(),_e=-1,be=null,T.pop(),T.length>0?(U=T[T.length-1],he.setTextureUnits(U.state.textureUnits),mt===!0&&Ye.setGlobalState(q.clippingPlanes,U.state.camera)):U=null,F.pop(),F.length>0?B=F[F.length-1]:B=null,Q!==null&&Q.renderEnd()};function Er(A,W,oe,ae){if(A.visible===!1)return;if(A.layers.test(W.layers)){if(A.isGroup)oe=A.renderOrder;else if(A.isLOD)A.autoUpdate===!0&&A.update(W);else if(A.isLightProbeGrid)U.pushLightProbeGrid(A);else if(A.isLight)U.pushLight(A),A.castShadow&&U.pushShadow(A);else if(A.isSprite){if(!A.frustumCulled||pt.intersectsSprite(A)){ae&&Ut.setFromMatrixPosition(A.matrixWorld).applyMatrix4(qt);const Xe=ge.update(A),Fe=A.material;Fe.visible&&B.push(A,Xe,Fe,oe,Ut.z,null)}}else if((A.isMesh||A.isLine||A.isPoints)&&(!A.frustumCulled||pt.intersectsObject(A))){const Xe=ge.update(A),Fe=A.material;if(ae&&(A.boundingSphere!==void 0?(A.boundingSphere===null&&A.computeBoundingSphere(),Ut.copy(A.boundingSphere.center)):(Xe.boundingSphere===null&&Xe.computeBoundingSphere(),Ut.copy(Xe.boundingSphere.center)),Ut.applyMatrix4(A.matrixWorld).applyMatrix4(qt)),Array.isArray(Fe)){const Ze=Xe.groups;for(let qe=0,et=Ze.length;qe<et;qe++){const lt=Ze[qe],Je=Fe[lt.materialIndex];Je&&Je.visible&&B.push(A,Xe,Je,oe,Ut.z,lt)}}else Fe.visible&&B.push(A,Xe,Fe,oe,Ut.z,null)}}const ze=A.children;for(let Xe=0,Fe=ze.length;Xe<Fe;Xe++)Er(ze[Xe],W,oe,ae)}function _l(A,W,oe,ae){const{opaque:re,transmissive:ze,transparent:Xe}=A;U.setupLightsView(oe),mt===!0&&Ye.setGlobalState(q.clippingPlanes,oe),ae&&E.viewport(N.copy(ae)),re.length>0&&br(re,W,oe),ze.length>0&&br(ze,W,oe),Xe.length>0&&br(Xe,W,oe),E.buffers.depth.setTest(!0),E.buffers.depth.setMask(!0),E.buffers.color.setMask(!0),E.setPolygonOffset(!1)}function xl(A,W,oe,ae){if((oe.isScene===!0?oe.overrideMaterial:null)!==null)return;if(U.state.transmissionRenderTarget[ae.id]===void 0){const Je=Ct.has("EXT_color_buffer_half_float")||Ct.has("EXT_color_buffer_float");U.state.transmissionRenderTarget[ae.id]=new na(1,1,{generateMipmaps:!0,type:Je?Ba:Ai,minFilter:Qr,samples:Math.max(4,D.samples),stencilBuffer:c,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Tt.workingColorSpace})}const ze=U.state.transmissionRenderTarget[ae.id],Xe=ae.viewport||N;ze.setSize(Xe.z*q.transmissionResolutionScale,Xe.w*q.transmissionResolutionScale);const Fe=q.getRenderTarget(),Ze=q.getActiveCubeFace(),qe=q.getActiveMipmapLevel();q.setRenderTarget(ze),q.getClearColor(Te),Ce=q.getClearAlpha(),Ce<1&&q.setClearColor(16777215,.5),q.clear(),Yt&&at.render(oe);const et=q.toneMapping;q.toneMapping=ta;const lt=ae.viewport;if(ae.viewport!==void 0&&(ae.viewport=void 0),U.setupLightsView(ae),mt===!0&&Ye.setGlobalState(q.clippingPlanes,ae),br(A,oe,ae),he.updateMultisampleRenderTarget(ze),he.updateRenderTargetMipmap(ze),Ct.has("WEBGL_multisampled_render_to_texture")===!1){let Je=!1;for(let Nt=0,rn=W.length;Nt<rn;Nt++){const jt=W[Nt],{object:Ht,geometry:Gt,material:ke,group:In}=jt;if(ke.side===Ua&&Ht.layers.test(ae.layers)){const vt=ke.side;ke.side=$n,ke.needsUpdate=!0,Ga(Ht,oe,ae,Gt,ke,In),ke.side=vt,ke.needsUpdate=!0,Je=!0}}Je===!0&&(he.updateMultisampleRenderTarget(ze),he.updateRenderTargetMipmap(ze))}q.setRenderTarget(Fe,Ze,qe),q.setClearColor(Te,Ce),lt!==void 0&&(ae.viewport=lt),q.toneMapping=et}function br(A,W,oe){const ae=W.isScene===!0?W.overrideMaterial:null;for(let re=0,ze=A.length;re<ze;re++){const Xe=A[re],{object:Fe,geometry:Ze,group:qe}=Xe;let et=Xe.material;et.allowOverride===!0&&ae!==null&&(et=ae),Fe.layers.test(oe.layers)&&Ga(Fe,W,oe,Ze,et,qe)}}function Ga(A,W,oe,ae,re,ze){A.onBeforeRender(q,W,oe,ae,re,ze),A.modelViewMatrix.multiplyMatrices(oe.matrixWorldInverse,A.matrixWorld),A.normalMatrix.getNormalMatrix(A.modelViewMatrix),re.onBeforeRender(q,W,oe,ae,A,ze),re.transparent===!0&&re.side===Ua&&re.forceSinglePass===!1?(re.side=$n,re.needsUpdate=!0,q.renderBufferDirect(oe,W,ae,re,A,ze),re.side=Mr,re.needsUpdate=!0,q.renderBufferDirect(oe,W,ae,re,A,ze),re.side=Ua):q.renderBufferDirect(oe,W,ae,re,A,ze),A.onAfterRender(q,W,oe,ae,re,ze)}function Va(A,W,oe){W.isScene!==!0&&(W=cn);const ae=se.get(A),re=U.state.lights,ze=U.state.shadowsArray,Xe=re.state.version,Fe=Ne.getParameters(A,re.state,ze,W,oe,U.state.lightProbeGridArray),Ze=Ne.getProgramCacheKey(Fe);let qe=ae.programs;ae.environment=A.isMeshStandardMaterial||A.isMeshLambertMaterial||A.isMeshPhongMaterial?W.environment:null,ae.fog=W.fog;const et=A.isMeshStandardMaterial||A.isMeshLambertMaterial&&!A.envMap||A.isMeshPhongMaterial&&!A.envMap;ae.envMap=De.get(A.envMap||ae.environment,et),ae.envMapRotation=ae.environment!==null&&A.envMap===null?W.environmentRotation:A.envMapRotation,qe===void 0&&(A.addEventListener("dispose",tn),qe=new Map,ae.programs=qe);let lt=qe.get(Ze);if(lt!==void 0){if(ae.currentProgram===lt&&ae.lightsStateVersion===Xe)return oa(A,Fe),lt}else Fe.uniforms=Ne.getUniforms(A),Q!==null&&A.isNodeMaterial&&Q.build(A,oe,Fe),A.onBeforeCompile(Fe,q),lt=Ne.acquireProgram(Fe,Ze),qe.set(Ze,lt),ae.uniforms=Fe.uniforms;const Je=ae.uniforms;return(!A.isShaderMaterial&&!A.isRawShaderMaterial||A.clipping===!0)&&(Je.clippingPlanes=Ye.uniform),oa(A,Fe),ae.needsLights=Sl(A),ae.lightsStateVersion=Xe,ae.needsLights&&(Je.ambientLightColor.value=re.state.ambient,Je.lightProbe.value=re.state.probe,Je.directionalLights.value=re.state.directional,Je.directionalLightShadows.value=re.state.directionalShadow,Je.spotLights.value=re.state.spot,Je.spotLightShadows.value=re.state.spotShadow,Je.rectAreaLights.value=re.state.rectArea,Je.ltc_1.value=re.state.rectAreaLTC1,Je.ltc_2.value=re.state.rectAreaLTC2,Je.pointLights.value=re.state.point,Je.pointLightShadows.value=re.state.pointShadow,Je.hemisphereLights.value=re.state.hemi,Je.directionalShadowMatrix.value=re.state.directionalShadowMatrix,Je.spotLightMatrix.value=re.state.spotLightMatrix,Je.spotLightMap.value=re.state.spotLightMap,Je.pointShadowMatrix.value=re.state.pointShadowMatrix),ae.lightProbeGrid=U.state.lightProbeGridArray.length>0,ae.currentProgram=lt,ae.uniformsList=null,lt}function sa(A){if(A.uniformsList===null){const W=A.currentProgram.getUniforms();A.uniformsList=cu.seqWithValue(W.seq,A.uniforms)}return A.uniformsList}function oa(A,W){const oe=se.get(A);oe.outputColorSpace=W.outputColorSpace,oe.batching=W.batching,oe.batchingColor=W.batchingColor,oe.instancing=W.instancing,oe.instancingColor=W.instancingColor,oe.instancingMorph=W.instancingMorph,oe.skinning=W.skinning,oe.morphTargets=W.morphTargets,oe.morphNormals=W.morphNormals,oe.morphColors=W.morphColors,oe.morphTargetsCount=W.morphTargetsCount,oe.numClippingPlanes=W.numClippingPlanes,oe.numIntersection=W.numClipIntersection,oe.vertexAlphas=W.vertexAlphas,oe.vertexTangents=W.vertexTangents,oe.toneMapping=W.toneMapping}function Tr(A,W){if(A.length===0)return null;if(A.length===1)return A[0].texture!==null?A[0]:null;w.setFromMatrixPosition(W.matrixWorld);for(let oe=0,ae=A.length;oe<ae;oe++){const re=A[oe];if(re.texture!==null&&re.boundingBox.containsPoint(w))return re}return null}function ka(A,W,oe,ae,re){W.isScene!==!0&&(W=cn),he.resetTextureUnits();const ze=W.fog,Xe=ae.isMeshStandardMaterial||ae.isMeshLambertMaterial||ae.isMeshPhongMaterial?W.environment:null,Fe=$===null?q.outputColorSpace:$.isXRRenderTarget===!0?$.texture.colorSpace:Tt.workingColorSpace,Ze=ae.isMeshStandardMaterial||ae.isMeshLambertMaterial&&!ae.envMap||ae.isMeshPhongMaterial&&!ae.envMap,qe=De.get(ae.envMap||Xe,Ze),et=ae.vertexColors===!0&&!!oe.attributes.color&&oe.attributes.color.itemSize===4,lt=!!oe.attributes.tangent&&(!!ae.normalMap||ae.anisotropy>0),Je=!!oe.morphAttributes.position,Nt=!!oe.morphAttributes.normal,rn=!!oe.morphAttributes.color;let jt=ta;ae.toneMapped&&($===null||$.isXRRenderTarget===!0)&&(jt=q.toneMapping);const Ht=oe.morphAttributes.position||oe.morphAttributes.normal||oe.morphAttributes.color,Gt=Ht!==void 0?Ht.length:0,ke=se.get(ae),In=U.state.lights;if(mt===!0&&(dt===!0||A!==be)){const Ft=A===be&&ae.id===_e;Ye.setState(ae,A,Ft)}let vt=!1;ae.version===ke.__version?(ke.needsLights&&ke.lightsStateVersion!==In.state.version||ke.outputColorSpace!==Fe||re.isBatchedMesh&&ke.batching===!1||!re.isBatchedMesh&&ke.batching===!0||re.isBatchedMesh&&ke.batchingColor===!0&&re.colorTexture===null||re.isBatchedMesh&&ke.batchingColor===!1&&re.colorTexture!==null||re.isInstancedMesh&&ke.instancing===!1||!re.isInstancedMesh&&ke.instancing===!0||re.isSkinnedMesh&&ke.skinning===!1||!re.isSkinnedMesh&&ke.skinning===!0||re.isInstancedMesh&&ke.instancingColor===!0&&re.instanceColor===null||re.isInstancedMesh&&ke.instancingColor===!1&&re.instanceColor!==null||re.isInstancedMesh&&ke.instancingMorph===!0&&re.morphTexture===null||re.isInstancedMesh&&ke.instancingMorph===!1&&re.morphTexture!==null||ke.envMap!==qe||ae.fog===!0&&ke.fog!==ze||ke.numClippingPlanes!==void 0&&(ke.numClippingPlanes!==Ye.numPlanes||ke.numIntersection!==Ye.numIntersection)||ke.vertexAlphas!==et||ke.vertexTangents!==lt||ke.morphTargets!==Je||ke.morphNormals!==Nt||ke.morphColors!==rn||ke.toneMapping!==jt||ke.morphTargetsCount!==Gt||!!ke.lightProbeGrid!=U.state.lightProbeGridArray.length>0)&&(vt=!0):(vt=!0,ke.__version=ae.version);let En=ke.currentProgram;vt===!0&&(En=Va(ae,W,re),Q&&ae.isNodeMaterial&&Q.onUpdateProgram(ae,En,ke));let ti=!1,wi=!1,ni=!1;const Vt=En.getUniforms(),sn=ke.uniforms;if(E.useProgram(En.program)&&(ti=!0,wi=!0,ni=!0),ae.id!==_e&&(_e=ae.id,wi=!0),ke.needsLights){const Ft=Tr(U.state.lightProbeGridArray,re);ke.lightProbeGrid!==Ft&&(ke.lightProbeGrid=Ft,wi=!0)}if(ti||be!==A){E.buffers.depth.getReversed()&&A.reversedDepth!==!0&&(A._reversedDepth=!0,A.updateProjectionMatrix()),Vt.setValue(X,"projectionMatrix",A.projectionMatrix),Vt.setValue(X,"viewMatrix",A.matrixWorldInverse);const Xi=Vt.map.cameraPosition;Xi!==void 0&&Xi.setValue(X,$t.setFromMatrixPosition(A.matrixWorld)),D.logarithmicDepthBuffer&&Vt.setValue(X,"logDepthBufFC",2/(Math.log(A.far+1)/Math.LN2)),(ae.isMeshPhongMaterial||ae.isMeshToonMaterial||ae.isMeshLambertMaterial||ae.isMeshBasicMaterial||ae.isMeshStandardMaterial||ae.isShaderMaterial)&&Vt.setValue(X,"isOrthographic",A.isOrthographicCamera===!0),be!==A&&(be=A,wi=!0,ni=!0)}if(ke.needsLights&&(In.state.directionalShadowMap.length>0&&Vt.setValue(X,"directionalShadowMap",In.state.directionalShadowMap,he),In.state.spotShadowMap.length>0&&Vt.setValue(X,"spotShadowMap",In.state.spotShadowMap,he),In.state.pointShadowMap.length>0&&Vt.setValue(X,"pointShadowMap",In.state.pointShadowMap,he)),re.isSkinnedMesh){Vt.setOptional(X,re,"bindMatrix"),Vt.setOptional(X,re,"bindMatrixInverse");const Ft=re.skeleton;Ft&&(Ft.boneTexture===null&&Ft.computeBoneTexture(),Vt.setValue(X,"boneTexture",Ft.boneTexture,he))}re.isBatchedMesh&&(Vt.setOptional(X,re,"batchingTexture"),Vt.setValue(X,"batchingTexture",re._matricesTexture,he),Vt.setOptional(X,re,"batchingIdTexture"),Vt.setValue(X,"batchingIdTexture",re._indirectTexture,he),Vt.setOptional(X,re,"batchingColorTexture"),re._colorsTexture!==null&&Vt.setValue(X,"batchingColorTexture",re._colorsTexture,he));const Di=oe.morphAttributes;if((Di.position!==void 0||Di.normal!==void 0||Di.color!==void 0)&&k.update(re,oe,En),(wi||ke.receiveShadow!==re.receiveShadow)&&(ke.receiveShadow=re.receiveShadow,Vt.setValue(X,"receiveShadow",re.receiveShadow)),(ae.isMeshStandardMaterial||ae.isMeshLambertMaterial||ae.isMeshPhongMaterial)&&ae.envMap===null&&W.environment!==null&&(sn.envMapIntensity.value=W.environmentIntensity),sn.dfgLUT!==void 0&&(sn.dfgLUT.value=s3()),wi){if(Vt.setValue(X,"toneMappingExposure",q.toneMappingExposure),ke.needsLights&&gn(sn,ni),ze&&ae.fog===!0&&Ve.refreshFogUniforms(sn,ze),Ve.refreshMaterialUniforms(sn,ae,ve,Me,U.state.transmissionRenderTarget[A.id]),ke.needsLights&&ke.lightProbeGrid){const Ft=ke.lightProbeGrid;sn.probesSH.value=Ft.texture,sn.probesMin.value.copy(Ft.boundingBox.min),sn.probesMax.value.copy(Ft.boundingBox.max),sn.probesResolution.value.copy(Ft.resolution)}cu.upload(X,sa(ke),sn,he)}if(ae.isShaderMaterial&&ae.uniformsNeedUpdate===!0&&(cu.upload(X,sa(ke),sn,he),ae.uniformsNeedUpdate=!1),ae.isSpriteMaterial&&Vt.setValue(X,"center",re.center),Vt.setValue(X,"modelViewMatrix",re.modelViewMatrix),Vt.setValue(X,"normalMatrix",re.normalMatrix),Vt.setValue(X,"modelMatrix",re.matrixWorld),ae.uniformsGroups!==void 0){const Ft=ae.uniformsGroups;for(let Xi=0,Xa=Ft.length;Xi<Xa;Xi++){const Ar=Ft[Xi];Se.update(Ar,En),Se.bind(Ar,En)}}return En}function gn(A,W){A.ambientLightColor.needsUpdate=W,A.lightProbe.needsUpdate=W,A.directionalLights.needsUpdate=W,A.directionalLightShadows.needsUpdate=W,A.pointLights.needsUpdate=W,A.pointLightShadows.needsUpdate=W,A.spotLights.needsUpdate=W,A.spotLightShadows.needsUpdate=W,A.rectAreaLights.needsUpdate=W,A.hemisphereLights.needsUpdate=W}function Sl(A){return A.isMeshLambertMaterial||A.isMeshToonMaterial||A.isMeshPhongMaterial||A.isMeshStandardMaterial||A.isShadowMaterial||A.isShaderMaterial&&A.lights===!0}this.getActiveCubeFace=function(){return L},this.getActiveMipmapLevel=function(){return H},this.getRenderTarget=function(){return $},this.setRenderTargetTextures=function(A,W,oe){const ae=se.get(A);ae.__autoAllocateDepthBuffer=A.resolveDepthBuffer===!1,ae.__autoAllocateDepthBuffer===!1&&(ae.__useRenderToTexture=!1),se.get(A.texture).__webglTexture=W,se.get(A.depthTexture).__webglTexture=ae.__autoAllocateDepthBuffer?void 0:oe,ae.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(A,W){const oe=se.get(A);oe.__webglFramebuffer=W,oe.__useDefaultFramebuffer=W===void 0},this.setRenderTarget=function(A,W=0,oe=0){$=A,L=W,H=oe;let ae=null,re=!1,ze=!1;if(A){const Fe=se.get(A);if(Fe.__useDefaultFramebuffer!==void 0){E.bindFramebuffer(X.FRAMEBUFFER,Fe.__webglFramebuffer),N.copy(A.viewport),Y.copy(A.scissor),de=A.scissorTest,E.viewport(N),E.scissor(Y),E.setScissorTest(de),_e=-1;return}else if(Fe.__webglFramebuffer===void 0)he.setupRenderTarget(A);else if(Fe.__hasExternalTextures)he.rebindTextures(A,se.get(A.texture).__webglTexture,se.get(A.depthTexture).__webglTexture);else if(A.depthBuffer){const et=A.depthTexture;if(Fe.__boundDepthTexture!==et){if(et!==null&&se.has(et)&&(A.width!==et.image.width||A.height!==et.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");he.setupDepthRenderbuffer(A)}}const Ze=A.texture;(Ze.isData3DTexture||Ze.isDataArrayTexture||Ze.isCompressedArrayTexture)&&(ze=!0);const qe=se.get(A).__webglFramebuffer;A.isWebGLCubeRenderTarget?(Array.isArray(qe[W])?ae=qe[W][oe]:ae=qe[W],re=!0):A.samples>0&&he.useMultisampledRTT(A)===!1?ae=se.get(A).__webglMultisampledFramebuffer:Array.isArray(qe)?ae=qe[oe]:ae=qe,N.copy(A.viewport),Y.copy(A.scissor),de=A.scissorTest}else N.copy(je).multiplyScalar(ve).floor(),Y.copy(Dt).multiplyScalar(ve).floor(),de=ut;if(oe!==0&&(ae=fe),E.bindFramebuffer(X.FRAMEBUFFER,ae)&&E.drawBuffers(A,ae),E.viewport(N),E.scissor(Y),E.setScissorTest(de),re){const Fe=se.get(A.texture);X.framebufferTexture2D(X.FRAMEBUFFER,X.COLOR_ATTACHMENT0,X.TEXTURE_CUBE_MAP_POSITIVE_X+W,Fe.__webglTexture,oe)}else if(ze){const Fe=W;for(let Ze=0;Ze<A.textures.length;Ze++){const qe=se.get(A.textures[Ze]);X.framebufferTextureLayer(X.FRAMEBUFFER,X.COLOR_ATTACHMENT0+Ze,qe.__webglTexture,oe,Fe)}}else if(A!==null&&oe!==0){const Fe=se.get(A.texture);X.framebufferTexture2D(X.FRAMEBUFFER,X.COLOR_ATTACHMENT0,X.TEXTURE_2D,Fe.__webglTexture,oe)}_e=-1},this.readRenderTargetPixels=function(A,W,oe,ae,re,ze,Xe,Fe=0){if(!(A&&A.isWebGLRenderTarget)){wt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Ze=se.get(A).__webglFramebuffer;if(A.isWebGLCubeRenderTarget&&Xe!==void 0&&(Ze=Ze[Xe]),Ze){E.bindFramebuffer(X.FRAMEBUFFER,Ze);try{const qe=A.textures[Fe],et=qe.format,lt=qe.type;if(A.textures.length>1&&X.readBuffer(X.COLOR_ATTACHMENT0+Fe),!D.textureFormatReadable(et)){wt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!D.textureTypeReadable(lt)){wt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}W>=0&&W<=A.width-ae&&oe>=0&&oe<=A.height-re&&X.readPixels(W,oe,ae,re,Ae.convert(et),Ae.convert(lt),ze)}finally{const qe=$!==null?se.get($).__webglFramebuffer:null;E.bindFramebuffer(X.FRAMEBUFFER,qe)}}},this.readRenderTargetPixelsAsync=async function(A,W,oe,ae,re,ze,Xe,Fe=0){if(!(A&&A.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Ze=se.get(A).__webglFramebuffer;if(A.isWebGLCubeRenderTarget&&Xe!==void 0&&(Ze=Ze[Xe]),Ze)if(W>=0&&W<=A.width-ae&&oe>=0&&oe<=A.height-re){E.bindFramebuffer(X.FRAMEBUFFER,Ze);const qe=A.textures[Fe],et=qe.format,lt=qe.type;if(A.textures.length>1&&X.readBuffer(X.COLOR_ATTACHMENT0+Fe),!D.textureFormatReadable(et))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!D.textureTypeReadable(lt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Je=X.createBuffer();X.bindBuffer(X.PIXEL_PACK_BUFFER,Je),X.bufferData(X.PIXEL_PACK_BUFFER,ze.byteLength,X.STREAM_READ),X.readPixels(W,oe,ae,re,Ae.convert(et),Ae.convert(lt),0);const Nt=$!==null?se.get($).__webglFramebuffer:null;E.bindFramebuffer(X.FRAMEBUFFER,Nt);const rn=X.fenceSync(X.SYNC_GPU_COMMANDS_COMPLETE,0);return X.flush(),await Cb(X,rn,4),X.bindBuffer(X.PIXEL_PACK_BUFFER,Je),X.getBufferSubData(X.PIXEL_PACK_BUFFER,0,ze),X.deleteBuffer(Je),X.deleteSync(rn),ze}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(A,W=null,oe=0){const ae=Math.pow(2,-oe),re=Math.floor(A.image.width*ae),ze=Math.floor(A.image.height*ae),Xe=W!==null?W.x:0,Fe=W!==null?W.y:0;he.setTexture2D(A,0),X.copyTexSubImage2D(X.TEXTURE_2D,oe,0,0,Xe,Fe,re,ze),E.unbindTexture()},this.copyTextureToTexture=function(A,W,oe=null,ae=null,re=0,ze=0){let Xe,Fe,Ze,qe,et,lt,Je,Nt,rn;const jt=A.isCompressedTexture?A.mipmaps[ze]:A.image;if(oe!==null)Xe=oe.max.x-oe.min.x,Fe=oe.max.y-oe.min.y,Ze=oe.isBox3?oe.max.z-oe.min.z:1,qe=oe.min.x,et=oe.min.y,lt=oe.isBox3?oe.min.z:0;else{const sn=Math.pow(2,-re);Xe=Math.floor(jt.width*sn),Fe=Math.floor(jt.height*sn),A.isDataArrayTexture?Ze=jt.depth:A.isData3DTexture?Ze=Math.floor(jt.depth*sn):Ze=1,qe=0,et=0,lt=0}ae!==null?(Je=ae.x,Nt=ae.y,rn=ae.z):(Je=0,Nt=0,rn=0);const Ht=Ae.convert(W.format),Gt=Ae.convert(W.type);let ke;W.isData3DTexture?(he.setTexture3D(W,0),ke=X.TEXTURE_3D):W.isDataArrayTexture||W.isCompressedArrayTexture?(he.setTexture2DArray(W,0),ke=X.TEXTURE_2D_ARRAY):(he.setTexture2D(W,0),ke=X.TEXTURE_2D),E.activeTexture(X.TEXTURE0),E.pixelStorei(X.UNPACK_FLIP_Y_WEBGL,W.flipY),E.pixelStorei(X.UNPACK_PREMULTIPLY_ALPHA_WEBGL,W.premultiplyAlpha),E.pixelStorei(X.UNPACK_ALIGNMENT,W.unpackAlignment);const In=E.getParameter(X.UNPACK_ROW_LENGTH),vt=E.getParameter(X.UNPACK_IMAGE_HEIGHT),En=E.getParameter(X.UNPACK_SKIP_PIXELS),ti=E.getParameter(X.UNPACK_SKIP_ROWS),wi=E.getParameter(X.UNPACK_SKIP_IMAGES);E.pixelStorei(X.UNPACK_ROW_LENGTH,jt.width),E.pixelStorei(X.UNPACK_IMAGE_HEIGHT,jt.height),E.pixelStorei(X.UNPACK_SKIP_PIXELS,qe),E.pixelStorei(X.UNPACK_SKIP_ROWS,et),E.pixelStorei(X.UNPACK_SKIP_IMAGES,lt);const ni=A.isDataArrayTexture||A.isData3DTexture,Vt=W.isDataArrayTexture||W.isData3DTexture;if(A.isDepthTexture){const sn=se.get(A),Di=se.get(W),Ft=se.get(sn.__renderTarget),Xi=se.get(Di.__renderTarget);E.bindFramebuffer(X.READ_FRAMEBUFFER,Ft.__webglFramebuffer),E.bindFramebuffer(X.DRAW_FRAMEBUFFER,Xi.__webglFramebuffer);for(let Xa=0;Xa<Ze;Xa++)ni&&(X.framebufferTextureLayer(X.READ_FRAMEBUFFER,X.COLOR_ATTACHMENT0,se.get(A).__webglTexture,re,lt+Xa),X.framebufferTextureLayer(X.DRAW_FRAMEBUFFER,X.COLOR_ATTACHMENT0,se.get(W).__webglTexture,ze,rn+Xa)),X.blitFramebuffer(qe,et,Xe,Fe,Je,Nt,Xe,Fe,X.DEPTH_BUFFER_BIT,X.NEAREST);E.bindFramebuffer(X.READ_FRAMEBUFFER,null),E.bindFramebuffer(X.DRAW_FRAMEBUFFER,null)}else if(re!==0||A.isRenderTargetTexture||se.has(A)){const sn=se.get(A),Di=se.get(W);E.bindFramebuffer(X.READ_FRAMEBUFFER,me),E.bindFramebuffer(X.DRAW_FRAMEBUFFER,j);for(let Ft=0;Ft<Ze;Ft++)ni?X.framebufferTextureLayer(X.READ_FRAMEBUFFER,X.COLOR_ATTACHMENT0,sn.__webglTexture,re,lt+Ft):X.framebufferTexture2D(X.READ_FRAMEBUFFER,X.COLOR_ATTACHMENT0,X.TEXTURE_2D,sn.__webglTexture,re),Vt?X.framebufferTextureLayer(X.DRAW_FRAMEBUFFER,X.COLOR_ATTACHMENT0,Di.__webglTexture,ze,rn+Ft):X.framebufferTexture2D(X.DRAW_FRAMEBUFFER,X.COLOR_ATTACHMENT0,X.TEXTURE_2D,Di.__webglTexture,ze),re!==0?X.blitFramebuffer(qe,et,Xe,Fe,Je,Nt,Xe,Fe,X.COLOR_BUFFER_BIT,X.NEAREST):Vt?X.copyTexSubImage3D(ke,ze,Je,Nt,rn+Ft,qe,et,Xe,Fe):X.copyTexSubImage2D(ke,ze,Je,Nt,qe,et,Xe,Fe);E.bindFramebuffer(X.READ_FRAMEBUFFER,null),E.bindFramebuffer(X.DRAW_FRAMEBUFFER,null)}else Vt?A.isDataTexture||A.isData3DTexture?X.texSubImage3D(ke,ze,Je,Nt,rn,Xe,Fe,Ze,Ht,Gt,jt.data):W.isCompressedArrayTexture?X.compressedTexSubImage3D(ke,ze,Je,Nt,rn,Xe,Fe,Ze,Ht,jt.data):X.texSubImage3D(ke,ze,Je,Nt,rn,Xe,Fe,Ze,Ht,Gt,jt):A.isDataTexture?X.texSubImage2D(X.TEXTURE_2D,ze,Je,Nt,Xe,Fe,Ht,Gt,jt.data):A.isCompressedTexture?X.compressedTexSubImage2D(X.TEXTURE_2D,ze,Je,Nt,jt.width,jt.height,Ht,jt.data):X.texSubImage2D(X.TEXTURE_2D,ze,Je,Nt,Xe,Fe,Ht,Gt,jt);E.pixelStorei(X.UNPACK_ROW_LENGTH,In),E.pixelStorei(X.UNPACK_IMAGE_HEIGHT,vt),E.pixelStorei(X.UNPACK_SKIP_PIXELS,En),E.pixelStorei(X.UNPACK_SKIP_ROWS,ti),E.pixelStorei(X.UNPACK_SKIP_IMAGES,wi),ze===0&&W.generateMipmaps&&X.generateMipmap(ke),E.unbindTexture()},this.initRenderTarget=function(A){se.get(A).__webglFramebuffer===void 0&&he.setupRenderTarget(A)},this.initTexture=function(A){A.isCubeTexture?he.setTextureCube(A,0):A.isData3DTexture?he.setTexture3D(A,0):A.isDataArrayTexture||A.isCompressedArrayTexture?he.setTexture2DArray(A,0):he.setTexture2D(A,0),E.unbindTexture()},this.resetState=function(){L=0,H=0,$=null,E.reset(),we.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ea}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const i=this.getContext();i.drawingBufferColorSpace=Tt._getDrawingBufferColorSpace(e),i.unpackColorSpace=Tt._getUnpackColorSpace()}}const l3=`
varying vec2 v_uv;
void main() {
  v_uv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`,c3=`
precision mediump float;
varying vec2 v_uv;
uniform float u_time;
uniform vec2 u_resolution;
uniform float u_waveSpeed;
uniform float u_waveHeight;
uniform float u_density;

#define NUM_BLUE_SHADES 5

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

vec3 getBlueColor(int index, float brightness) {
  if (index == 0) return mix(vec3(0.2, 0.4, 0.8), vec3(0.3, 0.55, 0.9), brightness);
  if (index == 1) return mix(vec3(0.25, 0.55, 0.85), vec3(0.4, 0.7, 1.0), brightness);
  if (index == 2) return mix(vec3(0.15, 0.35, 0.75), vec3(0.25, 0.5, 0.85), brightness);
  if (index == 3) return mix(vec3(0.3, 0.6, 0.9), vec3(0.45, 0.75, 1.0), brightness);
  if (index == 4) return mix(vec3(0.1, 0.3, 0.7), vec3(0.2, 0.45, 0.8), brightness);
  return mix(vec3(0.2, 0.4, 0.8), vec3(0.35, 0.6, 0.95), brightness);
}

void main() {
  vec2 fragCoord = v_uv * u_resolution;
  vec2 uv = fragCoord / u_resolution.y;
  float animationTime = u_time * u_waveSpeed;
  float waveHeight = 0.25 * u_waveHeight;
  float waveFreq = 3.0 * u_density;
  float waveX = sin(uv.y * waveFreq + animationTime * 1.2) * waveHeight;
  float waveX2 = sin(uv.y * waveFreq * 1.3 + animationTime * 0.8 + 1.0) * waveHeight * 0.7;
  float totalWave = waveX + waveX2;
  vec2 shardCoord = vec2(uv.x + totalWave, uv.y) * vec2(4.0, 8.0) * u_density;
  float shardX = fract(shardCoord.x) - 0.5;
  float shardY = fract(shardCoord.y) - 0.5;
  vec2 shardId = floor(shardCoord);
  float skewedX = shardX + shardY * 0.3;
  float dist = abs(skewedX) + abs(shardY * 0.8);
  float rnd = hash(shardId);
  float rnd2 = hash(shardId + 100.0);
  float phase = hash(shardId + 200.0);
  float anim = sin(animationTime * (0.3 + phase * 0.2) + phase * 6.28) * 0.06 * u_waveHeight;
  float shardSize = (0.3 + rnd * 0.2) + anim;
  float shardEdge = smoothstep(shardSize, shardSize - 0.08, dist);
  int colorIndex = int(mod(floor(rnd * float(NUM_BLUE_SHADES)), float(NUM_BLUE_SHADES)));
  float colorPhase = animationTime * 0.4 + rnd2 * 6.28;
  float brightness = 0.5 + 0.5 * sin(colorPhase);
  vec3 waveColor = getBlueColor(colorIndex, brightness);
  float border = smoothstep(0.0, 0.06, dist) * smoothstep(shardSize, shardSize - 0.02, dist);
  waveColor *= (0.7 + 0.3 * border);
  shardId.y = floor(shardId.y / 2.0);
  vec3 normal = normalize(vec3(hash(shardId) * 0.5 - 0.25, hash(shardId + 1.0) * 0.5 - 0.25, 1.0));
  vec3 lightDir = normalize(vec3(0.3, 0.5, 0.8));
  float diffuse = max(dot(normal, lightDir), 0.0);
  waveColor *= (0.6 + 0.4 * diffuse);
  vec3 finalColor = mix(vec3(0.05, 0.15, 0.25), waveColor, shardEdge);
  float flowY = sin(animationTime * 0.3) * 0.4;
  float flowBand = exp(-pow((v_uv.y - (0.5 + flowY)) * 3.0, 2.0));
  finalColor += vec3(0.15, 0.3, 0.5) * flowBand * shardEdge;
  gl_FragColor = vec4(finalColor, 1.0);
}
`;function u3({onComplete:a}){const e=J.useRef(null),i=J.useRef(null);return J.useEffect(()=>{const s=i.current,l=e.current;if(!s||!l)return;const c=new o3({canvas:l,antialias:!1,alpha:!0});c.setPixelRatio(Math.min(window.devicePixelRatio,2));const{width:f,height:p}=s.getBoundingClientRect();c.setSize(f,p);const m=new Xb,h=new Lp(-1,1,1,-1,0,1),_=new f1,v=f<768?128:256,M=new vl(2,2,v,v),b=new Gi({vertexShader:l3,fragmentShader:c3,uniforms:{u_time:{value:0},u_resolution:{value:new Pt(f*Math.min(window.devicePixelRatio,2),p*Math.min(window.devicePixelRatio,2))},u_waveSpeed:{value:.5},u_waveHeight:{value:1},u_density:{value:1}}}),C=new ra(M,b);m.add(C);let y;const x=()=>{y=requestAnimationFrame(x),b.uniforms.u_time.value=_.getElapsedTime(),c.render(m,h)};x();const O=setTimeout(()=>{cancelAnimationFrame(y),a()},2500);return()=>{clearTimeout(O),cancelAnimationFrame(y),c.dispose(),M.dispose(),b.dispose()}},[a]),Re.jsxs("div",{"code-path":"src\\components\\SplashScreen.tsx:140:5",ref:i,className:"fixed inset-0 z-[100] bg-[#0a1f3d]",children:[Re.jsx("canvas",{"code-path":"src\\components\\SplashScreen.tsx:141:7",ref:e,className:"absolute inset-0 w-full h-full"}),Re.jsxs("div",{"code-path":"src\\components\\SplashScreen.tsx:142:7",className:"absolute inset-0 flex flex-col items-center justify-center",children:[Re.jsx("img",{"code-path":"src\\components\\SplashScreen.tsx:143:9",src:"/icons/logo.png",alt:"Kabul Bazar",className:"w-[120px] h-[120px] rounded-full object-cover animate-pulse"}),Re.jsx("h1",{"code-path":"src\\components\\SplashScreen.tsx:148:9",className:"mt-6 text-white text-[28px] font-bold tracking-[-0.5px]",children:"Kabul Bazar"})]})]})}const f3=a=>a.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),d3=a=>a.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,i,s)=>s?s.toUpperCase():i.toLowerCase()),I_=a=>{const e=d3(a);return e.charAt(0).toUpperCase()+e.slice(1)},Xx=(...a)=>a.filter((e,i,s)=>!!e&&e.trim()!==""&&s.indexOf(e)===i).join(" ").trim(),h3=a=>{for(const e in a)if(e.startsWith("aria-")||e==="role"||e==="title")return!0};var p3={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};const m3=J.forwardRef(({color:a="currentColor",size:e=24,strokeWidth:i=2,absoluteStrokeWidth:s,className:l="",children:c,iconNode:f,...p},m)=>J.createElement("svg",{ref:m,...p3,width:e,height:e,stroke:a,strokeWidth:s?Number(i)*24/Number(e):i,className:Xx("lucide",l),...!c&&!h3(p)&&{"aria-hidden":"true"},...p},[...f.map(([h,_])=>J.createElement(h,_)),...Array.isArray(c)?c:[c]]));const Rn=(a,e)=>{const i=J.forwardRef(({className:s,...l},c)=>J.createElement(m3,{ref:c,iconNode:e,className:Xx(`lucide-${f3(I_(a))}`,`lucide-${a}`,s),...l}));return i.displayName=I_(a),i};const g3=[["path",{d:"M10.268 21a2 2 0 0 0 3.464 0",key:"vwvbt9"}],["path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",key:"11g9vi"}]],v3=Rn("bell",g3);const _3=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],x3=Rn("circle-check",_3);const S3=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",key:"1u773s"}],["path",{d:"M12 17h.01",key:"p32p05"}]],y3=Rn("circle-question-mark",S3);const M3=[["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}],["circle",{cx:"12",cy:"5",r:"1",key:"gxeob9"}],["circle",{cx:"12",cy:"19",r:"1",key:"lyex9k"}]],E3=Rn("ellipsis-vertical",M3);const b3=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]],T3=Rn("globe",b3);const A3=[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",key:"5wwlr5"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"r6nss1"}]],R3=Rn("house",A3);const C3=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]],w3=Rn("info",C3);const D3=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],U3=Rn("loader-circle",D3);const N3=[["path",{d:"m16 17 5-5-5-5",key:"1bji2h"}],["path",{d:"M21 12H9",key:"dn1m92"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}]],L3=Rn("log-out",N3);const O3=[["path",{d:"M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",key:"1sd12s"}]],P3=Rn("message-circle",O3);const I3=[["path",{d:"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",key:"kfwtm"}]],B3=Rn("moon",I3);const F3=[["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"M2.586 16.726A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2h6.624a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586z",key:"2d38gg"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]],z3=Rn("octagon-x",F3);const H3=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],G3=Rn("plus",H3);const V3=[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]],k3=Rn("search",V3);const X3=[["path",{d:"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",key:"1i5ecw"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],W3=Rn("settings",X3);const q3=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]],Y3=Rn("shield",q3);const Z3=[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]],K3=Rn("sun",Z3);const Q3=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]],j3=Rn("triangle-alert",Q3);const J3=[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]],Wx=Rn("user",J3),$3=[{path:"/",label:"Home",Icon:R3},{path:"/create-post",label:"Create",Icon:G3,isCenter:!0},{path:"/messages",label:"Messages",Icon:P3},{path:"/profile",label:"Profile",Icon:Wx}];function eC(){const a=dl(),e=mi(),{unreadCount:i}=ll(),s=e.pathname,l=c=>{a(c)};return Re.jsx("nav",{"code-path":"src\\components\\BottomTab.tsx:23:5",className:"shrink-0 h-[72px] bg-white dark:bg-[#1C1C1E] border-t border-gray-200 dark:border-gray-800 z-50 flex items-center justify-around px-4 pb-safe relative",children:$3.map(c=>{const f=s===c.path||c.path!=="/"&&s.startsWith(c.path);return c.isCenter?Re.jsxs("button",{"code-path":"src\\components\\BottomTab.tsx:29:13",onClick:()=>l(c.path),className:"relative -mt-6 flex flex-col items-center justify-center",children:[Re.jsx("div",{"code-path":"src\\components\\BottomTab.tsx:34:15",className:"w-16 h-16 rounded-full bg-[#007AFF] shadow-[0_4px_12px_rgba(0,122,255,0.4)] flex items-center justify-center active:scale-95 transition-transform",children:Re.jsx(c.Icon,{"code-path":"src\\components\\BottomTab.tsx:35:17",size:28,className:"text-white",strokeWidth:2.5})}),Re.jsx("span",{"code-path":"src\\components\\BottomTab.tsx:37:15",className:"text-[10px] font-medium text-[#8E8E93] mt-0.5",children:c.label})]},c.path):Re.jsxs("button",{"code-path":"src\\components\\BottomTab.tsx:43:11",onClick:()=>l(c.path),className:"flex flex-col items-center justify-center gap-0.5 min-w-[60px] active:opacity-70 transition-opacity relative",children:[Re.jsxs("div",{"code-path":"src\\components\\BottomTab.tsx:48:13",className:"relative",children:[Re.jsx(c.Icon,{"code-path":"src\\components\\BottomTab.tsx:49:15",size:24,className:f?"text-[#007AFF]":"text-[#8E8E93]",strokeWidth:f?2.5:1.5}),c.path==="/messages"&&i>0&&Re.jsx("span",{"code-path":"src\\components\\BottomTab.tsx:55:17",className:"absolute -top-1.5 -right-2.5 min-w-[18px] h-[18px] bg-[#FF3B30] text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1",children:i>99?"99+":i})]}),Re.jsx("span",{"code-path":"src\\components\\BottomTab.tsx:60:13",className:`text-[10px] font-medium ${f?"text-[#007AFF]":"text-[#8E8E93]"}`,children:c.label})]},c.path)})})}function tC(){const a=dl(),{theme:e,toggleTheme:i,user:s,logout:l,unreadCount:c}=ll(),[f,p]=J.useState(!1),[m,h]=J.useState(""),[_,g]=J.useState(!1),[v,M]=J.useState(!1),b=J.useRef(null),C=J.useRef(null);J.useEffect(()=>{function O(I){b.current&&!b.current.contains(I.target)&&(g(!1),M(!1))}return document.addEventListener("mousedown",O),()=>document.removeEventListener("mousedown",O)},[]),J.useEffect(()=>{f&&C.current&&C.current.focus()},[f]);const y=O=>{O.key==="Enter"&&m.trim()&&(a(`/?search=${encodeURIComponent(m.trim())}`),p(!1),h(""))},x=()=>{l(),a("/login"),g(!1)};return Re.jsxs("header",{"code-path":"src\\components\\TopMenu.tsx:48:5",className:"shrink-0 h-14 glass-header z-40 flex items-center px-4 gap-3",children:[Re.jsx("div",{"code-path":"src\\components\\TopMenu.tsx:50:7",className:"flex-1 relative",children:Re.jsxs("div",{"code-path":"src\\components\\TopMenu.tsx:51:9",className:`flex items-center bg-[#F2F2F7] dark:bg-[#2C2C2E] rounded-xl h-10 px-3 transition-all ${f?"ring-2 ring-[#007AFF]":""}`,onClick:()=>p(!0),children:[Re.jsx(k3,{"code-path":"src\\components\\TopMenu.tsx:55:11",size:18,className:"text-[#8E8E93] shrink-0"}),Re.jsx("input",{"code-path":"src\\components\\TopMenu.tsx:56:11",ref:C,type:"text",placeholder:"Search posts...",value:m,onChange:O=>h(O.target.value),onKeyDown:y,onBlur:()=>{m||p(!1)},className:"bg-transparent border-none outline-none text-[15px] ml-2 w-full placeholder:text-[#8E8E93] text-[#1C1C1E] dark:text-white"})]})}),Re.jsx("button",{"code-path":"src\\components\\TopMenu.tsx:70:7",onClick:i,className:"w-9 h-9 flex items-center justify-center rounded-xl hover:bg-[#F2F2F7] dark:hover:bg-[#2C2C2E] transition-colors active:scale-95",children:e==="dark"?Re.jsx(K3,{"code-path":"src\\components\\TopMenu.tsx:74:29",size:20,className:"text-[#8E8E93]"}):Re.jsx(B3,{"code-path":"src\\components\\TopMenu.tsx:74:76",size:20,className:"text-[#8E8E93]"})}),Re.jsxs("button",{"code-path":"src\\components\\TopMenu.tsx:78:7",onClick:()=>a("/notifications"),className:"w-9 h-9 flex items-center justify-center rounded-xl hover:bg-[#F2F2F7] dark:hover:bg-[#2C2C2E] transition-colors active:scale-95 relative",children:[Re.jsx(v3,{"code-path":"src\\components\\TopMenu.tsx:82:9",size:20,className:"text-[#8E8E93]"}),c>0&&Re.jsx("span",{"code-path":"src\\components\\TopMenu.tsx:84:11",className:"absolute top-1 right-1 w-2.5 h-2.5 bg-[#FF3B30] rounded-full"})]}),Re.jsxs("div",{"code-path":"src\\components\\TopMenu.tsx:89:7",className:"relative",ref:b,children:[Re.jsx("button",{"code-path":"src\\components\\TopMenu.tsx:90:9",onClick:()=>g(!_),className:"w-9 h-9 flex items-center justify-center rounded-xl hover:bg-[#F2F2F7] dark:hover:bg-[#2C2C2E] transition-colors active:scale-95",children:Re.jsx(E3,{"code-path":"src\\components\\TopMenu.tsx:94:11",size:20,className:"text-[#8E8E93]"})}),_&&Re.jsxs("div",{"code-path":"src\\components\\TopMenu.tsx:98:11",className:"absolute right-0 top-12 w-52 bg-white dark:bg-[#2C2C2E] rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 py-2 z-50 fade-in",children:[Re.jsxs("button",{"code-path":"src\\components\\TopMenu.tsx:99:13",onClick:()=>{a("/profile"),g(!1)},className:"w-full flex items-center gap-3 px-4 py-2.5 text-[15px] text-[#1C1C1E] dark:text-white hover:bg-[#F2F2F7] dark:hover:bg-[#3A3A3C] transition-colors",children:[Re.jsx(Wx,{"code-path":"src\\components\\TopMenu.tsx:103:15",size:18,className:"text-[#8E8E93]"}),"Profile"]}),Re.jsxs("button",{"code-path":"src\\components\\TopMenu.tsx:106:13",onClick:()=>{a("/profile/edit"),g(!1)},className:"w-full flex items-center gap-3 px-4 py-2.5 text-[15px] text-[#1C1C1E] dark:text-white hover:bg-[#F2F2F7] dark:hover:bg-[#3A3A3C] transition-colors",children:[Re.jsx(W3,{"code-path":"src\\components\\TopMenu.tsx:110:15",size:18,className:"text-[#8E8E93]"}),"Settings"]}),Re.jsxs("div",{"code-path":"src\\components\\TopMenu.tsx:113:13",className:"relative",children:[Re.jsxs("button",{"code-path":"src\\components\\TopMenu.tsx:114:15",onClick:()=>M(!v),className:"w-full flex items-center gap-3 px-4 py-2.5 text-[15px] text-[#1C1C1E] dark:text-white hover:bg-[#F2F2F7] dark:hover:bg-[#3A3A3C] transition-colors",children:[Re.jsx(T3,{"code-path":"src\\components\\TopMenu.tsx:118:17",size:18,className:"text-[#8E8E93]"}),"Language"]}),v&&Re.jsx("div",{"code-path":"src\\components\\TopMenu.tsx:122:17",className:"absolute right-full top-0 mr-1 w-28 bg-white dark:bg-[#2C2C2E] rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 py-1",children:["en","ps","fa"].map(O=>Re.jsx("button",{"code-path":"src\\components\\TopMenu.tsx:124:21",onClick:()=>{ll.getState().setLanguage(O),M(!1),g(!1)},className:"w-full px-4 py-2 text-[14px] text-left text-[#1C1C1E] dark:text-white hover:bg-[#F2F2F7] dark:hover:bg-[#3A3A3C] uppercase",children:O},O))})]}),Re.jsxs("button",{"code-path":"src\\components\\TopMenu.tsx:135:13",onClick:()=>{g(!1)},className:"w-full flex items-center gap-3 px-4 py-2.5 text-[15px] text-[#1C1C1E] dark:text-white hover:bg-[#F2F2F7] dark:hover:bg-[#3A3A3C] transition-colors",children:[Re.jsx(y3,{"code-path":"src\\components\\TopMenu.tsx:139:15",size:18,className:"text-[#8E8E93]"}),"Support"]}),s?.isAdmin?Re.jsxs("button",{"code-path":"src\\components\\TopMenu.tsx:143:15",onClick:()=>{a("/admin"),g(!1)},className:"w-full flex items-center gap-3 px-4 py-2.5 text-[15px] text-[#007AFF] hover:bg-[#F2F2F7] dark:hover:bg-[#3A3A3C] transition-colors",children:[Re.jsx(Y3,{"code-path":"src\\components\\TopMenu.tsx:147:17",size:18,className:"text-[#007AFF]"}),"Admin Panel"]}):null,Re.jsx("div",{"code-path":"src\\components\\TopMenu.tsx:151:13",className:"border-t border-gray-200 dark:border-gray-700 mt-1 pt-1",children:Re.jsxs("button",{"code-path":"src\\components\\TopMenu.tsx:152:15",onClick:x,className:"w-full flex items-center gap-3 px-4 py-2.5 text-[15px] text-[#FF3B30] hover:bg-[#FFF5F5] dark:hover:bg-[#3A1A1A] transition-colors",children:[Re.jsx(L3,{"code-path":"src\\components\\TopMenu.tsx:156:17",size:18,className:"text-[#FF3B30]"}),"Logout"]})})]})]})]})}const nC=["/login","/signup","/chat/"],iC=["/login","/signup"];function aC(){const e=mi().pathname,i=nC.some(l=>e.startsWith(l)),s=iC.some(l=>e.startsWith(l));return Re.jsxs("div",{"code-path":"src\\components\\Layout.tsx:16:5",className:"h-full flex flex-col bg-background",children:[!s&&Re.jsx(tC,{"code-path":"src\\components\\Layout.tsx:17:30"}),Re.jsx("main",{"code-path":"src\\components\\Layout.tsx:18:7",className:"flex-1 overflow-y-auto no-scrollbar",children:Re.jsx(aE,{"code-path":"src\\components\\Layout.tsx:19:9"})}),!i&&Re.jsx(eC,{"code-path":"src\\components\\Layout.tsx:21:29"})]})}var rC=(a,e,i,s,l,c,f,p)=>{let m=document.documentElement,h=["light","dark"];function _(M){(Array.isArray(a)?a:[a]).forEach(b=>{let C=b==="class",y=C&&c?l.map(x=>c[x]||x):l;C?(m.classList.remove(...y),m.classList.add(c&&c[M]?c[M]:M)):m.setAttribute(b,M)}),g(M)}function g(M){p&&h.includes(M)&&(m.style.colorScheme=M)}function v(){return window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}if(s)_(s);else try{let M=localStorage.getItem(e)||i,b=f&&M==="system"?v():M;_(b)}catch{}},sC=J.createContext(void 0),oC={setTheme:a=>{},themes:[]},lC=()=>{var a;return(a=J.useContext(sC))!=null?a:oC};J.memo(({forcedTheme:a,storageKey:e,attribute:i,enableSystem:s,enableColorScheme:l,defaultTheme:c,value:f,themes:p,nonce:m,scriptProps:h})=>{let _=JSON.stringify([i,e,c,a,p,f,s,l]).slice(1,-1);return J.createElement("script",{...h,suppressHydrationWarning:!0,nonce:typeof window>"u"?m:"",dangerouslySetInnerHTML:{__html:`(${rC.toString()})(${_})`}})});function cC(a){if(typeof document>"u")return;let e=document.head||document.getElementsByTagName("head")[0],i=document.createElement("style");i.type="text/css",e.appendChild(i),i.styleSheet?i.styleSheet.cssText=a:i.appendChild(document.createTextNode(a))}const uC=a=>{switch(a){case"success":return hC;case"info":return mC;case"warning":return pC;case"error":return gC;default:return null}},fC=Array(12).fill(0),dC=({visible:a,className:e})=>Pe.createElement("div",{className:["sonner-loading-wrapper",e].filter(Boolean).join(" "),"data-visible":a},Pe.createElement("div",{className:"sonner-spinner"},fC.map((i,s)=>Pe.createElement("div",{className:"sonner-loading-bar",key:`spinner-bar-${s}`})))),hC=Pe.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20",fill:"currentColor",height:"20",width:"20"},Pe.createElement("path",{fillRule:"evenodd",d:"M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z",clipRule:"evenodd"})),pC=Pe.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor",height:"20",width:"20"},Pe.createElement("path",{fillRule:"evenodd",d:"M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z",clipRule:"evenodd"})),mC=Pe.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20",fill:"currentColor",height:"20",width:"20"},Pe.createElement("path",{fillRule:"evenodd",d:"M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z",clipRule:"evenodd"})),gC=Pe.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20",fill:"currentColor",height:"20",width:"20"},Pe.createElement("path",{fillRule:"evenodd",d:"M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-5a.75.75 0 01.75.75v4.5a.75.75 0 01-1.5 0v-4.5A.75.75 0 0110 5zm0 10a1 1 0 100-2 1 1 0 000 2z",clipRule:"evenodd"})),vC=Pe.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"},Pe.createElement("line",{x1:"18",y1:"6",x2:"6",y2:"18"}),Pe.createElement("line",{x1:"6",y1:"6",x2:"18",y2:"18"})),_C=()=>{const[a,e]=Pe.useState(document.hidden);return Pe.useEffect(()=>{const i=()=>{e(document.hidden)};return document.addEventListener("visibilitychange",i),()=>window.removeEventListener("visibilitychange",i)},[]),a};let dp=1;class xC{constructor(){this.subscribe=e=>(this.subscribers.push(e),()=>{const i=this.subscribers.indexOf(e);this.subscribers.splice(i,1)}),this.publish=e=>{this.subscribers.forEach(i=>i(e))},this.addToast=e=>{this.publish(e),this.toasts=[...this.toasts,e]},this.create=e=>{var i;const{message:s,...l}=e,c=typeof e?.id=="number"||((i=e.id)==null?void 0:i.length)>0?e.id:dp++,f=this.toasts.find(m=>m.id===c),p=e.dismissible===void 0?!0:e.dismissible;return this.dismissedToasts.has(c)&&this.dismissedToasts.delete(c),f?this.toasts=this.toasts.map(m=>m.id===c?(this.publish({...m,...e,id:c,title:s}),{...m,...e,id:c,dismissible:p,title:s}):m):this.addToast({title:s,...l,dismissible:p,id:c}),c},this.dismiss=e=>(e?(this.dismissedToasts.add(e),requestAnimationFrame(()=>this.subscribers.forEach(i=>i({id:e,dismiss:!0})))):this.toasts.forEach(i=>{this.subscribers.forEach(s=>s({id:i.id,dismiss:!0}))}),e),this.message=(e,i)=>this.create({...i,message:e}),this.error=(e,i)=>this.create({...i,message:e,type:"error"}),this.success=(e,i)=>this.create({...i,type:"success",message:e}),this.info=(e,i)=>this.create({...i,type:"info",message:e}),this.warning=(e,i)=>this.create({...i,type:"warning",message:e}),this.loading=(e,i)=>this.create({...i,type:"loading",message:e}),this.promise=(e,i)=>{if(!i)return;let s;i.loading!==void 0&&(s=this.create({...i,promise:e,type:"loading",message:i.loading,description:typeof i.description!="function"?i.description:void 0}));const l=Promise.resolve(e instanceof Function?e():e);let c=s!==void 0,f;const p=l.then(async h=>{if(f=["resolve",h],Pe.isValidElement(h))c=!1,this.create({id:s,type:"default",message:h});else if(yC(h)&&!h.ok){c=!1;const g=typeof i.error=="function"?await i.error(`HTTP error! status: ${h.status}`):i.error,v=typeof i.description=="function"?await i.description(`HTTP error! status: ${h.status}`):i.description,b=typeof g=="object"&&!Pe.isValidElement(g)?g:{message:g};this.create({id:s,type:"error",description:v,...b})}else if(h instanceof Error){c=!1;const g=typeof i.error=="function"?await i.error(h):i.error,v=typeof i.description=="function"?await i.description(h):i.description,b=typeof g=="object"&&!Pe.isValidElement(g)?g:{message:g};this.create({id:s,type:"error",description:v,...b})}else if(i.success!==void 0){c=!1;const g=typeof i.success=="function"?await i.success(h):i.success,v=typeof i.description=="function"?await i.description(h):i.description,b=typeof g=="object"&&!Pe.isValidElement(g)?g:{message:g};this.create({id:s,type:"success",description:v,...b})}}).catch(async h=>{if(f=["reject",h],i.error!==void 0){c=!1;const _=typeof i.error=="function"?await i.error(h):i.error,g=typeof i.description=="function"?await i.description(h):i.description,M=typeof _=="object"&&!Pe.isValidElement(_)?_:{message:_};this.create({id:s,type:"error",description:g,...M})}}).finally(()=>{c&&(this.dismiss(s),s=void 0),i.finally==null||i.finally.call(i)}),m=()=>new Promise((h,_)=>p.then(()=>f[0]==="reject"?_(f[1]):h(f[1])).catch(_));return typeof s!="string"&&typeof s!="number"?{unwrap:m}:Object.assign(s,{unwrap:m})},this.custom=(e,i)=>{const s=i?.id||dp++;return this.create({jsx:e(s),id:s,...i}),s},this.getActiveToasts=()=>this.toasts.filter(e=>!this.dismissedToasts.has(e.id)),this.subscribers=[],this.toasts=[],this.dismissedToasts=new Set}}const Jn=new xC,SC=(a,e)=>{const i=e?.id||dp++;return Jn.addToast({title:a,...e,id:i}),i},yC=a=>a&&typeof a=="object"&&"ok"in a&&typeof a.ok=="boolean"&&"status"in a&&typeof a.status=="number",MC=SC,EC=()=>Jn.toasts,bC=()=>Jn.getActiveToasts(),$C=Object.assign(MC,{success:Jn.success,info:Jn.info,warning:Jn.warning,error:Jn.error,custom:Jn.custom,message:Jn.message,promise:Jn.promise,dismiss:Jn.dismiss,loading:Jn.loading},{getHistory:EC,getToasts:bC});cC("[data-sonner-toaster][dir=ltr],html[dir=ltr]{--toast-icon-margin-start:-3px;--toast-icon-margin-end:4px;--toast-svg-margin-start:-1px;--toast-svg-margin-end:0px;--toast-button-margin-start:auto;--toast-button-margin-end:0;--toast-close-button-start:0;--toast-close-button-end:unset;--toast-close-button-transform:translate(-35%, -35%)}[data-sonner-toaster][dir=rtl],html[dir=rtl]{--toast-icon-margin-start:4px;--toast-icon-margin-end:-3px;--toast-svg-margin-start:0px;--toast-svg-margin-end:-1px;--toast-button-margin-start:0;--toast-button-margin-end:auto;--toast-close-button-start:unset;--toast-close-button-end:0;--toast-close-button-transform:translate(35%, -35%)}[data-sonner-toaster]{position:fixed;width:var(--width);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;--gray1:hsl(0, 0%, 99%);--gray2:hsl(0, 0%, 97.3%);--gray3:hsl(0, 0%, 95.1%);--gray4:hsl(0, 0%, 93%);--gray5:hsl(0, 0%, 90.9%);--gray6:hsl(0, 0%, 88.7%);--gray7:hsl(0, 0%, 85.8%);--gray8:hsl(0, 0%, 78%);--gray9:hsl(0, 0%, 56.1%);--gray10:hsl(0, 0%, 52.3%);--gray11:hsl(0, 0%, 43.5%);--gray12:hsl(0, 0%, 9%);--border-radius:8px;box-sizing:border-box;padding:0;margin:0;list-style:none;outline:0;z-index:999999999;transition:transform .4s ease}@media (hover:none) and (pointer:coarse){[data-sonner-toaster][data-lifted=true]{transform:none}}[data-sonner-toaster][data-x-position=right]{right:var(--offset-right)}[data-sonner-toaster][data-x-position=left]{left:var(--offset-left)}[data-sonner-toaster][data-x-position=center]{left:50%;transform:translateX(-50%)}[data-sonner-toaster][data-y-position=top]{top:var(--offset-top)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--offset-bottom)}[data-sonner-toast]{--y:translateY(100%);--lift-amount:calc(var(--lift) * var(--gap));z-index:var(--z-index);position:absolute;opacity:0;transform:var(--y);touch-action:none;transition:transform .4s,opacity .4s,height .4s,box-shadow .2s;box-sizing:border-box;outline:0;overflow-wrap:anywhere}[data-sonner-toast][data-styled=true]{padding:16px;background:var(--normal-bg);border:1px solid var(--normal-border);color:var(--normal-text);border-radius:var(--border-radius);box-shadow:0 4px 12px rgba(0,0,0,.1);width:var(--width);font-size:13px;display:flex;align-items:center;gap:6px}[data-sonner-toast]:focus-visible{box-shadow:0 4px 12px rgba(0,0,0,.1),0 0 0 2px rgba(0,0,0,.2)}[data-sonner-toast][data-y-position=top]{top:0;--y:translateY(-100%);--lift:1;--lift-amount:calc(1 * var(--gap))}[data-sonner-toast][data-y-position=bottom]{bottom:0;--y:translateY(100%);--lift:-1;--lift-amount:calc(var(--lift) * var(--gap))}[data-sonner-toast][data-styled=true] [data-description]{font-weight:400;line-height:1.4;color:#3f3f3f}[data-rich-colors=true][data-sonner-toast][data-styled=true] [data-description]{color:inherit}[data-sonner-toaster][data-sonner-theme=dark] [data-description]{color:#e8e8e8}[data-sonner-toast][data-styled=true] [data-title]{font-weight:500;line-height:1.5;color:inherit}[data-sonner-toast][data-styled=true] [data-icon]{display:flex;height:16px;width:16px;position:relative;justify-content:flex-start;align-items:center;flex-shrink:0;margin-left:var(--toast-icon-margin-start);margin-right:var(--toast-icon-margin-end)}[data-sonner-toast][data-promise=true] [data-icon]>svg{opacity:0;transform:scale(.8);transform-origin:center;animation:sonner-fade-in .3s ease forwards}[data-sonner-toast][data-styled=true] [data-icon]>*{flex-shrink:0}[data-sonner-toast][data-styled=true] [data-icon] svg{margin-left:var(--toast-svg-margin-start);margin-right:var(--toast-svg-margin-end)}[data-sonner-toast][data-styled=true] [data-content]{display:flex;flex-direction:column;gap:2px}[data-sonner-toast][data-styled=true] [data-button]{border-radius:4px;padding-left:8px;padding-right:8px;height:24px;font-size:12px;color:var(--normal-bg);background:var(--normal-text);margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end);border:none;font-weight:500;cursor:pointer;outline:0;display:flex;align-items:center;flex-shrink:0;transition:opacity .4s,box-shadow .2s}[data-sonner-toast][data-styled=true] [data-button]:focus-visible{box-shadow:0 0 0 2px rgba(0,0,0,.4)}[data-sonner-toast][data-styled=true] [data-button]:first-of-type{margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end)}[data-sonner-toast][data-styled=true] [data-cancel]{color:var(--normal-text);background:rgba(0,0,0,.08)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast][data-styled=true] [data-cancel]{background:rgba(255,255,255,.3)}[data-sonner-toast][data-styled=true] [data-close-button]{position:absolute;left:var(--toast-close-button-start);right:var(--toast-close-button-end);top:0;height:20px;width:20px;display:flex;justify-content:center;align-items:center;padding:0;color:var(--gray12);background:var(--normal-bg);border:1px solid var(--gray4);transform:var(--toast-close-button-transform);border-radius:50%;cursor:pointer;z-index:1;transition:opacity .1s,background .2s,border-color .2s}[data-sonner-toast][data-styled=true] [data-close-button]:focus-visible{box-shadow:0 4px 12px rgba(0,0,0,.1),0 0 0 2px rgba(0,0,0,.2)}[data-sonner-toast][data-styled=true] [data-disabled=true]{cursor:not-allowed}[data-sonner-toast][data-styled=true]:hover [data-close-button]:hover{background:var(--gray2);border-color:var(--gray5)}[data-sonner-toast][data-swiping=true]::before{content:'';position:absolute;left:-100%;right:-100%;height:100%;z-index:-1}[data-sonner-toast][data-y-position=top][data-swiping=true]::before{bottom:50%;transform:scaleY(3) translateY(50%)}[data-sonner-toast][data-y-position=bottom][data-swiping=true]::before{top:50%;transform:scaleY(3) translateY(-50%)}[data-sonner-toast][data-swiping=false][data-removed=true]::before{content:'';position:absolute;inset:0;transform:scaleY(2)}[data-sonner-toast][data-expanded=true]::after{content:'';position:absolute;left:0;height:calc(var(--gap) + 1px);bottom:100%;width:100%}[data-sonner-toast][data-mounted=true]{--y:translateY(0);opacity:1}[data-sonner-toast][data-expanded=false][data-front=false]{--scale:var(--toasts-before) * 0.05 + 1;--y:translateY(calc(var(--lift-amount) * var(--toasts-before))) scale(calc(-1 * var(--scale)));height:var(--front-toast-height)}[data-sonner-toast]>*{transition:opacity .4s}[data-sonner-toast][data-x-position=right]{right:0}[data-sonner-toast][data-x-position=left]{left:0}[data-sonner-toast][data-expanded=false][data-front=false][data-styled=true]>*{opacity:0}[data-sonner-toast][data-visible=false]{opacity:0;pointer-events:none}[data-sonner-toast][data-mounted=true][data-expanded=true]{--y:translateY(calc(var(--lift) * var(--offset)));height:var(--initial-height)}[data-sonner-toast][data-removed=true][data-front=true][data-swipe-out=false]{--y:translateY(calc(var(--lift) * -100%));opacity:0}[data-sonner-toast][data-removed=true][data-front=false][data-swipe-out=false][data-expanded=true]{--y:translateY(calc(var(--lift) * var(--offset) + var(--lift) * -100%));opacity:0}[data-sonner-toast][data-removed=true][data-front=false][data-swipe-out=false][data-expanded=false]{--y:translateY(40%);opacity:0;transition:transform .5s,opacity .2s}[data-sonner-toast][data-removed=true][data-front=false]::before{height:calc(var(--initial-height) + 20%)}[data-sonner-toast][data-swiping=true]{transform:var(--y) translateY(var(--swipe-amount-y,0)) translateX(var(--swipe-amount-x,0));transition:none}[data-sonner-toast][data-swiped=true]{user-select:none}[data-sonner-toast][data-swipe-out=true][data-y-position=bottom],[data-sonner-toast][data-swipe-out=true][data-y-position=top]{animation-duration:.2s;animation-timing-function:ease-out;animation-fill-mode:forwards}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=left]{animation-name:swipe-out-left}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=right]{animation-name:swipe-out-right}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=up]{animation-name:swipe-out-up}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=down]{animation-name:swipe-out-down}@keyframes swipe-out-left{from{transform:var(--y) translateX(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translateX(calc(var(--swipe-amount-x) - 100%));opacity:0}}@keyframes swipe-out-right{from{transform:var(--y) translateX(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translateX(calc(var(--swipe-amount-x) + 100%));opacity:0}}@keyframes swipe-out-up{from{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) - 100%));opacity:0}}@keyframes swipe-out-down{from{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) + 100%));opacity:0}}@media (max-width:600px){[data-sonner-toaster]{position:fixed;right:var(--mobile-offset-right);left:var(--mobile-offset-left);width:100%}[data-sonner-toaster][dir=rtl]{left:calc(var(--mobile-offset-left) * -1)}[data-sonner-toaster] [data-sonner-toast]{left:0;right:0;width:calc(100% - var(--mobile-offset-left) * 2)}[data-sonner-toaster][data-x-position=left]{left:var(--mobile-offset-left)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--mobile-offset-bottom)}[data-sonner-toaster][data-y-position=top]{top:var(--mobile-offset-top)}[data-sonner-toaster][data-x-position=center]{left:var(--mobile-offset-left);right:var(--mobile-offset-right);transform:none}}[data-sonner-toaster][data-sonner-theme=light]{--normal-bg:#fff;--normal-border:var(--gray4);--normal-text:var(--gray12);--success-bg:hsl(143, 85%, 96%);--success-border:hsl(145, 92%, 87%);--success-text:hsl(140, 100%, 27%);--info-bg:hsl(208, 100%, 97%);--info-border:hsl(221, 91%, 93%);--info-text:hsl(210, 92%, 45%);--warning-bg:hsl(49, 100%, 97%);--warning-border:hsl(49, 91%, 84%);--warning-text:hsl(31, 92%, 45%);--error-bg:hsl(359, 100%, 97%);--error-border:hsl(359, 100%, 94%);--error-text:hsl(360, 100%, 45%)}[data-sonner-toaster][data-sonner-theme=light] [data-sonner-toast][data-invert=true]{--normal-bg:#000;--normal-border:hsl(0, 0%, 20%);--normal-text:var(--gray1)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast][data-invert=true]{--normal-bg:#fff;--normal-border:var(--gray3);--normal-text:var(--gray12)}[data-sonner-toaster][data-sonner-theme=dark]{--normal-bg:#000;--normal-bg-hover:hsl(0, 0%, 12%);--normal-border:hsl(0, 0%, 20%);--normal-border-hover:hsl(0, 0%, 25%);--normal-text:var(--gray1);--success-bg:hsl(150, 100%, 6%);--success-border:hsl(147, 100%, 12%);--success-text:hsl(150, 86%, 65%);--info-bg:hsl(215, 100%, 6%);--info-border:hsl(223, 43%, 17%);--info-text:hsl(216, 87%, 65%);--warning-bg:hsl(64, 100%, 6%);--warning-border:hsl(60, 100%, 9%);--warning-text:hsl(46, 87%, 65%);--error-bg:hsl(358, 76%, 10%);--error-border:hsl(357, 89%, 16%);--error-text:hsl(358, 100%, 81%)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast] [data-close-button]{background:var(--normal-bg);border-color:var(--normal-border);color:var(--normal-text)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast] [data-close-button]:hover{background:var(--normal-bg-hover);border-color:var(--normal-border-hover)}[data-rich-colors=true][data-sonner-toast][data-type=success]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=success] [data-close-button]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=info]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=info] [data-close-button]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning] [data-close-button]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=error]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}[data-rich-colors=true][data-sonner-toast][data-type=error] [data-close-button]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}.sonner-loading-wrapper{--size:16px;height:var(--size);width:var(--size);position:absolute;inset:0;z-index:10}.sonner-loading-wrapper[data-visible=false]{transform-origin:center;animation:sonner-fade-out .2s ease forwards}.sonner-spinner{position:relative;top:50%;left:50%;height:var(--size);width:var(--size)}.sonner-loading-bar{animation:sonner-spin 1.2s linear infinite;background:var(--gray11);border-radius:6px;height:8%;left:-10%;position:absolute;top:-3.9%;width:24%}.sonner-loading-bar:first-child{animation-delay:-1.2s;transform:rotate(.0001deg) translate(146%)}.sonner-loading-bar:nth-child(2){animation-delay:-1.1s;transform:rotate(30deg) translate(146%)}.sonner-loading-bar:nth-child(3){animation-delay:-1s;transform:rotate(60deg) translate(146%)}.sonner-loading-bar:nth-child(4){animation-delay:-.9s;transform:rotate(90deg) translate(146%)}.sonner-loading-bar:nth-child(5){animation-delay:-.8s;transform:rotate(120deg) translate(146%)}.sonner-loading-bar:nth-child(6){animation-delay:-.7s;transform:rotate(150deg) translate(146%)}.sonner-loading-bar:nth-child(7){animation-delay:-.6s;transform:rotate(180deg) translate(146%)}.sonner-loading-bar:nth-child(8){animation-delay:-.5s;transform:rotate(210deg) translate(146%)}.sonner-loading-bar:nth-child(9){animation-delay:-.4s;transform:rotate(240deg) translate(146%)}.sonner-loading-bar:nth-child(10){animation-delay:-.3s;transform:rotate(270deg) translate(146%)}.sonner-loading-bar:nth-child(11){animation-delay:-.2s;transform:rotate(300deg) translate(146%)}.sonner-loading-bar:nth-child(12){animation-delay:-.1s;transform:rotate(330deg) translate(146%)}@keyframes sonner-fade-in{0%{opacity:0;transform:scale(.8)}100%{opacity:1;transform:scale(1)}}@keyframes sonner-fade-out{0%{opacity:1;transform:scale(1)}100%{opacity:0;transform:scale(.8)}}@keyframes sonner-spin{0%{opacity:1}100%{opacity:.15}}@media (prefers-reduced-motion){.sonner-loading-bar,[data-sonner-toast],[data-sonner-toast]>*{transition:none!important;animation:none!important}}.sonner-loader{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);transform-origin:center;transition:opacity .2s,transform .2s}.sonner-loader[data-visible=false]{opacity:0;transform:scale(.8) translate(-50%,-50%)}");function $c(a){return a.label!==void 0}const TC=3,AC="24px",RC="16px",B_=4e3,CC=356,wC=14,DC=45,UC=200;function ji(...a){return a.filter(Boolean).join(" ")}function NC(a){const[e,i]=a.split("-"),s=[];return e&&s.push(e),i&&s.push(i),s}const LC=a=>{var e,i,s,l,c,f,p,m,h;const{invert:_,toast:g,unstyled:v,interacting:M,setHeights:b,visibleToasts:C,heights:y,index:x,toasts:O,expanded:I,removeToast:w,defaultRichColors:B,closeButton:U,style:F,cancelButtonStyle:T,actionButtonStyle:P,className:q="",descriptionClassName:V="",duration:Q,position:fe,gap:me,expandByDefault:j,classNames:L,icons:H,closeButtonAriaLabel:$="Close toast"}=a,[_e,be]=Pe.useState(null),[N,Y]=Pe.useState(null),[de,Te]=Pe.useState(!1),[Ce,ee]=Pe.useState(!1),[Me,ve]=Pe.useState(!1),[He,nt]=Pe.useState(!1),[je,Dt]=Pe.useState(!1),[ut,pt]=Pe.useState(0),[mt,dt]=Pe.useState(0),qt=Pe.useRef(g.duration||Q||B_),$t=Pe.useRef(null),Ut=Pe.useRef(null),cn=x===0,Yt=x+1<=C,St=g.type,X=g.dismissible!==!1,Bt=g.className||"",Ct=g.descriptionClassName||"",D=Pe.useMemo(()=>y.findIndex(te=>te.toastId===g.id)||0,[y,g.id]),E=Pe.useMemo(()=>{var te;return(te=g.closeButton)!=null?te:U},[g.closeButton,U]),K=Pe.useMemo(()=>g.duration||Q||B_,[g.duration,Q]),se=Pe.useRef(0),he=Pe.useRef(0),De=Pe.useRef(0),Le=Pe.useRef(null),[pe,ge]=fe.split("-"),Ne=Pe.useMemo(()=>y.reduce((te,Ae,we)=>we>=D?te:te+Ae.height,0),[y,D]),Ve=_C(),Be=g.invert||_,Ie=St==="loading";he.current=Pe.useMemo(()=>D*me+Ne,[D,Ne]),Pe.useEffect(()=>{qt.current=K},[K]),Pe.useEffect(()=>{Te(!0)},[]),Pe.useEffect(()=>{const te=Ut.current;if(te){const Ae=te.getBoundingClientRect().height;return dt(Ae),b(we=>[{toastId:g.id,height:Ae,position:g.position},...we]),()=>b(we=>we.filter(Se=>Se.toastId!==g.id))}},[b,g.id]),Pe.useLayoutEffect(()=>{if(!de)return;const te=Ut.current,Ae=te.style.height;te.style.height="auto";const we=te.getBoundingClientRect().height;te.style.height=Ae,dt(we),b(Se=>Se.find(Oe=>Oe.toastId===g.id)?Se.map(Oe=>Oe.toastId===g.id?{...Oe,height:we}:Oe):[{toastId:g.id,height:we,position:g.position},...Se])},[de,g.title,g.description,b,g.id,g.jsx,g.action,g.cancel]);const Ye=Pe.useCallback(()=>{ee(!0),pt(he.current),b(te=>te.filter(Ae=>Ae.toastId!==g.id)),setTimeout(()=>{w(g)},UC)},[g,w,b,he]);Pe.useEffect(()=>{if(g.promise&&St==="loading"||g.duration===1/0||g.type==="loading")return;let te;return I||M||Ve?(()=>{if(De.current<se.current){const Se=new Date().getTime()-se.current;qt.current=qt.current-Se}De.current=new Date().getTime()})():qt.current!==1/0&&(se.current=new Date().getTime(),te=setTimeout(()=>{g.onAutoClose==null||g.onAutoClose.call(g,g),Ye()},qt.current)),()=>clearTimeout(te)},[I,M,g,St,Ve,Ye]),Pe.useEffect(()=>{g.delete&&(Ye(),g.onDismiss==null||g.onDismiss.call(g,g))},[Ye,g.delete]);function $e(){var te;if(H?.loading){var Ae;return Pe.createElement("div",{className:ji(L?.loader,g==null||(Ae=g.classNames)==null?void 0:Ae.loader,"sonner-loader"),"data-visible":St==="loading"},H.loading)}return Pe.createElement(dC,{className:ji(L?.loader,g==null||(te=g.classNames)==null?void 0:te.loader),visible:St==="loading"})}const at=g.icon||H?.[St]||uC(St);var k,Ue;return Pe.createElement("li",{tabIndex:0,ref:Ut,className:ji(q,Bt,L?.toast,g==null||(e=g.classNames)==null?void 0:e.toast,L?.default,L?.[St],g==null||(i=g.classNames)==null?void 0:i[St]),"data-sonner-toast":"","data-rich-colors":(k=g.richColors)!=null?k:B,"data-styled":!(g.jsx||g.unstyled||v),"data-mounted":de,"data-promise":!!g.promise,"data-swiped":je,"data-removed":Ce,"data-visible":Yt,"data-y-position":pe,"data-x-position":ge,"data-index":x,"data-front":cn,"data-swiping":Me,"data-dismissible":X,"data-type":St,"data-invert":Be,"data-swipe-out":He,"data-swipe-direction":N,"data-expanded":!!(I||j&&de),"data-testid":g.testId,style:{"--index":x,"--toasts-before":x,"--z-index":O.length-x,"--offset":`${Ce?ut:he.current}px`,"--initial-height":j?"auto":`${mt}px`,...F,...g.style},onDragEnd:()=>{ve(!1),be(null),Le.current=null},onPointerDown:te=>{te.button!==2&&(Ie||!X||($t.current=new Date,pt(he.current),te.target.setPointerCapture(te.pointerId),te.target.tagName!=="BUTTON"&&(ve(!0),Le.current={x:te.clientX,y:te.clientY})))},onPointerUp:()=>{var te,Ae,we;if(He||!X)return;Le.current=null;const Se=Number(((te=Ut.current)==null?void 0:te.style.getPropertyValue("--swipe-amount-x").replace("px",""))||0),We=Number(((Ae=Ut.current)==null?void 0:Ae.style.getPropertyValue("--swipe-amount-y").replace("px",""))||0),Oe=new Date().getTime()-((we=$t.current)==null?void 0:we.getTime()),gt=_e==="x"?Se:We,Rt=Math.abs(gt)/Oe;if(Math.abs(gt)>=DC||Rt>.11){pt(he.current),g.onDismiss==null||g.onDismiss.call(g,g),Y(_e==="x"?Se>0?"right":"left":We>0?"down":"up"),Ye(),nt(!0);return}else{var en,tn;(en=Ut.current)==null||en.style.setProperty("--swipe-amount-x","0px"),(tn=Ut.current)==null||tn.style.setProperty("--swipe-amount-y","0px")}Dt(!1),ve(!1),be(null)},onPointerMove:te=>{var Ae,we,Se;if(!Le.current||!X||((Ae=window.getSelection())==null?void 0:Ae.toString().length)>0)return;const Oe=te.clientY-Le.current.y,gt=te.clientX-Le.current.x;var Rt;const en=(Rt=a.swipeDirections)!=null?Rt:NC(fe);!_e&&(Math.abs(gt)>1||Math.abs(Oe)>1)&&be(Math.abs(gt)>Math.abs(Oe)?"x":"y");let tn={x:0,y:0};const Ha=ei=>1/(1.5+Math.abs(ei)/20);if(_e==="y"){if(en.includes("top")||en.includes("bottom"))if(en.includes("top")&&Oe<0||en.includes("bottom")&&Oe>0)tn.y=Oe;else{const ei=Oe*Ha(Oe);tn.y=Math.abs(ei)<Math.abs(Oe)?ei:Oe}}else if(_e==="x"&&(en.includes("left")||en.includes("right")))if(en.includes("left")&&gt<0||en.includes("right")&&gt>0)tn.x=gt;else{const ei=gt*Ha(gt);tn.x=Math.abs(ei)<Math.abs(gt)?ei:gt}(Math.abs(tn.x)>0||Math.abs(tn.y)>0)&&Dt(!0),(we=Ut.current)==null||we.style.setProperty("--swipe-amount-x",`${tn.x}px`),(Se=Ut.current)==null||Se.style.setProperty("--swipe-amount-y",`${tn.y}px`)}},E&&!g.jsx&&St!=="loading"?Pe.createElement("button",{"aria-label":$,"data-disabled":Ie,"data-close-button":!0,onClick:Ie||!X?()=>{}:()=>{Ye(),g.onDismiss==null||g.onDismiss.call(g,g)},className:ji(L?.closeButton,g==null||(s=g.classNames)==null?void 0:s.closeButton)},(Ue=H?.close)!=null?Ue:vC):null,(St||g.icon||g.promise)&&g.icon!==null&&(H?.[St]!==null||g.icon)?Pe.createElement("div",{"data-icon":"",className:ji(L?.icon,g==null||(l=g.classNames)==null?void 0:l.icon)},g.promise||g.type==="loading"&&!g.icon?g.icon||$e():null,g.type!=="loading"?at:null):null,Pe.createElement("div",{"data-content":"",className:ji(L?.content,g==null||(c=g.classNames)==null?void 0:c.content)},Pe.createElement("div",{"data-title":"",className:ji(L?.title,g==null||(f=g.classNames)==null?void 0:f.title)},g.jsx?g.jsx:typeof g.title=="function"?g.title():g.title),g.description?Pe.createElement("div",{"data-description":"",className:ji(V,Ct,L?.description,g==null||(p=g.classNames)==null?void 0:p.description)},typeof g.description=="function"?g.description():g.description):null),Pe.isValidElement(g.cancel)?g.cancel:g.cancel&&$c(g.cancel)?Pe.createElement("button",{"data-button":!0,"data-cancel":!0,style:g.cancelButtonStyle||T,onClick:te=>{$c(g.cancel)&&X&&(g.cancel.onClick==null||g.cancel.onClick.call(g.cancel,te),Ye())},className:ji(L?.cancelButton,g==null||(m=g.classNames)==null?void 0:m.cancelButton)},g.cancel.label):null,Pe.isValidElement(g.action)?g.action:g.action&&$c(g.action)?Pe.createElement("button",{"data-button":!0,"data-action":!0,style:g.actionButtonStyle||P,onClick:te=>{$c(g.action)&&(g.action.onClick==null||g.action.onClick.call(g.action,te),!te.defaultPrevented&&Ye())},className:ji(L?.actionButton,g==null||(h=g.classNames)==null?void 0:h.actionButton)},g.action.label):null)};function F_(){if(typeof window>"u"||typeof document>"u")return"ltr";const a=document.documentElement.getAttribute("dir");return a==="auto"||!a?window.getComputedStyle(document.documentElement).direction:a}function OC(a,e){const i={};return[a,e].forEach((s,l)=>{const c=l===1,f=c?"--mobile-offset":"--offset",p=c?RC:AC;function m(h){["top","right","bottom","left"].forEach(_=>{i[`${f}-${_}`]=typeof h=="number"?`${h}px`:h})}typeof s=="number"||typeof s=="string"?m(s):typeof s=="object"?["top","right","bottom","left"].forEach(h=>{s[h]===void 0?i[`${f}-${h}`]=p:i[`${f}-${h}`]=typeof s[h]=="number"?`${s[h]}px`:s[h]}):m(p)}),i}const PC=Pe.forwardRef(function(e,i){const{id:s,invert:l,position:c="bottom-right",hotkey:f=["altKey","KeyT"],expand:p,closeButton:m,className:h,offset:_,mobileOffset:g,theme:v="light",richColors:M,duration:b,style:C,visibleToasts:y=TC,toastOptions:x,dir:O=F_(),gap:I=wC,icons:w,containerAriaLabel:B="Notifications"}=e,[U,F]=Pe.useState([]),T=Pe.useMemo(()=>s?U.filter(de=>de.toasterId===s):U.filter(de=>!de.toasterId),[U,s]),P=Pe.useMemo(()=>Array.from(new Set([c].concat(T.filter(de=>de.position).map(de=>de.position)))),[T,c]),[q,V]=Pe.useState([]),[Q,fe]=Pe.useState(!1),[me,j]=Pe.useState(!1),[L,H]=Pe.useState(v!=="system"?v:typeof window<"u"&&window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"),$=Pe.useRef(null),_e=f.join("+").replace(/Key/g,"").replace(/Digit/g,""),be=Pe.useRef(null),N=Pe.useRef(!1),Y=Pe.useCallback(de=>{F(Te=>{var Ce;return(Ce=Te.find(ee=>ee.id===de.id))!=null&&Ce.delete||Jn.dismiss(de.id),Te.filter(({id:ee})=>ee!==de.id)})},[]);return Pe.useEffect(()=>Jn.subscribe(de=>{if(de.dismiss){requestAnimationFrame(()=>{F(Te=>Te.map(Ce=>Ce.id===de.id?{...Ce,delete:!0}:Ce))});return}setTimeout(()=>{VE.flushSync(()=>{F(Te=>{const Ce=Te.findIndex(ee=>ee.id===de.id);return Ce!==-1?[...Te.slice(0,Ce),{...Te[Ce],...de},...Te.slice(Ce+1)]:[de,...Te]})})})}),[U]),Pe.useEffect(()=>{if(v!=="system"){H(v);return}if(v==="system"&&(window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches?H("dark"):H("light")),typeof window>"u")return;const de=window.matchMedia("(prefers-color-scheme: dark)");try{de.addEventListener("change",({matches:Te})=>{H(Te?"dark":"light")})}catch{de.addListener(({matches:Ce})=>{try{H(Ce?"dark":"light")}catch(ee){console.error(ee)}})}},[v]),Pe.useEffect(()=>{U.length<=1&&fe(!1)},[U]),Pe.useEffect(()=>{const de=Te=>{var Ce;if(f.every(ve=>Te[ve]||Te.code===ve)){var Me;fe(!0),(Me=$.current)==null||Me.focus()}Te.code==="Escape"&&(document.activeElement===$.current||(Ce=$.current)!=null&&Ce.contains(document.activeElement))&&fe(!1)};return document.addEventListener("keydown",de),()=>document.removeEventListener("keydown",de)},[f]),Pe.useEffect(()=>{if($.current)return()=>{be.current&&(be.current.focus({preventScroll:!0}),be.current=null,N.current=!1)}},[$.current]),Pe.createElement("section",{ref:i,"aria-label":`${B} ${_e}`,tabIndex:-1,"aria-live":"polite","aria-relevant":"additions text","aria-atomic":"false",suppressHydrationWarning:!0},P.map((de,Te)=>{var Ce;const[ee,Me]=de.split("-");return T.length?Pe.createElement("ol",{key:de,dir:O==="auto"?F_():O,tabIndex:-1,ref:$,className:h,"data-sonner-toaster":!0,"data-sonner-theme":L,"data-y-position":ee,"data-x-position":Me,style:{"--front-toast-height":`${((Ce=q[0])==null?void 0:Ce.height)||0}px`,"--width":`${CC}px`,"--gap":`${I}px`,...C,...OC(_,g)},onBlur:ve=>{N.current&&!ve.currentTarget.contains(ve.relatedTarget)&&(N.current=!1,be.current&&(be.current.focus({preventScroll:!0}),be.current=null))},onFocus:ve=>{ve.target instanceof HTMLElement&&ve.target.dataset.dismissible==="false"||N.current||(N.current=!0,be.current=ve.relatedTarget)},onMouseEnter:()=>fe(!0),onMouseMove:()=>fe(!0),onMouseLeave:()=>{me||fe(!1)},onDragEnd:()=>fe(!1),onPointerDown:ve=>{ve.target instanceof HTMLElement&&ve.target.dataset.dismissible==="false"||j(!0)},onPointerUp:()=>j(!1)},T.filter(ve=>!ve.position&&Te===0||ve.position===de).map((ve,He)=>{var nt,je;return Pe.createElement(LC,{key:ve.id,icons:w,index:He,toast:ve,defaultRichColors:M,duration:(nt=x?.duration)!=null?nt:b,className:x?.className,descriptionClassName:x?.descriptionClassName,invert:l,visibleToasts:y,closeButton:(je=x?.closeButton)!=null?je:m,interacting:me,position:de,style:x?.style,unstyled:x?.unstyled,classNames:x?.classNames,cancelButtonStyle:x?.cancelButtonStyle,actionButtonStyle:x?.actionButtonStyle,closeButtonAriaLabel:x?.closeButtonAriaLabel,removeToast:Y,toasts:T.filter(Dt=>Dt.position==ve.position),heights:q.filter(Dt=>Dt.position==ve.position),setHeights:V,expandByDefault:p,gap:I,expanded:Q,swipeDirections:e.swipeDirections})})):null}))}),IC=({...a})=>{const{theme:e="system"}=lC();return Re.jsx(PC,{"code-path":"src\\components\\ui\\sonner.tsx:15:5",theme:e,className:"toaster group",icons:{success:Re.jsx(x3,{"code-path":"src\\components\\ui\\sonner.tsx:19:18",className:"size-4"}),info:Re.jsx(w3,{"code-path":"src\\components\\ui\\sonner.tsx:20:15",className:"size-4"}),warning:Re.jsx(j3,{"code-path":"src\\components\\ui\\sonner.tsx:21:18",className:"size-4"}),error:Re.jsx(z3,{"code-path":"src\\components\\ui\\sonner.tsx:22:16",className:"size-4"}),loading:Re.jsx(U3,{"code-path":"src\\components\\ui\\sonner.tsx:23:18",className:"size-4 animate-spin"})},style:{"--normal-bg":"var(--popover)","--normal-text":"var(--popover-foreground)","--normal-border":"var(--border)","--border-radius":"var(--radius)"},...a})},BC=J.lazy(()=>Vi(()=>import("./Home-BZptX8n4.js"),__vite__mapDeps([0,1,2,3,4,5,6]))),FC=J.lazy(()=>Vi(()=>import("./PostDetail-BR0NYSqd.js"),__vite__mapDeps([7,1,5,8,2,3,4]))),zC=J.lazy(()=>Vi(()=>import("./CreatePost-B7lxCjPi.js"),__vite__mapDeps([9,10,11]))),HC=J.lazy(()=>Vi(()=>import("./Profile-BzWEA-7b.js"),__vite__mapDeps([12,13,6]))),GC=J.lazy(()=>Vi(()=>import("./ProfileEdit-DFF5X6tV.js"),__vite__mapDeps([14,5]))),VC=J.lazy(()=>Vi(()=>import("./Messages-BvUg67lJ.js"),__vite__mapDeps([15,5,16]))),kC=J.lazy(()=>Vi(()=>import("./Chat-TVdsD_dG.js"),__vite__mapDeps([17,5]))),XC=J.lazy(()=>Vi(()=>import("./Notifications-B91uSy1P.js"),__vite__mapDeps([18,5,13,19,8,16,2]))),WC=J.lazy(()=>Vi(()=>import("./Admin-bwQPas81.js"),__vite__mapDeps([20,5,8,19]))),qC=J.lazy(()=>Vi(()=>import("./Login-BpMacnxv.js"),__vite__mapDeps([21,22,10,3]))),YC=J.lazy(()=>Vi(()=>import("./Signup-Cp5F891r.js"),__vite__mapDeps([23,22,4,10,3,11])));function ZC({children:a}){const{login:e,logout:i,theme:s,setTheme:l}=ll();return J.useEffect(()=>{const c=localStorage.getItem("token");c&&Bv.me().then(m=>{e(c,m)}).catch(()=>{i()});const f=localStorage.getItem("theme");f?l(f):window.matchMedia("(prefers-color-scheme: dark)").matches&&l("dark");const p=setInterval(()=>{Bv.heartbeat().catch(()=>{})},3e4);return()=>clearInterval(p)},[]),J.useEffect(()=>{document.documentElement.classList.toggle("dark",s==="dark")},[s]),Re.jsx(Re.Fragment,{children:a})}function KC(){const{isAuthenticated:a,user:e}=ll();return Re.jsxs(sE,{"code-path":"src\\App.tsx:65:5",children:[Re.jsxs(di,{"code-path":"src\\App.tsx:66:7",element:Re.jsx(aC,{"code-path":"src\\App.tsx:66:23"}),children:[Re.jsx(di,{"code-path":"src\\App.tsx:67:9",path:"/",element:Re.jsx(BC,{"code-path":"src\\App.tsx:67:34"})}),Re.jsx(di,{"code-path":"src\\App.tsx:68:9",path:"/post/:id",element:Re.jsx(FC,{"code-path":"src\\App.tsx:68:42"})}),Re.jsx(di,{"code-path":"src\\App.tsx:69:9",path:"/create-post",element:a?Re.jsx(zC,{"code-path":"src\\App.tsx:70:29"}):Re.jsx(Ta,{"code-path":"src\\App.tsx:70:46",to:"/login"})}),Re.jsx(di,{"code-path":"src\\App.tsx:72:9",path:"/profile",element:a?Re.jsx(HC,{"code-path":"src\\App.tsx:73:29"}):Re.jsx(Ta,{"code-path":"src\\App.tsx:73:43",to:"/login"})}),Re.jsx(di,{"code-path":"src\\App.tsx:75:9",path:"/profile/edit",element:a?Re.jsx(GC,{"code-path":"src\\App.tsx:76:29"}):Re.jsx(Ta,{"code-path":"src\\App.tsx:76:47",to:"/login"})}),Re.jsx(di,{"code-path":"src\\App.tsx:78:9",path:"/messages",element:a?Re.jsx(VC,{"code-path":"src\\App.tsx:79:29"}):Re.jsx(Ta,{"code-path":"src\\App.tsx:79:44",to:"/login"})}),Re.jsx(di,{"code-path":"src\\App.tsx:81:9",path:"/chat/:conversationId",element:a?Re.jsx(kC,{"code-path":"src\\App.tsx:82:29"}):Re.jsx(Ta,{"code-path":"src\\App.tsx:82:40",to:"/login"})}),Re.jsx(di,{"code-path":"src\\App.tsx:84:9",path:"/notifications",element:a?Re.jsx(XC,{"code-path":"src\\App.tsx:85:29"}):Re.jsx(Ta,{"code-path":"src\\App.tsx:85:49",to:"/login"})}),Re.jsx(di,{"code-path":"src\\App.tsx:87:9",path:"/admin",element:a&&e?.isAdmin?Re.jsx(WC,{"code-path":"src\\App.tsx:88:46"}):Re.jsx(Ta,{"code-path":"src\\App.tsx:88:58",to:"/"})})]}),Re.jsx(di,{"code-path":"src\\App.tsx:91:7",path:"/login",element:a?Re.jsx(Ta,{"code-path":"src\\App.tsx:92:27",to:"/"}):Re.jsx(qC,{"code-path":"src\\App.tsx:92:49"})}),Re.jsx(di,{"code-path":"src\\App.tsx:94:7",path:"/signup",element:a?Re.jsx(Ta,{"code-path":"src\\App.tsx:95:27",to:"/"}):Re.jsx(YC,{"code-path":"src\\App.tsx:95:49"})})]})}function QC(){const[a,e]=J.useState(!0);return Re.jsx(UE,{"code-path":"src\\App.tsx:105:5",children:Re.jsxs(ZC,{"code-path":"src\\App.tsx:106:7",children:[a?Re.jsx(u3,{"code-path":"src\\App.tsx:108:11",onComplete:()=>e(!1)}):Re.jsx(J.Suspense,{"code-path":"src\\App.tsx:110:11",fallback:Re.jsx("div",{"code-path":"src\\App.tsx:111:13",className:"min-h-screen bg-background flex items-center justify-center",children:Re.jsx("div",{"code-path":"src\\App.tsx:112:15",className:"animate-pulse text-brand-blue text-lg font-semibold",children:"Kabul Bazar"})}),children:Re.jsx(KC,{"code-path":"src\\App.tsx:115:13"})}),Re.jsx(IC,{"code-path":"src\\App.tsx:118:9",position:"top-center"})]})})}nM.createRoot(document.getElementById("root")).render(Re.jsx(QC,{"code-path":"src\\main.tsx:5:53"}));export{v3 as B,y3 as C,E3 as E,L3 as L,P3 as M,W3 as S,Wx as U,ll as a,Bv as b,Rn as c,JC as d,jC as e,Y3 as f,mi as g,Re as j,J as r,$C as t,dl as u};
